import { spawn } from 'child_process';
import http from 'http';
import config from '../config.js';

function spawnCommand(scriptPath, env = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(scriptPath, {
      shell: true,
      stdio: ['ignore', 'pipe', 'pipe'],
      env: { ...process.env, ...env },
    });

    let stdout = '';
    let stderr = '';

    child.stdout.on('data', (data) => {
      stdout += data.toString();
    });

    child.stderr.on('data', (data) => {
      stderr += data.toString();
    });

    child.on('close', (code) => {
      if (code === 0) {
        resolve({ code, stdout, stderr });
      } else {
        reject(new Error(`Script exited with code ${code}\n${stderr}`));
      }
    });

    child.on('error', (err) => {
      reject(new Error(`Failed to spawn: ${err.message}\n${stderr}`));
    });
  });
}

function httpGet(urlPath, baseUrl) {
  return new Promise((resolve, reject) => {
    const url = new URL(urlPath, baseUrl);
    const req = http.get(url, { timeout: 5000 }, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        if (res.statusCode === 200) {
          try {
            resolve(JSON.parse(data));
          } catch (e) {
            resolve({ raw: data });
          }
        } else {
          resolve({ statusCode: res.statusCode, data });
        }
      });
    });

    req.on('error', (err) => {
      reject(new Error(`HTTP request failed: ${err.message}`));
    });

    req.on('timeout', () => {
      req.destroy();
      reject(new Error('HTTP request timed out'));
    });
  });
}

async function checkHealth(baseUrl) {
  try {
    const resp = await httpGet('/health', baseUrl);
    return resp.status === 'healthy' || resp.statusCode === 200;
  } catch {
    return false;
  }
}

async function waitForReady(baseUrl, timeoutMs = 60000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    if (await checkHealth(baseUrl)) {
      return true;
    }
    await new Promise((r) => setTimeout(r, 1000));
  }
  return false;
}

export async function startServer(options = {}) {
  const { folderPath } = options || {};
  const scriptsDir = config.zImage?.scriptsDir || '';
  const baseUrl = config.zImage?.baseUrl || 'http://localhost:8090';
  const startTimeout = config.zImage?.startTimeoutMs || 60000;
  const startScript = `${scriptsDir}/zimage-start`;

  console.log('[imageGenLifecycle] Starting Z-Image server...');

  // Build env: pass user's Z-Image folder path to override script default
  const spawnEnv = {};
  if (folderPath && folderPath.trim()) {
    spawnEnv.Z_IMAGE_DIR = folderPath.trim();
    console.log(`[imageGenLifecycle] Using Z_IMAGE_DIR=${spawnEnv.Z_IMAGE_DIR}`);
  }

  try {
    await spawnCommand(startScript, spawnEnv);
  } catch (err) {
    console.error('[imageGenLifecycle] zimage-start script failed:', err.message);
    throw new Error(`Failed to start Z-Image server: ${err.message}`);
  }

  console.log('[imageGenLifecycle] Waiting for server to become ready...');
  const ready = await waitForReady(baseUrl, startTimeout);

  if (!ready) {
    throw new Error('Z-Image server did not become ready within timeout');
  }

  console.log('[imageGenLifecycle] Z-Image server is ready');
  return { success: true };
}

export async function stopServer() {
  const scriptsDir = config.zImage?.scriptsDir || '';
  const stopScript = `${scriptsDir}/zimage-stop`;

  console.log('[imageGenLifecycle] Stopping Z-Image server...');

  try {
    await spawnCommand(stopScript);
    console.log('[imageGenLifecycle] Z-Image server stopped');
    return { success: true };
  } catch (err) {
    console.error('[imageGenLifecycle] zimage-stop script failed:', err.message);
    // Still try to kill the process directly
    try {
      await spawnCommand(`pkill -f "api_server.py.*--port 8090"`);
    } catch {}
    return { success: false, error: err.message };
  }
}

export async function isRunning() {
  const baseUrl = config.zImage?.baseUrl || 'http://localhost:8090';
  const running = await checkHealth(baseUrl);
  return { running };
}

export { checkHealth };