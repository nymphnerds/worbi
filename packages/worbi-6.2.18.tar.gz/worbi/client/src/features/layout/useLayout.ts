import { useState, useCallback, useEffect, useMemo } from 'react';
import type { ActivityType } from '../navigation/useActivityRouter';

type HideableIcon = ActivityType | 'ai';

const MIN_LEFT_WIDTH = 180;
const MAX_LEFT_WIDTH = 500;
const MIN_RIGHT_WIDTH = 280;
const MAX_RIGHT_WIDTH = 600;
const MIN_SEARCH_WIDTH = 200;
const MAX_SEARCH_WIDTH = 500;

export function useLayout() {
  const [leftWidth, setLeftWidth] = useState(() => {
    const stored = localStorage.getItem('wbu-left-width');
    return stored ? parseInt(stored, 10) : 250;
  });
  const [rightWidth, setRightWidth] = useState(() => {
    const stored = localStorage.getItem('wbu-right-width');
    return stored ? parseInt(stored, 10) : 350;
  });
  const [leftPanelHidden, setLeftPanelHidden] = useState(() => {
    const stored = localStorage.getItem('wbu-left-panel-hidden');
    return stored !== null ? stored === 'true' : false;
  });
  const [searchWidth, setSearchWidth] = useState(() => {
    const stored = localStorage.getItem('wbu-search-width');
    return stored ? parseInt(stored, 10) : 250;
  });
  const [showAISidebar, setShowAISidebarState] = useState(() => {
    const stored = localStorage.getItem('wbu-ai-sidebar');
    return stored !== null ? stored === 'true' : false;
  });

  const setShowAISidebar = useCallback((value: boolean | ((prev: boolean) => boolean)) => {
    setShowAISidebarState((prev) => {
      const next = typeof value === 'function' ? value(prev) : value;
      localStorage.setItem('wbu-ai-sidebar', String(next));
      return next;
    });
  }, []);

  const toggleAISidebar = useCallback(() => {
    setShowAISidebar((prev: boolean) => {
      const next = !prev;
      localStorage.setItem('wbu-ai-sidebar', String(next));
      return next;
    });
  }, []);

  const toggleLeftPanel = useCallback(() => {
    setLeftPanelHidden((prev) => {
      localStorage.setItem('wbu-left-panel-hidden', String(!prev));
      return !prev;
    });
  }, []);

  /**
   * Create a horizontal resize handler.
   * @param setter - React state setter for the width value
   * @param getInitialWidth - Function returning the current width from React state
   * @param min - Minimum allowed width in px
   * @param max - Maximum allowed width in px
   * @param persistKey - localStorage key for persisting final width (null to skip)
   * @param reverse - If true, positive delta subtracts (for right-edge panels)
   */
  const createResizeHandler = useCallback(
    (
      setter: React.Dispatch<React.SetStateAction<number>>,
      getInitialWidth: () => number,
      min: number,
      max: number,
      persistKey: string | null,
      reverse: boolean = false,
    ) => {
      return (e: React.MouseEvent) => {
        e.preventDefault();
        const startX = e.clientX;
        const startWidth = getInitialWidth();

        const onMouseMove = (moveEvent: MouseEvent) => {
          const delta = moveEvent.clientX - startX;
          const signedDelta = reverse ? -delta : delta;
          let newWidth = Math.round(startWidth + signedDelta);
          if (newWidth < min) newWidth = min;
          if (newWidth > max) newWidth = max;
          setter(newWidth);
        };

        const onMouseUp = () => {
          document.removeEventListener('mousemove', onMouseMove);
          document.removeEventListener('mouseup', onMouseUp);
          if (persistKey) {
            // Read the final value from localStorage-compatible source
            // We persist via the setter's functional update pattern
            setter((current) => {
              localStorage.setItem(persistKey, String(current));
              return current;
            });
          }
          document.body.style.cursor = '';
          document.body.style.userSelect = '';
        };

        document.body.style.cursor = 'col-resize';
        document.body.style.userSelect = 'none';
        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
      };
    },
    [],
  );

  const resizeLeftPanel = useCallback(
    (e: React.MouseEvent) => {
      createResizeHandler(
        setLeftWidth,
        () => leftWidth,
        MIN_LEFT_WIDTH,
        MAX_LEFT_WIDTH,
        'wbu-left-width',
        false,
      )(e);
    },
    [createResizeHandler, leftWidth],
  );

  const resizeRightPanel = useCallback(
    (e: React.MouseEvent) => {
      createResizeHandler(
        setRightWidth,
        () => rightWidth,
        MIN_RIGHT_WIDTH,
        MAX_RIGHT_WIDTH,
        'wbu-right-width',
        true,
      )(e);
    },
    [createResizeHandler, rightWidth],
  );

  const resizeSearchPanel = useCallback(
    (e: React.MouseEvent) => {
      createResizeHandler(
        setSearchWidth,
        () => searchWidth,
        MIN_SEARCH_WIDTH,
        MAX_SEARCH_WIDTH,
        'wbu-search-width',
        false,
      )(e);
    },
    [createResizeHandler, searchWidth],
  );

  // Sidebar icon visibility — reactive to localStorage changes
  const [visibilityRefreshKey, setVisibilityRefreshKey] = useState(0);
  useEffect(() => {
    const handler = () => setVisibilityRefreshKey(k => k + 1);
    window.addEventListener('storage', handler);
    window.addEventListener('wbu-sidebar-visibility-change', handler);
    return () => {
      window.removeEventListener('storage', handler);
      window.removeEventListener('wbu-sidebar-visibility-change', handler);
    };
  }, []);

  const hiddenIcons = useMemo((): Set<HideableIcon> => {
    void visibilityRefreshKey; // trigger recompute
    try {
      const raw = localStorage.getItem('wbu_sidebar_visibility');
      if (raw) {
        const visibility: Record<string, boolean> = JSON.parse(raw);
        const hidden: HideableIcon[] = [];
        for (const key of Object.keys(visibility)) {
          if (visibility[key] === false) hidden.push(key as HideableIcon);
        }
        return new Set(hidden);
      }
    } catch { /* ignore */ }
    return new Set();
  }, [visibilityRefreshKey]);

  return {
    leftWidth,
    setLeftWidth,
    rightWidth,
    setRightWidth,
    searchWidth,
    setSearchWidth,
    leftPanelHidden,
    setLeftPanelHidden,
    showAISidebar,
    setShowAISidebar,
    toggleAISidebar,
    toggleLeftPanel,
    resizeLeftPanel,
    resizeRightPanel,
    resizeSearchPanel,
    hiddenIcons,
    visibilityRefreshKey,
  };
}

export type { HideableIcon };