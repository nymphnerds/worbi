import { useState, useCallback, useEffect, useRef } from 'react';
import { getUserRecents, saveUserRecents, getUserStarred, saveUserStarred, UserRecentFile, UserStarredFile } from '../services/api';

const MAX_RECENTS = 10;

// Debounce helper — cancels pending saves on unmount so a departing user's data
// cannot leak into the next logged-in user's server-side file via a stale timer.
function useDebouncedSave() {
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  // Track mounted state so pending timers don't fire after unmount
  const mountedRef = useRef(true);

  useEffect(() => {
    return () => {
      mountedRef.current = false;
      if (timerRef.current) {
        clearTimeout(timerRef.current);
      }
    };
  }, []);

  const debouncedSave = useCallback(<T>(data: T, saveFn: (d: T) => Promise<void>) => {
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(async () => {
      // Bail if component unmounted (user logged out) — avoid saving
      // under a different user's auth token
      if (!mountedRef.current) return;
      try {
        await saveFn(data);
      } catch {
        // Silently fail - data is still in state
      }
    }, 500);
  }, []);
  return debouncedSave;
}

export function useRecents(refreshKey = 0) {
  const [recentFiles, setRecentFiles] = useState<UserRecentFile[]>([]);
  const [starredFiles, setStarredFiles] = useState<UserStarredFile[]>([]);
  const [loading, setLoading] = useState(true);
  const debouncedSave = useDebouncedSave();

  // Load data from server on mount
  const loadFromServer = useCallback(async () => {
    try {
      const [recents, starred] = await Promise.all([
        getUserRecents(),
        getUserStarred(),
      ]);
      setRecentFiles(recents);
      setStarredFiles(starred);
      setLoading(false);
    } catch {
      setRecentFiles([]);
      setStarredFiles([]);
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    let mounted = true;
    // Immediately clear stale data and re-enter loading so the debounced
    // save effects don't flush old-user data during a login transition
    setRecentFiles([]);
    setStarredFiles([]);
    setLoading(true);
    
    (async () => {
      try {
        const [recents, starred] = await Promise.all([
          getUserRecents(),
          getUserStarred(),
        ]);
        if (mounted) {
          setRecentFiles(recents);
          setStarredFiles(starred);
          setLoading(false);
        }
      } catch {
        if (mounted) {
          setRecentFiles([]);
          setStarredFiles([]);
          setLoading(false);
        }
      }
    })();
    
    return () => {
      mounted = false;
    };
  }, [refreshKey]);

  const addRecentFile = useCallback((path: string) => {
    const name = path.split('/').pop() || path;
    setRecentFiles(prev => {
      const filtered = prev.filter(r => r.path !== path);
      const updated = [{ path, name, lastOpened: Date.now() }, ...filtered];
      return updated.slice(0, MAX_RECENTS);
    });
  }, []);

  // Debounced save recents when they change
  useEffect(() => {
    if (!loading) {
      debouncedSave(recentFiles, saveUserRecents);
    }
  }, [recentFiles, loading, debouncedSave]);

  const toggleStar = useCallback((path: string) => {
    const name = path.split('/').pop() || path;
    setStarredFiles(prev => {
      const exists = prev.find(s => s.path === path);
      if (exists) {
        return prev.filter(s => s.path !== path);
      }
      return [...prev, { path, name }];
    });
  }, []);

  // Debounced save starred when they change
  useEffect(() => {
    if (!loading) {
      debouncedSave(starredFiles, saveUserStarred);
    }
  }, [starredFiles, loading, debouncedSave]);

  const isStarred = useCallback((path: string) => {
    return starredFiles.some(s => s.path === path);
  }, [starredFiles]);

  const removeRecent = useCallback((path: string) => {
    setRecentFiles(prev => prev.filter(r => r.path !== path));
  }, []);

  const removeStar = useCallback((path: string) => {
    setStarredFiles(prev => prev.filter(s => s.path !== path));
  }, []);

  const clearRecents = useCallback(() => {
    setRecentFiles([]);
  }, []);

  return {
    recentFiles,
    starredFiles,
    loading,
    addRecentFile,
    toggleStar,
    isStarred,
    removeRecent,
    removeStar,
    clearRecents,
  };
}