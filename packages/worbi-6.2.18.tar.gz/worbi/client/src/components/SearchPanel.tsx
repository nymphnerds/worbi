import React, { useCallback } from 'react';
import { SearchResult, SearchMatch } from '../services/api';

interface SearchPanelProps {
  width: number;
  query: string;
  onQueryChange: (q: string) => void;
  results: SearchResult[];
  loading: boolean;
  error: string | null;
  onFileOpen: (path: string) => void;
}

const SearchPanel: React.FC<SearchPanelProps> = ({
  width,
  query,
  onQueryChange,
  results,
  loading,
  error,
  onFileOpen,
}) => {
  const handleFileClick = useCallback((path: string) => {
    onFileOpen(path);
  }, [onFileOpen]);

  return (
    <div className="search-panel" style={{ width }}>
      <div className="search-panel-header">
        <h2>SEARCH</h2>
      </div>
      <div className="search-input-wrapper">
        <input
          type="text"
          className="search-input"
          placeholder="Search in files..."
          value={query}
          onChange={(e) => onQueryChange(e.target.value)}
        />
        {loading && <span className="search-loading">Searching...</span>}
      </div>

      <div className="search-results">
        {error && (
          <div className="search-error">{error}</div>
        )}

        {!loading && !error && query.trim() && results.length === 0 && (
          <div className="search-empty">No results found</div>
        )}

        {!loading && !query.trim() && (
          <div className="search-empty">Type to search across all files</div>
        )}

        {results.map((result, idx) => (
          <div key={idx} className="search-result-file">
            <div
              className="search-result-file-name"
              onClick={() => handleFileClick(result.path)}
            >
              {result.name}
            </div>
            <div className="search-result-file-path">{result.path}</div>
            <div className="search-result-matches">
              {result.matches.map((match: SearchMatch, mIdx: number) => (
                <div
                  key={mIdx}
                  className="search-result-match"
                  onClick={() => handleFileClick(result.path)}
                >
                  <span className="search-result-line">L{match.line}</span>
                  <span className="search-result-context">{match.context}</span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SearchPanel;