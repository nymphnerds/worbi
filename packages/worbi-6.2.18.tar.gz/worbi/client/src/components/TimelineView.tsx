import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Settings, X, ChevronUp, ChevronDown, Pencil, Plus, Trash2 } from 'lucide-react';
import { getTimeline, type TimelineEra, type TimelineEvent, type TimelineTag } from '../services/api';
import { getEras, saveEras, DEFAULT_ERAS } from '../utils/timelineConfig';

interface TimelineViewProps {
  onFileSelect: (path: string) => void;
  /** Numeric key that changes when file operations occur, triggering auto-refresh */
  refreshKey?: number;
}

// Get the primary tag color for an event (uses first tag's color, or gray if no tags)
function getEventDotColor(event: TimelineEvent): string {
  if (event.tags && event.tags.length > 0) {
    return event.tags[0].color;
  }
  return '#9ca3af'; // gray-400 fallback
}

function getEventTagLabel(event: TimelineEvent): string {
  if (event.tags && event.tags.length > 0) {
    return event.tags[0].name;
  }
  return 'NoTag';
}

// Custom multi-select dropdown
interface MultiSelectDropdownProps {
  label: string;
  options: string[];
  selected: Set<string>;
  onToggle: (option: string) => void;
  onSelectAll: () => void;
  onDeselectAll: () => void;
}

const MultiSelectDropdown: React.FC<MultiSelectDropdownProps> = ({
  label, options, selected, onToggle, onSelectAll, onDeselectAll,
}) => {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const allSelected = options.length > 0 && selected.size === options.length;

  return (
    <div ref={ref} className="timeline-filter-dropdown">
      <button
        className="timeline-filter-btn"
        onClick={() => setOpen(!open)}
        title={label}
      >
        {label}: {selected.size === 0 ? 'None' : selected.size === options.length ? 'All' : `${selected.size}`}
        <span className={`timeline-filter-arrow ${open ? 'open' : ''}`}>▾</span>
      </button>
      {open && (
        <div className="timeline-filter-menu">
          <div className="timeline-filter-actions">
            <button onClick={allSelected ? onDeselectAll : onSelectAll}>
              {allSelected ? 'Deselect All' : 'Select All'}
            </button>
          </div>
          <div className="timeline-filter-options">
            {options.map((option) => (
              <label key={option} className="timeline-filter-option">
                <input
                  type="checkbox"
                  checked={selected.has(option)}
                  onChange={() => onToggle(option)}
                />
                <span>{option}</span>
              </label>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

// Timeline event row
const TimelineEventRow: React.FC<{ event: TimelineEvent; onClick: () => void }> = ({ event, onClick }) => {
  const dotColor = getEventDotColor(event);
  const tagLabel = getEventTagLabel(event);

  return (
    <div className="timeline-event" onClick={onClick} title={event.snippet || event.name}>
      <span className="timeline-dot" style={{ backgroundColor: dotColor }}></span>
      <div className="timeline-event-content">
        <div className="timeline-event-header">
          <span className="timeline-event-date">{event.isApproximate ? '~' : ''}{event.date}</span>
          <span className="timeline-event-name">{event.name}</span>
        </div>
        <div className="timeline-event-meta">
          {tagLabel && (
            <span className="timeline-tag-badge" style={{ color: dotColor }}>
              {tagLabel}
            </span>
          )}
          <span className="timeline-event-path">{event.path}</span>
        </div>
      </div>
    </div>
  );
};

// Collapsible era section
const EraSection: React.FC<{
  era: TimelineEra;
  onEventClick: (path: string) => void;
  filteredEvents: TimelineEvent[];
}> = ({ era, onEventClick, filteredEvents }) => {
  const [collapsed, setCollapsed] = useState(false);

  if (filteredEvents.length === 0) return null;

  return (
    <div className="timeline-era">
      <button
        className="timeline-era-header"
        onClick={() => setCollapsed(!collapsed)}
      >
        <span className={`timeline-era-arrow ${collapsed ? 'collapsed' : ''}`}>▶</span>
        <span className="timeline-era-name">{era.name}</span>
        <span className="timeline-era-count">({filteredEvents.length})</span>
      </button>
      {!collapsed && (
        <div className="timeline-era-events">
          {filteredEvents.map((event) => (
            <TimelineEventRow
              key={event.path}
              event={event}
              onClick={() => onEventClick(event.path)}
            />
          ))}
        </div>
      )}
    </div>
  );
};

// Skeleton loading placeholder
const TimelineSkeleton: React.FC = () => (
  <div className="timeline-skeleton">
    <div className="timeline-skeleton-era" />
    <div className="timeline-skeleton-event" />
    <div className="timeline-skeleton-event" />
    <div className="timeline-skeleton-event" />
    <div className="timeline-skeleton-era" />
    <div className="timeline-skeleton-event" />
    <div className="timeline-skeleton-event" />
  </div>
);

// ============================================================
// Settings Modal Components
// ============================================================

// Inline editable item with actions
interface ManageItemProps {
  name: string;
  index: number;
  total: number;
  onEdit: (name: string) => void;
  onDelete: () => void;
  onMoveUp: () => void;
  onMoveDown: () => void;
  showReorder: boolean;
}

const ManageItem: React.FC<ManageItemProps> = ({ name, index, total, onEdit, onDelete, onMoveUp, onMoveDown, showReorder }) => {
  const [editing, setEditing] = useState(false);
  const [editValue, setEditValue] = useState(name);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (editing && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [editing]);

  const handleSave = () => {
    if (editValue.trim() && editValue.trim() !== name) {
      onEdit(editValue.trim());
    } else {
      setEditValue(name);
    }
    setEditing(false);
  };

  return (
    <div className="timeline-manage-item">
      {editing ? (
        <input
          ref={inputRef}
          className="timeline-manage-edit-input"
          value={editValue}
          onChange={(e) => setEditValue(e.target.value)}
          onBlur={handleSave}
          onKeyDown={(e) => {
            if (e.key === 'Enter') handleSave();
            if (e.key === 'Escape') { setEditValue(name); setEditing(false); }
          }}
        />
      ) : (
        <span className="timeline-manage-item-name">{name}</span>
      )}
      <div className="timeline-manage-item-actions">
        {showReorder && (
          <>
            <button
              className="timeline-manage-action-btn"
              onClick={onMoveUp}
              disabled={index === 0}
              title="Move up"
            >
              <ChevronUp size={12} />
            </button>
            <button
              className="timeline-manage-action-btn"
              onClick={onMoveDown}
              disabled={index === total - 1}
              title="Move down"
            >
              <ChevronDown size={12} />
            </button>
          </>
        )}
        <button
          className="timeline-manage-action-btn"
          onClick={() => { setEditValue(name); setEditing(true); }}
          title="Edit"
        >
          <Pencil size={12} />
        </button>
        <button
          className="timeline-manage-action-btn timeline-manage-action-delete"
          onClick={onDelete}
          title="Delete"
        >
          <Trash2 size={12} />
        </button>
      </div>
    </div>
  );
};

// Settings modal (Eras only — tags are managed via the Tags panel)
interface SettingsModalProps {
  onClose: () => void;
  onErasChange: (eras: string[]) => void;
}

const SettingsModal: React.FC<SettingsModalProps> = ({ onClose, onErasChange }) => {
  const [eras, setEras] = useState<string[]>(getEras());
  const [newEra, setNewEra] = useState('');

  const addEra = () => {
    const val = newEra.trim();
    if (val && !eras.includes(val)) {
      const updated = [...eras, val];
      setEras(updated);
      saveEras(updated);
      onErasChange(updated);
      setNewEra('');
    }
  };

  const editEra = (oldName: string, newName: string) => {
    const updated = eras.map((e) => (e === oldName ? newName : e));
    setEras(updated);
    saveEras(updated);
    onErasChange(updated);
  };

  const deleteEra = (name: string) => {
    if (eras.length <= 1) return;
    const updated = eras.filter((e) => e !== name);
    setEras(updated);
    saveEras(updated);
    onErasChange(updated);
  };

  const moveEra = (fromIndex: number, toIndex: number) => {
    if (toIndex < 0 || toIndex >= eras.length) return;
    const updated = [...eras];
    const [item] = updated.splice(fromIndex, 1);
    updated.splice(toIndex, 0, item);
    setEras(updated);
    saveEras(updated);
    onErasChange(updated);
  };

  return (
    <>
      <div className="timeline-modal-overlay" onClick={onClose} />
      <div className="timeline-modal">
        <div className="timeline-modal-header">
          <span>Timeline Settings</span>
          <button className="timeline-modal-close" onClick={onClose}>
            <X size={14} />
          </button>
        </div>

        <div className="timeline-modal-content">
          <div className="timeline-manage-list">
            {eras.map((era, i) => (
              <ManageItem
                key={era}
                name={era}
                index={i}
                total={eras.length}
                onEdit={(newName) => editEra(era, newName)}
                onDelete={() => deleteEra(era)}
                onMoveUp={() => moveEra(i, i - 1)}
                onMoveDown={() => moveEra(i, i + 1)}
                showReorder={true}
              />
            ))}
            <div className="timeline-manage-add">
              <input
                className="timeline-manage-add-input"
                placeholder="New era name..."
                value={newEra}
                onChange={(e) => setNewEra(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter') addEra(); }}
              />
              <button
                className="timeline-manage-add-btn"
                onClick={addEra}
                disabled={!newEra.trim() || eras.includes(newEra.trim())}
              >
                <Plus size={14} /> Add
              </button>
            </div>
          </div>
        </div>

        <div className="timeline-modal-footer">
          <button className="timeline-modal-reset-btn" onClick={() => {
            const reset = [...DEFAULT_ERAS];
            setEras(reset);
            saveEras(reset);
            onErasChange(reset);
          }}>
            Reset to Defaults
          </button>
          <button className="timeline-modal-done-btn" onClick={onClose}>Done</button>
        </div>
      </div>
    </>
  );
};

// ============================================================
// Main TimelineView
// ============================================================

const TimelineView: React.FC<TimelineViewProps> = ({ onFileSelect, refreshKey }) => {
  const [eras, setEras] = useState<TimelineEra[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedEras, setSelectedEras] = useState<Set<string>>(new Set());
  const [selectedTags, setSelectedTags] = useState<Set<string>>(new Set());
  const [showSettings, setShowSettings] = useState(false);
  const refreshTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lastRefreshRef = useRef<number>(0);

  const fetchTimeline = useCallback(async () => {
    // Debounce rapid refresh calls (e.g., during batch operations)
    const now = Date.now();
    if (now - lastRefreshRef.current < 500) {
      if (refreshTimerRef.current) clearTimeout(refreshTimerRef.current);
      refreshTimerRef.current = setTimeout(() => {
        fetchTimeline();
      }, 500);
      return;
    }
    lastRefreshRef.current = now;

    try {
      setLoading(true);
      setError(null);
      const data = await getTimeline();
      setEras(data.eras);

      // Initialize filter sets to include all available options
      if (data.eras.length > 0) {
        const eraNames = data.eras.map((e) => e.name);
        const tags = new Set<string>();
        data.eras.forEach((e) =>
          e.events.forEach((ev) => {
            ev.tags?.forEach((t) => tags.add(t.name));
          })
        );
        setSelectedEras(new Set(eraNames));
        if (selectedTags.size === 0) {
          setSelectedTags(tags);
        }
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load timeline');
    } finally {
      setLoading(false);
    }
    }, [selectedTags.size]);

  useEffect(() => {
    fetchTimeline();
  }, [fetchTimeline]);

  // Auto-refresh when refreshKey changes (file operations trigger parent re-render)
  useEffect(() => {
    fetchTimeline();
  }, [refreshKey, fetchTimeline]);

  // Cleanup timer on unmount
  useEffect(() => {
    return () => {
      if (refreshTimerRef.current) clearTimeout(refreshTimerRef.current);
    };
  }, []);

  // Collect unique options for filters
  const eraOptions = eras.map((e) => e.name);
  const tagOptions = [...new Set(eras.flatMap((e) => e.events.flatMap((ev) => ev.tags?.map((t) => t.name) || [])))].sort();

  // Filter eras and events
  const filteredEras = eras
    .map((era) => ({
      ...era,
      events: era.events.filter((ev) => {
        if (!selectedEras.has(era.name)) return false;
        // If tag filter is active, check if event has any of the selected tags
        // Events with no tags are always included (they show "NoTag")
        if (selectedTags.size > 0 && tagOptions.length > 1) {
          const eventTagNames = ev.tags?.map((t) => t.name) || [];
          if (eventTagNames.length === 0) return true;
          return eventTagNames.some((t) => selectedTags.has(t));
        }
        return true;
      }),
    }))
    .filter((era) => era.events.length > 0);

  const totalEvents = filteredEras.reduce((sum, era) => sum + era.events.length, 0);

  // Era filter toggles
  const toggleEra = (era: string) => {
    setSelectedEras((prev) => {
      const next = new Set(prev);
      if (next.has(era)) next.delete(era);
      else next.add(era);
      return next;
    });
  };

  const selectAllEras = () => setSelectedEras(new Set(eraOptions));
  const deselectAllEras = () => setSelectedEras(new Set());

  // Tag filter toggles
  const toggleTag = (tag: string) => {
    setSelectedTags((prev) => {
      const next = new Set(prev);
      if (next.has(tag)) next.delete(tag);
      else next.add(tag);
      return next;
    });
  };

  const selectAllTags = () => setSelectedTags(new Set(tagOptions));
  const deselectAllTags = () => setSelectedTags(new Set());

  return (
    <div className="timeline-panel">
      <div className="timeline-header">
        <span>Timeline</span>
        <div className="timeline-header-right">
          <span className="timeline-event-total">{totalEvents} event{totalEvents !== 1 ? 's' : ''}</span>
          <button
            className="timeline-settings-btn"
            onClick={() => setShowSettings(true)}
            title="Manage Eras"
          >
            <Settings size={14} />
          </button>
        </div>
      </div>

      {/* Filters */}
      {(eraOptions.length > 1 || tagOptions.length > 1) && (
        <div className="timeline-filters">
          {eraOptions.length > 1 && (
            <MultiSelectDropdown
              label="Eras"
              options={eraOptions}
              selected={selectedEras}
              onToggle={toggleEra}
              onSelectAll={selectAllEras}
              onDeselectAll={deselectAllEras}
            />
          )}
          {tagOptions.length > 1 && (
            <MultiSelectDropdown
              label="Tags"
              options={tagOptions}
              selected={selectedTags}
              onToggle={toggleTag}
              onSelectAll={selectAllTags}
              onDeselectAll={deselectAllTags}
            />
          )}
        </div>
      )}

      {/* Content */}
      <div className="timeline-content">
        {loading ? (
          <TimelineSkeleton />
        ) : error ? (
          <div className="timeline-error">
            <p>Could not load timeline.</p>
            <p><span style={{ color: 'hsl(var(--muted-foreground))' }}>{error}</span></p>
            <button className="timeline-retry-btn" onClick={fetchTimeline}>Retry</button>
          </div>
        ) : filteredEras.length === 0 && !loading ? (
          <div className="timeline-empty">
            <p>No timeline entries found.</p>
            <p style={{ fontSize: '0.7rem', marginTop: '0.5rem', color: 'hsl(var(--muted-foreground))' }}>
              Create a document in <code>/World/Timeline/</code> or add{' '}
              <code>Date/Period</code> and <code>Era</code> fields to your documents.
            </p>
          </div>
        ) : (
          filteredEras.map((era) => (
            <EraSection
              key={era.name}
              era={era}
              onEventClick={onFileSelect}
              filteredEvents={era.events}
            />
          ))
        )}
      </div>

      {/* Settings Modal */}
      {showSettings && (
        <SettingsModal
          onClose={() => setShowSettings(false)}
          onErasChange={() => {}}
        />
      )}
    </div>
  );
};

export default TimelineView;