import { useState, useCallback } from 'react';
import { X, Gamepad2, Loader2, Check, AlertCircle } from 'lucide-react';
import { detectTemplateType, buildGameReadyPath, type TemplateTypeConfig } from '../utils/templateDetector';
import { buildGenerationPrompt } from '../utils/gameGeneratorPrompts';
import { sendChat } from '../services/api';

interface GameExportModalProps {
  currentPath: string | null;
  content: string;
  onClose: () => void;
  onFileCreated: (path: string) => void;
  aiOffline?: boolean;
}

export function GameExportModal({ currentPath, content, onClose, onFileCreated, aiOffline }: GameExportModalProps) {
  const [step, setStep] = useState<'detect' | 'confirm' | 'generating' | 'review' | 'done'>('detect');
  const [templateType, setTemplateType] = useState<TemplateTypeConfig | null>(null);
  const [llmResponse, setLlmResponse] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  // Step 1: Detect template type from folder path
  useState(() => {
    if (!currentPath) {
      setError('No file is open. Please open a document first.');
      return;
    }
    const folderPath = currentPath.substring(0, currentPath.lastIndexOf('/')) || '';
    const detected = detectTemplateType(folderPath);
    if (!detected) {
      setError(`Template type not recognized for folder "${folderPath}". Supported folders: NPCs, Quests, MainStory, Locations, Items, Factions.`);
      return;
    }
    setTemplateType(detected);
    setStep('confirm');
  });

  const handleGenerate = useCallback(async () => {
    if (!templateType || !currentPath) return;
    setIsGenerating(true);
    setStep('generating');
    setError(null);

    try {
      const fileName = currentPath.split('/').pop()?.replace(/\.[^.]+$/, '') || 'export';
      const prompt = buildGenerationPrompt(templateType.promptKey, content, fileName);

      // Send to LLM via the existing API
      const response = await sendChat(prompt, [], '', 'You are a game file generator. Convert the following template into the game engine format.');
      setLlmResponse(response.content);
      setStep('review');
    } catch (err) {
      setError(`Generation failed: ${err instanceof Error ? err.message : 'Unknown error'}`);
    } finally {
      setIsGenerating(false);
    }
  }, [templateType, currentPath, content]);

  const handleSave = useCallback(async () => {
    if (!templateType || !currentPath || !llmResponse) return;

    try {
      const fileName = currentPath.split('/').pop()?.replace(/\.[^.]+$/, '') || 'export';
      const gamePath = buildGameReadyPath(templateType, fileName);

      // Save the generated content as a new file via the API
      const { createFile } = await import('../services/api');
      await createFile(gamePath, '');
      const { updateFile } = await import('../services/api');
      await updateFile(gamePath, llmResponse);

      setStep('done');
      // Notify parent after a short delay so the "done" state is visible
      setTimeout(() => {
        onFileCreated(gamePath);
      }, 1500);
    } catch (err) {
      setError(`Save failed: ${err instanceof Error ? err.message : 'Unknown error'}`);
      setStep('review');
    }
  }, [templateType, currentPath, llmResponse, onFileCreated]);

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/50" onClick={onClose}>
      <div
        className="bg-[#1e1e2e] rounded-lg shadow-2xl border border-[#3a3a4a] w-[90vw] max-w-2xl max-h-[85vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-border">
          <div className="flex items-center gap-2">
            <Gamepad2 size={16} className="text-green-400" />
            <h2 className="text-sm font-semibold text-white">Generate Game File</h2>
          </div>
          <button onClick={onClose} className="p-1 rounded hover:bg-accent text-muted-foreground">
            <X size={14} />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-auto px-4 py-4">
          {/* Error State */}
          {error && (
            <div className="flex items-start gap-3 p-3 rounded bg-red-900/20 border border-red-800/50">
              <AlertCircle size={16} className="text-red-400 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-xs text-red-300">{error}</p>
                <button onClick={onClose} className="text-xs text-red-400 underline mt-2">Close</button>
              </div>
            </div>
          )}

          {/* Confirm Step */}
          {step === 'confirm' && templateType && (
            <div className="space-y-4">
              <div className="p-3 rounded bg-secondary/50 border border-border">
                <p className="text-xs text-muted-foreground mb-1">Detected Template Type</p>
                <p className="text-sm text-white font-medium">{templateType.label}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Output: <code className="text-green-400">GameReady/{templateType.outputSubfolder}/</code>
                </p>
              </div>

              {aiOffline ? (
                <div className="flex items-center gap-2 p-3 rounded bg-yellow-900/20 border border-yellow-800/50">
                  <AlertCircle size={16} className="text-yellow-400 flex-shrink-0" />
                  <p className="text-xs text-yellow-300">LLM is offline. Game file generation requires a connected AI server.</p>
                </div>
              ) : (
                <p className="text-xs text-muted-foreground">
                  The AI will analyze your document and convert it to the game engine format. It may ask clarifying questions if information is missing.
                </p>
              )}

              <div className="flex justify-end gap-2 pt-2">
                <button onClick={onClose} className="px-3 py-1.5 text-xs rounded border border-border text-muted-foreground hover:bg-accent">
                  Cancel
                </button>
                <button
                  onClick={handleGenerate}
                  disabled={aiOffline}
                  className="px-3 py-1.5 text-xs rounded bg-green-700 text-white hover:bg-green-600 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Generate
                </button>
              </div>
            </div>
          )}

          {/* Generating Step */}
          {step === 'generating' && (
            <div className="flex flex-col items-center justify-center py-12 gap-3">
              <Loader2 size={32} className="text-green-400 animate-spin" />
              <p className="text-sm text-muted-foreground">Generating game file...</p>
              <p className="text-xs text-muted-foreground">The AI is analyzing your document</p>
            </div>
          )}

          {/* Review Step */}
          {step === 'review' && llmResponse && (
            <div className="space-y-3">
              <p className="text-xs text-muted-foreground">
                Review the generated game file below. Edit if needed, then save.
              </p>
              <textarea
                value={llmResponse}
                onChange={(e) => setLlmResponse(e.target.value)}
                className="w-full h-80 px-3 py-2 text-xs font-mono bg-background border border-border rounded resize-none focus:outline-none focus:border-primary"
                spellCheck={false}
              />
              <div className="flex justify-end gap-2">
                <button onClick={onClose} className="px-3 py-1.5 text-xs rounded border border-border text-muted-foreground hover:bg-accent">
                  Discard
                </button>
                <button onClick={handleSave} className="px-3 py-1.5 text-xs rounded bg-green-700 text-white hover:bg-green-600">
                  Save to GameReady/
                </button>
              </div>
            </div>
          )}

          {/* Done Step */}
          {step === 'done' && (
            <div className="flex flex-col items-center justify-center py-12 gap-3">
              <Check size={32} className="text-green-400" />
              <p className="text-sm text-white">Game file saved successfully!</p>
              <p className="text-xs text-muted-foreground">Closing...</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}