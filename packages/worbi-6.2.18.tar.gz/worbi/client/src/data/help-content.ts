// WORBI Help System — Structured help article data
// Extracted from README.md, CHANGELOG.md, docs/, and component analysis

export interface HelpShortcut {
  keys: string;
  description: string;
  platform?: 'mac' | 'windows' | 'linux';
}

export interface HelpArticle {
  id: string;
  title: string;
  description: string;
  content: string;
  shortcuts?: HelpShortcut[];
  relatedArticles?: string[];
}

export interface HelpCategory {
  id: string;
  name: string;
  icon: string;
  articles: HelpArticle[];
}

export const HELP_CATEGORIES: HelpCategory[] = [
  {
    id: 'getting-started',
    name: 'Getting Started',
    icon: '🚀',
    articles: [
      {
        id: 'welcome',
        title: 'Welcome to WORBI',
        description: 'Introduction to WORBI — your AI-powered world-building workspace',
        content: `WORBI (WorldBuilder UI) is a professional world-building workspace for writers, GMs, and creators — running 100% locally on your machine. No cloud. No trackers. Your data, your rules.

**What you can do with WORBI:**
- **Write stories** — Full WYSIWYG rich text editor with two-column layout
- **Design quests** — AI-assisted quest outlines and document templates
- **Build worlds** — Organize lore, characters, locations, and timelines
- **Generate images** — Local AI image generation via Z-Image-Turbo
- **Explore connections** — Visual relationship graphs between your documents

**Getting Started:**
1. Set up your LLM provider in Settings → LLM (local or cloud)
2. Create your first document using the File menu or Ctrl+Shift+N for templates
3. Use the AI sidebar (Sparkles icon) for writing assistance
4. Organize with tags, timelines, and the relationship graph`,
        shortcuts: [
          { keys: 'Ctrl+Shift+N', description: 'New from Template' },
          { keys: 'Ctrl+S', description: 'Save file' },
        ],
        relatedArticles: ['first-document', 'workspace-layout'],
      },
      {
        id: 'installation',
        title: 'Installation & Setup',
        description: 'Install WORBI and configure your development environment',
        content: `**Prerequisites:**
- **Node.js** ≥ 18
- **npm** ≥ 9
- **GPU (optional)** — NVIDIA with ≥ 8 GB VRAM for local image generation
- **LLM backend** — Any OpenAI-compatible server (LM Studio, Ollama, vLLM) or cloud provider

**Install & Run:**

\`\`\`bash
git clone git@github.com:rauty79/worbi.git
cd worbi
npm install
npm run dev
\`\`\`

**Services:**
| Service | URL |
|---------|-----|
| API Server | http://localhost:8082 |
| Web Client | http://localhost:5173 |

**Optional: Z-Image Server**
For local image generation, run [Nymphs2D2](../Z-Image/) on localhost:8090 and configure in Settings → Images.

**LLM Configuration:**
Configure your LLM provider in Settings → LLM. WORBI supports:
- **Local:** LM Studio, Ollama, llama.cpp, TextGen WebUI, LocalAI, Jan, vLLM
- **Cloud:** OpenAI, Groq, Together AI, OpenRouter, Mistral, xAI

> ⚠ Non-OpenAI providers (Anthropic, Google) may require a custom adapter for chat.`,
        relatedArticles: ['welcome', 'llm-setup'],
      },
      {
        id: 'first-document',
        title: 'Creating Your First Document',
        description: 'Create documents from scratch or use pre-built templates',
        content: `WORBI offers several ways to create documents:

**Blank Document:**
- Click File → New Blank File in the header
- Or click "New File" on the Welcome screen

**From Template (Recommended):**
WORBI includes 7 pre-built templates:
- **Character Sheet** — Name, appearance, personality, backstory
- **Location** — Geography, climate, points of interest
- **Quest Outline** — Objectives, NPCs, rewards, timeline
- **Timeline Entry** — Date, era, events, participants
- **Item/Artifact** — Description, powers, history
- **Faction** — Members, goals, territories
- **Creature** — Stats, abilities, habitat

Access templates via:
- File → New from Template...
- Welcome screen → "New from Template" button
- Keyboard: Ctrl+Shift+N

**Working with Templates:**
1. Select a template from the modal
2. Enter a file name
3. The document opens in the editor with pre-filled structure
4. Fill in the fields and start writing!`,
        shortcuts: [
          { keys: 'Ctrl+Shift+N', description: 'New from Template' },
        ],
        relatedArticles: ['welcome', 'editor-basics'],
      },
      {
        id: 'workspace-layout',
        title: 'Workspace Layout',
        description: 'Understanding the WORBI interface — Activity Bar, Editor, Panels, and more',
        content: `WORBI uses a VS Code–style layout with four main areas:

**1. Activity Bar (Left Edge)**
A thin icon bar for switching between views:
- 📁 **Explorer** — File tree browser
- 🔍 **Search** — Full-text workspace search
- ⭐ **Starred Files** — Your favorite/quick-access files
- 🏷️ **Tags** — Tag management and file filtering
- 🕐 **Timeline** — Chronological event browser
- 📖 **Outline** — Document headings and bookmarks
- 📊 **Graph** — Relationship graph visualization
- 🖼️ **Images** — Image generator panel

**2. Header (Top)**
- WORBI logo and tagline
- File menu (New File, Templates, Import DOCX)
- AI sidebar toggle
- Current user display
- Logout button

**3. Main Editor Area (Center)**
- Tab bar for open documents
- Rich text editor with formatting toolbar
- Optional Information Panel (right side, draggable)

**4. AI Sidebar (Right)**
- Chat panel for AI assistance
- Toggle with Sparkles icon in Activity Bar or Header
- Greyed out when AI server is offline

**5. Status Bar (Bottom)**
- Shows LLM connection status
- Save status and other indicators

**Resizable Panels:**
- Drag the divider between panels to resize
- Left sidebar width is adjustable
- Right Information Panel width is adjustable`,
        relatedArticles: ['welcome', 'file-explorer'],
      },
    ],
  },
  {
    id: 'editor',
    name: 'Editor',
    icon: '✏️',
    articles: [
      {
        id: 'editor-basics',
        title: 'Rich Text Formatting',
        description: 'Formatting tools available in the WORBI editor',
        content: `The WORBI editor is powered by TipTap (ProseMirror) and provides full WYSIWYG editing:

**Text Formatting:**
- **Bold** — Ctrl+B
- **Italic** — Ctrl+I
- **Underline** — Ctrl+U
- **Headings** — H1 through H6
- **Lists** — Ordered and unordered
- **Tables** — Insert and edit tables
- **Code Blocks** — Fenced code with monospace font
- **Inline Code** — Backtick-wrapped code
- **Text Alignment** — Left, center, right
- **Text Colors** — Custom color support

**Multi-File Editing:**
- Open multiple documents in tabs
- Dirty-state indicators (●) show unsaved changes
- Tab close button with save prompt for unsaved changes
- Unsaved changes browser warning (prevents accidental data loss)

**Image Support:**
- Drag-to-resize images with hover handles
- Images persist via blob bridge system
- Click images for full-size preview`,
        shortcuts: [
          { keys: 'Ctrl+B', description: 'Bold' },
          { keys: 'Ctrl+I', description: 'Italic' },
          { keys: 'Ctrl+U', description: 'Underline' },
          { keys: 'Ctrl+S', description: 'Save file' },
        ],
        relatedArticles: ['two-column', 'images-media', 'spellcheck'],
      },
      {
        id: 'two-column',
        title: 'Two-Column Editor Layout',
        description: 'Use the main + margin column layout for annotations and notes',
        content: `WORBI features a unique two-column editor layout:

**Main Column (~66%):**
- Your primary writing area
- Full rich text editing
- Content flows naturally

**Margin Column (~34%):**
- Side notes, annotations, and marginalia
- Separate TipTap instance (independent editing)
- Perfect for GM notes, commentary, or design remarks

**Resizing:**
- Hover over the divider between columns
- Drag left/right to adjust proportions
- Content delimiter shows the split point

**Use Cases:**
- Write story text in the main column with GM notes in the margin
- Draft content with editorial comments
- Separate canonical lore from author notes
- Character dialogue with stage directions in margin`,
        relatedArticles: ['editor-basics', 'bookmarks'],
      },
      {
        id: 'images-media',
        title: 'Images & Media',
        description: 'Insert, manage, and resize images in your documents',
        content: `**Inserting Images:**
- Use the image button in the editor toolbar
- Select from workspace assets or upload new images
- Images are saved in the assets/images/ folder

**Resizing Images:**
- Hover over an image to reveal resize handles
- Drag handles to resize proportionally
- Dimensions persist across save/reload cycles

**Image Preview:**
- Click an image for full-size preview
- Navigate between images in the same document

**Asset Management:**
- Generated images land in assets/images/ automatically
- Image Explorer in the sidebar shows all workspace images
- Hero images can be set per document in the Information Panel

**Supported Formats:**
JPG, JPEG, PNG, GIF, BMP, WebP, SVG, ICO`,
        relatedArticles: ['editor-basics', 'image-generation'],
      },
      {
        id: 'spellcheck',
        title: 'Spellcheck',
        description: 'Real-time typo detection and correction',
        content: `WORBI includes a built-in spellcheck system:

**How It Works:**
- Real-time typo detection as you type
- Misspelled words shown with red underlines
- Hover over underlined words for suggestion tooltips
- Batch processing for performance on long documents

**Using Spellcheck:**
- Spellcheck runs automatically — no toggle needed
- Right-click a highlighted word for suggestions
- Select a replacement to apply the fix
- Suggestions appear in a contextual menu

**Performance:**
- Words are processed in batches to maintain editor responsiveness
- Custom names and made-up words can be ignored`,
        relatedArticles: ['editor-basics'],
      },
      {
        id: 'find-replace',
        title: 'Find & Replace',
        description: 'Search and replace text within the current document',
        content: `**Opening Find & Replace:**
- Press Ctrl+F for Find
- Press Ctrl+H for Find & Replace
- Or use the editor toolbar buttons

**Features:**
- Highlight all matches in the current document
- Navigate between matches with Previous/Next buttons
- Case-sensitive toggle
- Replace one at a time or replace all

**Usage:**
1. Enter your search term
2. Toggle case sensitivity if needed
3. Navigate matches or replace as needed
4. Match count shows current position (e.g., "3 of 12")`,
        shortcuts: [
          { keys: 'Ctrl+F', description: 'Find' },
          { keys: 'Ctrl+H', description: 'Find & Replace' },
        ],
        relatedArticles: ['editor-basics', 'workspace-search'],
      },
      {
        id: 'wikilinks',
        title: 'WikiLinks ([[links]])',
        description: 'Create clickable cross-document links using Obsidian-style syntax',
        content: `WikiLinks allow you to create connections between documents using Obsidian-style \`[[bracket]]\` syntax.

**Creating Links:**
- Type \`[[\` in the editor to trigger autocomplete
- Select a document from the dropdown (keyboard navigable with arrows + Enter)
- Link format: \`[[Document Name]]\`
- Custom display: \`[[Document Name|Custom Text]]\`

**Link States:**
- 🔵 **Blue link** — Document exists, click to open
- 🟠 **Amber link** — Document doesn't exist yet, click to create
- Links include a 📒 emoji prefix for visual identification

**Link Resolution:**
- Case-insensitive matching against workspace .html files
- Clicking an existing link opens it in a new tab
- Clicking a missing link prompts document creation

**Hover Popover:**
- Hover over a link (300ms delay) to see:
  - Document name and path
  - Content preview
  - "Open Document" button
- Popover auto-closes after 1500ms of inactivity
- Move mouse over popover to keep it open

**Backlinks:**
- The Information Panel shows which documents link to the current one
- Includes context snippets showing the link in context

**Edge Cases:**
- Links in code blocks are not parsed
- Circular links are handled gracefully
- Self-links render as non-clickable`,
        shortcuts: [
          { keys: '[[' , description: 'Trigger WikiLink autocomplete' },
        ],
        relatedArticles: ['relationship-graph', 'backlinks'],
      },
      {
        id: 'file-restore',
        title: 'File Restore',
        description: 'Revert to the version of a document when it was last opened',
        content: `WORBI provides a one-click restore feature to recover from accidental edits:

**How It Works:**
- When you open a file, WORBI snapshots its content
- The snapshot persists even after saving
- If you accidentally make wrong changes (and save them), you can restore

**Using Restore:**
- Click the ⟲ (Restore) icon in the editor toolbar
- A confirmation dialog appears to prevent accidental data loss
- Click Confirm to restore to the last opened version

**Restore Awareness:**
- The restore button stays enabled after saving if content differs from the original snapshot
- Not just a "dirty" check — works even after saving wrong changes

**Limitations:**
- Restores to the version when the file was *opened* (not the last saved version)
- Reopening the file creates a new snapshot`,
        relatedArticles: ['editor-basics'],
      },
      {
        id: 'emoji-picker',
        title: 'Emoji Picker',
        description: 'Insert emojis at the cursor position using the built-in picker',
        content: `**Accessing the Picker:**
- Click the smile icon (😊) in the editor toolbar
- The emoji picker opens at the cursor position

**Categories (800+ emojis):**
- Smileys, People, Animals, Food, Activities, Travel, Objects, Symbols, Flags

**Features:**
- Search within the active category
- Horizontal scrollable category tabs with emoji icons
- Click an emoji to insert it at the cursor position
- Dark theme consistent with WORBI's design`,
        relatedArticles: ['editor-basics'],
      },
    ],
  },
  {
    id: 'ai-features',
    name: 'AI Features',
    icon: '🤖',
    articles: [
      {
        id: 'ai-chat',
        title: 'AI Chat Panel',
        description: 'Use the AI sidebar for writing assistance, worldbuilding help, and more',
        content: `The AI Chat Panel provides conversational AI assistance for your world-building work.

**Opening the Chat:**
- Click the Sparkles icon in the Activity Bar
- Or click the "AI" button in the Header
- State is persisted — it stays open/closed between sessions

**What You Can Ask:**
- Writing assistance and creative prompts
- Worldbuilding and lore questions
- Quest design and character development
- Historical research and fact-checking (with web search)

**Context Awareness:**
- Your current document content is shared as context
- The AI knows what you're working on
- Ask questions about your specific document

**Tools Toggle:**
- Click the ⚡ button in the chat header to enable AI tools
- When ON (amber glow): AI can search the web and access workspace files
- When OFF: Standard chat mode

**Offline Detection:**
- If the LLM server is offline, AI features are greyed out
- A red banner appears in the chat panel
- Features automatically re-enable when the server comes back online`,
        shortcuts: [],
        relatedArticles: ['ghost-text', 'ai-tools'],
      },
      {
        id: 'ghost-text',
        title: 'Ghost Text (Inline Completions)',
        description: 'AI-powered inline text completions as you type',
        content: `Ghost Text provides inline AI continuation suggestions rendered as dimmed text at your cursor position.

**Triggering Ghost Text:**
- Press Ctrl+Space at any point in your document
- Or click the ✨ Sparkles button in the toolbar
- AI generates a continuation based on your current context

**Accepting/Dismissing:**
- Press Tab to accept the suggestion (commits the text)
- Press Esc to dismiss the suggestion

**Auto-Complete Mode:**
- Toggle the "AI" button in the toolbar for continuous suggestions
- Provides automatic suggestions while typing
- Uses a 1.5-second idle debounce to avoid interrupting your flow
- Toggle off when you want to write without AI suggestions

**Tips:**
- Ghost text works best when you've written a clear preceding sentence
- The AI uses your current document as context
- Works with any LLM configured in Settings`,
        shortcuts: [
          { keys: 'Ctrl+Space', description: 'Trigger AI ghost text' },
          { keys: 'Tab', description: 'Accept AI suggestion' },
          { keys: 'Esc', description: 'Dismiss AI suggestion' },
        ],
        relatedArticles: ['ai-chat', 'name-generator'],
      },
      {
        id: 'name-generator',
        title: 'AI Name Generator',
        description: 'Generate culture-specific names for characters, places, and factions',
        content: `The Name Generator creates culture-specific names for your world-building projects.

**Supported Cultures:**
- Elvish, Dwarvish, Nordic, and more
- Configure the culture type when generating

**What You Can Generate:**
- Character names
- Place names (cities, regions, landmarks)
- Item names (artifacts, weapons, treasures)
- Faction names (guilds, kingdoms, organizations)

**How to Use:**
1. Open the Name Generator from the editor toolbar
2. Select the name type and culture
3. Click Generate
4. Click any result to insert it at your cursor position`,
        relatedArticles: ['ghost-text', 'document-generator'],
      },
      {
        id: 'document-generator',
        title: 'AI Document Generator',
        description: 'Scaffold structured documents from an AI prompt',
        content: `The Document Generator creates structured documents from a text prompt.

**Document Types:**
- Character sheets
- Location descriptions
- Quest outlines
- Timeline entries
- Freeform documents

**How to Use:**
1. Click "Generate with AI" from the Welcome screen or toolbar
2. Enter a descriptive prompt (e.g., "A grizzled dwarven blacksmith who secretly forges enchanted weapons")
3. Select the document type
4. AI generates a structured document
5. Review and edit the result in the editor

**Tips:**
- Be specific in your prompts for better results
- The AI uses your LLM provider (configured in Settings → LLM)
- Generated documents are created in the current folder`,
        relatedArticles: ['name-generator', 'document-templates'],
      },
      {
        id: 'ai-tools',
        title: 'AI Tools Engine',
        description: 'AI-powered tools for web search, file operations, and workspace actions',
        content: `The AI Tools Engine allows the AI assistant to take actions beyond text generation.

**Available Tools:**

| Tool | Description | Permission |
|------|-------------|------------|
| 🔍 Web Search | Internet research & lore lookups | Web Search toggle |
| 📄 Read File | Read workspace file contents | File Access: read+ |
| 📁 List Files | List directory contents | File Access: read+ |
| 📝 Create File | Create new documents | File Access: readwrite+ |
| ✏️ Edit File | Modify existing documents | File Access: readwrite+ |
| 🗑️ Delete File | Delete workspace files | File Access: full |
| 🔄 Rename File | Rename files/folders | File Access: full |
| 🔎 Search Files | Search text across files | File Access: read+ |

**Enabling Tools:**
- Click the ⚡ button in the chat header
- Configure permissions in Settings → Tools tab

**Permission Levels:**
- **none** — No file access
- **read** — Can read and list files
- **readwrite** — Can read, create, and edit
- **full** — Full access including delete and rename

**Tool Status:**
- Tool activities shown as colored cards in chat
- Real-time status: ✅ Done or ❌ Error
- Loading text changes to "⚡ Thinking & acting..."

**Security:**
- All file operations restricted to workspace directory
- Delete requires explicit permission (off by default)
- File reads truncated to 10,000 characters`,
        relatedArticles: ['ai-chat', 'tool-permissions'],
      },
      {
        id: 'image-generation',
        title: 'AI Image Generation',
        description: 'Generate images locally using Z-Image-Turbo',
        content: `WORBI integrates with Z-Image-Turbo (Nymphs2D2) for local AI image generation.

**Requirements:**
- NVIDIA GPU with ≥ 8 GB VRAM
- Z-Image server running on localhost:8090
- Configure server URL in Settings → Images

**Features:**
- **Text-to-Image** — Prompt → image in seconds
- **Image-to-Image** — Variations from an existing image
- **Full Controls** — Steps, guidance scale, seed, negative prompt, strength
- **Real-Time Progress** — Live progress bar during generation
- **Auto Save** — Generated images saved to assets/images/

**VRAM Protection:**
- Server-side GPU check prevents OOM crashes
- Configurable minimum free VRAM threshold (default 8 GB)
- Warning dialog if VRAM is below threshold
- "Generate Anyway" option for override

**Accessing the Generator:**
- Click the Image icon in the Activity Bar
- Or click the ✨ button in the Image Explorer header
- Configure in Settings → Images tab`,
        relatedArticles: ['images-media', 'image-to-text'],
      },
      {
        id: 'image-to-text',
        title: 'Image to Text (Transcription)',
        description: 'Convert handwritten or printed documents to text using AI vision',
        content: `The Image to Text feature transcribes images of documents using your LLM's vision capabilities.

**How to Use:**
1. Open the Image Generator Panel
2. Switch to "Image to Text" mode
3. Upload an image or select from workspace
4. Add custom instructions (optional)
5. Click Transcribe

**Output Options:**
- **Copy to Clipboard** — Copy the transcribed text
- **Insert into Prompt** — Use the text in the generator
- **Open in Editor** — Creates a new timestamped document (e.g., \`Transcribed_20260502_042700\`) in the current folder

**Supported Models:**
- Works with any vision-capable LLM (LLaVA, GPT-4o, Claude Vision)
- Configure your model in Settings → LLM`,
        relatedArticles: ['image-generation', 'ai-chat'],
      },
      {
        id: 'llm-setup',
        title: 'LLM Configuration',
        description: 'Set up and configure your LLM provider for AI features',
        content: `WORBI supports any OpenAI-compatible API for AI features.

**Configuring Your LLM:**
1. Open Settings → LLM tab
2. Select a provider preset or choose "Custom"
3. Enter your API base URL and API key (if required)
4. Click "Test Connection" to verify
5. Select a model from the dropdown
6. Save settings

**Provider Presets (16 available):**

**Local:**
- LM Studio (localhost:1234)
- Ollama (localhost:11434)
- llama.cpp (localhost:8080)
- TextGen WebUI (localhost:5000)
- LocalAI (localhost:8080)
- Jan (localhost:1337)
- vLLM (localhost:8000)

**Cloud:**
- OpenAI, Groq, Together AI, OpenRouter, Mistral, xAI
- Anthropic ⚠, Google AI Studio ⚠

**Connection Status:**
- 🟢 Connected — Server responding with loaded models
- 🟡 Reachable but no models — Server up, no models loaded
- 🔴 Failed — Connection unsuccessful
- Gray — Not tested yet

> ⚠ Anthropic and Google use non-OpenAI APIs and may require a custom adapter.`,
        relatedArticles: ['ai-chat', 'installation'],
      },
    ],
  },
  {
    id: 'organization',
    name: 'Organization',
    icon: '📁',
    articles: [
      {
        id: 'file-explorer',
        title: 'File Explorer',
        description: 'Navigate, create, and manage your workspace files and folders',
        content: `The File Explorer provides a tree view of your workspace.

**Default Folders:**
WORBI creates these folders automatically:
- **MainStory** — Your primary narrative documents
- **Quests** — Quest outlines and adventure content
- **Characters** — Character sheets and profiles
- **World** — Locations, lore, and world-building

**File Operations:**
- **Create** — New files and folders
- **Rename** — Rename files and folders
- **Delete** — Remove files and folders (with confirmation)
- **Copy** — Duplicate files within the workspace
- **Move** — Move files between folders
- **Download** — Download files as HTML

**Undo/Redo:**
File operations support undo/redo:
- Create, delete, rename, copy, move operations can be undone
- Uses a file system undo/redo stack

**System Files:**
- \`.wbu_meta.json\` support files are hidden by default
- Only user-created files are shown

**New Files:**
- Auto-appends \`.html\` extension for new files
- Files are created in the currently selected folder`,
        shortcuts: [],
        relatedArticles: ['workspace-layout', 'starred-files'],
      },
      {
        id: 'tags',
        title: 'Tags & Tag Relationships',
        description: 'Organize documents with color-coded tags and discover connections',
        content: `**Creating Tags:**
- Open the Tags view in the Activity Bar
- Click "Add Tag" to create a new tag
- Choose a color for the tag from the color picker
- Tags are color-coded for visual organization

**Applying Tags:**
- Open a document's Information Panel
- In the TAGS section, click to add tags
- Multiple tags can be applied to any document
- Tags display with their defined color in the panel

**Filtering by Tags:**
- Use the tag filter in the Tags sidebar
- Click a tag to filter the file explorer
- Only files with the selected tag are shown

**Tag Relationships:**
- **Implicit** — Files sharing the same tag are connected
- **Explicit** — Define explicit connections between tags
- Relationships shown in the Relationship Graph view

**Tag Colors:**
Each tag has a defined color used consistently across:
- Tag badges in the Information Panel
- Timeline event dots
- Graph node labels
- File explorer indicators`,
        shortcuts: [],
        relatedArticles: ['relationship-graph', 'timeline'],
      },
      {
        id: 'starred-files',
        title: 'Starred Files (Favorites)',
        description: 'Mark files as favorites for quick access',
        content: `**Starring Files:**
- Click the star icon next to a file in the Explorer
- Starred files appear in the Starred Files view
- Also shown on the Welcome screen

**Accessing Starred Files:**
- Click the Star icon in the Activity Bar
- Browse the Favorites section on the Welcome screen
- Click a file to open it immediately

**Managing Stars:**
- Hover over a starred file to reveal the remove button
- Click X to remove from favorites
- Stars are persisted in localStorage`,
        shortcuts: [],
        relatedArticles: ['file-explorer', 'welcome-screen'],
      },
      {
        id: 'timeline',
        title: 'Timeline View',
        description: 'Browse events chronologically, organized by era',
        content: `The Timeline View provides a chronological browser for your world's events.

**How It Works:**
- Documents with Date/Period + Era fields are automatically detected
- Scans the entire workspace (any folder)
- Events are grouped by era and sorted chronologically

**Setting Timeline Metadata:**
- Open a document's Information Panel
- In the Timeline section:
  - **Era** — Select or type an era name
  - **Date/Period** — Enter a date number
- Selecting an era auto-fills the next sequential date

**Timeline Features:**
- **Era Headers** — Click to expand/collapse era groups
- **Tag-Colored Dots** — Event dots use the document's tag colors
- **NoTag Label** — Events without tags show "NoTag"
- **Collapsible Eras** — Organize by clicking era headers

**Settings:**
- Click the gear icon in the Timeline header
- **Era Order** — Define custom era ordering
- **Date Format** — Configure how dates display

**Filters:**
- **Era Filter** — Select specific eras to show
- **Tag Filter** — Filter by tag categories
- Untagged events always appear even with tag filters active`,
        shortcuts: [],
        relatedArticles: ['tags', 'information-panel'],
      },
      {
        id: 'bookmarks',
        title: 'Outline & Bookmarks',
        description: 'Quick-navigate document headings and create permanent bookmarks',
        content: `The Outline panel (Book icon in Activity Bar) shows all headings in the active document.

**Headings:**
- Automatically detects H1, H2, and H3 headings
- Updates in real-time as you edit
- Click any heading to scroll to it with smooth animation
- Brief purple highlight on navigation target

**Manual Bookmarks:**
- Press Ctrl+Shift+M to pin current cursor position
- Auto-generated label based on context
- Bookmarks are permanent (survive page reloads)

**Bookmark Management:**
- Per-file persistence stored in localStorage
- Hover to reveal remove button
- Delete unwanted bookmarks with one click

**Empty States:**
- Helpful guidance when no document is open
- Hints when no headings are found in the current document`,
        shortcuts: [
          { keys: 'Ctrl+Shift+M', description: 'Create bookmark at cursor' },
        ],
        relatedArticles: ['two-column', 'editor-basics'],
      },
      {
        id: 'relationship-graph',
        title: 'Relationship Graph',
        description: 'Visualize document connections as an interactive force-directed graph',
        content: `The Relationship Graph visualizes connections between your documents using Cytoscape.js.

**Opening the Graph:**
- Click the GitGraph icon in the Activity Bar
- Or click "Open Graph" link in the DocumentEditor header

**Graph Types (5 views):**
- **Full Graph** — All document connections
- **Character Network** — Character-to-character connections
- **Location Map** — Location-based connections
- **Thematic Links** — Theme-based connections
- **Tag-Based Only** — Connections from shared tags (no AI needed)

**Relationship Types (5 categories):**
- Character Connection (amber)
- Location (green)
- Thematic (purple)
- Narrative (blue)
- Tag-Based (gray dashed)

**Node Interaction:**
- Click a node to open its document
- Drag nodes to rearrange
- Hover for tooltips with tags and metadata
- Timeline metadata shown in tooltips when available

**Filtering:**
- Filter by tags in the sidebar
- Filter by relationship types
- Filter by era (select specific eras to include)

**Controls:**
- Resizable, draggable modal
- Maximize, zoom, pan, and re-layout buttons
- Smart caching to localStorage for fast reload

**AI Requirements:**
- LLM-powered for most graph types
- Greyed out when AI is offline
- Tag-Based Only works without AI`,
        shortcuts: [],
        relatedArticles: ['tags', 'wikilinks', 'timeline'],
      },
      {
        id: 'workspace-search',
        title: 'Workspace Search',
        description: 'Full-text search across all workspace documents',
        content: `**Opening Search:**
- Click the magnifying glass icon in the Activity Bar

**Search Features:**
- Full-text search across all workspace text files
- Debounced input for responsive searching
- Results shown with file path and matching line
- Click a result to open the file at the match location

**Search Scope:**
- Searches all text files in your workspace
- Includes document content, not just file names
- Results update in real-time as you type`,
        shortcuts: [],
        relatedArticles: ['find-replace', 'file-explorer'],
      },
      {
        id: 'story-bible',
        title: 'Story Bible Compiler',
        description: 'Compile your workspace into a single reference document',
        content: `The Story Bible Compiler creates a single HTML document from your workspace.

**How to Use:**
1. Open the compiler from the toolbar or menu
2. Select files to include:
   - Individual files
   - Entire folders
   - Entire workspace
3. Configure compilation options
4. Click Compile

**Compilation Options:**
- **Table of Contents** — With anchor links for navigation
- **Section Dividers** — Visual separators between documents
- **File Path Subtitles** — Show source paths in the output
- **Margin Note Exclusion** — Exclude margin column content
- **Ordering** — By folder, alphabetical, or last modified

**Use Cases:**
- Create print-ready world bibles
- Compile character compendiums
- Generate quest reference guides
- Export for sharing with collaborators`,
        shortcuts: [],
        relatedArticles: ['export-import'],
      },
    ],
  },
  {
    id: 'settings',
    name: 'Settings',
    icon: '⚙️',
    articles: [
      {
        id: 'settings-overview',
        title: 'Settings Overview',
        description: 'Configure WORBI behavior, appearance, and integrations',
        content: `WORBI Settings are organized into 5 tabs:

**LLM Tab:**
- Provider selection (16 presets + custom)
- API base URL and API key
- Model selection
- Connection testing

**Tools Tab:**
- Web search toggle
- File access level (none/read/readwrite/full)
- Granular permissions (create, edit, delete, rename)
- Max search results slider

**Images Tab:**
- Z-Image server status
- Start/stop server controls
- Model info
- Minimum free VRAM threshold

**Editor Tab:**
- Max open tabs setting
- Editor behavior preferences

**Appearance Tab:**
- Theme presets (6 available)
- Light/dark mode toggle
- Full color customization (13 colors)
- Live preview
- Reset to default

Settings are saved per-user and persisted across sessions.`,
        shortcuts: [],
        relatedArticles: ['llm-setup', 'tool-permissions', 'appearance'],
      },
      {
        id: 'tool-permissions',
        title: 'AI Tool Permissions',
        description: 'Control what actions the AI can perform on your workspace',
        content: `**Access Settings → Tools tab to manage permissions.**

**Web Search:**
- Toggle on/off to allow AI internet research
- Max search results configurable (1-20)

**File Access Levels:**

| Level | Read | Create | Edit | Delete | Rename |
|-------|------|--------|------|--------|--------|
| none | ❌ | ❌ | ❌ | ❌ | ❌ |
| read | ✅ | ❌ | ❌ | ❌ | ❌ |
| readwrite | ✅ | ✅* | ✅* | ❌ | ❌ |
| full | ✅ | ✅* | ✅* | ✅* | ✅* |

*Requires corresponding granular toggle enabled.

**Granular Permissions:**
- Allow file creation
- Allow file modification (readwrite+)
- Allow file deletion (full only, off by default)
- Allow file/folder renaming (full only)

**Quick Toggle:**
- ⚡ button in chat header enables/disables all tools
- Status cards show tool activity in real-time`,
        shortcuts: [],
        relatedArticles: ['ai-tools', 'settings-overview'],
      },
      {
        id: 'appearance',
        title: 'Appearance & Themes',
        description: 'Customize WORBI look with presets and full color control',
        content: `**Access Settings → Appearance tab to customize your theme.**

**Theme Presets (6 available):**
- **Purple Mist** (default) — Subtle purple accents
- **Nord** — Cool blue-grey tones
- **Gruvbox** — Warm retro colors
- **Dracula** — Dark with vibrant accents
- **Ocean** — Deep blue tones
- **Rose** — Pink/red accents

**Light/Dark Mode:**
- Smooth animated toggle
- 3 presets include dedicated light variants (Purple Mist, Nord, Ocean)

**Full Color Customization:**
13 individually customizable colors:
- Background, Text, Panels, Panel Text
- Borders, Input BG, Muted BG, Muted Text
- Primary, Primary Text, Danger, Success, Warning

**Live Preview:**
- Real-time preview panel
- Shows buttons, status dots, and input fields
- Updates as you adjust colors

**Persistence:**
- Theme settings saved to localStorage
- Restored automatically on app startup
- One-click reset to restore Purple Mist default

**Technical:**
- All colors applied as CSS custom properties
- Variables: --bg, --fg, --primary, etc.
- Consistent theming across all components`,
        shortcuts: [],
        relatedArticles: ['settings-overview'],
      },
    ],
  },
  {
    id: 'shortcuts',
    name: 'Keyboard Shortcuts',
    icon: '⌨️',
    articles: [
      {
        id: 'all-shortcuts',
        title: 'All Keyboard Shortcuts',
        description: 'Complete reference of all keyboard shortcuts in WORBI',
        content: `**App Shortcuts:**

| Shortcut | Action |
|----------|--------|
| Ctrl+S / Cmd+S | Save file |
| Ctrl+Shift+N | New from Template |
| Ctrl+Shift+M | Create bookmark at cursor |
| F1 | Open Help (coming soon) |
| Esc | Close modals / dismiss suggestions |

**Editor Shortcuts:**

| Shortcut | Action |
|----------|--------|
| Ctrl+B | Bold |
| Ctrl+I | Italic |
| Ctrl+U | Underline |
| Ctrl+F | Find |
| Ctrl+H | Find & Replace |

**AI Shortcuts:**

| Shortcut | Action |
|----------|--------|
| Ctrl+Space | Trigger AI ghost text |
| Tab | Accept AI suggestion |
| Esc | Dismiss AI suggestion |

**Customizing Shortcuts:**
- Open Settings → Keyboard tab
- 7 programmable shortcuts available
- Click any shortcut to record a new key combination
- Conflict detection warns about duplicate bindings
- Reset individual or all shortcuts to defaults
- Custom bindings saved to localStorage

**Rebindable Shortcuts:**
- Save
- New from Template
- Find
- Find & Replace
- AI Complete
- Accept AI Suggestion
- Decline AI Suggestion

**Platform Display:**
- Ctrl shown as ⌘ on macOS
- Win shown on Windows for Meta key`,
        shortcuts: [
          { keys: 'Ctrl+S', description: 'Save file' },
          { keys: 'Ctrl+B', description: 'Bold' },
          { keys: 'Ctrl+I', description: 'Italic' },
          { keys: 'Ctrl+Space', description: 'AI ghost text' },
          { keys: 'Tab', description: 'Accept AI suggestion' },
          { keys: 'Esc', description: 'Dismiss AI suggestion' },
          { keys: 'Ctrl+F', description: 'Find' },
          { keys: 'Ctrl+H', description: 'Find & Replace' },
          { keys: 'Ctrl+Shift+N', description: 'New from Template' },
          { keys: 'Ctrl+Shift+M', description: 'Create bookmark' },
        ],
        relatedArticles: ['settings-overview'],
      },
    ],
  },
  {
    id: 'import-export',
    name: 'Import & Export',
    icon: '💾',
    articles: [
      {
        id: 'export-import',
        title: 'Import & Export',
        description: 'Import DOCX files and export to PDF or DOCX',
        content: `**Import:**

**DOCX Import:**
- Click File → Import DOCX
- Or drag a .docx file into WORBI
- Uses mammoth.js for conversion
- Content imported as HTML into the editor

**Export:**

**PDF Export:**
- Renders editor content as print-ready PDF
- Uses html2pdf.js for generation
- Ideal for world bibles and reference documents

**DOCX Export:**
- Export editor content as .docx file
- Edit offline in Microsoft Word
- Preserves formatting and structure

**Story Bible Export:**
- Compile multiple files into a single document
- Includes table of contents and section dividers
- See "Story Bible Compiler" for details`,
        shortcuts: [],
        relatedArticles: ['story-bible'],
      },
    ],
  },
];

// Helper: get all articles flat for search
export function getAllArticles(): HelpArticle[] {
  return HELP_CATEGORIES.flatMap(cat => cat.articles);
}

// Helper: find article by id
export function getArticleById(id: string): HelpArticle | undefined {
  for (const cat of HELP_CATEGORIES) {
    const article = cat.articles.find(a => a.id === id);
    if (article) return article;
  }
  return undefined;
}

// Helper: find category by article id
export function getCategoryForArticle(articleId: string): HelpCategory | undefined {
  return HELP_CATEGORIES.find(cat => cat.articles.some(a => a.id === articleId));
}

// Helper: search articles by query
export function searchArticles(query: string): HelpArticle[] {
  const q = query.toLowerCase().trim();
  if (!q) return [];
  return getAllArticles().filter(article =>
    article.title.toLowerCase().includes(q) ||
    article.description.toLowerCase().includes(q) ||
    article.content.toLowerCase().includes(q) ||
    article.shortcuts?.some(s => s.keys.toLowerCase().includes(q) || s.description.toLowerCase().includes(q))
  );
}

// Helper: get display keys for current platform
export function formatShortcut(keys: string): string {
  if (typeof navigator === 'undefined') return keys;
  const isMac = navigator.userAgent.includes('Mac');
  if (isMac) {
    return keys.replace(/Ctrl/g, '⌘').replace(/Alt/g, '⌥').replace(/Shift/g, '⇧');
  }
  return keys;
}