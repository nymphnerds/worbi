import { useState, useCallback, useEffect } from 'react';
import { X, Check, AlertCircle, Settings as SettingsIcon, Zap, Shield, RefreshCw, Eye, EyeOff, Sparkles, Palette, Play, Square, Cpu, Search, Tags, MapPin, Clock, ListTree, GitGraph, Image as ImageIcon, Bell, LayoutPanelLeft } from 'lucide-react';
import { useLLM } from '../hooks/useLLM';
import { getMaxTabs, setMaxTabs } from '../hooks/useFiles';
import { ThemePicker } from '../components/ThemePicker';
import type { ToolPermissions, ImageGenStatus as ImageGenStatusType, LlmServerStatus, DetectedLlmServer } from '../services/api';
import { getImageGenerationStatus, testZImageConnection, saveUserSettings, getLlmServerStatus, startLlmServer, stopLlmServer, detectLlmServers } from '../services/api';

// Static provider presets for manual selection

const PROVIDER_PRESETS = [
  // Local providers
  { id: 'lm-studio', name: 'LM Studio', group: 'local', defaultUrl: 'http://localhost:1234/v1', requiresApiKey: false },
  { id: 'ollama', name: 'Ollama', group: 'local', defaultUrl: 'http://localhost:11434/v1', requiresApiKey: false },
  { id: 'llama-cpp', name: 'llama.cpp', group: 'local', defaultUrl: 'http://localhost:8080/v1', requiresApiKey: false },
  { id: 'textgen-webui', name: 'TextGen WebUI', group: 'local', defaultUrl: 'http://localhost:5000/v1', requiresApiKey: false },
  { id: 'localai', name: 'LocalAI', group: 'local', defaultUrl: 'http://localhost:8080/v1', requiresApiKey: false },
  { id: 'jan', name: 'Jan', group: 'local', defaultUrl: 'http://localhost:1337/v1', requiresApiKey: false },
  { id: 'vllm', name: 'vLLM', group: 'local', defaultUrl: 'http://localhost:8000/v1', requiresApiKey: false },
  // Cloud providers
  { id: 'openai', name: 'OpenAI', group: 'cloud', defaultUrl: 'https://api.openai.com/v1', requiresApiKey: true },
  { id: 'groq', name: 'Groq', group: 'cloud', defaultUrl: 'https://api.groq.com/openai/v1', requiresApiKey: true },
  { id: 'together', name: 'Together AI', group: 'cloud', defaultUrl: 'https://api.together.xyz/v1', requiresApiKey: true },
  { id: 'openrouter', name: 'OpenRouter', group: 'cloud', defaultUrl: 'https://openrouter.ai/api/v1', requiresApiKey: true },
  { id: 'mistral', name: 'Mistral', group: 'cloud', defaultUrl: 'https://api.mistral.ai/v1', requiresApiKey: true },
  { id: 'anthropic', name: 'Anthropic', group: 'cloud', defaultUrl: 'https://api.anthropic.com/v1', requiresApiKey: true, warning: 'Anthropic uses a non-OpenAI-compatible API. Model loading and chat may not work without a custom adapter.' },
  { id: 'xai', name: 'xAI (Grok)', group: 'cloud', defaultUrl: 'https://api.x.ai/v1', requiresApiKey: true },
  { id: 'google', name: 'Google AI Studio', group: 'cloud', defaultUrl: 'https://generativelanguage.googleapis.com/v1', requiresApiKey: true, warning: 'Google AI Studio uses a non-OpenAI-compatible API. Model loading and chat may not work without a custom adapter.' },
  // Custom
  { id: 'custom', name: 'Custom (any OpenAI-compatible server)', group: 'other', defaultUrl: '', requiresApiKey: false },
];

type SettingsTab = 'llm' | 'tools' | 'images' | 'editor' | 'appearance';

interface SettingsProps {
  onClose: () => void;
}

const inputClass = 'w-full rounded-md bg-[#2a2a3a] px-3 py-2 text-sm text-[#e0e0e0] focus:outline-none focus:ring-1 focus:ring-[#a78bfa]';

const selectClass = `${inputClass} appearance-none cursor-pointer`;

// Connection status helpers
const statusColor = (status: string): string => {
  switch (status) {
    case 'connected': return 'text-green-400';
    case 'reachable-no-models': return 'text-yellow-400';
    case 'failed': return 'text-red-400';
    case 'testing': return 'text-[#888]';
    default: return 'text-[#666]';
  }
};

const statusText = (status: string, modelName: string): string => {
  switch (status) {
    case 'connected': return modelName ? `Connected — ${modelName}` : 'Connected';
    case 'reachable-no-models': return 'Server reachable but no models';
    case 'failed': return 'Connection failed';
    case 'testing': return 'Testing connection...';
    default: return 'Not tested';
  }
};

const dotClass = (status: string): string => {
  switch (status) {
    case 'connected': return 'bg-green-400';
    case 'reachable-no-models': return 'bg-yellow-400';
    case 'failed': return 'bg-red-400';
    case 'testing': return 'bg-[#888] animate-pulse';
    default: return 'bg-[#444]';
  }
};

export function Settings({ onClose }: SettingsProps) {
  const {
    settings,
    loading,
    error,
    models,
    testing,
    updateSettings,
    saveUserSettings,
    testConn,
    loadModels,
    toolPermissions,
    updateToolPermissions,
    saveToolPermissions,
    connectionStatus,
  } = useLLM();

  const [activeTab, setActiveTab] = useState<SettingsTab>('llm');
  const [saved, setSaved] = useState(false);
  const [maxTabs, setMaxTabsState] = useState(getMaxTabs());
  const [showApiKey, setShowApiKey] = useState(false);

  // Sidebar visibility settings
  const SIDEBAR_ICONS = [
    { key: 'tags' as const, label: 'Tags', icon: Tags },
    { key: 'locations' as const, label: 'Locations', icon: MapPin },
    { key: 'timeline' as const, label: 'Timeline', icon: Clock },
    { key: 'outline' as const, label: 'Outline', icon: ListTree },
    { key: 'graph' as const, label: 'Relationship Graph', icon: GitGraph },
    { key: 'images' as const, label: 'Image Generator', icon: ImageIcon },
    { key: 'reminders' as const, label: 'Reminders', icon: Bell },
    { key: 'ai' as const, label: 'AI Panel', icon: Sparkles },
  ];

  const DEFAULT_VISIBILITY: Record<string, boolean> = {
    tags: false, locations: false, timeline: false, outline: false,
    graph: false, images: false, reminders: false, ai: false,
  };

  const [sidebarVisibility, setSidebarVisibility] = useState(() => {
    try {
      const stored = localStorage.getItem('wbu_sidebar_visibility');
      if (stored) {
        const parsed = JSON.parse(stored);
        return { ...DEFAULT_VISIBILITY, ...parsed };
      }
    } catch { /* ignore */
    }
    return { ...DEFAULT_VISIBILITY };
  });

  const handleToggleVisibility = useCallback((key: string) => {
    setSidebarVisibility((prev: Record<string, boolean>) => {
      const next = { ...prev, [key]: !prev[key] };
      try { localStorage.setItem('wbu_sidebar_visibility', JSON.stringify(next)); } catch { /* ignore */ }
      window.dispatchEvent(new Event('wbu-sidebar-visibility-change'));
      return next;
    });
  }, []);

  // LLM Operation Mode (managed vs external) - stored in localStorage
  const [llmMode, setLlmMode] = useState(() => {
    try {
      return localStorage.getItem('wbu_llm_mode') || 'managed';
    } catch {
      return 'managed';
    }
  });
  const [llmFolderPath, setLlmFolderPath] = useState(() => {
    try {
      return localStorage.getItem('wbu_llm_folder') || '';
    } catch {
      return '';
    }
  });
  const [llmConfigSaved, setLlmConfigSaved] = useState(false);

  const saveLlmConfig = useCallback(() => {
    localStorage.setItem('wbu_llm_mode', llmMode);
    localStorage.setItem('wbu_llm_folder', llmFolderPath);
    setLlmConfigSaved(true);
    setTimeout(() => setLlmConfigSaved(false), 2000);
  }, [llmMode, llmFolderPath]);

  // Track if maxTokens was auto-adjusted
  const [maxTokensAdjusted, setMaxTokensAdjusted] = useState(false);
  const clearMaxTokensAdjusted = useCallback(() => setMaxTokensAdjusted(false), []);

  // Helper: calculate suggested maxTokens from context window
  const suggestedMaxTokens = (contextWindow: number) => Math.floor(contextWindow * 0.5);

  // UI-only state for form fields (commit to settings on save)
  const [formProviderId, setFormProviderId] = useState(settings.providerId);
  const [formBaseUrl, setFormBaseUrl] = useState(settings.baseUrl);
  const [formApiKey, setFormApiKey] = useState(settings.apiKey);
  const [formModelName, setFormModelName] = useState(settings.modelName);
  const [testError, setTestError] = useState<string | null>(null);

  // Sync form state when settings change
  useEffect(() => {
    setFormProviderId(settings.providerId);
    setFormBaseUrl(settings.baseUrl);
    setFormApiKey(settings.apiKey);
    setFormModelName(settings.modelName);
  }, [settings.providerId, settings.baseUrl, settings.apiKey, settings.modelName]);

  const handleMaxTabsChange = useCallback((val: number) => {
    const clamped = Math.max(1, Math.min(50, val));
    setMaxTabsState(clamped);
    setMaxTabs(clamped);
  }, []);

  const handleSave = useCallback(async () => {
    // Build merged settings with current form values to avoid stale closure
    const merged = {
      ...settings,
      providerId: formProviderId,
      baseUrl: formBaseUrl,
      apiKey: formApiKey,
      modelName: formModelName,
      serverType: formProviderId === 'ollama' ? 'ollama' : '',
    };
    // Commit form values to settings state
    updateSettings(merged);
    // Pass merged settings directly to avoid stale closure
    await saveUserSettings(merged);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }, [formProviderId, formBaseUrl, formApiKey, formModelName, settings, updateSettings, saveUserSettings]);

  const handleSavePermissions = useCallback(async () => {
    await saveToolPermissions(toolPermissions);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }, [saveToolPermissions, toolPermissions]);

  const handleProviderChange = useCallback((providerId: string) => {
    setFormProviderId(providerId);

    // Find the provider in presets
    const preset = PROVIDER_PRESETS.find((p) => p.id === providerId);
    if (preset && preset.defaultUrl) {
      setFormBaseUrl(preset.defaultUrl);
    } else if (providerId === 'custom') {
      // Keep existing URL for custom
    }
  }, []);

  const handleTestConnection = useCallback(async () => {
    setTestError(null);
    updateSettings({
      providerId: formProviderId,
      baseUrl: formBaseUrl,
      apiKey: formApiKey,
      serverType: formProviderId === 'ollama' ? 'ollama' : '',
    });
    await testConn();
    // After test, load models if success
    if (connectionStatus === 'connected' || formBaseUrl) {
      loadModels(formBaseUrl, formApiKey, formProviderId === 'ollama' ? 'ollama' : '');
    }
  }, [formProviderId, formBaseUrl, formApiKey, testConn, loadModels, connectionStatus, updateSettings]);

  const handleRefreshModels = useCallback(async () => {
    loadModels(formBaseUrl, formApiKey, formProviderId === 'ollama' ? 'ollama' : '');
  }, [formBaseUrl, formApiKey, formProviderId, loadModels]);

  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    if (e.key === 'Escape') onClose();
  }, [onClose]);

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown]);

  const toggleRow = "flex items-center justify-between py-3 border-b border-[#2a2a3a]";

  const maskApiKey = (key: string): string => {
    if (!key) return '';
    if (key.length <= 8) return key.substring(0, 2) + '***';
    return key.substring(0, 4) + '*'.repeat(key.length - 8) + key.substring(key.length - 4);
  };

  // Group providers
  const localPresets = PROVIDER_PRESETS.filter((p) => p.group === 'local');
  const cloudPresets = PROVIDER_PRESETS.filter((p) => p.group === 'cloud');
  const otherPresets = PROVIDER_PRESETS.filter((p) => p.group === 'other');

  // Check if selected provider requires API key
  const selectedPreset = PROVIDER_PRESETS.find((p) => p.id === formProviderId);
  const requiresApiKey = selectedPreset?.requiresApiKey || false;
  const providerWarning = selectedPreset?.warning;

  return (
    <div className="flex flex-col h-full bg-[#1e1e2e]">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-[#3a3a4a]">
        <h2 className="text-sm font-semibold text-[#e0e0e0]">Settings</h2>
        <button
          onClick={onClose}
          className="p-1 rounded hover:bg-[#2a2a3a] transition-colors text-[#e0e0e0]"
        >
          <X size={16} />
        </button>
      </div>

      {/* Settings Tabs */}
      <div className="flex border-b border-[#3a3a4a] overflow-x-auto scrollbar-thin">
        {([
          { key: 'llm' as SettingsTab, label: 'LLM', icon: SettingsIcon },
          { key: 'tools' as SettingsTab, label: 'Tools', icon: Zap },
          { key: 'images' as SettingsTab, label: 'Images', icon: Sparkles },
          { key: 'editor' as SettingsTab, label: 'Editor', icon: SettingsIcon },
          { key: 'appearance' as SettingsTab, label: 'Appearance', icon: Palette },
        ]).map(({ key, label, icon: Icon }) => (
          <button
            key={key}
            onClick={() => setActiveTab(key)}
            className={`flex-shrink-0 flex items-center gap-2 px-6 py-3 text-sm font-medium transition-colors border-b-2 ${
              activeTab === key
                ? 'border-[#a78bfa] text-white'
                : 'border-transparent text-[#4a4a5a] hover:text-[#6a6a7a]'
            }`}
          >
            <Icon size={18} />
            {label}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-6 max-w-2xl">
        {/* === LLM Tab === */}
        {activeTab === 'llm' && (
          <>
            {(error || testError) && (
              <div className="flex items-center gap-2 mb-4 p-3 rounded-md bg-red-500/10 text-red-400 text-sm">
                <AlertCircle size={16} />
                {testError || error}
              </div>
            )}

            {providerWarning && (
              <div className="flex items-start gap-2 mb-4 p-3 rounded-md bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300">
                <AlertCircle size={16} className="mt-0.5 flex-shrink-0" />
                <p>{providerWarning}</p>
              </div>
            )}

            <div className="space-y-5">
              {/* Provider Selection */}
              <div>
                <label className="block text-xs font-medium mb-1.5 text-[#e0e0e0] uppercase tracking-wider">Provider</label>
                <select
                  value={formProviderId}
                  onChange={(e) => handleProviderChange(e.target.value)}
                  className={`${selectClass} w-full`}
                >
                  <optgroup label="Local (no API key)">
                    {localPresets.map((p) => (
                      <option key={p.id} value={p.id}>{p.name}</option>
                    ))}
                  </optgroup>
                  <optgroup label="Cloud (API key required)">
                    {cloudPresets.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name}{p.warning ? ' ⚠' : ''}
                      </option>
                    ))}
                  </optgroup>
                  <optgroup label="Other">
                    {otherPresets.map((p) => (
                      <option key={p.id} value={p.id}>{p.name}</option>
                    ))}
                  </optgroup>
                </select>
                <p className="text-[11px] text-[#888] mt-1">Select a provider to auto-fill the URL below, then configure your connection.</p>
              </div>

              {/* Connection Mode — only for local/custom providers */}
              {!selectedPreset || selectedPreset.group !== 'cloud' ? (
                <div>
                  <label className="block text-xs font-medium mb-1.5 text-[#e0e0e0] uppercase tracking-wider">Connection Mode</label>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setLlmMode('managed')}
                      className={`px-3 py-1.5 text-xs rounded-md transition-colors ${
                        llmMode === 'managed'
                          ? 'bg-[#a78bfa] text-white'
                          : 'bg-[#2a2a3a] text-[#e0e0e0] hover:bg-[#3a3a4a]'
                      }`}
                    >
                      Managed (WORBI controls)
                    </button>
                    <button
                      onClick={() => setLlmMode('external')}
                      className={`px-3 py-1.5 text-xs rounded-md transition-colors ${
                        llmMode === 'external'
                          ? 'bg-[#a78bfa] text-white'
                          : 'bg-[#2a2a3a] text-[#e0e0e0] hover:bg-[#3a3a4a]'
                      }`}
                    >
                      External (User-managed)
                    </button>
                  </div>
                  <p className="text-[11px] text-[#888] mt-1">
                    {llmMode === 'managed'
                      ? 'WORBI starts/stops your LLM server automatically.'
                      : 'You manage the server manually; WORBI connects to the URL below.'}
                  </p>
                </div>
              ) : null}

              {/* URL — shown for cloud providers or external local mode */}
              {selectedPreset?.group === 'cloud' || llmMode === 'external' ? (
                <div>
                  <label className="block text-xs font-medium mb-1.5 text-[#e0e0e0] uppercase tracking-wider">URL</label>
                  <input
                    type="text"
                    value={formBaseUrl}
                    onChange={(e) => setFormBaseUrl(e.target.value)}
                    placeholder="http://localhost:1234/v1"
                    className={inputClass}
                  />
                  <p className="text-[11px] text-[#888] mt-1">Base URL for the LLM API endpoint.</p>
                </div>
              ) : null}

              {/* API Key — shown when URL is visible */}
              {selectedPreset?.group === 'cloud' || llmMode === 'external' ? (
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="block text-xs font-medium text-[#e0e0e0] uppercase tracking-wider">
                      API Key {requiresApiKey ? <span className="text-red-400">*</span> : '(optional)'}
                    </label>
                  </div>
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <input
                        type={showApiKey ? 'text' : 'password'}
                        value={formApiKey}
                        onChange={(e) => setFormApiKey(e.target.value)}
                        placeholder={requiresApiKey ? 'Enter your API key' : 'Optional — for local servers leave empty'}
                        className={`${inputClass} pr-8`}
                      />
                      <button
                        onClick={() => setShowApiKey(!showApiKey)}
                        className="absolute right-2 top-1/2 -translate-y-1/2 text-[#888] hover:text-[#e0e0e0]"
                        title={showApiKey ? 'Hide key' : 'Show key'}
                      >
                        {showApiKey ? <EyeOff size={14} /> : <Eye size={14} />}
                      </button>
                    </div>
                  </div>
                  {formApiKey && formApiKey.length > 4 && (
                    <p className="text-[11px] text-[#888] mt-1">Masked: {maskApiKey(formApiKey)}</p>
                  )}
                </div>
              ) : null}

              {/* Managed Local — Folder Path + Server Management */}
              {llmMode === 'managed' && selectedPreset?.group !== 'cloud' ? (
                <>
                  <div>
                    <label className="block text-xs font-medium mb-1.5 text-[#e0e0e0] uppercase tracking-wider">LLM Installation Folder</label>
                    <input
                      type="text"
                      value={llmFolderPath}
                      onChange={(e) => setLlmFolderPath(e.target.value)}
                      placeholder="~/llama.cpp (default)"
                      className={inputClass}
                    />
                    <p className="text-[11px] text-[#888] mt-1">
                      Path to your LLM server installation. Leave empty for default detection.
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={saveLlmConfig}
                      className="px-3 py-1.5 text-xs rounded-md bg-[#a78bfa]/20 text-[#a78bfa] hover:bg-[#a78bfa]/30 transition-colors"
                    >
                      {llmConfigSaved ? '✓ Saved!' : 'Save Configuration'}
                    </button>
                    {llmConfigSaved && (
                      <span className="text-[11px] text-green-400 flex items-center gap-1">
                        <Check size={12} /> Configuration saved
                      </span>
                    )}
                  </div>

                  <div className="border-t border-[#3a3a4a] pt-4">
                    <h3 className="text-xs font-semibold text-[#e0e0e0] mb-3 flex items-center gap-2">
                      <Cpu size={14} /> LLM Server (Managed)
                    </h3>
                    <p className="text-[11px] text-[#888] mb-3">
                      Start/stop a managed LLM server directly from WORBI.
                    </p>
                    <LlmServerStatusPanel serverType={providerToServerType(formProviderId)} />
                  </div>
                </>
              ) : null}

              {/* Model */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-medium text-[#e0e0e0] uppercase tracking-wider">Model</label>
                  <button
                    onClick={handleRefreshModels}
                    disabled={loading || !formBaseUrl}
                    className="p-1 rounded text-[#888] hover:text-[#e0e0e0] transition-colors disabled:opacity-50"
                    title="Refresh model list"
                  >
                    <RefreshCw size={13} className={loading ? 'animate-spin' : ''} />
                  </button>
                </div>
                <select
                  value={formModelName}
                  onChange={(e) => setFormModelName(e.target.value)}
                  disabled={!formBaseUrl}
                  className={`${selectClass} disabled:opacity-50`}
                >
                  {formModelName && !models.includes(formModelName) && (
                    <option key="saved" value={formModelName}>✓ {formModelName}</option>
                  )}
                  <option value="">-- Select a model --</option>
                  {models.map((m) => (
                    <option key={m} value={m}>{m}</option>
                  ))}
                </select>
                {!formBaseUrl && (
                  <p className="text-[11px] text-[#888] mt-1">Enter a provider URL above to load models.</p>
                )}
                {formBaseUrl && models.length === 0 && !loading && connectionStatus === 'failed' && (
                  <p className="text-[11px] text-yellow-400 mt-1">⚠ Could not load models. Check URL and click Refresh.</p>
                )}
              </div>

              {/* Connection Status */}
              <div>
                <div className="flex items-center gap-3">
                  <div className={`w-2.5 h-2.5 rounded-full ${dotClass(connectionStatus)}`} />
                  <span className={`text-xs font-medium ${statusColor(connectionStatus)}`}>
                    {statusText(connectionStatus, formModelName)}
                  </span>
                  <button
                    onClick={handleTestConnection}
                    disabled={testing || !formBaseUrl}
                    className="ml-auto px-3 py-1.5 text-xs rounded-md bg-[#a78bfa]/20 text-[#a78bfa] hover:bg-[#a78bfa]/30 transition-colors disabled:opacity-50"
                  >
                    {testing ? 'Testing...' : 'Test Connection'}
                  </button>
                </div>
              </div>

              {/* Max Tokens */}
              <div>
                <label className="block text-xs font-medium mb-1.5 text-[#e0e0e0] uppercase tracking-wider">Max Tokens</label>
                <input
                  type="number"
                  value={settings.maxTokens}
                  onChange={(e) => updateSettings({ maxTokens: parseInt(e.target.value) || 4096 })}
                  className={inputClass}
                />
                <p className="text-[11px] text-[#888] mt-1">Maximum tokens in the LLM response.</p>
              </div>

              {/* Context Window Size */}
              <div>
                <label className="block text-xs font-medium mb-1.5 text-[#e0e0e0] uppercase tracking-wider">
                  Context Window Size: {settings.contextWindow?.toLocaleString() || '8,192'} tokens
                </label>
                <div className="flex gap-2 mb-2 flex-wrap">
                  {[4096, 8192, 16384, 32768, 128000].map((v) => (
                    <button
                      key={v}
                      onClick={() => {
                        const suggested = suggestedMaxTokens(v);
                        const newMax = Math.max(256, Math.min(suggested, settings.maxTokens > v ? suggested : settings.maxTokens));
                        if (newMax !== settings.maxTokens) {
                          setMaxTokensAdjusted(true);
                          setTimeout(() => setMaxTokensAdjusted(false), 3000);
                        }
                        updateSettings({ contextWindow: v, maxTokens: newMax });
                      }}
                      className={`px-2 py-1 text-xs rounded-md transition-colors ${
                        settings.contextWindow === v
                          ? 'bg-[#a78bfa] text-white'
                          : 'bg-[#2a2a3a] text-[#888] hover:text-[#e0e0e0]'
                      }`}
                    >
                      {v >= 1000 ? `${v / 1000}K` : v}
                    </button>
                  ))}
                  <input
                    type="number"
                    value={settings.contextWindow}
                    onChange={(e) => {
                      const cw = parseInt(e.target.value) || 8192;
                      const suggested = suggestedMaxTokens(cw);
                      const newMax = Math.max(256, Math.min(suggested, settings.maxTokens > cw ? suggested : settings.maxTokens));
                      if (newMax !== settings.maxTokens) {
                        setMaxTokensAdjusted(true);
                        setTimeout(() => setMaxTokensAdjusted(false), 3000);
                      }
                      updateSettings({ contextWindow: cw, maxTokens: newMax });
                    }}
                    className={`${inputClass} w-24`}
                    min={1024}
                    step={1}
                  />
                </div>
                {maxTokensAdjusted && (
                  <div className="flex items-center gap-1.5 mt-1 text-[11px] text-amber-300 animate-pulse">
                    <Zap size={11} />
                    Max Tokens auto-adjusted to fit context window
                  </div>
                )}
                <p className="text-[11px] text-[#888] mt-1">Your model's context window limit. Chat history is auto-trimmed to stay within this limit while reserving space for the document and system prompt.</p>
              </div>

              {/* Temperature */}
              <div>
                <label className="block text-xs font-medium mb-1.5 text-[#e0e0e0] uppercase tracking-wider">Temperature: {settings.temperature.toFixed(1)}</label>
                <input type="range" min="0" max="2" step="0.1" value={settings.temperature}
                  onChange={(e) => updateSettings({ temperature: parseFloat(e.target.value) })} className="w-full" />
                <div className="flex justify-between text-[10px] text-[#888] mt-0.5">
                  <span>Deterministic</span><span>Creative</span>
                </div>
              </div>

              {/* Advanced Inference */}
              <div className="border-t border-[#3a3a4a] pt-4">
                <h3 className="text-xs font-semibold mb-3 text-[#e0e0e0]">Advanced Inference</h3>

                <div className="mb-4">
                  <label className="block text-xs font-medium mb-1.5 text-[#e0e0e0] uppercase tracking-wider">Top P: {settings.topP.toFixed(2)}</label>
                  <input type="range" min="0" max="1" step="0.01" value={settings.topP}
                    onChange={(e) => updateSettings({ topP: parseFloat(e.target.value) })} className="w-full" />
                  <div className="flex justify-between text-[10px] text-[#888] mt-0.5">
                    <span>Focused</span><span>Diverse</span>
                  </div>
                </div>

                <div className="mb-4">
                  <label className="block text-xs font-medium mb-1.5 text-[#e0e0e0] uppercase tracking-wider">Top K: {settings.topK}</label>
                  <input type="range" min="0" max="100" step="1" value={settings.topK}
                    onChange={(e) => updateSettings({ topK: parseInt(e.target.value) })} className="w-full" />
                  <div className="flex justify-between text-[10px] text-[#888] mt-0.5">
                    <span>Restrictive</span><span>Open</span>
                  </div>
                </div>

                <div className="mb-4">
                  <label className="block text-xs font-medium mb-1.5 text-[#e0e0e0] uppercase tracking-wider">Frequency Penalty: {settings.frequencyPenalty.toFixed(1)}</label>
                  <input type="range" min="-2" max="2" step="0.1" value={settings.frequencyPenalty}
                    onChange={(e) => updateSettings({ frequencyPenalty: parseFloat(e.target.value) })} className="w-full" />
                  <div className="flex justify-between text-[10px] text-[#888] mt-0.5">
                    <span>Repeat more</span><span>Repeat less</span>
                  </div>
                </div>

                <div className="mb-4">
                  <label className="block text-xs font-medium mb-1.5 text-[#e0e0e0] uppercase tracking-wider">Presence Penalty: {settings.presencePenalty.toFixed(1)}</label>
                  <input type="range" min="-2" max="2" step="0.1" value={settings.presencePenalty}
                    onChange={(e) => updateSettings({ presencePenalty: parseFloat(e.target.value) })} className="w-full" />
                  <div className="flex justify-between text-[10px] text-[#888] mt-0.5">
                    <span>Stay on topic</span><span>Explore new topics</span>
                  </div>
                </div>
              </div>

              {/* System Prompt */}
              <div>
                <label className="block text-xs font-medium mb-1.5 text-[#e0e0e0] uppercase tracking-wider">System Prompt</label>
                <textarea
                  value={settings.systemPrompt}
                  onChange={(e) => updateSettings({ systemPrompt: e.target.value })}
                  rows={6}
                  className={`${inputClass} resize-y`}
                  placeholder="Enter system prompt..."
                />
                <p className="text-[11px] text-[#888] mt-1">This prompt is sent to the LLM as context before each conversation.</p>
              </div>

              {/* Save */}
              <div className="flex items-center gap-3 pt-3 border-t border-[#3a3a4a]">
                <button
                  onClick={handleSave}
                  disabled={loading}
                  className="flex items-center gap-1.5 px-4 py-2 text-xs rounded-md bg-[#a78bfa] text-white hover:bg-[#b89dfc] transition-all disabled:opacity-50 hover:scale-105 hover:brightness-110"
                >
                  {saved ? <Check size={14} /> : <SettingsIcon size={14} />}
                  {saved ? 'Saved!' : 'Save Settings'}
                </button>
              </div>
            </div>
          </>
        )}

        {/* === Tools Tab === */}
        {activeTab === 'tools' && (
          <div className="space-y-5">
            <div className="p-3 rounded-md bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300">
              <div className="flex items-start gap-2">
                <Zap size={16} className="mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium mb-1">AI Tool Permissions</p>
                  <p className="text-amber-300/80">Control what the AI assistant can do when tools are enabled. Toggle the ⚡ button in the chat header to activate/deactivate.</p>
                </div>
              </div>
            </div>

            {/* Web Search */}
            <div className={toggleRow}>
              <div>
                <p className="text-xs font-medium text-[#e0e0e0]">🔍 Web Search</p>
                <p className="text-[11px] text-[#888] mt-0.5">Allow AI to search the internet</p>
              </div>
              <label className="relative cursor-pointer" onClick={() => updateToolPermissions({ webSearch: !toolPermissions.webSearch })}>
                <div className={`block w-10 h-5 rounded-full transition-colors ${toolPermissions.webSearch ? 'bg-amber-500' : 'bg-[#3a3a4a]'}`}>
                  <div className={`absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full transition-transform ${toolPermissions.webSearch ? 'translate-x-5' : ''}`} />
                </div>
              </label>
            </div>

            {/* File Access Level */}
            <div>
              <label className="block text-xs font-medium mb-1.5 text-[#e0e0e0] uppercase tracking-wider">📄 File Access Level</label>
              <select
                value={toolPermissions.fileAccessLevel}
                onChange={(e) => updateToolPermissions({ fileAccessLevel: e.target.value as ToolPermissions['fileAccessLevel'] })}
                className={inputClass}
              >
                <option value="none">No file access</option>
                <option value="read">Read only (view files)</option>
                <option value="readwrite">Read + Write (edit files)</option>
                <option value="full">Full (create, edit, delete, rename)</option>
              </select>
              <p className="text-[11px] text-[#888] mt-1">Controls what the AI can do with workspace files.</p>
            </div>

            {/* Granular File Permissions */}
            {toolPermissions.fileAccessLevel !== 'none' && (
              <>
                <div className="border-t border-[#3a3a4a] pt-4">
                  <div className="flex items-center gap-2 mb-3">
                    <Shield size={14} className="text-[#a78bfa]" />
                    <h3 className="text-xs font-semibold text-[#e0e0e0]">Granular Permissions</h3>
                  </div>

                  {/* Allow Create */}
                  <div className={toggleRow}>
                    <div>
                      <p className="text-xs font-medium text-[#e0e0e0]">📝 Create Files</p>
                      <p className="text-[11px] text-[#888] mt-0.5">Allow AI to create new files</p>
                    </div>
                    <label className="relative cursor-pointer" onClick={() => updateToolPermissions({ allowCreate: !toolPermissions.allowCreate })}>
                      <div className={`block w-10 h-5 rounded-full transition-colors ${toolPermissions.allowCreate ? 'bg-amber-500' : 'bg-[#3a3a4a]'}`}>
                        <div className={`absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full transition-transform ${toolPermissions.allowCreate ? 'translate-x-5' : ''}`} />
                      </div>
                    </label>
                  </div>

                  {/* Allow Edit */}
                  {toolPermissions.fileAccessLevel !== 'read' && (
                    <div className={toggleRow}>
                      <div>
                        <p className="text-xs font-medium text-[#e0e0e0]">✏️ Edit Files</p>
                        <p className="text-[11px] text-[#888] mt-0.5">Allow AI to modify existing files</p>
                      </div>
                      <label className="relative cursor-pointer" onClick={() => updateToolPermissions({ allowEdit: !toolPermissions.allowEdit })}>
                        <div className={`block w-10 h-5 rounded-full transition-colors ${toolPermissions.allowEdit ? 'bg-amber-500' : 'bg-[#3a3a4a]'}`}>
                          <div className={`absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full transition-transform ${toolPermissions.allowEdit ? 'translate-x-5' : ''}`} />
                        </div>
                      </label>
                    </div>
                  )}

                  {/* Allow Delete */}
                  {toolPermissions.fileAccessLevel === 'full' && (
                    <div className={toggleRow}>
                      <div>
                        <p className="text-xs font-medium text-[#e0e0e0]">🗑️ Delete Files</p>
                        <p className="text-[11px] text-[#888] mt-0.5">Allow AI to delete files (cannot be undone)</p>
                      </div>
                      <label className="relative cursor-pointer" onClick={() => updateToolPermissions({ allowDelete: !toolPermissions.allowDelete })}>
                        <div className={`block w-10 h-5 rounded-full transition-colors ${toolPermissions.allowDelete ? 'bg-red-500' : 'bg-[#3a3a4a]'}`}>
                          <div className={`absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full transition-transform ${toolPermissions.allowDelete ? 'translate-x-5' : ''}`} />
                        </div>
                      </label>
                    </div>
                  )}

                  {/* Allow Rename */}
                  {toolPermissions.fileAccessLevel === 'full' && (
                    <div className={toggleRow}>
                      <div>
                        <p className="text-xs font-medium text-[#e0e0e0]">🔄 Rename Files</p>
                        <p className="text-[11px] text-[#888] mt-0.5">Allow AI to rename files and folders</p>
                      </div>
                      <label className="relative cursor-pointer" onClick={() => updateToolPermissions({ allowRename: !toolPermissions.allowRename })}>
                        <div className={`block w-10 h-5 rounded-full transition-colors ${toolPermissions.allowRename ? 'bg-amber-500' : 'bg-[#3a3a4a]'}`}>
                          <div className={`absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full transition-transform ${toolPermissions.allowRename ? 'translate-x-5' : ''}`} />
                        </div>
                      </label>
                    </div>
                  )}
                </div>

                {/* Max Search Results */}
                <div>
                  <label className="block text-xs font-medium mb-1.5 text-[#e0e0e0] uppercase tracking-wider">
                    🔍 Max Search Results: {toolPermissions.maxSearchResults}
                  </label>
                  <input
                    type="range"
                    min="1"
                    max="20"
                    step="1"
                    value={toolPermissions.maxSearchResults}
                    onChange={(e) => updateToolPermissions({ maxSearchResults: parseInt(e.target.value) })}
                    className="w-full"
                  />
                  <div className="flex justify-between text-[10px] text-[#888] mt-0.5">
                    <span>Fewer results</span>
                    <span>More results</span>
                  </div>
                </div>
              </>
            )}

            {/* Save */}
            <div className="flex items-center gap-3 pt-3 border-t border-[#3a3a4a]">
              <button
                onClick={handleSavePermissions}
                disabled={loading}
                className="flex items-center gap-1.5 px-4 py-2 text-xs rounded-md bg-amber-500/20 text-amber-400 hover:bg-amber-500/30 transition-colors disabled:opacity-50"
              >
                {saved ? <Check size={14} /> : <Shield size={14} />}
                {saved ? 'Saved!' : 'Save Permissions'}
              </button>
            </div>
          </div>
        )}

        {/* === Images Tab === */}
        {activeTab === 'images' && (
          <div className="space-y-5">
            {/* Z-Image Info */}
            <div>
              <h3 className="text-xs font-semibold text-[#e0e0e0] mb-3 flex items-center gap-2">
                <Sparkles size={14} /> Z-Image (Nymphs2D2)
              </h3>
              <p className="text-[11px] text-[#888] mb-3">
                Local AI image generation via Z-Image-Turbo model. Images are generated on-demand and saved to your assets/images/ folder.
              </p>

              {/* Server Status */}
              <ImageGenStatusPanel />
            </div>

            {/* Portable Mode Config */}
            <div>
              <h3 className="text-xs font-semibold text-[#e0e0e0] mb-3 flex items-center gap-2">
                <SettingsIcon size={14} /> Portable Configuration
              </h3>
              <ZImageConfigPanel />
            </div>

            {/* Minimum VRAM */}
            <div>
              <h3 className="text-xs font-semibold text-[#e0e0e0] mb-3">GPU Memory Check</h3>
              <MinimumVramInput />
            </div>

          </div>
        )}

        {/* === Editor Tab === */}
        {activeTab === 'editor' && (
          <div className="space-y-5">
            <div>
              <label className="block text-xs font-medium mb-1.5 text-[#e0e0e0] uppercase tracking-wider">Max Open Tabs</label>
              <div className="flex items-center gap-3">
                <input
                  type="range"
                  min="1"
                  max="50"
                  value={maxTabs}
                  onChange={(e) => handleMaxTabsChange(parseInt(e.target.value) || 10)}
                  className="flex-1"
                />
                <input
                  type="number"
                  min="1"
                  max="50"
                  value={maxTabs}
                  onChange={(e) => handleMaxTabsChange(parseInt(e.target.value) || 10)}
                  className="w-20 rounded-md bg-[#2a2a3a] px-3 py-2 text-sm text-center text-[#e0e0e0] focus:outline-none focus:ring-1 focus:ring-[#a78bfa]"
                />
              </div>
              <p className="text-[11px] text-[#888] mt-1">Maximum number of files that can be open as tabs simultaneously. Saved locally.</p>
            </div>

            {/* Sidebar Icons */}
            <div className="border-t border-[#3a3a4a] pt-4">
              <h3 className="text-xs font-semibold mb-3 text-[#e0e0e0] flex items-center gap-2">
                <LayoutPanelLeft size={14} /> Sidebar Icons
              </h3>
              <p className="text-[11px] text-[#888] mb-3">Toggle visibility of sidebar icons. Explorer, Search, Starred, and Settings are always visible.</p>

              {SIDEBAR_ICONS.map(({ key, label, icon: Icon }) => (
                <div key={key} className="flex items-center justify-between py-2.5 border-b border-[#2a2a3a] last:border-b-0">
                  <div className="flex items-center gap-2">
                    <Icon size={16} className="text-[#888]" />
                    <span className="text-xs text-[#e0e0e0]">{label}</span>
                  </div>
                  <label className="relative cursor-pointer" onClick={() => handleToggleVisibility(key)}>
                    <div className={`block w-10 h-5 rounded-full transition-colors ${sidebarVisibility[key] ? 'bg-[#a78bfa]' : 'bg-[#3a3a4a]'}`}>
                      <div className={`absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full transition-transform ${sidebarVisibility[key] ? 'translate-x-5' : ''}`} />
                    </div>
                  </label>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* === Appearance Tab === */}
        {activeTab === 'appearance' && (
          <div className="space-y-5">
            <ThemePicker />
          </div>
        )}
      </div>
    </div>
  );
}

// Map provider preset IDs to backend server type names
const PROVIDER_TO_SERVER_TYPE: Record<string, string> = {
  'llama-cpp': 'llama.cpp',
  'ollama': 'ollama',
  'vllm': 'vLLM',
  'lm-studio': 'LM Studio',
  'textgen-webui': 'TextGen WebUI',
  'localai': 'LocalAI',
  'jan': 'Jan',
};

const providerToServerType = (providerId: string): string => {
  return PROVIDER_TO_SERVER_TYPE[providerId] || 'llama.cpp';
};

function LlmServerStatusPanel({ serverType }: { serverType: string }) {
  const [detectedServers, setDetectedServers] = useState<DetectedLlmServer[]>([]);
  const [llmStatus, setLlmStatus] = useState<LlmServerStatus | null>(null);
  const [detecting, setDetecting] = useState(false);
  const [checking, setChecking] = useState(false);
  const [actionLoading, setActionLoading] = useState(false);
  const [actionResult, setActionResult] = useState<string | null>(null);

  const selectedServer = detectedServers.find((s) => s.serverType === serverType);
  const isFound = selectedServer?.found || false;
  const isRunning = llmStatus?.running || false;

  // Detect servers on mount
  const runDetection = useCallback(async () => {
    setDetecting(true);
    setActionResult(null);
    try {
      const servers = await detectLlmServers();
      setDetectedServers(servers);
      const found = servers.find((s) => s.serverType === serverType);
      setActionResult(
        found?.found ? `${serverType} detected.` : found ? `${serverType} not installed.` : 'Detection complete.'
      );
    } catch (err: any) {
      setActionResult(err.message || 'Failed to detect servers');
    }
    setDetecting(false);
  }, [serverType]);

  // Check status for the given server type
  const check = useCallback(async () => {
    setChecking(true);
    try {
      const st = await getLlmServerStatus(serverType);
      setLlmStatus(st);
    } catch (err: any) {
      setActionResult(err.message || 'Failed to get LLM server status');
    }
    setChecking(false);
  }, [serverType]);

  useEffect(() => {
    runDetection();
  }, [runDetection]);

  useEffect(() => {
    check();
  }, [check]);

  const handleStart = useCallback(async () => {
    setActionLoading(true);
    setActionResult(null);
    try {
      await startLlmServer(serverType);
      setActionResult(`${serverType} server started successfully`);
      await check();
    } catch (err: any) {
      setActionResult(err.message || `Failed to start ${serverType} server`);
    }
    setActionLoading(false);
  }, [check, serverType]);

  const handleStop = useCallback(async () => {
    setActionLoading(true);
    setActionResult(null);
    try {
      await stopLlmServer(serverType);
      setActionResult(`${serverType} server stopped successfully`);
      await check();
    } catch (err: any) {
      setActionResult(err.message || `Failed to stop ${serverType} server`);
    }
    setActionLoading(false);
  }, [check, serverType]);

  return (
    <div className="rounded-md bg-[#2a2a3a] p-4 space-y-3">
      {/* Detect Button */}
      <div className="flex items-center justify-between">
        <span className="text-xs text-[#888]">Scan for installed LLM servers</span>
        <button
          onClick={runDetection}
          disabled={detecting}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-md bg-[#a78bfa]/20 text-[#a78bfa] hover:bg-[#a78bfa]/30 transition-colors disabled:opacity-50"
        >
          <Search size={12} className={detecting ? 'animate-spin' : ''} />
          {detecting ? 'Scanning...' : detectedServers.length > 0 ? 'Re-scan' : 'Detect Servers'}
        </button>
      </div>

      {/* Server Info */}
      <div className="flex items-center gap-2 text-xs text-[#888]">
        <span>Active:</span>
        <span className="text-[#e0e0e0] font-medium">{selectedServer?.name || serverType}</span>
        {detectedServers.length > 0 && !isFound && <span className="text-yellow-400">(not detected)</span>}
        {isFound && (
          <span className="text-[10px] text-green-400 bg-green-500/10 px-1.5 py-0.5 rounded">Found</span>
        )}
      </div>

      {selectedServer && (
        <div className="text-[10px] text-[#666]">
          Binary: <code className="bg-[#1e1e2e] px-1 py-0.5 rounded">{selectedServer.binary}</code>
          {' '}· Port: {selectedServer.defaultPort}
          {selectedServer.paths.length > 0 && <> · Paths: {selectedServer.paths.join(', ')}</>}
        </div>
      )}

      {/* Status */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="text-xs text-[#e0e0e0]">Server Status</span>
        <div className="flex items-center gap-2">
          <div className={`w-2 h-2 rounded-full ${isRunning ? 'bg-green-400' : 'bg-red-400'}`} />
          <span className="text-xs text-[#888]">{isRunning ? 'Running' : 'Stopped'}</span>
        </div>
      </div>

      {isRunning && llmStatus && (
        <div className="space-y-1 text-[11px] text-[#888]">
          {llmStatus.pid && <div>PID: {llmStatus.pid}</div>}
          {llmStatus.port && <div>Port: {llmStatus.port}</div>}
          {llmStatus.model && <div>Model: {llmStatus.model}</div>}
        </div>
      )}

      {/* Actions */}
      <div className="flex flex-wrap gap-2 pt-1">
        <button
          onClick={handleStart}
          disabled={actionLoading || isRunning}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-md bg-green-500/20 text-green-400 hover:bg-green-500/30 transition-colors disabled:opacity-50"
        >
          <Play size={12} />
          {actionLoading ? 'Starting...' : `Start ${serverType}`}
        </button>
        <button
          onClick={handleStop}
          disabled={actionLoading || !isRunning}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-md bg-red-500/20 text-red-400 hover:bg-red-500/30 transition-colors disabled:opacity-50"
        >
          <Square size={12} />
          {actionLoading ? 'Stopping...' : 'Stop Server'}
        </button>
        <button
          onClick={check}
          disabled={checking}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-md bg-[#3a3a4a] text-[#e0e0e0] hover:bg-[#4a4a5a] transition-colors disabled:opacity-50"
        >
          <RefreshCw size={12} className={checking ? 'animate-spin' : ''} />
          Refresh
        </button>
      </div>

      {actionResult && (
        <div className={`text-xs ${actionResult.includes('successfully') ? 'text-green-400' : actionResult.includes('Failed') ? 'text-red-400' : 'text-[#888]'}`}>
          {actionResult}
        </div>
      )}
    </div>
  );
}

function MinimumVramInput() {
  const STORAGE_KEY = 'wbu_image_min_vram_mb';
  const [minVram, setMinVram] = useState(() => {
    try {
      const val = localStorage.getItem(STORAGE_KEY);
      return val ? parseInt(val, 10) : 8192;
    } catch {
      return 8192;
    }
  });
  const [saved, setSaved] = useState(false);

  const handleChange = (v: number) => {
    const clamped = Math.max(1024, Math.min(32768, v));
    setMinVram(clamped);
    localStorage.setItem(STORAGE_KEY, clamped.toString());
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="rounded-md bg-[#2a2a3a] p-4 space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="text-xs text-[#e0e0e0] font-medium">Minimum Free VRAM</p>
          <p className="text-[11px] text-[#888] mt-0.5">
            Server refuses to start below this threshold (prevents crashes from OOM).
          </p>
        </div>
        <div className="flex items-center gap-2">
          <input
            type="number"
            min={1024}
            max={32768}
            step={256}
            value={minVram}
            onChange={(e) => handleChange(parseInt(e.target.value) || 8192)}
            className="w-24 rounded-md bg-[#3a3a4a] px-2 py-1 text-sm text-center text-[#e0e0e0] focus:outline-none focus:ring-1 focus:ring-[#a78bfa]"
          />
          <span className="text-[11px] text-[#888]">MB ({(minVram / 1024).toFixed(1)} GB)</span>
        </div>
      </div>
      {saved && (
        <div className="text-[11px] text-green-400 flex items-center gap-1">
          <Check size={12} /> Saved
        </div>
      )}
    </div>
  );
}

function ImageGenStatusPanel() {
  const [status, setStatus] = useState<ImageGenStatusType | null>(null);
  const [checking, setChecking] = useState(false);
  const [zImageUrl, setZImageUrl] = useState(() => {
    try {
      return localStorage.getItem('wbu_zimage_url') || 'http://localhost:8090';
    } catch {
      return 'http://localhost:8090';
    }
  });
  const [testResult, setTestResult] = useState<string | null>(null);
  const [testing, setTesting] = useState(false);
  const [saved, setSaved] = useState(false);

  const check = useCallback(async () => {
    setChecking(true);
    try {
      const st = await getImageGenerationStatus();
      setStatus(st);
    } catch {
      setStatus({ available: false, running: false });
    }
    setChecking(false);
  }, []);

  useEffect(() => {
    check();
  }, [check]);

  const handleTest = useCallback(async () => {
    setTesting(true);
    setTestResult(null);
    try {
      const result = await testZImageConnection(zImageUrl);
      if (result.success) {
        setTestResult(`Connected! Model: ${result.loadedModelId || 'unknown'}, Backend: ${result.backend || 'unknown'}`);
      } else {
        setTestResult(result.message || 'Connection failed');
      }
    } catch (err: any) {
      setTestResult(err.message || 'Connection failed');
    }
    setTesting(false);
  }, [zImageUrl]);

  const handleSaveUrl = useCallback(() => {
    localStorage.setItem('wbu_zimage_url', zImageUrl);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }, [zImageUrl]);

  const isRunning = status?.running || false;

  return (
    <div className="rounded-md bg-[#2a2a3a] p-4 space-y-3">
      {/* URL Config */}
      <div>
        <label className="block text-xs font-medium text-[#e0e0e0] mb-1.5">Z-Image Server URL</label>
        <div className="flex flex-wrap gap-2">
          <input
            type="text"
            value={zImageUrl}
            onChange={(e) => setZImageUrl(e.target.value)}
            placeholder="http://localhost:8090"
            className="flex-1 min-w-0 rounded-md bg-[#3a3a4a] px-3 py-1.5 text-sm text-[#e0e0e0] focus:outline-none focus:ring-1 focus:ring-[#a78bfa]"
          />
          <button
            onClick={handleSaveUrl}
            className="px-3 py-1.5 text-xs rounded-md bg-[#a78bfa]/20 text-[#a78bfa] hover:bg-[#a78bfa]/30 transition-colors flex-shrink-0"
          >
            {saved ? 'Saved!' : 'Save'}
          </button>
        </div>
        <p className="text-[11px] text-[#888] mt-1">URL of your externally running Z-Image (Nymphs2D2) server.</p>
      </div>

      {/* Status */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="text-xs text-[#e0e0e0]">Connection</span>
        <div className="flex items-center gap-2">
          <div className={`w-2 h-2 rounded-full ${isRunning ? 'bg-green-400' : 'bg-red-400'}`} />
          <span className="text-xs text-[#888]">{isRunning ? 'Connected' : 'Disconnected'}</span>
        </div>
      </div>

      {isRunning && status && (
        <div className="space-y-1 text-[11px] text-[#888]">
          {status.backend && <div>Backend: {status.backend}</div>}
          {status.loadedModelId && <div>Model: {status.loadedModelId}</div>}
          {status.device && <div>Device: {status.device}</div>}
          {status.supportedModes && <div>Modes: {status.supportedModes.join(', ')}</div>}
        </div>
      )}

      {/* Test + Refresh */}
      <div className="flex flex-wrap gap-2 pt-1">
        <button
          onClick={handleTest}
          disabled={testing}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-md bg-[#a78bfa]/20 text-[#a78bfa] hover:bg-[#a78bfa]/30 transition-colors disabled:opacity-50"
        >
          <Sparkles size={12} />
          {testing ? 'Testing...' : 'Test Connection'}
        </button>
        <button
          onClick={check}
          disabled={checking}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-md bg-[#3a3a4a] text-[#e0e0e0] hover:bg-[#4a4a5a] transition-colors disabled:opacity-50"
        >
          <RefreshCw size={12} className={checking ? 'animate-spin' : ''} />
          Refresh
        </button>
      </div>

      {testResult && (
        <div className={`text-xs ${testResult.startsWith('Connected') ? 'text-green-400' : 'text-red-400'}`}>
          {testResult}
        </div>
      )}

      {status?.error && (
        <div className="text-xs text-red-400">{status.error}</div>
      )}
    </div>
  );
}

function ZImageConfigPanel() {
  const [mode, setMode] = useState(() => {
    try {
      return localStorage.getItem('wbu_zimage_mode') || 'managed';
    } catch {
      return 'managed';
    }
  });
  const [folderPath, setFolderPath] = useState(() => {
    try {
      return localStorage.getItem('wbu_zimage_folder') || '';
    } catch {
      return '';
    }
  });
  const [saved, setSaved] = useState(false);

  const handleSave = useCallback(() => {
    localStorage.setItem('wbu_zimage_mode', mode);
    localStorage.setItem('wbu_zimage_folder', folderPath);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }, [mode, folderPath]);

  return (
    <div className="rounded-md bg-[#2a2a3a] p-4 space-y-3">
      {/* Mode Selector */}
      <div>
        <label className="block text-xs font-medium text-[#e0e0e0] mb-1.5">Operation Mode</label>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setMode('managed')}
            className={`px-3 py-1.5 text-xs rounded-md transition-colors ${
              mode === 'managed'
                ? 'bg-[#a78bfa] text-white'
                : 'bg-[#3a3a4a] text-[#e0e0e0] hover:bg-[#4a4a5a]'
            }`}
          >
            Managed (WORBI controls)
          </button>
          <button
            onClick={() => setMode('external')}
            className={`px-3 py-1.5 text-xs rounded-md transition-colors ${
              mode === 'external'
                ? 'bg-[#a78bfa] text-white'
                : 'bg-[#3a3a4a] text-[#e0e0e0] hover:bg-[#4a4a5a]'
            }`}
          >
            External (User-managed)
          </button>
        </div>
        <p className="text-[11px] text-[#888] mt-1">
          {mode === 'managed'
            ? 'WORBI will start/stop Z-Image automatically when needed.'
            : 'You manage Z-Image manually. WORBI will connect to the URL above (Start/Stop buttons will be hidden).'}
        </p>
      </div>

      {/* Folder Path — only needed in Managed mode */}
      {mode === 'managed' ? (
        <div>
          <label className="block text-xs font-medium text-[#e0e0e0] mb-1.5">Z-Image Installation Folder</label>
          <input
            type="text"
            value={folderPath}
            onChange={(e) => setFolderPath(e.target.value)}
            placeholder="~/Z-Image (default)"
            className="w-full rounded-md bg-[#3a3a4a] px-3 py-1.5 text-sm text-[#e0e0e0] focus:outline-none focus:ring-1 focus:ring-[#a78bfa]"
          />
          <p className="text-[11px] text-[#888] mt-1">
            Path to your Z-Image installation. Leave empty to use default (~/Z-Image). Requires server restart.
          </p>
        </div>
      ) : null}

      {/* Save Button */}
      <div className="flex items-center gap-2">
        <button
          onClick={handleSave}
          className="px-3 py-1.5 text-xs rounded-md bg-[#a78bfa]/20 text-[#a78bfa] hover:bg-[#a78bfa]/30 transition-colors"
        >
          {saved ? '✓ Saved!' : 'Save Configuration'}
        </button>
        {saved && (
          <span className="text-[11px] text-green-400 flex items-center gap-1">
            <Check size={12} /> Configuration saved
          </span>
        )}
      </div>
    </div>
  );
}
