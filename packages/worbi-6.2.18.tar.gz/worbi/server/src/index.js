import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

import config from './config.js';
import authMiddleware from './middleware/authMiddleware.js';
import authRoutes from './routes/auth.js';
import fileRoutes from './routes/files.js';
import imageRoutes from './routes/images.js';
import llmRoutes from './routes/llm.js';
import imageGenRoutes from './routes/imageGeneration.js';
import settingsRoutes from './routes/settings.js';
import timelineRoutes from './routes/timeline.js';
import graphRoutes from './routes/graph.js';
import reminderRoutes from './routes/reminders.js';
import { usersRoot } from './services/authService.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

// Middleware
app.use(cors({ origin: '*' }));  // Allow all origins (private system)
app.use(morgan('dev'));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Ensure data directories exist
const dirs = [usersRoot];
for (const dir of dirs) {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

// Public routes (no auth required)
app.use('/api/auth', authRoutes);

// Image proxy routes (public /proxy, auth per-route for /sign and /sign-batch)
app.use('/api/images', imageRoutes);

// Health check (public)
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Protected routes (auth required)
app.use('/api/files', authMiddleware, fileRoutes);
app.use('/api/files', authMiddleware, timelineRoutes);
app.use('/api/llm', authMiddleware, llmRoutes);
app.use('/api/llm', authMiddleware, imageGenRoutes);
app.use('/api/llm/graph', authMiddleware, graphRoutes);
app.use('/api/settings', authMiddleware, settingsRoutes);
app.use('/api/reminders', authMiddleware, reminderRoutes);

// Start server (bind to 0.0.0.0 for network access via WSL)
const PORT = config.port;
const HOST = '0.0.0.0';
app.listen(PORT, HOST, () => {
  console.log(`WBUI Server running on http://0.0.0.0:${PORT}`);
  console.log(`Users root: ${usersRoot}`);
});

export default app;