import { spawn } from 'child_process';
import { existsSync } from 'fs';
import http from 'http';
import config from '../config.js';

function spawnCommand(scriptPath, env = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(scriptPath, {
      shell: true,
      stdio: ['ignore', 'pipe', 'pipe'],
      env: { ...process.env, ...env },
    });

    let stdout = '';
    let stderr = '';

    child.stdout.on('data', (data) => {
      stdout += data.toString();
    });

    child.stderr.on('data', (data) => {
      stderr += data.toString();
    });

    child.on('close', (code) => {
      if (code === 0) {
        resolve({ code, stdout, stderr });
      } else {
        reject(new Error(`Script exited with code ${code}\n${stderr}`));
      }
    });

    child.on('error', (err) => {
      reject(new Error(`Failed to spawn: ${err.message}\n${stderr}`));
    });
  });
}

function httpGet(urlPath, baseUrl) {
  return new Promise((resolve, reject) => {
    const url = new URL(urlPath, baseUrl);
    const req = http.get(url, { timeout: 5000 }, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        if (res.statusCode === 200) {
          try {
            resolve(JSON.parse(data));
          } catch (e) {
            resolve({ raw: data });
          }
        } else {
          resolve({ statusCode: res.statusCode, data });
        }
      });
    });

    req.on('error', (err) => {
      reject(new Error(`HTTP request failed: ${err.message}`));
    });

    req.on('timeout', () => {
      req.destroy();
      reject(new Error('HTTP request timed out'));
    });
  });
}

// Check if the LLM server is responding at the given base URL
async function checkHealth(baseUrl) {
  try {
    const resp = await httpGet('/v1/models', baseUrl);
    return resp.statusCode === 200 || (!!resp.data && !resp.data.raw);
  } catch {
    return false;
  }
}

async function waitForReady(baseUrl, timeoutMs = 120000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    if (await checkHealth(baseUrl)) {
      return true;
    }
    await new Promise((r) => setTimeout(r, 2000));
  }
  return false;
}

/**
 * Detect all installed LLM servers on the system.
 * Returns an array sorted by priority (llama.cpp first).
 */
export function detectServers() {
  const results = [];
  const servers = config.managedLlmServers;

  for (const [key, def] of Object.entries(servers)) {
    const found = [];

    // 1. Check search paths for binary
    for (const p of (def.searchPaths || [])) {
      if (existsSync(p)) {
        found.push(p);
      }
    }

    // 2. Check if a process with the binary name is running
    let running = false;
    if (found.length > 0) {
      running = checkHealth(def.defaultBaseUrl);
    }

    results.push({
      serverType: key,
      name: def.name,
      binary: def.binary,
      defaultPort: def.defaultPort,
      defaultBaseUrl: def.defaultBaseUrl,
      paths: found,
      found: found.length > 0,
      running, // Promise-like; will be resolved in route
      priority: def.priority,
    });
  }

  // Sort by priority
  results.sort((a, b) => a.priority - b.priority);
  return results;
}

/**
 * Resolve the base URL for a given server type.
 */
function getBaseUrlForType(serverType) {
  const def = config.managedLlmServers[serverType];
  if (def) return def.defaultBaseUrl;
  return config.llm?.baseUrl || 'http://localhost:8000/v1';
}

/**
 * Start the LLM server of the given type.
 * If no type specified, defaults to 'llama.cpp'.
 */
export async function startLlm(serverType = 'llama.cpp', options = {}) {
  const { folderPath } = options || {};
  const def = config.managedLlmServers[serverType];
  const baseUrl = def ? def.defaultBaseUrl : (config.llm?.baseUrl || 'http://localhost:8000/v1');
  const startTimeout = 120000;

  console.log(`[llmLifecycle] Starting LLM server: ${serverType}`);

  const spawnEnv = {};
  if (folderPath && folderPath.trim()) {
    spawnEnv.NYPH_LLM_DIR = folderPath.trim();
    console.log(`[llmLifecycle] Using NYPH_LLM_DIR=${spawnEnv.NYPH_LLM_DIR}`);
  }

  // For llama.cpp, use the start script
  if (serverType === 'llama.cpp' && def?.startScript) {
    try {
      await spawnCommand(def.startScript, spawnEnv);
    } catch (err) {
      console.error('[llmLifecycle] lms-start script failed:', err.message);
      throw new Error(`Failed to start LLM server: ${err.message}`);
    }
  }

  console.log(`[llmLifecycle] Waiting for LLM server (${serverType}) to become ready...`);
  const ready = await waitForReady(baseUrl, startTimeout);

  if (!ready) {
    throw new Error(`LLM server (${serverType}) did not become ready within timeout`);
  }

  console.log(`[llmLifecycle] LLM server (${serverType}) is ready`);
  return { success: true };
}

/**
 * Stop the LLM server of the given type.
 * If no type specified, defaults to 'llama.cpp'.
 */
export async function stopLlm(serverType = 'llama.cpp') {
  const def = config.managedLlmServers[serverType];

  console.log(`[llmLifecycle] Stopping LLM server: ${serverType}`);

  // For llama.cpp, use the stop script
  if (serverType === 'llama.cpp' && def?.stopScript) {
    try {
      await spawnCommand(def.stopScript);
      console.log('[llmLifecycle] LLM server stopped via stop script');
      return { success: true };
    } catch (err) {
      console.error('[llmLifecycle] lms-stop script failed:', err.message);
      try {
        await spawnCommand(`pkill -f "llama-server.*--port ${def?.defaultPort || 8000}"`);
      } catch {}
      return { success: false, error: err.message };
    }
  }

  // Fallback: try to kill the process by binary name
  try {
    await spawnCommand(`pkill -f "${def?.binary || serverType}"`);
    return { success: true };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

export async function isRunning(serverType) {
  const baseUrl = serverType
    ? getBaseUrlForType(serverType)
    : (config.llm?.baseUrl || 'http://localhost:8000/v1');
  const running = await checkHealth(baseUrl);
  return { running };
}

export { checkHealth };