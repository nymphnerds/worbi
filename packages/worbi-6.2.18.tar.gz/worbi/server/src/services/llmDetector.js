// LLM Detector — probes local ports to find running LLM servers
// Results are cached for 30 seconds to avoid hammering ports.

import { getLocalProviders } from './providerCatalog.js';

// In-memory cache
let cachedResult = null;
let cachedAt = 0;
const CACHE_TTL = 30_000; // 30 seconds

/**
 * Probe a single provider URL with a timeout.
 * Returns { ok: boolean, data: any | null }
 */
async function probeUrl(url, timeoutMs = 2000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, {
      signal: controller.signal,
      headers: { 'Content-Type': 'application/json' },
    });
    clearTimeout(timer);

    if (!response.ok) {
      return { ok: false, data: null };
    }

    const data = await response.json();
    return { ok: true, data };
  } catch (err) {
    clearTimeout(timer);
    return { ok: false, data: null };
  }
}

/**
 * Extract model names from an OpenAI-compatible /models response.
 * Expected: { data: [{ id: "model-name", ... }, ...] }
 */
function parseOpenAiModels(data) {
  if (!data || !Array.isArray(data.data)) return [];
  return data.data.map((m) => m.id || m.name).filter(Boolean);
}

/**
 * Extract model names from Ollama's native /api/tags response.
 * Expected: { models: [{ name: "model:tag", ... }, ...] }
 */
function parseOllamaModels(data) {
  if (!data || !Array.isArray(data.models)) return [];
  return data.models.map((m) => m.name).filter(Boolean);
}

/**
 * Detect which local LLM providers are running.
 * Probes each provider concurrently with a 2-second timeout.
 *
 * Returns:
 * {
 *   detected: [{ id, name, url, detectedAt, models, defaultModel }],
 *   notDetected: [{ id, name, url }]
 * }
 */
async function detectLocalProviders() {
  // Return cached result if still valid
  if (cachedResult && (Date.now() - cachedAt) < CACHE_TTL) {
    return cachedResult;
  }

  const providers = getLocalProviders().filter(
    (p) => p.defaultPort !== null // Skip "custom-local" which has no default port
  );

  // Deduplicate by port to avoid probing the same port twice (llamacpp and localai share 8080)
  const seenPorts = new Set();
  const uniqueProviders = [];

  for (const provider of providers) {
    if (seenPorts.has(provider.defaultPort)) {
      // Skip duplicates — the first provider for this port takes priority
      continue;
    }
    seenPorts.add(provider.defaultPort);
    uniqueProviders.push(provider);
  }

  // Probe all providers concurrently
  const results = await Promise.allSettled(
    uniqueProviders.map(async (provider) => {
      // Build the probe URL: base without /v1, then append /models
      const baseUrl = provider.defaultUrl.replace(/\/v1$/, '');
      const probeUrl = `${baseUrl}/models`;

      const { ok, data } = await probeUrl(probeUrl);

      if (ok) {
        const models = parseOpenAiModels(data);

        // Special handling for Ollama — also try native endpoint if OpenAI format returned no models
        let finalModels = models;
        if (provider.id === 'ollama' && finalModels.length === 0) {
          const nativeUrl = `${baseUrl}/api/tags`;
          const nativeResult = await probeUrl(nativeUrl);
          if (nativeResult.ok) {
            finalModels = parseOllamaModels(nativeResult.data);
          }
        }

        return {
          detected: true,
          provider: {
            id: provider.id,
            name: provider.name,
            url: provider.defaultUrl,
            detectedAt: provider.defaultUrl,
            models: finalModels,
            defaultModel: finalModels[0] || '',
          },
        };
      }

      // For Ollama, also try the native endpoint as a fallback
      if (provider.id === 'ollama') {
        const nativeUrl = `${baseUrl}/api/tags`;
        const nativeResult = await probeUrl(nativeUrl);
        if (nativeResult.ok) {
          const models = parseOllamaModels(nativeResult.data);
          return {
            detected: true,
            provider: {
              id: provider.id,
              name: provider.name,
              url: provider.defaultUrl,
              detectedAt: provider.defaultUrl,
              models,
              defaultModel: models[0] || '',
            },
          };
        }
      }

      return {
        detected: false,
        provider: {
          id: provider.id,
          name: provider.name,
          url: provider.defaultUrl,
        },
      };
    })
  );

  const detected = [];
  const notDetected = [];

  for (const result of results) {
    if (result.status === 'fulfilled') {
      if (result.value.detected) {
        detected.push(result.value.provider);
      } else {
        notDetected.push(result.value.provider);
      }
    }
  }

  // Also add providers that were skipped due to port dedup but not detected
  for (const provider of providers) {
    if (seenPorts.has(provider.defaultPort) && !uniqueProviders.includes(provider)) {
      // This provider shares a port with one already tested — if the other was detected,
      // this one might also be running on the same port. Mark as not detected (user can manually select).
      notDetected.push({
        id: provider.id,
        name: provider.name,
        url: provider.defaultUrl,
      });
    }
  }

  cachedResult = { detected, notDetected };
  cachedAt = Date.now();

  return cachedResult;
}

/**
 * Clear the detection cache (useful for manual re-scan).
 */
function clearCache() {
  cachedResult = null;
  cachedAt = 0;
}

export { detectLocalProviders, clearCache };