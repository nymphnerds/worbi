import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import axios from 'axios';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Workspace root: project root (Nymphs-Brain/)
const WORKSPACE_ROOT = path.resolve(__dirname, '../../../');
const MAX_FILE_SIZE = 256 * 1024; // 256KB read limit

/**
 * Validate and resolve a path within the workspace sandbox.
 * Throws an error if the path escapes the workspace root.
 */
function resolveSafePath(userPath) {
  if (!userPath || typeof userPath !== 'string') {
    throw new Error('Invalid path: empty or not a string');
  }

  // Normalize and resolve
  const normalized = path.normalize(userPath);
  
  // Block path traversal attempts
  if (normalized.startsWith('..')) {
    throw new Error('Path traversal not allowed');
  }

  const resolved = path.resolve(WORKSPACE_ROOT, normalized);

  // Ensure the resolved path is within workspace
  if (!resolved.startsWith(WORKSPACE_ROOT)) {
    throw new Error('Access denied: path outside workspace');
  }

  return resolved;
}

/**
 * Check if a file is likely binary by reading a sample.
 */
function isBinary(filePath) {
  try {
    const chunk = fs.readFileSync(filePath, { encoding: 'latin1', length: 8192, flag: 'r' });
    const binaryPattern = /[\x00-\x08\x0E-\x1F]/;
    return binaryPattern.test(chunk);
  } catch {
    return true; // If we can't read it, treat as binary
  }
}

/**
 * Search the web using DuckDuckGo HTML endpoint.
 * Parses the HTML response to extract titles, URLs and snippets.
 */
async function webSearch(query, maxResults = 5) {
  try {
    const limit = Math.min(Math.max(1, maxResults), 20);
    const searchUrl = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`;

    const response = await axios.get(searchUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml',
        'Accept-Language': 'en-US,en;q=0.9',
      },
      timeout: 15000,
    });

    const html = response.data;

    // Parse results from DuckDuckGo HTML
    const results = [];
    // Match result blocks: <a href="..."> followed by .result-snippet
    const resultRegex = /<a\s+href="([^"]+)"[^>]*class="result__a"[^>]*>([^<]+)<\/a>[\s\S]*?class="result-snippet"[^>]*>([^<]*)<\/div>/g;
    let match;

    while ((match = resultRegex.exec(html)) !== null && results.length < limit) {
      let url = match[1];
      const title = match[2].trim();
      const snippet = match[3].trim();

      // DuckDuckGo uses redirect URLs, try to extract the actual URL
      if (url.startsWith('/')) {
        try {
          const redirectResp = await axios.get(`https://html.duckduckgo.com${url}`, {
            maxRedirects: 0,
            validateStatus: (status) => status === 302 || status === 303 || status === 200,
            headers: {
              'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36',
            },
            timeout: 5000,
          }).catch(() => null);

          if (redirectResp && redirectResp.headers?.location) {
            url = redirectResp.headers.location;
          } else if (redirectResp && redirectResp.data) {
            // Try to extract URL from redirect page
            const urlMatch = redirectResp.data.match(/window\.location\.replace\(['"]([^'"]+)['"]\)/);
            if (urlMatch) url = urlMatch[1];
          }
        } catch {
          // Keep the DDG redirect URL
        }
      }

      results.push({ title, url, snippet });
    }

    // Fallback: simpler regex if the main one didn't match
    if (results.length === 0) {
      const simpleRegex = /<a\s+href="([^"]+)"[^>]*>([^<]+)<\/a>/g;
      const seenUrls = new Set();
      while ((match = simpleRegex.exec(html)) !== null && results.length < limit) {
        const url = match[1];
        const title = match[2].trim();
        if (url.startsWith('/') || title.length < 5 || seenUrls.has(url)) continue;
        seenUrls.add(url);
        // Only keep http(s) URLs
        if (url.startsWith('http')) {
          results.push({ title, url, snippet: '' });
        }
      }
    }

    if (results.length === 0) {
      return `No search results found for "${query}".`;
    }

    // Fetch the top result for more detail
    let detail = '';
    if (results[0]?.url && results[0].url.startsWith('http')) {
      try {
        const fetched = await fetchWebpage(results[0].url);
        if (fetched) {
          detail = `\n\n--- Content from "${results[0].url}" ---\n${fetched}`;
        }
      } catch {
        // Ignore fetch failures
      }
    }

    // Format results
    const formatted = results.map((r, i) => {
      return `${i + 1}. ${r.title}\n   URL: ${r.url}\n   ${r.snippet || '(no snippet)'}`;
    }).join('\n\n');

    return `Search Results for "${query}":\n\n${formatted}${detail}`;
  } catch (error) {
    throw new Error(`Web search failed: ${error.message}`);
  }
}

/**
 * Fetch a webpage and convert it to clean text content.
 */
async function fetchWebpage(url, maxLength = 4000) {
  try {
    const response = await axios.get(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml',
      },
      timeout: 10000,
      transformResponse: [(data) => data], // Keep raw HTML string
    });

    const html = response.data;

    // Strip HTML tags
    const text = html
      .replace(/<script[\s\S]*?<\/script>/gi, '')
      .replace(/<style[\s\S]*?<\/style>/gi, '')
      .replace(/<[^>]+>/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();

    return text.substring(0, maxLength) + (text.length > maxLength ? '\n\n... (truncated)' : '');
  } catch (error) {
    return null;
  }
}

/**
 * Read a file from the workspace.
 */
function readFile(filePath) {
  const safePath = resolveSafePath(filePath);

  if (!fs.existsSync(safePath)) {
    throw new Error(`File not found: ${filePath}`);
  }

  const stat = fs.statSync(safePath);
  if (stat.isDirectory()) {
    throw new Error(`Path is a directory, not a file: ${filePath}. Use list_directory instead.`);
  }

  if (stat.size > MAX_FILE_SIZE) {
    throw new Error(`File too large to read: ${filePath} (${(stat.size / 1024).toFixed(1)}KB, max ${MAX_FILE_SIZE / 1024}KB)`);
  }

  if (isBinary(safePath)) {
    throw new Error(`Cannot read binary file: ${filePath}`);
  }

  const content = fs.readFileSync(safePath, 'utf-8');
  return `Contents of "${filePath}" (${(stat.size / 1024).toFixed(1)}KB):\n\n${content}`;
}

/**
 * List directory contents within the workspace.
 */
function listDirectory(dirPath = '') {
  const safePath = resolveSafePath(dirPath || '.');

  if (!fs.existsSync(safePath)) {
    throw new Error(`Directory not found: ${dirPath || '.'}`);
  }

  const stat = fs.statSync(safePath);
  if (!stat.isDirectory()) {
    throw new Error(`Path is a file, not a directory: ${dirPath}`);
  }

  const entries = fs.readdirSync(safePath, { withFileTypes: true });
  const items = entries.map(dirent => {
    const type = dirent.isDirectory() ? 'folder' : 'file';
    const name = dirent.name;
    let info = `${type === 'folder' ? '📁' : '📄'} ${name}`;
    
    if (type === 'file') {
      try {
        const fullPath = path.join(safePath, name);
        const s = fs.statSync(fullPath);
        info += ` (${(s.size / 1024).toFixed(1)}KB)`;
      } catch { /* ignore stat errors */ }
    }

    return info;
  });

  return `Directory listing for "${dirPath || '.'}":\n${items.length === 0 ? '(empty)' : items.join('\n')}`;
}

/**
 * Create a new file or overwrite an existing file.
 */
function writeFile(filePath, content) {
  const safePath = resolveSafePath(filePath);

  // Ensure parent directory exists
  const parentDir = path.dirname(safePath);
  if (!fs.existsSync(parentDir)) {
    fs.mkdirSync(parentDir, { recursive: true });
  }

  fs.writeFileSync(safePath, content, 'utf-8');
  return `File created/updated: ${filePath} (${(Buffer.byteLength(content) / 1024).toFixed(1)}KB)`;
}

/**
 * Edit a file by replacing specific text.
 */
function editFile(filePath, searchText, replaceText) {
  const safePath = resolveSafePath(filePath);

  if (!fs.existsSync(safePath)) {
    throw new Error(`File not found: ${filePath}. Use write_file to create new files.`);
  }

  const stat = fs.statSync(safePath);
  if (stat.isDirectory()) {
    throw new Error(`Path is a directory: ${filePath}`);
  }

  if (isBinary(safePath)) {
    throw new Error(`Cannot edit binary file: ${filePath}`);
  }

  const currentContent = fs.readFileSync(safePath, 'utf-8');

  if (!currentContent.includes(searchText)) {
    throw new Error(`Text not found in file: ${filePath}\n\nThe search text does not appear in the file. Read the file first with read_file to see its exact contents.`);
  }

  // Replace first occurrence
  const newContent = currentContent.replace(searchText, replaceText);
  fs.writeFileSync(safePath, newContent, 'utf-8');

  return `File edited: ${filePath}\nReplaced 1 occurrence.`;
}

/**
 * Create a new folder (directory).
 */
function createFolder(folderPath) {
  const safePath = resolveSafePath(folderPath);

  if (fs.existsSync(safePath)) {
    throw new Error(`Path already exists: ${folderPath}`);
  }

  fs.mkdirSync(safePath, { recursive: true });
  return `Folder created: ${folderPath}`;
}

/**
 * Delete a file.
 */
function deleteFile(filePath) {
  const safePath = resolveSafePath(filePath);

  if (!fs.existsSync(safePath)) {
    throw new Error(`File not found: ${filePath}`);
  }

  const stat = fs.statSync(safePath);
  if (stat.isDirectory()) {
    throw new Error(`Path is a directory: ${filePath}. Cannot delete directories.`);
  }

  // Prevent deleting critical project files
  const criticalFiles = ['.gitignore', 'README.md', 'CHANGELOG.md', 'package.json'];
  const basename = path.basename(filePath);
  const dirname = path.dirname(filePath) === '.' ? '' : path.dirname(filePath);
  
  if (dirname === '' && criticalFiles.includes(basename)) {
    throw new Error(`Cannot delete critical project file: ${filePath}`);
  }

  fs.unlinkSync(safePath);
  return `File deleted: ${filePath}`;
}

/**
 * Rename or move a file within the workspace.
 */
function renameFile(filePath, newName) {
  const safePath = resolveSafePath(filePath);

  if (!fs.existsSync(safePath)) {
    throw new Error(`File not found: ${filePath}`);
  }

  const stat = fs.statSync(safePath);
  if (stat.isDirectory()) {
    throw new Error(`Path is a directory: ${filePath}. Cannot rename directories.`);
  }

  const parentDir = path.dirname(safePath);
  const newPath = path.join(parentDir, newName);
  const newSafePath = resolveSafePath(newPath);

  if (fs.existsSync(newSafePath)) {
    throw new Error(`Destination already exists: ${newName}`);
  }

  fs.renameSync(safePath, newSafePath);
  return `File renamed: ${filePath} → ${path.join(path.dirname(filePath), newName)}`;
}

/**
 * Execute a tool by name. Used by llmService to dispatch tool calls.
 */
async function executeTool(toolName, arguments_obj) {
  const tools = {
    web_search: () => webSearch(arguments_obj?.query, arguments_obj?.max_results),
    read_file: () => readFile(arguments_obj?.file_path || arguments_obj?.filePath),
    list_directory: () => listDirectory(arguments_obj?.dir_path || arguments_obj?.dirPath || ''),
    write_file: () => writeFile(arguments_obj?.file_path || arguments_obj?.filePath, arguments_obj?.content),
    edit_file: () => editFile(
      arguments_obj?.file_path || arguments_obj?.filePath,
      arguments_obj?.search_text || arguments_obj?.searchText,
      arguments_obj?.replace_text || arguments_obj?.replaceText
    ),
    create_folder: () => createFolder(arguments_obj?.folder_path || arguments_obj?.folderPath),
    delete_file: () => deleteFile(arguments_obj?.file_path || arguments_obj?.filePath),
    rename_file: () => renameFile(arguments_obj?.file_path || arguments_obj?.filePath, arguments_obj?.new_name || arguments_obj?.newName),
  };

  const toolFn = tools[toolName];
  if (!toolFn) {
    throw new Error(`Unknown tool: ${toolName}`);
  }

  return await toolFn();
}

/**
 * Get tool definitions for the LLM based on user permissions.
 */
function getToolDefinitions(permissions) {
  const tools = [];

  if (permissions?.webSearch) {
    tools.push({
      type: 'function',
      function: {
        name: 'web_search',
        description: 'Search the web using DuckDuckGo and optionally fetch the top result. Use this to find current information, documentation, or real-world references.',
        parameters: {
          type: 'object',
          properties: {
            query: { type: 'string', description: 'The search query' },
            max_results: { type: 'integer', description: 'Number of results to return (1-20, default: 5)', minimum: 1, maximum: 20 },
          },
          required: ['query'],
        },
      },
    });
  }

  const fileLevel = permissions?.fileAccessLevel || 'none';

  if (fileLevel !== 'none') {
    // Read tools (available at Read level and above)
    tools.push({
      type: 'function',
      function: {
        name: 'read_file',
        description: 'Read the contents of a file in the workspace. Path is relative to the workspace root.',
        parameters: {
          type: 'object',
          properties: {
            file_path: { type: 'string', description: 'Path to the file relative to workspace root' },
          },
          required: ['file_path'],
        },
      },
    });

    tools.push({
      type: 'function',
      function: {
        name: 'list_directory',
        description: 'List files and folders in a directory within the workspace. Path is relative to the workspace root. Empty string lists the workspace root.',
        parameters: {
          type: 'object',
          properties: {
            dir_path: { type: 'string', description: 'Path to the directory relative to workspace root (empty for root)' },
          },
          required: [],
        },
      },
    });
  }

  if (fileLevel === 'readwrite' || fileLevel === 'full') {
    if (permissions?.allowCreate) {
      tools.push({
        type: 'function',
        function: {
          name: 'write_file',
          description: 'Create a new file or overwrite an existing file in the workspace. Parent directories are created automatically.',
          parameters: {
            type: 'object',
            properties: {
              file_path: { type: 'string', description: 'Path to the file relative to workspace root' },
              content: { type: 'string', description: 'Content to write to the file' },
            },
            required: ['file_path', 'content'],
          },
        },
      });

      tools.push({
        type: 'function',
        function: {
          name: 'create_folder',
          description: 'Create a new folder in the workspace. Parent folders are created automatically.',
          parameters: {
            type: 'object',
            properties: {
              folder_path: { type: 'string', description: 'Path to the folder relative to workspace root' },
            },
            required: ['folder_path'],
          },
        },
      });
    }

    if (permissions?.allowEdit) {
      tools.push({
        type: 'function',
        function: {
          name: 'edit_file',
          description: 'Edit an existing file by replacing exact text. The search_text must match exactly (including whitespace). Read the file first if unsure.',
          parameters: {
            type: 'object',
            properties: {
              file_path: { type: 'string', description: 'Path to the file relative to workspace root' },
              search_text: { type: 'string', description: 'Exact text to find and replace (first occurrence only)' },
              replace_text: { type: 'string', description: 'Text to replace with' },
            },
            required: ['file_path', 'search_text', 'replace_text'],
          },
        },
      });
    }
  }

  if (fileLevel === 'full') {
    if (permissions?.allowDelete) {
      tools.push({
        type: 'function',
        function: {
          name: 'delete_file',
          description: 'Delete a file from the workspace. Cannot delete directories or critical project files.',
          parameters: {
            type: 'object',
            properties: {
              file_path: { type: 'string', description: 'Path to the file relative to workspace root' },
            },
            required: ['file_path'],
          },
        },
      });
    }

    if (permissions?.allowRename) {
      tools.push({
        type: 'function',
        function: {
          name: 'rename_file',
          description: 'Rename a file within the same directory. Cannot rename directories.',
          parameters: {
            type: 'object',
            properties: {
              file_path: { type: 'string', description: 'Current path to the file relative to workspace root' },
              new_name: { type: 'string', description: 'New filename (not a path, just the name)' },
            },
            required: ['file_path', 'new_name'],
          },
        },
      });
    }
  }

  return tools;
}

export {
  executeTool,
  getToolDefinitions,
  webSearch,
  readFile,
  listDirectory,
  writeFile,
  editFile,
  createFolder,
  deleteFile,
  renameFile,
};