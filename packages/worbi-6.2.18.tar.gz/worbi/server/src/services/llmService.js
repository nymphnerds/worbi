import axios from 'axios';
import config from '../config.js';
import { executeTool, getToolDefinitions } from './toolService.js';

// Default tool permissions (used when not provided)
const defaultPermissions = {
  webSearch: false,
  fileAccessLevel: 'none',
  allowCreate: false,
  allowEdit: false,
  allowDelete: false,
  allowRename: false,
  maxSearchResults: 5,
};

const MAX_TOOL_TURNS = 10;

/**
 * Build headers for LLM API requests
 */
function buildHeaders(apiKey) {
  const headers = { 'Content-Type': 'application/json' };
  if (apiKey) {
    headers['Authorization'] = `Bearer ${apiKey}`;
  }
  return headers;
}

/**
 * Normalize base URL — ensure it ends without trailing slash
 */
function normalizeBaseUrl(url) {
  if (!url) return '';
  return url.replace(/\/+$/, '');
}

/**
 * Fetch available models from LLM server
 * @param {Object} settings - User settings with baseUrl, apiKey, serverType
 */
async function fetchModels(settings) {
  const baseUrl = normalizeBaseUrl(settings.baseUrl);
  if (!baseUrl) {
    throw new Error('No base URL configured. Please set your LLM provider URL in Settings.');
  }

  const isOllama = settings.serverType === 'ollama';
  const headers = buildHeaders(settings.apiKey);

  try {
    let response;
    if (isOllama) {
      // Ollama native API: /api/tags
      response = await axios.get(`${baseUrl}/api/tags`, { headers });
      const models = (response.data.models || []).map((m) => m.name).filter(Boolean);
      return models;
    } else {
      // OpenAI-compatible: /models
      response = await axios.get(`${baseUrl}/models`, { headers });
      const models = (response.data.data || []).map((m) => m.id).filter(Boolean);
      return models;
    }
  } catch (error) {
    throw new Error(`Failed to fetch models: ${error.message}`);
  }
}

/**
 * Test LLM connection by listing models
 * @param {Object} settings - User settings
 */
async function testConnection(settings) {
  try {
    const models = await fetchModels(settings);
    return { success: true, message: 'Connection successful', models };
  } catch (error) {
    return { success: false, message: `Connection failed: ${error.message}` };
  }
}

/**
 * Get a human-friendly label for tool activity
 */
function getToolActivityLabel(toolName, args) {
  switch (toolName) {
    case 'web_search':
      return `🔍 Searching the web for "${args?.query || '...'}"...`;
    case 'read_file':
      return `📄 Reading ${args?.file_path || args?.filePath || '...'}...`;
    case 'list_directory':
      return `📁 Listing ${(args?.dir_path || args?.dirPath) || 'workspace root'}...`;
    case 'write_file':
      return `📝 Writing ${args?.file_path || args?.filePath || '...'}...`;
    case 'edit_file':
      return `✏️ Editing ${args?.file_path || args?.filePath || '...'}...`;
    case 'create_folder':
      return `📁 Creating folder ${args?.folder_path || args?.folderPath || '...'}...`;
    case 'delete_file':
      return `🗑️ Deleting ${args?.file_path || args?.filePath || '...'}...`;
    case 'rename_file':
      return `🔄 Renaming ${args?.file_path || args?.filePath || '...'}...`;
    default:
      return `⚙️ Running ${toolName}...`;
  }
}

/**
 * Send chat message to LLM with optional tool calling support
 * @param {Array} messages - Chat history messages
 * @param {string} documentContent - Current document content for context
 * @param {string} [systemPrompt] - Optional user-defined system prompt
 * @param {Object} [permissions] - Tool permissions from user settings
 * @param {Object} settings - User LLM settings (baseUrl, apiKey, modelName, etc.)
 */
async function sendChatMessage(messages, documentContent, systemPrompt, permissions, settings) {
  const defaultPrompt = 'You are a helpful AI assistant for a game worldbuilder tool. The user is working on a document with the following content. Use this context to assist with writing, worldbuilding, lore, character development, and quest design.';
  const prompt = systemPrompt && systemPrompt.trim() ? systemPrompt.trim() : defaultPrompt;

  const fullSystemPrompt = `${prompt}

---
Current Document Content:
${documentContent || '(Empty document)'}
---`;

  const apiMessages = [
    { role: 'system', content: fullSystemPrompt },
    ...messages,
  ];

  // Extract settings with fallbacks
  const baseUrl = normalizeBaseUrl(settings?.baseUrl || config.llm.baseUrl);
  const apiKey = settings?.apiKey || config.llm.apiKey || '';
  const modelName = settings?.modelName || config.llm.modelName;
  const maxTokens = settings?.maxTokens ?? config.llm.maxTokens;
  const temperature = settings?.temperature ?? config.llm.temperature;
  const topP = settings?.topP ?? config.llm.topP;
  const topK = settings?.topK ?? config.llm.topK;
  const frequencyPenalty = settings?.frequencyPenalty ?? config.llm.frequencyPenalty;
  const presencePenalty = settings?.presencePenalty ?? config.llm.presencePenalty;
  const seed = settings?.seed ?? config.llm.seed;

  if (!baseUrl) {
    throw new Error('No LLM base URL configured. Please configure your LLM provider in Settings.');
  }

  // Determine if tools should be active
  const perms = permissions || defaultPermissions;
  const tools = getToolDefinitions(perms);
  const toolsEnabled = tools.length > 0;

  // Track tool activity for the response
  const toolActivity = [];

  // Build request body with inference parameters
  const buildRequestBody = (msgs, includeTools = false) => {
    const body = {
      model: modelName,
      messages: msgs,
      max_tokens: maxTokens,
      temperature: temperature,
    };

    if (topP !== undefined && topP !== 1.0) body.top_p = topP;
    if (topK !== undefined && topK !== 50) body.top_k = topK;
    if (frequencyPenalty !== undefined && frequencyPenalty !== 0.0) body.frequency_penalty = frequencyPenalty;
    if (presencePenalty !== undefined && presencePenalty !== 0.0) body.presence_penalty = presencePenalty;
    if (seed !== undefined && seed !== 0) body.seed = seed;

    if (includeTools && toolsEnabled) {
      body.tools = tools;
      body.tool_choice = 'auto';
    }

    return body;
  };

  const headers = buildHeaders(apiKey);

  try {
    let currentMessages = [...apiMessages];
    let turnCount = 0;

    while (turnCount < MAX_TOOL_TURNS) {
      const requestBody = buildRequestBody(currentMessages, true);

      const response = await axios.post(
        `${baseUrl}/chat/completions`,
        requestBody,
        { headers }
      );

      const choice = response.data.choices?.[0];
      if (!choice) {
        throw new Error('No response from LLM');
      }

      const message = choice.message;

      // Check if the LLM wants to call tools
      if (message.tool_calls && message.tool_calls.length > 0) {
        turnCount++;
        currentMessages.push(message);

        // Execute each tool call
        for (const toolCall of message.tool_calls) {
          const toolName = toolCall.function?.name;
          let toolArgs = {};

          try {
            toolArgs = JSON.parse(toolCall.function?.arguments || '{}');
          } catch {
            toolArgs = {};
          }

          // Apply maxSearchResults limit from permissions
          if (toolName === 'web_search' && perms.maxSearchResults) {
            if (!toolArgs.max_results || toolArgs.max_results > perms.maxSearchResults) {
              toolArgs.max_results = perms.maxSearchResults;
            }
          }

          const activityLabel = getToolActivityLabel(toolName, toolArgs);
          toolActivity.push({
            tool: toolName,
            status: 'running',
            label: activityLabel,
            args: toolArgs,
          });

          let toolResult;
          try {
            toolResult = await executeTool(toolName, toolArgs);
            toolActivity[toolActivity.length - 1].status = 'complete';
            toolActivity[toolActivity.length - 1].result = toolResult;
          } catch (error) {
            toolResult = `Error: ${error.message}`;
            toolActivity[toolActivity.length - 1].status = 'error';
            toolActivity[toolActivity.length - 1].error = error.message;
          }

          currentMessages.push({
            role: 'tool',
            tool_call_id: toolCall.id,
            content: toolResult,
          });
        }

        // Continue the loop to send the tool results back to the LLM
        continue;
      }

      // No tool calls - return the final text response
      return {
        role: 'assistant',
        content: message.content || '',
        toolActivity: toolActivity.length > 0 ? toolActivity : undefined,
      };
    }

    // Max turns reached
    return {
      role: 'assistant',
      content: 'I reached the maximum number of tool calls. Please try a more specific request.',
      toolActivity: toolActivity.length > 0 ? toolActivity : undefined,
    };

  } catch (error) {
    throw new Error(`LLM request failed: ${error.message}`);
  }
}

/**
 * Send a completion request (creative writing continuation)
 * Used for the inline AI writing assistant (ghost text at cursor)
 * @param {string} context - The text context to continue from
 * @param {string} [documentTitle] - Optional document title for context
 * @param {number} [maxTokens=200] - Max tokens to generate
 * @param {Object} settings - User LLM settings
 */
async function sendCompletion(context, documentTitle, maxTokens, settings) {
  const completionSystemPrompt = `You are a creative writing assistant embedded in WORBI, a world-building document editor.
Complete the user's text in their voice and style. Continue naturally from the cutoff point.
Match the tone, vocabulary, and pacing of the surrounding text.
Do NOT add dialogue markers, chapter headings, or structural elements unless the context clearly calls for them.
Output ONLY the continuation text — no explanations, no meta-commentary.`;

  const fullSystemPrompt = documentTitle
    ? `${completionSystemPrompt}\n\nThe document is titled: ${documentTitle}`
    : completionSystemPrompt;

  // Send as a single chat message — the LLM returns the continuation
  const response = await sendChatMessage(
    [{ role: 'user', content: context }],
    '',
    fullSystemPrompt,
    { webSearch: false, fileAccessLevel: 'none', allowCreate: false, allowEdit: false, allowDelete: false, allowRename: false, maxSearchResults: 0 },
    { ...settings, maxTokens: maxTokens || 200 }
  );

  return {
    completion: response.content || '',
    model: settings?.modelName || config.llm.modelName,
  };
}

/**
 * Document type templates for AI document generation
 */
const DOCUMENT_TEMPLATES = {
  character: `You are generating a character sheet for a world-building project.
Output structured HTML with these sections:
<h2>Character Name</h2>
<p><strong>Role:</strong> ...</p>
<p><strong>Race/Species:</strong> ...</p>
<p><strong>Age:</strong> ...</p>
<h3>Physical Description</h3>
<p>...</p>
<h3>Personality</h3>
<p>...</p>
<h3>Background</h3>
<p>...</p>
<h3>Abilities & Skills</h3>
<p>...</p>
<h3>Motivations & Goals</h3>
<p>...</p>
<h3>Relationships</h3>
<p>...</p>
<h3>Notes</h3>
<p>...</p>

Fill in all sections with creative, detailed content based on the user's prompt.
Use the margin column (<!-- MARGIN_SPLIT -->) for supplementary notes.`,

  location: `You are generating a location description for a world-building project.
Output structured HTML with these sections:
<h2>Location Name</h2>
<p><strong>Type:</strong> (city, dungeon, forest, mountain, etc.)</p>
<p><strong>Region:</strong> ...</p>
<p><strong>Climate:</strong> ...</p>
<h3>Geography & Layout</h3>
<p>...</p>
<h3>Population & Culture</h3>
<p>...</p>
<h3>Points of Interest</h3>
<p>...</p>
<h3>History</h3>
<p>...</p>
<h3>Adventure Hooks</h3>
<p>...</p>

Fill in all sections with creative, detailed content based on the user's prompt.`,

  quest: `You are generating a quest outline for a world-building project.
Output structured HTML with these sections:
<h2>Quest Name</h2>
<p><strong>Recommended Level:</strong> ...</p>
<p><strong>Quest Giver:</strong> ...</p>
<p><strong>Location:</strong> ...</p>
<h3>Hook</h3>
<p>How the party discovers the quest...</p>
<h3>Objectives</h3>
<ol><li>...</li><li>...</li></ol>
<h3>Key NPCs</h3>
<p>...</p>
<h3>Encounters</h3>
<p>...</p>
<h3>Rewards</h3>
<p>...</p>
<h3>Possible Complications</h3>
<p>...</p>

Fill in all sections with creative, detailed content based on the user's prompt.`,

  timeline: `You are generating a timeline entry for a world-building project.
Output structured HTML with these sections:
<h2>Event Name</h2>
<p><strong>Date/Period:</strong> ...</p>
<p><strong>Category:</strong> (historical, personal, mythological, etc.)</p>
<h3>Description</h3>
<p>What happened...</p>
<h3>Key Figures</h3>
<p>...</p>
<h3>Consequences</h3>
<p>How this event shaped the world...</p>
<h3>Related Events</h3>
<p>...</p>

Fill in all sections with creative, detailed content based on the user's prompt.`,

  freeform: `You are generating content for a world-building document.
Write creative, detailed prose based on the user's prompt.
Use HTML formatting with appropriate headings, paragraphs, and lists.`,
};

/**
 * Generate a document from a prompt using AI
 * @param {string} prompt - User's description of what to generate
 * @param {string} docType - Document type: 'character', 'location', 'quest', 'timeline', 'freeform'
 * @param {string} [documentContext] - Optional context from current document
 * @param {Object} settings - User LLM settings
 */
async function generateDocument(prompt, docType, documentContext, settings) {
  const template = DOCUMENT_TEMPLATES[docType] || DOCUMENT_TEMPLATES.freeform;

  const userMessage = documentContext
    ? `Here is some context from my world:\n\n${documentContext}\n\nPlease generate a document based on this prompt:\n\n${prompt}`
    : `Please generate a document based on this prompt:\n\n${prompt}`;

  const response = await sendChatMessage(
    [{ role: 'user', content: userMessage }],
    '',
    template,
    { webSearch: false, fileAccessLevel: 'none', allowCreate: false, allowEdit: false, allowDelete: false, allowRename: false, maxSearchResults: 0 },
    settings
  );

  return {
    html: response.content || '',
    model: settings?.modelName || config.llm.modelName,
  };
}

/**
 * Transcribe an image to text using a vision-capable LLM model
 * Sends the image as a base64 data URI with a transcription prompt
 * @param {string} imageBase64 - Base64-encoded image data URI (e.g. "data:image/png;base64,...")
 * @param {string} [customPrompt] - Optional custom prompt for the transcription
 * @param {Object} settings - User LLM settings
 */
async function transcribeImage(imageBase64, customPrompt, settings) {
  const defaultPrompt = 'Transcribe all the text visible in this image. Preserve the original formatting, paragraph structure, line breaks, and any handwritten style. If the text is handwritten, do your best to accurately transcribe it. Output only the transcribed text with no additional commentary.';
  const prompt = customPrompt && customPrompt.trim() ? customPrompt.trim() : defaultPrompt;

  // Extract settings with fallbacks
  const baseUrl = normalizeBaseUrl(settings?.baseUrl || config.llm.baseUrl);
  const apiKey = settings?.apiKey || config.llm.apiKey || '';
  const modelName = settings?.modelName || config.llm.modelName;
  const maxTokens = settings?.maxTokens ?? config.llm.maxTokens;
  const temperature = settings?.temperature ?? config.llm.temperature;

  if (!baseUrl) {
    throw new Error('No LLM base URL configured. Please configure your LLM provider in Settings.');
  }

  if (!imageBase64) {
    throw new Error('No image provided for transcription.');
  }

  // Build vision message with image
  const messages = [
    {
      role: 'user',
      content: [
        { type: 'text', text: prompt },
        { type: 'image_url', image_url: { url: imageBase64 } },
      ],
    },
  ];

  const body = {
    model: modelName,
    messages: messages,
    max_tokens: maxTokens,
    temperature: temperature,
  };

  const headers = buildHeaders(apiKey);

  try {
    const response = await axios.post(
      `${baseUrl}/chat/completions`,
      body,
      { headers, maxBodyLength: Infinity, maxContentLength: Infinity }
    );

    const choice = response.data.choices?.[0];
    if (!choice) {
      throw new Error('No response from LLM');
    }

    const content = choice.message?.content || '';

    // Check for error about vision not being supported
    if (content.toLowerCase().includes('does not support') || content.toLowerCase().includes('vision')) {
      // Some models return an error message instead of throwing
      // But typically the API itself throws, so this is a fallback
    }

    return {
      text: content,
      model: modelName,
    };
  } catch (error) {
    // Provide helpful error for vision-unsupported models
    if (error.response?.data?.error?.message?.toLowerCase().includes('vision') ||
        error.response?.data?.error?.message?.toLowerCase().includes('image') ||
        error.response?.data?.error?.message?.toLowerCase().includes('multimodal')) {
      throw new Error(`Your current model "${modelName}" does not support image/vision input. Please switch to a vision-capable model (e.g., LLaVA, GPT-4o, Claude Vision) in Settings.`);
    }
    throw new Error(`Image transcription failed: ${error.message}`);
  }
}

export {
  fetchModels,
  testConnection,
  sendChatMessage,
  sendCompletion,
  generateDocument,
  transcribeImage,
};
