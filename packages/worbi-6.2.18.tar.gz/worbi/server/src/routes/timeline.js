import fs from 'fs';
import express from 'express';
import path from 'path';
import { getUserWorkspaceDir } from '../services/authService.js';
import { getFileTags as getFileTagsFromService, getAllTags as getAllTagsFromService } from '../services/tagService.js';

const router = express.Router();

const TIMELINE_METADATA_FILE = '.wbu_timeline_metadata.json';

// Load persisted timeline metadata from sidecar JSON
function loadTimelineMetadata(workspaceRoot) {
  const metaPath = path.join(workspaceRoot, TIMELINE_METADATA_FILE);
  if (fs.existsSync(metaPath)) {
    try {
      return JSON.parse(fs.readFileSync(metaPath, 'utf-8'));
    } catch {
      return {};
    }
  }
  return {};
}

// Save timeline metadata to sidecar JSON
function saveTimelineMetadata(workspaceRoot, data) {
  const metaPath = path.join(workspaceRoot, TIMELINE_METADATA_FILE);
  fs.writeFileSync(metaPath, JSON.stringify(data, null, 2), 'utf-8');
}

// PUT /api/files/timeline/metadata - Persist timeline metadata server-side
router.put('/timeline/metadata', (req, res) => {
  try {
    const username = req.user.username;
    const workspaceRoot = getUserWorkspaceDir(username);
    const { filePath, metadata } = req.body;

    if (!filePath || !metadata) {
      return res.status(400).json({ error: 'filePath and metadata required' });
    }

    const all = loadTimelineMetadata(workspaceRoot);
    if (!all[filePath]) {
      all[filePath] = {};
    }
    // Merge: add/update fields, delete fields set to empty string
    for (const [key, value] of Object.entries(metadata)) {
      if (value === '') {
        delete all[filePath][key];
      } else {
        all[filePath][key] = value;
      }
    }
    // Clean up empty entries
    if (Object.keys(all[filePath]).length === 0) {
      delete all[filePath];
    }
    saveTimelineMetadata(workspaceRoot, all);
    res.json({ ok: true });
  } catch (error) {
    console.error('[timeline] Error saving metadata:', error);
    res.status(500).json({ error: 'Failed to save timeline metadata' });
  }
});

// Default era ordering
const ERA_ORDER = [
  'First Age',
  'Second Age',
  'Third Age',
  'Fourth Age',
  'Future',
  'Unknown'
];


// Parse timeline metadata from HTML content
function parseTimelineEntry(content, filePath) {
  const result = {
    name: '',
    path: filePath,
    date: '',
    era: '',
    isApproximate: false,
    dateSortable: null,
    snippet: ''
  };

  // Extract Date/Period
  const dateMatch = content.match(/<p><strong>Date\/Period:<\/strong>\s*(.*?)\s*<\/p>/i);
  if (dateMatch) {
    result.date = dateMatch[1].replace(/<[^>]*>/g, '').trim();
    // Check for approximate indicator
    result.isApproximate = result.date.includes('~') || result.date.toLowerCase().includes('approx');
  }

  // Extract Era
  const eraMatch = content.match(/<p><strong>Era:<\/strong>\s*(.*?)\s*<\/p>/i);
  if (eraMatch) {
    result.era = eraMatch[1].replace(/<[^>]*>/g, '').trim();
  }

  // Extract document name from first <h2> tag
  const nameMatch = content.match(/<h2[^>]*>(.*?)<\/h2>/i);
  if (nameMatch) {
    result.name = nameMatch[1].replace(/<[^>]*>/g, '').trim();
  } else {
    // Fallback: use filename without extension
    result.name = path.basename(filePath, '.html');
  }

  // Extract first paragraph as snippet
  const snippetMatch = content.match(/<h3><\/h3>\s*<p>(.*?)<\/p>/i);
  if (!snippetMatch) {
    const pMatch = content.match(/<p>(.*?)<\/p>/i);
    if (pMatch) {
      result.snippet = pMatch[1].replace(/<[^>]*>/g, '').trim().substring(0, 100);
    }
  } else {
    result.snippet = snippetMatch[1].replace(/<[^>]*>/g, '').trim().substring(0, 100);
  }

  // Extract sortable number from date
  result.dateSortable = extractSortableDate(result.date);

  return result;
}

// Extract a sortable number from a date string
function extractSortableDate(dateStr) {
  if (!dateStr) return null;

  // Try to extract a 4-digit year (e.g., "3A 1247" → 1247, "1452 BCE" → -1452)
  const yearMatch = dateStr.match(/(\d{4,6})/);
  if (yearMatch) {
    const year = parseInt(yearMatch[1], 10);
    // Check for BCE/BC (negative years)
    if (dateStr.toLowerCase().includes('bce') || dateStr.toLowerCase().includes(' bc')) {
      return -year;
    }
    return year;
  }

  // Try to extract any numeric year (2-6 digits)
  const numMatch = dateStr.match(/(\d{2,6})/);
  if (numMatch) {
    return parseInt(numMatch[1], 10);
  }

  return null;
}

// Binary/asset extensions to skip when scanning
const BINARY_EXTENSIONS = new Set([
  'jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'svg', 'ico',
  'pdf', 'zip', 'tar', 'gz', 'rar', '7z',
  'mp3', 'mp4', 'avi', 'mov', 'wmv',
  'exe', 'dll', 'so', 'dylib',
  'docx', 'xlsx', 'pptx',
]);

function isScannableFile(filename) {
  if (filename.startsWith('.')) return false;
  const ext = path.extname(filename).toLowerCase().slice(1);
  if (BINARY_EXTENSIONS.has(ext)) return false;
  return true;
}

// Recursively walk directory to find all scannable text files (not just .html)
function walkDir(dirPath, workspaceRoot, entries = []) {
  try {
    const items = fs.readdirSync(dirPath, { withFileTypes: true });
    for (const item of items) {
      if (item.isDirectory()) {
        walkDir(path.join(dirPath, item.name), workspaceRoot, entries);
      } else if (item.isFile() && isScannableFile(item.name)) {
        const fullPath = path.join(dirPath, item.name);
        const relativePath = path.relative(workspaceRoot, fullPath);
        entries.push({ fullPath, relativePath });
      }
    }
  } catch (e) {
    // Skip directories that can't be read
  }
  return entries;
}

// GET /api/files/timeline/suggest-date?era=Third+Age - Suggest next date for era
router.get('/timeline/suggest-date', (req, res) => {
  try {
    const { era } = req.query;
    if (!era) {
      return res.status(400).json({ error: 'era query parameter required' });
    }

    const username = req.user.username;
    const workspaceRoot = getUserWorkspaceDir(username);
    if (!fs.existsSync(workspaceRoot)) {
      return res.json({ suggestedDate: '1' });
    }

    // Walk workspace to find all scannable files
    const files = walkDir(workspaceRoot, workspaceRoot);
    const persistedMeta = loadTimelineMetadata(workspaceRoot);

    let countInEra = 0;

    for (const file of files) {
      try {
        const content = fs.readFileSync(file.fullPath, 'utf-8');
        const entry = parseTimelineEntry(content, file.relativePath);

        // Merge with persisted metadata
        const stored = persistedMeta[file.relativePath];
        if (stored) {
          if (stored.date) entry.date = stored.date;
          if (stored.era) entry.era = stored.era;
        }

        if (entry.era === era) {
          countInEra++;
        }
      } catch {
        // skip
      }
    }

    res.json({ suggestedDate: String(countInEra + 1) });
  } catch (error) {
    console.error('[timeline] Error suggesting date:', error);
    res.status(500).json({ error: 'Failed to suggest date' });
  }
});

// GET /api/files/timeline - Get all timeline entries grouped by era
router.get('/timeline', (req, res) => {
  try {
    const username = req.user.username;
    const workspaceRoot = getUserWorkspaceDir(username);
    if (!fs.existsSync(workspaceRoot)) {
      return res.json({ eras: [] });
    }

    // Walk workspace to find all HTML files
    const htmlFiles = walkDir(workspaceRoot, workspaceRoot);

    // Load persisted metadata from sidecar JSON (client-set via InformationPanel)
    const persistedMeta = loadTimelineMetadata(workspaceRoot);

    const timelineEntries = [];

    for (const file of htmlFiles) {
      try {
        const content = fs.readFileSync(file.fullPath, 'utf-8');
        const isInTimelineFolder = file.relativePath.includes('/Timeline/') || 
                                   file.relativePath.startsWith('Timeline/');

        // Parse the entry from HTML content
        const entry = parseTimelineEntry(content, file.relativePath);

        // Merge with persisted metadata (client-set metadata takes precedence)
        const stored = persistedMeta[file.relativePath];
        if (stored) {
          if (stored.date) entry.date = stored.date;
          if (stored.era) entry.era = stored.era;
        }

        // Re-check approximate and re-extract sortable after merge
        entry.isApproximate = entry.date.includes('~') || entry.date.toLowerCase().includes('approx');
        entry.dateSortable = extractSortableDate(entry.date);

        // Check if this is a timeline entry (date + era required, category removed)
        const hasMetadata = entry.date && entry.era;

        if (hasMetadata || isInTimelineFolder) {
          // If in Timeline folder but missing era, infer from folder
          if (!entry.era) {
            entry.era = 'Unknown';
          }

          // Get file tags for color display
          try {
            const tagNames = getFileTagsFromService(username, file.relativePath);
            const allTags = getAllTagsFromService();
            entry.tags = tagNames.map(name => {
              const tagDef = allTags.find(t => t.name === name);
              return {
                name,
                color: tagDef ? tagDef.color : '#a78bfa'
              };
            });
          } catch {
            entry.tags = [];
          }

          timelineEntries.push(entry);
        }
      } catch (e) {
        // Skip files that can't be read
      }
    }

    // Group by era
    const eraMap = new Map();
    for (const entry of timelineEntries) {
      const eraName = entry.era || 'Unknown';
      if (!eraMap.has(eraName)) {
        eraMap.set(eraName, []);
      }
      eraMap.get(eraName).push(entry);
    }

    // Sort events within each era
    for (const [era, events] of eraMap) {
      events.sort((a, b) => {
        // If both have sortable dates, sort numerically (most recent first)
        if (a.dateSortable !== null && b.dateSortable !== null) {
          return b.dateSortable - a.dateSortable;
        }
        // If one has sortable and other doesn't, sortable comes first
        if (a.dateSortable !== null) return -1;
        if (b.dateSortable !== null) return 1;
        // Both non-numeric: sort alphabetically by date string, then by name
        if (a.date && b.date) {
          const dateCmp = a.date.localeCompare(b.date);
          if (dateCmp !== 0) return dateCmp;
        }
        return a.name.localeCompare(b.name);
      });
    }

    // Sort eras by configured order
    const sortedEras = [];
    const unknownEras = [];

    // Add eras in configured order
    for (const eraName of ERA_ORDER) {
      if (eraMap.has(eraName)) {
        sortedEras.push({
          name: eraName,
          events: eraMap.get(eraName)
        });
        eraMap.delete(eraName);
      }
    }

    // Remaining eras go to bottom (sorted alphabetically)
    for (const [eraName, events] of eraMap) {
      unknownEras.push({ name: eraName, events });
    }
    unknownEras.sort((a, b) => a.name.localeCompare(b.name));

    sortedEras.push(...unknownEras);

    res.json({ eras: sortedEras });
  } catch (error) {
    console.error('[timeline] Error fetching timeline:', error);
    res.status(500).json({ error: 'Failed to fetch timeline data' });
  }
});

export default router;