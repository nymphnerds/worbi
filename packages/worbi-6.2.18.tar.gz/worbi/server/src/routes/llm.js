import express from 'express';
import http from 'http';
import config from '../config.js';
import * as llmService from '../services/llmService.js';
import { getAllProviders, getProviderById } from '../services/providerCatalog.js';
import { detectLocalProviders, clearCache } from '../services/llmDetector.js';
import * as llmLifecycle from '../services/llmLifecycle.js';
import * as imageGenLifecycle from '../services/imageGenLifecycle.js';

const router = express.Router();

// GET /api/llm/providers — Return the static provider catalog (no auth needed)
router.get('/providers', (req, res) => {
  res.json({ providers: getAllProviders() });
});

// GET /api/llm/detect — Probe local LLM ports (auth required)
router.get('/detect', async (req, res) => {
  const username = req.user?.username;
  if (!username) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  try {
    const result = await detectLocalProviders();
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// POST /api/llm/detect/rescan — Clear cache and re-run detection (auth required)
router.post('/detect/rescan', async (req, res) => {
  const username = req.user?.username;
  if (!username) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  try {
    clearCache();
    const result = await detectLocalProviders();
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// GET /api/llm/models — Fetch models from the user's configured provider
router.get('/models', async (req, res) => {
  const username = req.user?.username;
  if (!username) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  try {
    let settings;
    if (req.query.baseUrl) {
      settings = {
        baseUrl: req.query.baseUrl,
        apiKey: req.query.apiKey || '',
        serverType: req.query.serverType || '',
      };
    } else {
      settings = config.loadUserSettings(username);
    }

    const models = await llmService.fetchModels(settings);
    res.json({ models });
  } catch (error) {
    res.status(502).json({ error: error.message });
  }
});

// GET /api/llm/system-info — DEPRECATED, use /detect instead
router.get('/system-info', async (req, res) => {
  res.json({
    modelName: '',
    serverOnline: false,
    deprecated: true,
    message: 'This endpoint is deprecated. Use GET /api/llm/detect instead.',
  });
});

// POST /api/llm/complete — Creative writing completion (ghost text at cursor)
router.post('/complete', async (req, res) => {
  const username = req.user?.username;
  if (!username) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  try {
    const { context, documentTitle, maxTokens } = req.body;

    if (!context) {
      return res.status(400).json({ error: 'Context is required' });
    }

    const settings = config.loadUserSettings(username);
    const result = await llmService.sendCompletion(context, documentTitle, maxTokens, settings);

    res.json(result);
  } catch (error) {
    res.status(502).json({ error: error.message });
  }
});

// POST /api/llm/generate-document — Generate a structured document from a prompt
router.post('/generate-document', async (req, res) => {
  const username = req.user?.username;
  if (!username) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  try {
    const { prompt, docType, documentContext } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    if (!docType) {
      return res.status(400).json({ error: 'Document type is required' });
    }

    const validTypes = ['character', 'location', 'quest', 'timeline', 'freeform'];
    if (!validTypes.includes(docType)) {
      return res.status(400).json({ error: `Invalid document type. Must be one of: ${validTypes.join(', ')}` });
    }

    const settings = config.loadUserSettings(username);
    const result = await llmService.generateDocument(prompt, docType, documentContext, settings);

    res.json(result);
  } catch (error) {
    res.status(502).json({ error: error.message });
  }
});

// POST /api/llm/transcribe-image — Transcribe an image to text using vision LLM
router.post('/transcribe-image', async (req, res) => {
  const username = req.user?.username;
  if (!username) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  try {
    const { image, prompt } = req.body;

    if (!image) {
      return res.status(400).json({ error: 'Image is required' });
    }

    const settings = config.loadUserSettings(username);
    const result = await llmService.transcribeImage(image, prompt, settings);

    res.json(result);
  } catch (error) {
    res.status(502).json({ error: error.message });
  }
});

// POST /api/llm/chat — Send chat message using user's saved settings
router.post('/chat', async (req, res) => {
  const username = req.user?.username;
  if (!username) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  try {
    const { message, history, documentContent, systemPrompt, permissions } = req.body;

    if (!message) {
      return res.status(400).json({ error: 'Message is required' });
    }

    const settings = config.loadUserSettings(username);

    const messages = (history || []).concat([{ role: 'user', content: message }]);
    const response = await llmService.sendChatMessage(messages, documentContent, systemPrompt, permissions, settings);

    res.json({ response });
  } catch (error) {
    res.status(502).json({ error: error.message });
  }
});

// GET /api/llm/detect-servers — Detect installed LLM server binaries (auth required)
router.get('/detect-servers', async (req, res) => {
  const username = req.user?.username;
  if (!username) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  try {
    const raw = llmLifecycle.detectServers();
    // Resolve running status (detectServers sets running to a Promise-like value)
    const servers = await Promise.all(raw.map(async (s) => ({
      ...s,
      running: await llmLifecycle.checkHealth(s.defaultBaseUrl),
    })));
    res.json(servers);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// GET /api/llm/server/status — Check if the LLM server is running
router.get('/server/status', async (req, res) => {
  const username = req.user?.username;
  if (!username) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  try {
    const serverType = req.query.serverType || 'llama.cpp';
    const status = await llmLifecycle.isRunning(serverType);
    res.json(status);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// POST /api/llm/server/start — Start the LLM server
router.post('/server/start', async (req, res) => {
  const username = req.user?.username;
  if (!username) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  try {
    const { serverType, folderPath } = req.body || {};
    const settings = config.loadUserSettings(username);
    const resolvedServerType = serverType || 'llama.cpp';
    const resolvedFolderPath = folderPath || settings.llm?.folderPath || '';
    const result = await llmLifecycle.startLlm(resolvedServerType, { folderPath: resolvedFolderPath });
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// POST /api/llm/server/stop — Stop the LLM server
router.post('/server/stop', async (req, res) => {
  const username = req.user?.username;
  if (!username) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  try {
    const { serverType } = req.body || {};
    const result = await llmLifecycle.stopLlm(serverType || 'llama.cpp');
    res.json(result);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Helper: POST to Z-Image server (mirrors imageGeneration.js httpPost)
function zImagePost(baseUrl, urlPath, body, timeout = 120000) {
  return new Promise((resolve, reject) => {
    const url = new URL(urlPath, baseUrl);
    const jsonData = JSON.stringify(body);
    const options = {
      hostname: url.hostname,
      port: url.port,
      path: url.pathname,
      method: 'POST',
      timeout,
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(jsonData),
      },
    };
    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try {
          resolve({ statusCode: res.statusCode, data: JSON.parse(data) });
        } catch {
          resolve({ statusCode: res.statusCode, raw: data });
        }
      });
    });
    req.on('error', (err) => reject(new Error(`Z-Image request failed: ${err.message}`)));
    req.on('timeout', () => { req.destroy(); reject(new Error('Z-Image request timed out')); });
    req.write(jsonData);
    req.end();
  });
}

// POST /api/llm/gpu-handoff — Stop LLM, generate image via Z-Image, restart LLM
router.post('/gpu-handoff', async (req, res) => {
  const username = req.user?.username;
  if (!username) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  try {
    const { prompt, negative_prompt, width, height, steps, guidance_scale, seed } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    const settings = config.loadUserSettings(username);
    // Resolve Z-Image URL from user settings
    const zImageUrl = (settings.zImage && settings.zImage.baseUrl) || config.zImage?.baseUrl || 'http://localhost:8090';
    const stages = [];

    // Stage 1: Stop LLM server to free VRAM
    console.log('[gpu-handoff] Stage 1: Stopping LLM server...');
    try {
      const stopResult = await llmLifecycle.stopLlm();
      stages.push({ stage: 'stop-llm', status: 'success', detail: stopResult });
    } catch (err) {
      stages.push({ stage: 'stop-llm', status: 'warn', detail: err.message });
    }

    // Brief pause to let GPU memory release
    await new Promise((r) => setTimeout(r, 2000));

    // Stage 2: Generate image using Z-Image directly
    console.log('[gpu-handoff] Stage 2: Generating image via Z-Image...');
    try {
      const payload = {
        mode: 'txt2img',
        prompt,
        width: width || 1024,
        height: height || 1024,
      };
      if (negative_prompt) payload.negative_prompt = negative_prompt;
      if (steps) payload.steps = steps;
      if (guidance_scale !== undefined) payload.guidance_scale = guidance_scale;
      if (seed !== null && seed !== undefined) payload.seed = seed;

      const imageResult = await zImagePost(zImageUrl, '/generate', payload);
      if (imageResult.statusCode >= 400) {
        throw new Error(imageResult.data?.detail || 'Image generation failed');
      }
      stages.push({ stage: 'generate-image', status: 'success', detail: imageResult.data });
    } catch (err) {
      stages.push({ stage: 'generate-image', status: 'failed', detail: err.message });
    }

    // Brief pause before restarting LLM
    await new Promise((r) => setTimeout(r, 2000));

    // Stage 3: Restart LLM server
    console.log('[gpu-handoff] Stage 3: Restarting LLM server...');
    try {
      const folderPath = settings.llm?.folderPath || '';
      const startResult = await llmLifecycle.startLlm('llama.cpp', { folderPath });
      stages.push({ stage: 'restart-llm', status: 'success', detail: startResult });
    } catch (err) {
      stages.push({ stage: 'restart-llm', status: 'failed', detail: err.message });
    }

    // Check final LLM status
    const finalStatus = await llmLifecycle.isRunning();

    res.json({
      stages,
      llmRestored: finalStatus.running,
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;