import { fileURLToPath } from 'url';
import fs from 'fs';
import path from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Directory for user settings JSON files
const userSettingsDir = path.join(__dirname, '../../data/user-settings');

// Global server config
const serverConfig = {
  port: process.env.PORT || 8082,
  host: '0.0.0.0',
};

// Path to lms-start script (used to extract MODEL_KEY)
const lmsStartScript = path.resolve(__dirname, '../../../bin/lms-start');

// Hardcoded LLM settings — connects to local llama-server on port 8000
// Model: qwen3.6-27b (managed via Nymphs-Brain/bin/lms-start)
const llmSettings = {
  baseUrl: 'http://localhost:8000/v1',
  apiKey: 'dummy',
  modelName: 'qwen3.6-27b',
  maxTokens: 4096,
  temperature: 0.7,
  topP: 1.0,
  topK: 50,
  frequencyPenalty: 0.0,
  presencePenalty: 0.0,
  stopSequences: '',
  seed: 0,
};

const defaultSystemPrompt = 'You are a helpful AI assistant for a game worldbuilder tool. The user is working on a document with the following content. Use this context to assist with writing, worldbuilding, lore, character development, and quest design.';

// Default user settings template
const defaultUserSettings = {
  providerId: '',          // Provider ID from catalog (e.g., 'lmstudio', 'ollama', 'openai', 'custom-local')
  serverType: '',          // Legacy field — kept for compatibility ('ollama' triggers native API path)
  baseUrl: '',             // Full base URL for the LLM API
  apiKey: '',              // API key (empty for local providers)
  modelName: '',           // Selected model name
  maxTokens: 4096,
  temperature: 0.7,
  topP: 1.0,
  topK: 50,
  frequencyPenalty: 0.0,
  presencePenalty: 0.0,
  stopSequences: '',
  seed: 0,
  systemPrompt: defaultSystemPrompt,
  // Tool permissions
  toolPermissions: {
    webSearch: true,
    fileAccessLevel: 'read', // 'none' | 'read' | 'readwrite' | 'full'
    allowCreate: false,
    allowEdit: false,
    allowDelete: false,
    allowRename: false,
    maxSearchResults: 5,
  },
  // Z-Image (Nymphs2D2) server settings
  zImage: {
    baseUrl: '',             // User's Z-Image server URL (e.g., http://localhost:8090)
    mode: 'managed',         // 'managed' (WORBI starts/stops) | 'external' (user manages)
    folderPath: '',          // User's Z-Image installation folder (overrides default ~/Z-Image)
  },
  // LLM Server (Nymphs-LLM) lifecycle settings
  llm: {
    mode: 'managed',         // 'managed' (WORBI starts/stops) | 'external' (user manages)
    folderPath: '',          // User's LLM installation folder (overrides default ~/Nymphs-LLM)
  },
  // Auto GPU handoff setting
  autoGpuHandoff: false,     // Automatically stop LLM before image gen, restart after
};

function ensureSettingsDir() {
  if (!fs.existsSync(userSettingsDir)) {
    fs.mkdirSync(userSettingsDir, { recursive: true });
  }
}

function getUserSettingsFile(username) {
  return path.join(userSettingsDir, `${username}-settings.json`);
}

function loadUserSettings(username) {
  try {
    const filePath = getUserSettingsFile(username);
    if (fs.existsSync(filePath)) {
      const data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
      // Merge with defaults to ensure all fields exist
      return { ...defaultUserSettings, ...data };
    }
  } catch (err) {
    console.error(`Failed to load settings for ${username}:`, err.message);
  }
  return { ...defaultUserSettings };
}

function saveUserSettings(username, settings) {
  try {
    ensureSettingsDir();
    const merged = { ...defaultUserSettings, ...settings };
    const filePath = getUserSettingsFile(username);
    fs.writeFileSync(filePath, JSON.stringify(merged, null, 2), 'utf-8');
    return merged;
  } catch (err) {
    console.error(`Failed to save settings for ${username}:`, err.message);
    return { ...defaultUserSettings, ...settings };
  }
}

// Ensure settings directory exists on startup
ensureSettingsDir();

// Managed LLM server type definitions — detection info for each supported server
const managedLlmServers = {
  'llama.cpp': {
    name: 'llama.cpp',
    binary: 'llama-server',
    defaultPort: 8000,
    defaultBaseUrl: 'http://localhost:8000/v1',
    searchPaths: [
      '/home/nymph/Nymphs-Brain/local-tools/bin/llama-server',
      '/home/nymph/llama.cpp/build/bin/llama-server',
      '/home/nymph/llama.cpp/llama-server',
      '/usr/local/bin/llama-server',
      '/home/nymph/.local/bin/llama-server',
    ],
    startScript: '/home/nymph/Nymphs-Brain/bin/lms-start',
    stopScript: '/home/nymph/Nymphs-Brain/bin/lms-stop',
    pidFile: '/home/nymph/Nymphs-Brain/logs/lms.pid',
    priority: 1, // Highest priority
  },
  'lm-studio': {
    name: 'LM Studio',
    binary: 'lm-studio-server',
    defaultPort: 1234,
    defaultBaseUrl: 'http://localhost:1234/v1',
    searchPaths: [
      '/home/nymph/.lmstudio/bin/lm-studio-server',
      '/home/nymph/.cache/lm-studio/bin/lm-studio-server',
    ],
    priority: 2,
  },
  'ollama': {
    name: 'Ollama',
    binary: 'ollama',
    defaultPort: 11434,
    defaultBaseUrl: 'http://localhost:11434/v1',
    searchPaths: [
      '/usr/local/bin/ollama',
      '/home/nymph/.local/bin/ollama',
      '/home/nymph/ollama/ollama',
    ],
    isSystemd: true, // May run as systemd service
    priority: 3,
  },
  'vllm': {
    name: 'vLLM',
    binary: 'vllm',
    defaultPort: 8000,
    defaultBaseUrl: 'http://localhost:8000/v1',
    searchPaths: [
      '/home/nymph/.local/bin/vllm',
      '/usr/local/bin/vllm',
    ],
    priority: 4,
  },
  'textgen-webui': {
    name: 'TextGen WebUI',
    binary: 'server.py',
    defaultPort: 5000,
    defaultBaseUrl: 'http://localhost:5000/v1',
    searchPaths: [
      '/home/nymph/text-generation-webui/server.py',
    ],
    priority: 5,
  },
  'localai': {
    name: 'LocalAI',
    binary: 'localai',
    defaultPort: 8080,
    defaultBaseUrl: 'http://localhost:8080/v1',
    searchPaths: [
      '/usr/local/bin/localai',
      '/home/nymph/.local/bin/localai',
    ],
    priority: 6,
  },
  'jan': {
    name: 'Jan',
    binary: 'jan',
    defaultPort: 1337,
    defaultBaseUrl: 'http://localhost:1337/v1',
    searchPaths: [
      '/home/nymph/.jan/bin/jan',
    ],
    priority: 7,
  },
};

// Z-Image (Nymphs2D2) configuration
const zImageSettings = {
  baseUrl: process.env.Z_IMAGE_BASE_URL || 'http://localhost:8090',
  timeoutMs: parseInt(process.env.Z_IMAGE_TIMEOUT_MS || '120000'),
  startTimeoutMs: parseInt(process.env.Z_IMAGE_START_TIMEOUT_MS || '60000'),
  scriptsDir: process.env.Z_IMAGE_SCRIPTS_DIR || '/home/nymph/Nymphs-Brain/bin',
  outputDir: process.env.Z_IMAGE_OUTPUT_DIR || '/home/nymph/Z-Image/outputs',
  minVramMb: parseInt(process.env.Z_IMAGE_MIN_VRAM_MB || '8192'), // Minimum free VRAM in MB for generation
};

const config = {
  port: serverConfig.port,
  host: serverConfig.host,
  llm: llmSettings,
  managedLlmServers,
  zImage: zImageSettings,
  lmsStartScript,
  loadUserSettings,
  saveUserSettings,
};

export default config;
