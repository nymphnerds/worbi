import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import fs from 'fs';
import path from 'path';
import os from 'os';

// Mock authService before importing locationService
let mockWorkspaceDir = '/tmp/mock-workspace';
let tempRoot = '';
let mockHome = '';

// Pre-create temp dirs before vi.mock factory runs (mocks are hoisted)
tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'worbi-loc-pre-'));
mockHome = path.join(tempRoot, 'home');
mockWorkspaceDir = path.join(tempRoot, 'workspace');
fs.mkdirSync(mockHome, { recursive: true });
fs.mkdirSync(mockWorkspaceDir, { recursive: true });

vi.mock('../../../src/services/authService.js', () => ({
  getUserWorkspaceDir: () => mockWorkspaceDir,
}));

// Mock os.homedir to redirect ~/.wbu to a temp directory
vi.mock('os', async () => {
  const actual = await vi.importActual<any>('os');
  return {
    ...actual,
    homedir: () => mockHome,
  };
});

import * as locationService from '../../../src/services/locationService.js';

// Helper to get the locations.json path
function getLocationsPath() {
  return path.join(mockHome, '.wbu', 'locations.json');
}

// Default locations the service initializes with
const DEFAULT_REGISTRY = {
  locations: [
    { id: 'loc_001', name: 'Home', color: '#22c55e', description: 'Home location' },
    { id: 'loc_002', name: 'Work', color: '#3b82f6', description: 'Workplace' },
    { id: 'loc_003', name: 'Travel', color: '#f59e0b', description: 'Travel destination' },
  ],
};

describe('locationService (functional with temp workspace)', () => {
  beforeEach(() => {
    // Clean and recreate for each test
    if (fs.existsSync(tempRoot)) {
      fs.rmSync(tempRoot, { recursive: true, force: true });
    }
    fs.mkdirSync(mockHome, { recursive: true });
    fs.mkdirSync(mockWorkspaceDir, { recursive: true });
    // Reset locations.json to defaults
    const locPath = getLocationsPath();
    fs.mkdirSync(path.dirname(locPath), { recursive: true });
    fs.writeFileSync(locPath, JSON.stringify(DEFAULT_REGISTRY, null, 2), 'utf-8');
  });

  afterEach(() => {
    if (tempRoot && fs.existsSync(tempRoot)) {
      fs.rmSync(tempRoot, { recursive: true, force: true });
    }
  });

  // ─── getAllLocations ───

  describe('getAllLocations()', () => {
    it('returns default locations after init', () => {
      const locations = locationService.getAllLocations();
      expect(locations.length).toBeGreaterThanOrEqual(3);
      const names = locations.map((l: any) => l.name);
      expect(names).toContain('Home');
      expect(names).toContain('Work');
      expect(names).toContain('Travel');
    });

    it('includes id, name, color, description fields', () => {
      const locations = locationService.getAllLocations();
      const loc = locations[0];
      expect(loc.id).toBeDefined();
      expect(loc.name).toBeDefined();
      expect(loc.color).toBeDefined();
      expect(loc.description).toBeDefined();
    });
  });

  // ─── createLocation ───

  describe('createLocation()', () => {
    it('creates a location with name and defaults', () => {
      const ts = Date.now();
      const loc = locationService.createLocation(`Gym-${ts}`, undefined, 'Fitness center');
      expect(loc.name).toBe(`Gym-${ts}`);
      expect(loc.id).toMatch(/^loc_/);
      expect(loc.color).toBe('#10b981');
      expect(loc.description).toBe('Fitness center');
    });

    it('creates with custom color', () => {
      const ts = Date.now();
      const loc = locationService.createLocation(`Gym2-${ts}`, '#ff0000', 'Red gym');
      expect(loc.color).toBe('#ff0000');
    });

    it('throws when name is empty', () => {
      expect(() => locationService.createLocation('', undefined, '')).toThrow('Location name is required');
    });

    it('throws on duplicate name (case-insensitive)', () => {
      // "Home" already exists as default
      expect(() => locationService.createLocation('home', undefined, '')).toThrow(/already exists/i);
    });

    it('trims whitespace from name', () => {
      const ts = Date.now();
      const loc = locationService.createLocation(`  Trimmed-${ts}  `, undefined, '');
      expect(loc.name).toBe(`Trimmed-${ts}`);
    });
  });

  // ─── updateLocation ───

  describe('updateLocation()', () => {
    it('updates name', () => {
      const ts = Date.now();
      const created = locationService.createLocation(`Temp-${ts}`, undefined, '');
      const renamedTs = Date.now();
      const updated = locationService.updateLocation(created.id, { name: `Renamed-${renamedTs}` });
      expect(updated.name).toBe(`Renamed-${renamedTs}`);
    });

    it('updates color and description', () => {
      const ts = Date.now();
      const created = locationService.createLocation(`Temp2-${ts}`, undefined, '');
      const updated = locationService.updateLocation(created.id, {
        color: '#00ff00',
        description: 'Updated desc',
      });
      expect(updated.color).toBe('#00ff00');
      expect(updated.description).toBe('Updated desc');
    });

    it('throws when location not found', () => {
      expect(() => locationService.updateLocation('loc_nonexistent', { name: 'X' }))
        .toThrow('Location not found');
    });

    it('throws on empty name update', () => {
      const ts = Date.now();
      const created = locationService.createLocation(`Temp3-${ts}`, undefined, '');
      expect(() => locationService.updateLocation(created.id, { name: '' }))
        .toThrow('Location name cannot be empty');
    });

    it('throws on duplicate name update', () => {
      const ts = Date.now();
      // Default "Work" exists
      const created = locationService.createLocation(`Unique-${ts}`, undefined, '');
      expect(() => locationService.updateLocation(created.id, { name: 'Work' }))
        .toThrow(/already exists/i);
    });
  });

  // ─── deleteLocation ───

  describe('deleteLocation()', () => {
    it('deletes a location', () => {
      const ts = Date.now();
      const created = locationService.createLocation(`ToDelete-${ts}`, undefined, '');
      const result = locationService.deleteLocation(created.id);
      expect(result.success).toBe(true);
      const all = locationService.getAllLocations();
      expect(all.some((l: any) => l.id === created.id)).toBe(false);
    });

    it('throws when location not found', () => {
      expect(() => locationService.deleteLocation('loc_nonexistent'))
        .toThrow('Location not found');
    });
  });

  // ─── File location operations ───

  describe('getFileLocations()', () => {
    it('returns empty array for file with no locations', () => {
      const locs = locationService.getFileLocations('testuser', 'doc.html');
      expect(locs).toEqual([]);
    });
  });

  describe('addLocationsToFile()', () => {
    it('adds a valid location to file', () => {
      const result = locationService.addLocationsToFile('testuser', 'doc.html', ['Home']);
      expect(result.success).toBe(true);
      expect(result.added).toContain('Home');
    });

    it('does not add duplicate', () => {
      locationService.addLocationsToFile('testuser', 'doc2.html', ['Home']);
      const result2 = locationService.addLocationsToFile('testuser', 'doc2.html', ['Home']);
      expect(result2.added).toEqual([]);
    });

    it('throws for non-existent location', () => {
      expect(() =>
        locationService.addLocationsToFile('testuser', 'doc.html', ['NonExistent'])
      ).toThrow(/does not exist/i);
    });
  });

  describe('removeLocationFromFile()', () => {
    it('removes location from file', () => {
      locationService.addLocationsToFile('testuser', 'doc3.html', ['Home', 'Work']);
      const locs = locationService.getFileLocations('testuser', 'doc3.html');
      expect(locs.length).toBe(2);

      locationService.removeLocationFromFile('testuser', 'doc3.html', 'Home');
      const locsAfter = locationService.getFileLocations('testuser', 'doc3.html');
      expect(locsAfter).not.toContain('Home');
      expect(locsAfter).toContain('Work');
    });
  });

  describe('setFileLocations()', () => {
    it('replaces all locations', () => {
      locationService.addLocationsToFile('testuser', 'doc4.html', ['Home', 'Work']);
      const result = locationService.setFileLocations('testuser', 'doc4.html', ['Travel']);
      expect(result.locations).toEqual(['Travel']);

      const locs = locationService.getFileLocations('testuser', 'doc4.html');
      expect(locs).toEqual(['Travel']);
    });

    it('throws for non-existent location', () => {
      expect(() =>
        locationService.setFileLocations('testuser', 'doc.html', ['NonExistent'])
      ).toThrow(/does not exist/i);
    });
  });

  describe('getFilesByLocation()', () => {
    it('returns files with the location', () => {
      // Create a scannable file in the workspace
      fs.writeFileSync(path.join(mockWorkspaceDir, 'located.html'), '<h1>Hi</h1>');
      locationService.addLocationsToFile('testuser', 'located.html', ['Home']);

      const results = locationService.getFilesByLocation('testuser', 'Home');
      expect(results.length).toBeGreaterThanOrEqual(1);
      const found = results.find((r: any) => r.name === 'located.html');
      expect(found).toBeDefined();
      expect(found!.locations).toContain('Home');
    });

    it('returns empty array for location with no files', () => {
      const results = locationService.getFilesByLocation('testuser', 'Travel');
      expect(results).toEqual([]);
    });

    it('skips dotfiles', () => {
      fs.writeFileSync(path.join(mockWorkspaceDir, '.hidden'), 'secret');
      // dotfiles are not scannable, so adding location won't appear in walk
      const results = locationService.getFilesByLocation('testuser', 'Home');
      const hidden = results.find((r: any) => r.name === '.hidden');
      expect(hidden).toBeUndefined();
    });
  });
});