import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import fs from 'fs';
import path from 'path';
import os from 'os';

// Mock authService before importing fileService
let mockWorkspaceDir = '/tmp/mock-workspace';
let mockAssetsDir = '/tmp/mock-assets';
let tempRoot = '';

vi.mock('../../../src/services/authService.js', () => ({
  getUserWorkspaceDir: () => mockWorkspaceDir,
  getUserAssetsDir: () => mockAssetsDir,
}));

import * as fileService from '../../../src/services/fileService.js';

// ─── Path Safety Tests (use default mock paths) ───

describe('fileService.getSafePath()', () => {
  it('resolves a simple relative path within workspace', () => {
    const result = fileService.getSafePath('testuser', 'foo/bar.html');
    expect(result).toContain('foo/bar.html');
    expect(result).not.toContain('..');
  });

  it('resolves empty string to workspace root', () => {
    const result = fileService.getSafePath('testuser', '');
    expect(result).toBeDefined();
    expect(result).toBe(mockWorkspaceDir);
  });

  it('blocks path traversal with ../', () => {
    expect(() => fileService.getSafePath('testuser', '../../../etc/passwd'))
      .toThrow(/traversal|outside|forbidden|invalid/i);
  });

  it('treats absolute path as relative segment (path.join behavior)', () => {
    const result = fileService.getSafePath('testuser', '/etc/passwd');
    expect(result).toContain('mock-workspace');
    expect(result).not.toEqual('/etc/passwd');
  });

  it('blocks traversal nested in subdirectory', () => {
    expect(() => fileService.getSafePath('testuser', 'docs/../../../../etc/passwd'))
      .toThrow(/traversal|outside|forbidden|invalid/i);
  });

  it('allows deep nested paths within workspace', () => {
    const result = fileService.getSafePath('testuser', 'a/b/c/d/e/file.html');
    expect(result).toContain('a/b/c/d/e/file.html');
  });

  it('handles null input (treated as empty string via || operator)', () => {
    const result = fileService.getSafePath('testuser', null as any);
    expect(result).toBeDefined();
    expect(result).toBe(mockWorkspaceDir);
  });

  it('handles undefined input (treated as empty string via || operator)', () => {
    const result = fileService.getSafePath('testuser', undefined as any);
    expect(result).toBeDefined();
    expect(result).toBe(mockWorkspaceDir);
  });

  it('handles backslashes as literal path components on Unix', () => {
    const result = fileService.getSafePath('testuser', '..\\..\\etc\\passwd');
    expect(result).toBeDefined();
    expect(result).toContain('mock-workspace');
  });

  it('handles dot-dot at end of path segment', () => {
    expect(() => fileService.getSafePath('testuser', 'foo/../..'))
      .toThrow(/traversal|outside|forbidden|invalid/i);
  });
});

describe('fileService.getImageFullPath()', () => {
  it('resolves simple path segments within assets', () => {
    const result = fileService.getImageFullPath('testuser', ['hero.png']);
    expect(result).toContain('hero.png');
    expect(result).not.toContain('..');
  });

  it('resolves nested path segments within assets', () => {
    const result = fileService.getImageFullPath('testuser', ['subdir', 'image.png']);
    expect(result).toContain('subdir');
    expect(result).toContain('image.png');
  });

  it('blocks path traversal with .. in segments', () => {
    expect(() => fileService.getImageFullPath('testuser', ['..', 'secret.png']))
      .toThrow(/traversal|outside|forbidden|invalid/i);
  });

  it('blocks traversal deep in segments', () => {
    expect(() => fileService.getImageFullPath('testuser', ['a', '..', '..', 'etc', 'passwd']))
      .toThrow(/traversal|outside|forbidden|invalid/i);
  });
});

describe('fileService.getSafeWorkspaceFilePath()', () => {
  it('resolves simple path segments within workspace', () => {
    const result = fileService.getSafeWorkspaceFilePath('testuser', ['docs', 'notes.html']);
    expect(result).toContain('docs');
    expect(result).toContain('notes.html');
  });

  it('resolves empty segments to workspace root', () => {
    const result = fileService.getSafeWorkspaceFilePath('testuser', []);
    expect(result).toBe(mockWorkspaceDir);
  });

  it('blocks path traversal with .. in segments', () => {
    expect(() => fileService.getSafeWorkspaceFilePath('testuser', ['..', 'etc', 'passwd']))
      .toThrow(/traversal|outside|forbidden|invalid/i);
  });

  it('allows deep nested segments', () => {
    const result = fileService.getSafeWorkspaceFilePath('testuser', ['a', 'b', 'c', 'd', 'file.html']);
    expect(result).toContain('a/b/c/d/file.html');
  });
});

// ─── Functional Tests with Temp Workspace ───

describe('fileService (functional with temp workspace)', () => {
  const testUser = 'testuser-func';

  beforeEach(() => {
    tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'worbi-fs-'));
    mockWorkspaceDir = path.join(tempRoot, 'workspace');
    mockAssetsDir = path.join(tempRoot, 'assets', 'images');
    fs.mkdirSync(mockWorkspaceDir, { recursive: true });
    fs.mkdirSync(mockAssetsDir, { recursive: true });
  });

  afterEach(() => {
    if (tempRoot && fs.existsSync(tempRoot)) {
      fs.rmSync(tempRoot, { recursive: true, force: true });
    }
  });

  describe('listDirectory()', () => {
    it('lists files and folders with correct type field', () => {
      fs.mkdirSync(path.join(mockWorkspaceDir, 'subdir'), { recursive: true });
      fs.writeFileSync(path.join(mockWorkspaceDir, 'file1.html'), '<h1>Hello</h1>');
      fs.writeFileSync(path.join(mockWorkspaceDir, 'file2.html'), '<p>World</p>');

      const results = fileService.listDirectory(testUser, '');
      expect(results.length).toBe(3);

      const file1 = results.find((r: any) => r.name === 'file1.html');
      expect(file1!.type).toBe('file');
      expect(file1!.size).toBeGreaterThan(0);

      const subdir = results.find((r: any) => r.name === 'subdir');
      expect(subdir!.type).toBe('folder');
      expect(subdir!.size).toBeUndefined();
    });

    it('returns empty array for empty directory', () => {
      const results = fileService.listDirectory(testUser, '');
      expect(results).toEqual([]);
    });

    it('only returns direct children (not recursive)', () => {
      fs.mkdirSync(path.join(mockWorkspaceDir, 'a', 'b'), { recursive: true });
      fs.writeFileSync(path.join(mockWorkspaceDir, 'a', 'b', 'deep.html'), 'deep');
      fs.writeFileSync(path.join(mockWorkspaceDir, 'a', 'top.html'), 'top');

      const results = fileService.listDirectory(testUser, '');
      expect(results.length).toBe(1);
      expect(results[0].name).toBe('a');
    });

    it('subdirectory listing when path provided', () => {
      fs.mkdirSync(path.join(mockWorkspaceDir, 'docs'), { recursive: true });
      fs.writeFileSync(path.join(mockWorkspaceDir, 'docs', 'guide.html'), 'guide');

      const results = fileService.listDirectory(testUser, 'docs');
      expect(results.length).toBe(1);
      expect(results[0].name).toBe('guide.html');
    });

    it('throws for non-existent path', () => {
      expect(() => fileService.listDirectory(testUser, 'nonexistent')).toThrow();
    });

    it('files include size, folders exclude size', () => {
      fs.writeFileSync(path.join(mockWorkspaceDir, 'sized.html'), 'abc');
      fs.mkdirSync(path.join(mockWorkspaceDir, 'folder'));

      const results = fileService.listDirectory(testUser, '');
      const file = results.find((r: any) => r.name === 'sized.html');
      const folder = results.find((r: any) => r.name === 'folder');
      expect(file!.size).toBe(3);
      expect(folder!.size).toBeUndefined();
    });

    it('hides dotfiles', () => {
      fs.writeFileSync(path.join(mockWorkspaceDir, '.hidden'), 'secret');
      fs.writeFileSync(path.join(mockWorkspaceDir, 'visible.html'), 'hi');

      const results = fileService.listDirectory(testUser, '');
      const names = results.map((r: any) => r.name);
      expect(names).not.toContain('.hidden');
      expect(names).toContain('visible.html');
    });
  });

  describe('readFile()', () => {
    it('returns correct content', () => {
      fs.writeFileSync(path.join(mockWorkspaceDir, 'test.html'), '<h1>Test</h1>');
      const content = fileService.readFile(testUser, 'test.html');
      expect(content).toBe('<h1>Test</h1>');
    });

    it('throws on directory', () => {
      fs.mkdirSync(path.join(mockWorkspaceDir, 'adir'));
      expect(() => fileService.readFile(testUser, 'adir')).toThrow(/directory/i);
    });

    it('throws on missing file', () => {
      expect(() => fileService.readFile(testUser, 'missing.html')).toThrow(/not found/i);
    });
  });

  describe('writeFile()', () => {
    it('creates file with content', () => {
      fileService.writeFile(testUser, 'new.html', '<p>New</p>');
      const content = fs.readFileSync(path.join(mockWorkspaceDir, 'new.html'), 'utf-8');
      expect(content).toBe('<p>New</p>');
    });

    it('auto-creates parent directories', () => {
      fileService.writeFile(testUser, 'deep/nested/file.html', 'content');
      expect(fs.existsSync(path.join(mockWorkspaceDir, 'deep', 'nested', 'file.html'))).toBe(true);
    });

    it('overwrites existing file', () => {
      fileService.writeFile(testUser, 'overwrite.html', 'first');
      fileService.writeFile(testUser, 'overwrite.html', 'second');
      const content = fileService.readFile(testUser, 'overwrite.html');
      expect(content).toBe('second');
    });
  });

  describe('createFolder()', () => {
    it('creates folder', () => {
      fileService.createFolder(testUser, 'newfolder');
      expect(fs.statSync(path.join(mockWorkspaceDir, 'newfolder')).isDirectory()).toBe(true);
    });

    it('throws if folder already exists', () => {
      fileService.createFolder(testUser, 'exists');
      expect(() => fileService.createFolder(testUser, 'exists')).toThrow(/already exists/i);
    });

    it('creates nested folders with recursive', () => {
      fileService.createFolder(testUser, 'a/b/c');
      expect(fs.statSync(path.join(mockWorkspaceDir, 'a', 'b', 'c')).isDirectory()).toBe(true);
    });
  });

  describe('deleteItem()', () => {
    it('deletes file', () => {
      fs.writeFileSync(path.join(mockWorkspaceDir, 'del.html'), 'delete me');
      fileService.deleteItem(testUser, 'del.html');
      expect(fs.existsSync(path.join(mockWorkspaceDir, 'del.html'))).toBe(false);
    });

    it('deletes empty folder', () => {
      fs.mkdirSync(path.join(mockWorkspaceDir, 'emptydir'));
      fileService.deleteItem(testUser, 'emptydir');
      expect(fs.existsSync(path.join(mockWorkspaceDir, 'emptydir'))).toBe(false);
    });

    it('deletes folder recursively', () => {
      fs.mkdirSync(path.join(mockWorkspaceDir, 'parent', 'child'), { recursive: true });
      fs.writeFileSync(path.join(mockWorkspaceDir, 'parent', 'child', 'file.html'), 'deep');
      fileService.deleteItem(testUser, 'parent');
      expect(fs.existsSync(path.join(mockWorkspaceDir, 'parent'))).toBe(false);
    });

    it('throws if item not found', () => {
      expect(() => fileService.deleteItem(testUser, 'nope.html')).toThrow(/not found/i);
    });
  });

  describe('renameItem()', () => {
    it('renames file', () => {
      fs.writeFileSync(path.join(mockWorkspaceDir, 'old.html'), 'content');
      fileService.renameItem(testUser, 'old.html', 'new.html');
      expect(fs.existsSync(path.join(mockWorkspaceDir, 'new.html'))).toBe(true);
      expect(fs.existsSync(path.join(mockWorkspaceDir, 'old.html'))).toBe(false);
    });

    it('renames folder', () => {
      fs.mkdirSync(path.join(mockWorkspaceDir, 'oldfolder'));
      fileService.renameItem(testUser, 'oldfolder', 'newfolder');
      expect(fs.existsSync(path.join(mockWorkspaceDir, 'newfolder'))).toBe(true);
      expect(fs.existsSync(path.join(mockWorkspaceDir, 'oldfolder'))).toBe(false);
    });

    it('throws if source missing', () => {
      expect(() => fileService.renameItem(testUser, 'missing.html', 'new.html')).toThrow(/not found/i);
    });

    it('throws if destination exists', () => {
      fs.writeFileSync(path.join(mockWorkspaceDir, 'a.html'), 'a');
      fs.writeFileSync(path.join(mockWorkspaceDir, 'b.html'), 'b');
      expect(() => fileService.renameItem(testUser, 'a.html', 'b.html')).toThrow(/already exists/i);
    });
  });

  describe('copyItem()', () => {
    it('copies file with -copy suffix', () => {
      fs.writeFileSync(path.join(mockWorkspaceDir, 'original.html'), '<h1>Original</h1>');
      const result = fileService.copyItem(testUser, 'original.html');
      expect(result.destName).toBe('original-copy.html');
      expect(fs.existsSync(path.join(mockWorkspaceDir, 'original-copy.html'))).toBe(true);
    });

    it('copies across directories', () => {
      fs.writeFileSync(path.join(mockWorkspaceDir, 'source.html'), 'source content');
      fs.mkdirSync(path.join(mockWorkspaceDir, 'target'));
      const result = fileService.copyItem(testUser, 'source.html', 'target');
      expect(result.destPath).toContain('target');
      expect(result.destPath).toContain('source-copy.html');
    });

    it('throws on conflict', () => {
      fs.writeFileSync(path.join(mockWorkspaceDir, 'file.html'), 'a');
      fs.writeFileSync(path.join(mockWorkspaceDir, 'file-copy.html'), 'b');
      expect(() => fileService.copyItem(testUser, 'file.html')).toThrow(/already exists/i);
    });

    it('throws for directories', () => {
      fs.mkdirSync(path.join(mockWorkspaceDir, 'adir'));
      expect(() => fileService.copyItem(testUser, 'adir')).toThrow(/folder copy not supported/i);
    });
  });

  describe('moveItem()', () => {
    it('moves file to destination folder', () => {
      fs.writeFileSync(path.join(mockWorkspaceDir, 'mefile.html'), 'move me');
      fs.mkdirSync(path.join(mockWorkspaceDir, 'dest'));
      const result = fileService.moveItem(testUser, 'mefile.html', 'dest');
      expect(result.destPath).toContain('dest');
      expect(result.destPath).toContain('mefile.html');
      expect(fs.existsSync(path.join(mockWorkspaceDir, 'mefile.html'))).toBe(false);
    });

    it('source gone after move', () => {
      fs.writeFileSync(path.join(mockWorkspaceDir, 'src.html'), 'hi');
      fs.mkdirSync(path.join(mockWorkspaceDir, 'tgt'));
      fileService.moveItem(testUser, 'src.html', 'tgt');
      expect(fs.existsSync(path.join(mockWorkspaceDir, 'src.html'))).toBe(false);
    });

    it('throws if source missing', () => {
      expect(() => fileService.moveItem(testUser, 'nope.html', 'dest')).toThrow(/not found/i);
    });

    it('throws if destination file exists', () => {
      fs.writeFileSync(path.join(mockWorkspaceDir, 'file.html'), 'source');
      fs.mkdirSync(path.join(mockWorkspaceDir, 'dest'));
      fs.writeFileSync(path.join(mockWorkspaceDir, 'dest', 'file.html'), 'existing');
      expect(() => fileService.moveItem(testUser, 'file.html', 'dest')).toThrow(/already exists/i);
    });
  });

  describe('searchWorkspace()', () => {
    it('matches filename', () => {
      fs.writeFileSync(path.join(mockWorkspaceDir, 'myquest.html'), 'content');
      const result = fileService.searchWorkspace(testUser, 'myquest');
      expect(result.results.length).toBe(1);
      expect(result.results[0].name).toBe('myquest.html');
    });

    it('matches content', () => {
      fs.writeFileSync(path.join(mockWorkspaceDir, 'doc.html'), 'The dragon awakens');
      const result = fileService.searchWorkspace(testUser, 'dragon');
      expect(result.results.length).toBe(1);
      expect(result.results[0].matches.length).toBeGreaterThan(0);
    });

    it('returns context around match', () => {
      fs.writeFileSync(path.join(mockWorkspaceDir, 'doc.html'), 'Lorem ipsum SEARCH_WORD dolor sit amet');
      const result = fileService.searchWorkspace(testUser, 'SEARCH_WORD');
      const context = result.results[0].matches[0].context;
      expect(context).toContain('SEARCH_WORD');
      expect(context).toContain('ipsum');
    });

    it('respects limit', () => {
      for (let i = 0; i < 5; i++) {
        fs.writeFileSync(path.join(mockWorkspaceDir, `limit${i}.html`), 'limit test content');
      }
      const result = fileService.searchWorkspace(testUser, 'limit', { limit: 3 });
      expect(result.results.length).toBeLessThanOrEqual(3);
    });

    it('skips binary files', () => {
      fs.writeFileSync(path.join(mockWorkspaceDir, 'image.jpg'), 'JPEG fake data');
      const result = fileService.searchWorkspace(testUser, 'fake');
      const jpgResults = result.results.filter((r: any) => r.name.endsWith('.jpg'));
      expect(jpgResults.length).toBe(0);
    });

    it('handles empty workspace', () => {
      const result = fileService.searchWorkspace(testUser, 'anything');
      expect(result.results).toEqual([]);
      expect(result.total).toBe(0);
    });

    it('handles no-match query', () => {
      fs.writeFileSync(path.join(mockWorkspaceDir, 'doc.html'), 'no match here');
      const result = fileService.searchWorkspace(testUser, 'xyznonexistent');
      expect(result.results.length).toBe(0);
    });
  });

  describe('recents', () => {
    it('saveUserRecents persists data', () => {
      const data = [{ name: 'a.html', path: 'a.html' }];
      fileService.saveUserRecents(testUser, data);
      const content = fs.readFileSync(path.join(mockWorkspaceDir, '.wbu_recents.json'), 'utf-8');
      expect(JSON.parse(content)).toEqual(data);
    });

    it('loadUserRecents retrieves data', () => {
      fs.writeFileSync(path.join(mockWorkspaceDir, '.wbu_recents.json'), JSON.stringify([{ name: 'x' }]));
      const data = fileService.loadUserRecents(testUser);
      expect(data).toEqual([{ name: 'x' }]);
    });

    it('loadUserRecents returns [] when file missing', () => {
      const data = fileService.loadUserRecents(testUser);
      expect(data).toEqual([]);
    });
  });

  describe('starred', () => {
    it('saveUserStarred persists data', () => {
      const data = [{ name: 'fav.html' }];
      fileService.saveUserStarred(testUser, data);
      const content = fs.readFileSync(path.join(mockWorkspaceDir, '.wbu_starred.json'), 'utf-8');
      expect(JSON.parse(content)).toEqual(data);
    });

    it('loadUserStarred retrieves data', () => {
      fs.writeFileSync(path.join(mockWorkspaceDir, '.wbu_starred.json'), JSON.stringify([{ name: 'star' }]));
      const data = fileService.loadUserStarred(testUser);
      expect(data).toEqual([{ name: 'star' }]);
    });

    it('loadUserStarred returns [] when file missing', () => {
      const data = fileService.loadUserStarred(testUser);
      expect(data).toEqual([]);
    });
  });
});