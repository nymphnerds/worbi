import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';

// Mock modules before importing the service
vi.mock('child_process', () => ({
  spawn: vi.fn(),
}));

vi.mock('http', () => ({
  default: {
    get: vi.fn(),
  },
}));

vi.mock('../../../src/config.js', () => ({
  default: {
    zImage: {
      scriptsDir: '/test/scripts',
      baseUrl: 'http://localhost:8090',
      startTimeoutMs: 5000,
    },
  },
}));

import * as cp from 'child_process';
import http from 'http';
import { startServer, stopServer, isRunning, checkHealth } from '../../../src/services/imageGenLifecycle.js';

// Helper: create a mock child process
function mockChildProcess(exitCode = 0) {
  const mock = {
    stdout: { on: vi.fn() },
    stderr: { on: vi.fn() },
    on: vi.fn((event, handler) => {
      if (event === 'close') {
        // Defer callback so Promise can resolve
        setImmediate(() => handler(exitCode));
      }
    }),
  } as any;
  return mock;
}

// Helper: create a mock http response
function mockHttpResponse(statusCode = 200, data: any = {}) {
  const mock = {
    statusCode,
    on: vi.fn((event, handler) => {
      if (event === 'data') {
        setImmediate(() => handler(JSON.stringify(data)));
      }
      if (event === 'end') {
        setImmediate(handler);
      }
    }),
  } as any;
  return mock;
}

describe('imageGenLifecycle', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    (cp.spawn as any).mockReset();
    (http.get as any).mockReset();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  describe('startServer()', () => {
    it('spawns the start script', async () => {
      (cp.spawn as any).mockReturnValue(mockChildProcess(0));
      (http.get as any).mockImplementation((_url: any, _opts: any, callback: any) => {
        setImmediate(() => callback(mockHttpResponse(200, { status: 'healthy' })));
        return mockHttpResponse();
      });

      const result = await startServer();
      expect(result.success).toBe(true);
      expect(cp.spawn).toHaveBeenCalledWith('/test/scripts/zimage-start', expect.any(Object));
    });

    it('passes Z_IMAGE_DIR env var when folderPath provided', async () => {
      (cp.spawn as any).mockReturnValue(mockChildProcess(0));
      (http.get as any).mockImplementation((_url: any, _opts: any, callback: any) => {
        setImmediate(() => callback(mockHttpResponse(200, { status: 'healthy' })));
        return mockHttpResponse();
      });

      await startServer({ folderPath: '/my/zimage/folder' });

      const spawnCall = (cp.spawn as any).mock.calls[0];
      expect(spawnCall[1].env).toBeDefined();
      expect(spawnCall[1].env.Z_IMAGE_DIR).toBe('/my/zimage/folder');
    });

    it('throws when server not ready after timeout', async () => {
      (cp.spawn as any).mockReturnValue(mockChildProcess(0));
      (http.get as any).mockImplementation((_url: any, _opts: any, _callback: any) => {
        const mockReq = {
          on: vi.fn((event: any, handler: any) => {
            if (event === 'timeout') setImmediate(handler);
          }),
          destroy: vi.fn(),
        } as any;
        return mockReq;
      });

      await expect(startServer({})).rejects.toThrow();
    });
  });

  describe('stopServer()', () => {
    it('spawns the stop script', async () => {
      (cp.spawn as any).mockReturnValue(mockChildProcess(0));

      const result = await stopServer();
      expect(result.success).toBe(true);
      expect(cp.spawn).toHaveBeenCalledWith('/test/scripts/zimage-stop', expect.any(Object));
    });

    it('returns success:false when stop script fails', async () => {
      (cp.spawn as any).mockReturnValue(mockChildProcess(1));

      const result = await stopServer();
      expect(result.success).toBe(false);
    });
  });

  describe('isRunning()', () => {
    it('returns running:true when health check passes', async () => {
      (http.get as any).mockImplementation((_url: any, _opts: any, callback: any) => {
        setImmediate(() => callback(mockHttpResponse(200, { status: 'healthy' })));
        return mockHttpResponse();
      });

      const result = await isRunning();
      expect(result.running).toBe(true);
    });

    it('returns running:false on connection failure', async () => {
      (http.get as any).mockImplementation((_url: any, opts: any, _callback: any) => {
        const mockReq = {
          on: vi.fn((event: any, handler: any) => {
            if (event === 'error') {
              setImmediate(() => handler(new Error('ECONNREFUSED')));
            }
          }),
        } as any;
        return mockReq;
      });

      const result = await isRunning();
      expect(result.running).toBe(false);
    });
  });

  describe('checkHealth()', () => {
    it('returns true when server responds with healthy status', async () => {
      (http.get as any).mockImplementation((_url: any, _opts: any, callback: any) => {
        setImmediate(() => callback(mockHttpResponse(200, { status: 'healthy' })));
        return mockHttpResponse();
      });

      const result = await checkHealth('http://localhost:8090');
      expect(result).toBe(true);
    });

    it('returns false on connection error', async () => {
      (http.get as any).mockImplementation((_url: any, opts: any, _callback: any) => {
        const mockReq = {
          on: vi.fn((event: any, handler: any) => {
            if (event === 'error') {
              setImmediate(() => handler(new Error('ECONNREFUSED')));
            }
          }),
        } as any;
        return mockReq;
      });

      const result = await checkHealth('http://localhost:8090');
      expect(result).toBe(false);
    });
  });
});