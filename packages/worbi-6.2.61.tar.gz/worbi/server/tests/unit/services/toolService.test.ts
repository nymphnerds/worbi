/**
 * toolService unit tests
 *
 * - File-based tools (read/write/edit/delete/rename/list/create_folder)
 *   operate on the real workspace root. Tests use a __test__ subdirectory
 *   that is cleaned up in afterAll.
 * - web_search is tested by mocking axios.
 * - getToolDefinitions permission gating is tested exhaustively.
 */
import { describe, it, expect, beforeEach, afterEach, vi, afterAll } from 'vitest';
import fs from 'fs';
import path from 'path';

vi.mock('axios', () => {
  const mockGet = vi.fn();
  return {
    default: { get: mockGet },
    get: mockGet,
  };
});

import axios from 'axios';
import * as toolService from '../../../src/services/toolService.js';

// ── Test workspace setup ──

// The toolService resolves WORKSPACE_ROOT = project root (Nymphs-Brain/WORBI/)
// We create a __test__ subdirectory for all test files.
const TEST_DIR = '__test__';

function testPath(...segments: string[]) {
  return path.join(TEST_DIR, ...segments);
}

function ensureTestDir() {
  if (!fs.existsSync(TEST_DIR)) {
    fs.mkdirSync(TEST_DIR, { recursive: true });
  }
}

function writeFile(name: string, content: string) {
  const p = path.join(TEST_DIR, name);
  const d = path.dirname(p);
  if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true });
  fs.writeFileSync(p, content, 'utf-8');
}

function cleanUp() {
  if (fs.existsSync(TEST_DIR)) {
    fs.rmSync(TEST_DIR, { recursive: true, force: true });
  }
}

// ── Tests ──

describe('toolService', () => {
  // ── web_search (mock axios) ──

  describe('web_search via executeTool()', () => {
    beforeEach(() => {
      (axios.get as any).mockResolvedValue({
        data: `<html><div><a href="https://example.com" class="result__a">Example</a>` +
          `<div class="result-snippet">A test result</div></div></html>`,
      });
    });

    it('returns formatted search results', async () => {
      const result = await toolService.executeTool('web_search', { query: 'test' });
      expect(typeof result).toBe('string');
      expect(result).toContain('Search Results');
    });
  });

  // ── read_file ──

  describe('read_file', () => {
    beforeEach(() => {
      ensureTestDir();
      writeFile('hello.txt', 'Hello World');
    });

    afterEach(() => cleanUp());

    it('returns file content', () => {
      const result = toolService.executeTool('read_file', { file_path: testPath('hello.txt') });
      expect(result).toBeInstanceOf(Promise);
      result.then((r: string) => {
        expect(r).toContain('Hello World');
      });
    });

    it('throws for non-existent file', async () => {
      await expect(
        toolService.executeTool('read_file', { file_path: testPath('nope.txt') })
      ).rejects.toThrow(/not found/i);
    });

    it('throws for path traversal', async () => {
      await expect(
        toolService.executeTool('read_file', { file_path: '../secret.txt' })
      ).rejects.toThrow(/traversal|denied|allowed/i);
    });
  });

  // ── list_directory ──

  describe('list_directory', () => {
    beforeEach(() => {
      ensureTestDir();
      writeFile('a.txt', 'a');
      writeFile('b.txt', 'b');
    });

    afterEach(() => cleanUp());

    it('returns formatted directory listing', async () => {
      const result = await toolService.executeTool('list_directory', { dir_path: TEST_DIR });
      expect(typeof result).toBe('string');
      expect(result).toContain('a.txt');
      expect(result).toContain('b.txt');
    });

    it('returns workspace root listing with empty path', async () => {
      const result = await toolService.executeTool('list_directory', { dir_path: '' });
      expect(typeof result).toBe('string');
      expect(result).toContain('Directory listing');
    });

    it('throws for non-existent directory', async () => {
      await expect(
        toolService.executeTool('list_directory', { dir_path: testPath('nonexistent') })
      ).rejects.toThrow(/not found/i);
    });
  });

  // ── write_file ──

  describe('write_file', () => {
    beforeEach(() => ensureTestDir());
    afterEach(() => cleanUp());

    it('creates a new file', async () => {
      const result = await toolService.executeTool('write_file', {
        file_path: testPath('new.txt'),
        content: 'written content',
      });
      expect(typeof result).toBe('string');
      expect(result).toContain('created/updated');
      expect(fs.existsSync(path.join(TEST_DIR, 'new.txt'))).toBe(true);
      expect(fs.readFileSync(path.join(TEST_DIR, 'new.txt'), 'utf-8')).toBe('written content');
    });

    it('creates parent directories automatically', async () => {
      await toolService.executeTool('write_file', {
        file_path: testPath('sub', 'deep', 'file.txt'),
        content: 'nested',
      });
      expect(fs.existsSync(path.join(TEST_DIR, 'sub', 'deep', 'file.txt'))).toBe(true);
    });

    it('overwrites existing file', async () => {
      writeFile('overwrite.txt', 'old');
      await toolService.executeTool('write_file', {
        file_path: testPath('overwrite.txt'),
        content: 'new',
      });
      expect(fs.readFileSync(path.join(TEST_DIR, 'overwrite.txt'), 'utf-8')).toBe('new');
    });
  });

  // ── edit_file ──

  describe('edit_file', () => {
    beforeEach(() => {
      ensureTestDir();
      writeFile('edit.txt', 'line one\nline two\nline three');
    });

    afterEach(() => cleanUp());

    it('replaces text in file', async () => {
      await toolService.executeTool('edit_file', {
        file_path: testPath('edit.txt'),
        search_text: 'line two',
        replace_text: 'modified',
      });
      const content = fs.readFileSync(path.join(TEST_DIR, 'edit.txt'), 'utf-8');
      expect(content).toBe('line one\nmodified\nline three');
    });

    it('throws when search text not found', async () => {
      await expect(
        toolService.executeTool('edit_file', {
          file_path: testPath('edit.txt'),
          search_text: 'does not exist',
          replace_text: 'x',
        })
      ).rejects.toThrow(/not found|does not appear/i);
    });

    it('throws for non-existent file', async () => {
      await expect(
        toolService.executeTool('edit_file', {
          file_path: testPath('ghost.txt'),
          search_text: 'x',
          replace_text: 'y',
        })
      ).rejects.toThrow(/not found/i);
    });
  });

  // ── create_folder ──

  describe('create_folder', () => {
    beforeEach(() => ensureTestDir());
    afterEach(() => cleanUp());

    it('creates a new folder', async () => {
      await toolService.executeTool('create_folder', { folder_path: testPath('newfolder') });
      const stat = fs.statSync(path.join(TEST_DIR, 'newfolder'));
      expect(stat.isDirectory()).toBe(true);
    });

    it('creates nested folders', async () => {
      await toolService.executeTool('create_folder', { folder_path: testPath('a', 'b', 'c') });
      const stat = fs.statSync(path.join(TEST_DIR, 'a', 'b', 'c'));
      expect(stat.isDirectory()).toBe(true);
    });

    it('throws if path already exists', async () => {
      writeFile('exists.txt', 'x');
      await expect(
        toolService.executeTool('create_folder', { folder_path: testPath('exists.txt') })
      ).rejects.toThrow(/already exists/i);
    });
  });

  // ── delete_file ──

  describe('delete_file', () => {
    beforeEach(() => {
      ensureTestDir();
      writeFile('deleteme.txt', 'delete me');
      writeFile('keep.txt', 'keep me');
    });

    afterEach(() => cleanUp());

    it('deletes a file', async () => {
      await toolService.executeTool('delete_file', { file_path: testPath('deleteme.txt') });
      expect(fs.existsSync(path.join(TEST_DIR, 'deleteme.txt'))).toBe(false);
    });

    it('allows deleting README.md in subdirectory', async () => {
      writeFile('README.md', 'sub readme');
      await toolService.executeTool('delete_file', { file_path: testPath('README.md') });
      expect(fs.existsSync(path.join(TEST_DIR, 'README.md'))).toBe(false);
    });

    it('throws for directories', async () => {
      fs.mkdirSync(path.join(TEST_DIR, 'isadir'), { recursive: true });
      await expect(
        toolService.executeTool('delete_file', { file_path: testPath('isadir') })
      ).rejects.toThrow(/directory/i);
    });

    it('throws for non-existent file', async () => {
      await expect(
        toolService.executeTool('delete_file', { file_path: testPath('ghost.txt') })
      ).rejects.toThrow(/not found/i);
    });
  });

  // ── rename_file ──

  describe('rename_file', () => {
    beforeEach(() => {
      ensureTestDir();
      writeFile('oldname.txt', 'content');
    });

    afterEach(() => cleanUp());

    it('renames a file', async () => {
      await toolService.executeTool('rename_file', {
        file_path: testPath('oldname.txt'),
        new_name: 'newname.txt',
      });
      expect(fs.existsSync(path.join(TEST_DIR, 'oldname.txt'))).toBe(false);
      expect(fs.existsSync(path.join(TEST_DIR, 'newname.txt'))).toBe(true);
      expect(fs.readFileSync(path.join(TEST_DIR, 'newname.txt'), 'utf-8')).toBe('content');
    });

    it('throws for non-existent file', async () => {
      await expect(
        toolService.executeTool('rename_file', {
          file_path: testPath('ghost.txt'),
          new_name: 'x.txt',
        })
      ).rejects.toThrow(/not found/i);
    });

    it('throws for directories', async () => {
      fs.mkdirSync(path.join(TEST_DIR, 'adir'), { recursive: true });
      await expect(
        toolService.executeTool('rename_file', {
          file_path: testPath('adir'),
          new_name: 'newdir',
        })
      ).rejects.toThrow(/directory/i);
    });
  });

  // ── Unknown tool ──

  describe('unknown tool', () => {
    it('throws for unknown tool name', async () => {
      await expect(
        toolService.executeTool('nonexistent_tool', {})
      ).rejects.toThrow(/Unknown tool/i);
    });
  });

  // ── getToolDefinitions permission gating ──

  describe('getToolDefinitions()', () => {
    function getToolNames(permissions: any) {
      const defs = toolService.getToolDefinitions(permissions);
      return defs.map((d: any) => d.function.name);
    }

    it('webSearch + read → web_search, read_file, list_directory', () => {
      const names = getToolNames({ webSearch: true, fileAccessLevel: 'read' });
      expect(names).toContain('web_search');
      expect(names).toContain('read_file');
      expect(names).toContain('list_directory');
      expect(names).not.toContain('write_file');
      expect(names).not.toContain('delete_file');
    });

    it('no webSearch + readwrite + allowCreate + allowEdit → read+write+create+edit', () => {
      const names = getToolNames({
        webSearch: false,
        fileAccessLevel: 'readwrite',
        allowCreate: true,
        allowEdit: true,
      });
      expect(names).not.toContain('web_search');
      expect(names).toContain('read_file');
      expect(names).toContain('write_file');
      expect(names).toContain('edit_file');
      expect(names).toContain('create_folder');
      expect(names).not.toContain('delete_file');
      expect(names).not.toContain('rename_file');
    });

    it('webSearch + full + all allows → all 8 tools', () => {
      const names = getToolNames({
        webSearch: true,
        fileAccessLevel: 'full',
        allowCreate: true,
        allowEdit: true,
        allowDelete: true,
        allowRename: true,
      });
      expect(names).toContain('web_search');
      expect(names).toContain('read_file');
      expect(names).toContain('list_directory');
      expect(names).toContain('write_file');
      expect(names).toContain('edit_file');
      expect(names).toContain('create_folder');
      expect(names).toContain('delete_file');
      expect(names).toContain('rename_file');
      expect(names.length).toBe(8);
    });

    it('fileAccessLevel none → empty (or web_search only if enabled)', () => {
      const names = getToolNames({ fileAccessLevel: 'none' });
      expect(names).toEqual([]);
    });

    it('fileAccessLevel none + webSearch → only web_search', () => {
      const names = getToolNames({ fileAccessLevel: 'none', webSearch: true });
      expect(names).toEqual(['web_search']);
    });

    it('no permissions → empty array', () => {
      const names = getToolNames({});
      expect(names).toEqual([]);
    });

    it('readwrite without allowCreate → no write/create', () => {
      const names = getToolNames({ fileAccessLevel: 'readwrite' });
      expect(names).toContain('read_file');
      expect(names).toContain('list_directory');
      expect(names).not.toContain('write_file');
      expect(names).not.toContain('edit_file');
      expect(names).not.toContain('create_folder');
    });
  });
});