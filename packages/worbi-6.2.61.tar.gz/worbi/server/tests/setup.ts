import { vi } from 'vitest';

// Set test environment
process.env.NODE_ENV = 'test';

// Mock global fetch
globalThis.fetch = vi.fn() as any;

// Override config.port to 0 (random port) in tests to avoid port conflicts
// This is handled per-test by mocking, not globally

// Mock console methods to reduce test output noise (optional - comment out for debugging)
// vi.spyOn(console, 'log').mockImplementation(() => {});
// vi.spyOn(console, 'warn').mockImplementation(() => {});