# Handoff: Interactive Relationship Graph

**Target Version:** v5.5.0
**Priority:** Medium (visualizes existing tag relationship data)
**Dependencies:**
- `TAG_RELATIONSHIP_SYSTEM.md` — **this is a legacy doc in `docs/` (not a pending handoff), meaning the tag relationship system is already implemented**. Confirm by checking `server/src/services/tagService.js` for relationship functions and `docs/TAG_RELATIONSHIP_SYSTEM.md` for the existing API. This dependency is satisfied.
- `CROSS_DOCUMENT_WIKILINKS.md` — wiki links add explicit edges to the graph. Must be implemented first for the full graph to include document connections.

---

## 1. Problem Statement

WORBI's tag relationship system already computes implicit relationships (documents sharing tags) and explicit relationships (manually defined tag connections). However, these relationships are only visible in the Information Panel as a flat list. Users with complex, interconnected worlds need a visual representation — a force-directed graph where they can see all their documents and how they relate to each other.

---

## 2. Target Behavior

A new Activity Bar panel (graph icon: `GitGraph` or `Workflow` from lucide-react) that renders an interactive D3.js or Cytoscape.js force-directed graph:

```
┌─────────────────────────────────────┐
│  Relationship Graph                 │
├─────────────────────────────────────┤
│  [Filter Tags ▾] [Filter Type ▾]    │
│                                     │
│    ┌──────┐    ┌──────┐             │
│    │ Elara│────│Goblin │            │
│    └──┬───┘    │ King  │            │
│       │        └──┬───┬┘            │
│       │           │   │             │
│    ┌──┴───┐  ┌───┴─┐ │             │
│    │Forest│  │Under│ │             │
│    │ Elf  │  │dark │ │             │
│    └──────┘  └─────┘ │             │
│                 │    │             │
│              ┌──┴────┴──┐          │
│              │ Crystal  │          │
│              │ Throne   │          │
│              └──────────┘          │
│                                     │
│  Node: 6  Edges: 8                  │
└─────────────────────────────────────┘
```

- **Nodes** = documents (colored by folder or primary tag)
- **Edges** = relationships (tag-based, wiki link, explicit)
- **Drag** nodes to rearrange
- **Click** a node to open the document
- **Hover** a node to see document name and tags
- **Zoom & Pan** with mouse wheel and drag
- **Filter** by tag or relationship type

---

## 3. Graph Data Model

### 3.1 Nodes

Each document becomes a node:

```json
{
  "id": "/Characters/Goblin King.html",
  "label": "Goblin King",
  "type": "character",
  "folder": "/Characters/",
  "tags": ["goblin", "royalty", "antagonist"],
  "color": "#f59e0b",
  "size": 12
}
```

**Node size** is proportional to the number of connections (degree centrality).

**Node color** is determined by:
- The document's primary tag color (if tagged)
- Or the folder (Characters = amber, Locations = green, Quests = blue, etc.)
- Or default gray

### 3.2 Edges

Three types of edges:

| Edge Type | Source | Appearance |
|-----------|--------|------------|
| **Tag-based (implicit)** | Two documents share at least one tag | Thin, dashed line, gray |
| **Wiki link (explicit)** | One document contains `[[Other Document]]` | Solid line, light blue |
| **Explicit relationship** | Tag relationship system declares a connection | Solid line, colored by relationship type |

```json
{
  "source": "/Characters/Goblin King.html",
  "target": "/World/The Underdark.html",
  "type": "tag",
  "sharedTags": ["goblin"],
  "strength": 1
}
```

**Edge thickness** is proportional to the number of shared tags (for tag-based edges) or relationship strength.

### 3.3 API Endpoint

`GET /api/files/graph`

Response:
```json
{
  "nodes": [
    {
      "id": "/Characters/Goblin King.html",
      "label": "Goblin King",
      "folder": "/Characters/",
      "tags": ["goblin", "royalty"],
      "tagColors": { "goblin": "#f59e0b", "royalty": "#a78bfa" }
    }
  ],
  "edges": [
    {
      "source": "/Characters/Goblin King.html",
      "target": "/World/The Underdark.html",
      "type": "tag",
      "sharedTags": ["goblin"],
      "strength": 1
    }
  ],
  "wikiLinks": [
    {
      "source": "/World/The Underdark.html",
      "target": "/Characters/Goblin King.html",
      "count": 3
    }
  ]
}
```

**Server implementation:**
1. List all `.html` files in the workspace
2. For each file, extract tags (from tagSystem or parsing HTML)
3. Compute implicit edges: for every pair of files sharing at least one tag, create an edge
4. Compute wiki link edges: scan all files for `[[...]]` references, create edges for each found link
5. Compute explicit edges: query the tag relationship system
6. Return combined graph data

**Optimization:** For workspaces with 100+ files, limit the graph to 100 most-connected nodes. Provide a filter to narrow the scope.

---

## 4. Visualization Library

**Recommendation: Cytoscape.js**

- Mature, well-maintained
- Built-in force-directed layout (`cose-bilkent` or `fcose`)
- Touch support for pan/zoom
- Extensive styling options
- Lighter than D3.js for graph-specific use cases

```bash
cd client && npm install cytoscape cytoscape-cose-bilkent
```

```typescript
import cytoscape from 'cytoscape';
import coseBilkent from 'cytoscape-cose-bilkent';

cytoscape.use(coseBilkent);

const cy = cytoscape({
  container: document.getElementById('graph-container'),
  elements: [...nodes, ...edges],
  style: [
    {
      selector: 'node',
      style: {
        'background-color': 'data(color)',
        'label': 'data(label)',
        'font-size': '10px',
        'color': '#e0e0e0',
        'width': 'data(size)',
        'height': 'data(size)',
      },
    },
    {
      selector: 'edge[type="tag"]',
      style: {
        'line-style': 'dashed',
        'line-color': '#555',
        'width': 1,
      },
    },
    {
      selector: 'edge[type="wikilink"]',
      style: {
        'line-style': 'solid',
        'line-color': '#7dd3fc',
        'width': 2,
      },
    },
  ],
  layout: {
    name: 'cose-bilkent',
    animate: true,
    animationDuration: 1000,
  },
});
```

---

## 5. Client Component

New component: `client/src/components/RelationshipGraph.tsx`

**Layout:**
- Full panel height and width
- Filter bar at the top
- Canvas area filling the remaining space
- Info bar at the bottom: "Nodes: 42 | Edges: 87 | Filtered by: goblin, royalty"

**Interactions:**

| Action | Result |
|--------|--------|
| Click node | Open document in a new tab |
| Double-click node | Center and zoom to that node |
| Hover node | Tooltip with document name, folder, tags |
| Hover edge | Tooltip with relationship type and shared tags |
| Drag node | Reposition (pins the node) |
| Drag background | Pan the view |
| Mouse wheel | Zoom in/out |
| Click "Fit" button | Reset zoom to fit all nodes |

**Toolbar buttons:**
- 🔍 Fit to screen
- 🔄 Re-layout (re-run force simulation)
- 📋 Filter by tag dropdown
- 📋 Filter by relationship type dropdown

**States:**
- **Loading:** Skeleton — a pulsing circle in the center of the panel
- **Empty:** "No relationships found. Tag your documents to create connections."
- **Error:** "Could not load relationship graph. [Retry]"
- **Single node:** Shows the node centered in the graph area

---

## 6. Node Color Mapping

| Folder / Context | Color | Tailwind |
|-----------------|-------|----------|
| `/Characters/` | Amber | `#f59e0b` |
| `/World/` | Green | `#22c55e` |
| `/Quests/` | Blue | `#3b82f6` |
| `/World/Timeline/` | Purple | `#a78bfa` |
| `/World/Items/` | Cyan | `#06b6d4` |
| `/World/Creatures/` | Red | `#ef4444` |
| `/World/Factions/` | Pink | `#ec4899` |
| No folder match | Gray | `#6b7280` |
| Primary tag color | Tag color | Overrides folder color |

If a document has a primary tag with a custom color, that color overrides the folder color. A small colored dot or ring on the node indicates secondary tags.

---

## 7. Activity Bar Integration

Add a new Activity Bar item: `GitGraph` icon (from lucide-react)

| Activity | Icon |
|----------|------|
| Explorer | `FolderOpen` |
| Search | `Search` |
| Starred | `Star` |
| Tags | `Tag` |
| Timeline | `Clock` |
| **Graph** | **`GitGraph`** (NEW) |
| (spacer) | |
| AI Sidebar | `Sparkles` |
| Settings | `Settings` |

Final Activity Bar order: Explorer → Search → Starred → Tags → Timeline → Graph → (spacer) → AI → Settings

---

## 8. Files to Create

| File | Purpose |
|------|---------|
| `server/src/services/graphService.js` | Graph data computation |
| `server/src/routes/graph.js` | Graph data endpoint |
| `client/src/components/RelationshipGraph.tsx` | Graph visualization panel |
| `client/src/hooks/useGraph.ts` | Graph data fetching and state |

## 9. Files to Modify

| File | Changes |
|------|---------|
| `server/src/index.js` | Register `/api/files/graph` route |
| `client/src/components/ActivityBar.tsx` | Add `GitGraph` icon for Graph activity |
| `client/src/App.tsx` | Add `'graph'` to ActivityType, render `<RelationshipGraph>` in left panel |
| `client/src/services/api.ts` | Add `getGraph()` function |
| `client/package.json` | Add `cytoscape` and `cytoscape-cose-bilkent` |

---

## 10. Edge Cases

| Scenario | Handling |
|----------|----------|
| **Very large graph (500+ nodes)** | Limit to 100 most-connected nodes. Show warning: "Showing most connected documents. Filter to narrow results." |
| **Isolated nodes (no edges)** | Show them in a separate cluster at the bottom, or hide them with a toggle |
| **Single connected component** | The force layout naturally clusters the connected nodes |
| **Graph with duplicates** | Each file appears once as a node. Wiki links to the same file are merged into one edge with a count |
| **Browser performance** | Cytoscape handles large graphs well. For 100+ nodes, disable animations |
| **Resize panel** | The graph canvas re-renders to fit the new panel dimensions |
| **Document deleted** | Node disappears from the graph on next data refresh |

---

## 11. Verification Checklist

- [ ] Relationship Graph icon appears in the Activity Bar
- [ ] Graph renders nodes for all tagged documents
- [ ] Edges appear between documents sharing tags
- [ ] Edges appear between documents with wiki links
- [ ] Nodes are colored by folder/primary tag
- [ ] Clicking a node opens the document
- [ ] Dragging a node repositions it
- [ ] Zoom and pan work with mouse/trackpad
- [ ] Filter by tag removes non-matching nodes
- [ ] Filter by edge type shows only selected relationship types
- [ ] Hovering a node shows tooltip with details
- [ ] "Fit to screen" resets the view
- [ ] "Re-layout" re-runs the force simulation
- [ ] Empty state shows when no relationships exist
- [ ] Graph refreshes when documents are tagged/untagged

---

## 12. Future Enhancements

- **3D graph:** Three.js or regl-based 3D graph visualization
- **Time-based layout:** Position nodes on a timeline axis (combine with Timeline View)
- **Export graph as image:** Render the current graph view as PNG/SVG
- **Node grouping:** Collapse clusters of related nodes into a single group node
- **Pathfinding:** "Show me the connections between Goblin King and the Elven Council" — highlights the shortest path
- **Graph metrics:** Display connectivity statistics (most connected node, average degree, clusters)