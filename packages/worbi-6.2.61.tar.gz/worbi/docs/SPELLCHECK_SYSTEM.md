# Spellcheck System

## Overview

WBUI uses a user-initiated (on-demand) spellchecker powered by `typo-js`, a pure JavaScript spellchecker using Hunspell-style dictionaries. Misspelled words are highlighted with a red wavy underline, and the total error count is displayed in the toolbar.

**Key design principle:** Spellcheck runs on demand (button click), not in real-time. This avoids infinite update loops, main thread blocking, and app crashes that plagued earlier real-time implementations.

---

## Architecture

### Components

| Component | File | Purpose |
|-----------|------|---------|
| `runSpellcheck()` | `client/src/extensions/spellcheck.ts` | Main entry point. Checks document, applies marks, returns count |
| `clearSpellcheckMarks()` | `client/src/extensions/spellcheck.ts` | Removes all spellcheck marks from the editor |
| `MisspelledMark` | `client/src/extensions/spellcheck.ts` | TipTap Mark type for visual underline rendering |
| `Spellcheck` | `client/src/extensions/spellcheck.ts` | Dummy extension (no plugins — spellcheck is manual) |
| `isMisspelled()` | `client/src/extensions/spellcheck.ts` | Checks a single word against the dictionary |
| `getSuggestions()` | `client/src/extensions/spellcheck.ts` | Returns up to 5 correction suggestions for a word |
| `initTypo()` | `client/src/extensions/spellcheck.ts` | Lazy-loads dictionary files on first use |
| Spellcheck button | `client/src/components/DocumentEditor.tsx` | Toolbar button in main editor (✓ icon) |
| CSS styling | `client/src/styles/globals.css` | `.spellcheck-misspelled` red wavy underline |

### Dictionary

- **Library:** `typo-js` (npm package)
- **Files:** `en_US.aff` and `en_US.dic` served from `client/public/dictionaries/en_US/`
- **Loading:** Lazy-loaded on first spellcheck operation via `fetch()`. Initial page load is fast; spellcheck activates once the dictionary is ready.
- **Caching:** Dictionary instance is cached (`typoInstance`) and reused across spellcheck operations.

---

## How It Works

### Flow Diagram

```
User clicks ✓ button
    │
    ▼
handleCheckSpelling() in DocumentEditor
    │  - Sets spellchecking = true (UI shows loading state)
    ▼
runSpellcheck(editor)
    │
    ├── 1. Ensure dictionary loaded (initTypo)
    │
    ├── 2. Yield to browser (await setTimeout(0)) so "spellchecking" UI renders
    │
    ├── 3. Extract full text, skip if >50K chars
    │
    ├── 4. Collect UNIQUE words only (Set deduplication)
    │       Also build word frequency Map for accurate counting
    │
    ├── 5. Check each unique word against dictionary
    │       - Yield every 200 words (await setTimeout(0)) for UI responsiveness
    │       - Build misspelledWords Set
    │
    ├── 6. Count total misspelled occurrences (unique check × frequency)
    │
    └── 7. APPLY MARKS IN SINGLE BATCH:
            a. Walk document with descendants() to find word positions
            b. Build nodes array: [{from, to, word}, ...]
            c. One transaction: tr.removeMark() then tr.addMark() for each node
            d. Single dispatch() → marks appear instantly
    │
    ▼
Returns count → toolbar shows "42 errors"
```

### Why It Doesn't Freeze

| Problem (v4.27) | Solution (v4.29) |
|-----------------|------------------|
| `dispatch()` called per-word in tight loop → full TipTap re-render each time | All marks applied in ONE transaction, ONE dispatch |
| Every token checked against dictionary (O(n) lookups) | Only UNIQUE words checked (O(unique) lookups) |
| Set converted to array on every iteration | `Array.from(set)` called once |
| No UI yields during work | `await setTimeout(0)` every 200 unique words |

---

## API Reference

### `runSpellcheck(editor: Editor): Promise<number>`

Runs spellcheck on the given TipTap editor. Returns the count of misspelled words.

**Behavior:**
- Loads dictionary lazily on first call
- Applies `misspelled` marks with red wavy underline
- Clears existing marks before applying new ones
- Skips documents over 50,000 characters
- Returns 0 if dictionary not loaded

### `clearSpellcheckMarks(editor: Editor): void`

Removes all spellcheck marks from the editor. Call this when switching files or before a new spellcheck run.

### `isMisspelled(word: string): boolean`

Checks a single word against the loaded dictionary. Strips non-alpha characters, ignores words < 2 characters.

### `getSuggestions(word: string): string[]`

Returns up to 5 spelling suggestions for a misspelled word.

---

## Integration

### DocumentEditor

The spellcheck button is in the **main toolbar** (right side):

```tsx
// State
const [spellcheckCount, setSpellcheckCount] = useState<number | null>(null);
const [spellchecking, setSpellchecking] = useState(false);

// Handler
const handleCheckSpelling = async () => {
  if (!mainEditor) return;
  setSpellchecking(true);
  setSpellcheckCount(null);
  try {
    const count = await runSpellcheck(mainEditor);
    setSpellcheckCount(count);
  } finally {
    setSpellchecking(false);
  }
};

// Clear marks on file switch
useEffect(() => {
  if (mainEditor) clearSpellcheckMarks(mainEditor);
}, [activeFile]);

// Button rendering
<Tooltip content="Check Spelling">
  <button onClick={handleCheckSpelling} disabled={spellchecking}>
    {spellchecking ? <Loader2 className="animate-spin" /> :
     spellcheckCount === 0 ? <CheckCheck /> :
     spellcheckCount !== null ? <span>{spellcheckCount} errors</span> :
     <CheckCheck />}
  </button>
</Tooltip>
```

### CSS Styling

```css
/* Red wavy underline on misspelled words */
.spellcheck-misspelled {
  text-decoration: underline wavy #ff4444;
  text-decoration-thickness: 2px;
  text-underline-offset: 2px;
  cursor: pointer;
  border-radius: 2px;
  background: rgba(255, 68, 68, 0.1);
  padding: 0 1px;
}
```

---

## Version History

| Version | What Changed | Status |
|---------|-------------|--------|
| v4.23 | Real-time spellcheck with `spellchecker` (GNU Aspell) + ProseMirror plugin | Crashed (node-ffi can't run in browser) |
| v4.24 | Replaced with `typo-js` (pure JS, Hunspell dicts) | Fixed white screen |
| v4.25 | Fixed `typo-js` API: `checkWord()` → `check()`, `suggest(word)` (no limit param) | Fixed API errors |
| v4.26 | Attempted real-time loop fixes | Still crashing |
| v4.27 | Switched to user-initiated (button). Added `runSpellcheck()` + `clearSpellcheckMarks()`. Keyboard shortcut removed (browser conflict). DOM marks applied per-word. | Caused UI lockup |
| v4.28 | Removed DOM mark dispatching entirely. Count-only mode. Unique word deduplication. UI yields every 200 words. | No lockup, but no visual underlines |
| v4.29 | Restored visual underlines via single batch transaction. Walk doc with `descendants()` to find positions, then one `tr.removeMark()` + loop `tr.addMark()` + single `dispatch()`. | Working |

---

## File Locations

```
WBServer/
├── client/
│   ├── public/
│   │   └── dictionaries/
│   │       └── en_US/
│   │           ├── en_US.aff          # Hunspell affinity rules
│   │           └── en_US.dic          # ~50K word dictionary
│   └── src/
│       ├── extensions/
│       │   └── spellcheck.ts          # Core spellcheck logic
│       ├── components/
│       │   └── DocumentEditor.tsx     # Spellcheck button + state
│       ├── styles/
│       │   └── globals.css            # .spellcheck-misspelled CSS
│       └── types/
│           └── typo-js.d.ts           # TypeScript declarations
└── docs/
    └── SPELLCHECK_SYSTEM.md           # This file
```

---

## Known Limitations

1. **No right-click suggestions** — The `MisspelledMark` stores suggestions as attributes, but there is no context menu UI to display them. Currently only visual underlines + count are shown.
2. **Single dictionary** — Only English (en_US) is supported. No dictionary switching.
3. **No real-time checking** — Spellcheck only runs on button click. Browser's native `spellcheck="true"` on the contenteditable element provides basic real-time underlines as a free bonus.
4. **50K character limit** — Documents over 50,000 characters are skipped entirely.
5. **Case-insensitive matching** — Words are lowercased before checking, so "HELLO" and "hello" are treated identically.
6. **No custom dictionary** — Users cannot add words to a personal dictionary. Words not in the ~50K word dictionary are flagged as misspelled.

---

## Future Improvements

- Right-click context menu on misspelled words with suggestions
- "Add to dictionary" button for false positives
- Multi-language support with dictionary switching
- Real-time spellcheck with optimized throttling (if performance can be achieved)
- Word count / character count in status bar
- Spellcheck-as-you-type with requestAnimationFrame-based debouncing