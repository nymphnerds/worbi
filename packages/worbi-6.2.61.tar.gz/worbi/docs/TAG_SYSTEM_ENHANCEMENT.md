# Tag System Enhancement - Progress Tracker

## Step 1: Design Document ✅
**File:** `TAG_RELATIONSHIP_SYSTEM.md`
**Status:** Complete
**Details:** Full phased design with 5 phases covering tags, implicit relationships, explicit relationships, graph visualization, and advanced features. Default tags: MainChar, MainChar2, NPC, Friend, Foe.

---

## Step 2: Backend Tag Service ✅
**File:** `server/src/services/tagService.js`
**Status:** Complete
**Details:**
- Tag registry stored in `~/.wbu/tags.json`
- 5 default tags initialized on first load
- Tag CRUD: `getAllTags()`, `createTag()`, `updateTag()`, `deleteTag()`
- File-level ops: `getFileTags()`, `addTagsToFile()`, `removeTagFromFile()`, `setFileTags()`
- Relationship queries: `getFilesByTag()`, `getFileRelationships()`
- Enhanced directory listing: `listDirectoryWithTags()` attaches tags to HTML files
- Metadata stored as `.__{filename}.wbu_meta.json` alongside each HTML file

---

## Step 3: Backend API Routes ✅
**File:** `server/src/routes/files.js`
**Status:** Complete
**Endpoints added:**
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/tags` | List all tags |
| POST | `/api/tags` | Create tag |
| PATCH | `/api/tags/:id` | Update tag |
| DELETE | `/api/tags/:id` | Delete tag |
| GET | `/api/files/by-tag/:tagName` | Files with tag |
| GET | `/api/files/file-tags/:path` | Get file tags |
| POST | `/api/files/file-tags/:path` | Add tags to file |
| DELETE | `/api/files/file-tags/:path/tags/:tagName` | Remove tag from file |
| PUT | `/api/files/file-tags/:path` | Set file tags (replace) |
| GET | `/api/files/relationships/:path` | Get relationships |

**Also:** `GET /api/files` now uses `listDirectoryWithTags()` to include tags on each file item.

---

## Next Step: Client API Types and Functions
**File:** `client/src/services/api.ts`
**Plan:**
- Add TypeScript types: `Tag`, `FileMetadata`, `RelationshipResult`
- Add API functions: `getTags()`, `createTag()`, `updateTag()`, `deleteTag()`, `getFilesByTag()`, `getFileTags()`, `addTagsToFile()`, `removeTagFromFile()`, `setFileTags()`, `getFileRelationships()`
- Extend existing `FileItem` type to include optional `tags` array