# APP_REFACTOR_TASK.md — Comprehensive Handoff Document

**Version:** v6.1.0+ (supersedes APP_TSX_REFACTOR.md for current codebase state)  
**Date:** 2026-05-04  
**Priority:** Medium — maintainability, reduces bug surface area  
**Current App.tsx:** 1,578 lines  
**Target App.tsx:** ~360 lines (77% reduction)  
**Status:** Feature modules created but UNUSED — App.tsx duplicates all logic inline

---

## 1. Executive Summary

`App.tsx` is a 1,578-line monolith managing ~17 distinct concerns. In a previous refactor effort (documented in `APP_TSX_REFACTOR.md`), 8 feature module files were created in `client/src/features/` but **never wired into App.tsx**. Meanwhile, App.tsx grew ~73% (908→1,578 lines) with new features (graph, bookmarks, locations, timeline, image generator, help panel, compile modal, reminders activity).

This document provides:
- Complete inventory of current App.tsx concerns with line references
- Gap analysis between existing feature modules and App.tsx
- Specifications for 3 new feature modules needed (editor, graph)
- Detailed 6-step implementation plan with line-level precision
- Revised architecture targets accounting for post-doc feature additions

---

## 2. Current State

### 2.1 App.tsx Concern Inventory (1,578 lines)

| Concern | Approx. Lines | App.tsx Location | Extracted? |
|---------|--------------|------------------|------------|
| Auth state + login gate | ~30 | L34, L1055-1057 | ❌ `AuthProvider.tsx` exists but unused |
| `isImageFile` / `isDocxFile` helpers | ~10 | L41-50 | ❌ Defined inline, also in `useFileOperations.ts` |
| `ActivityType` type alias | ~2 | L52 | ❌ Only 9 types, missing `images`, `outline`, `reminders` |
| Layout state (widths, hidden) | ~15 | L57-64 | ❌ `useLayout.ts` exists but unused |
| `toggleAISidebar` / `toggleLeftPanel` | ~15 | L172-185 | ❌ Inline |
| Resizer handlers (inline JSX) | ~40 | L1311-1413 | ❌ `useLayout.ts` has them but unused |
| Activity routing + `handleActivitySwitch` | ~15 | L59, L187-195 | ❌ `useActivityRouter.ts` exists but unused |
| `tagsShowAddTag` + reset effect | ~8 | L66, L354-358 | ❌ Inline |
| `showSettings` toggle | ~3 | L65 | ❌ `useSettings.ts` exists but unused |
| Sidebar icon visibility (`hiddenIcons`) | ~30 | L78-103 | ❌ NEW — not in any module |
| Batch selection state + handlers | ~55 | L105-106, L993-1052 | ❌ Inline |
| Graph state (`graphModalData`, `useGraph`) | ~80 | L109-110, L1207-1231, L1511-1521 | ❌ NEW — no module |
| Confirm/Prompt/FolderPicker dialogs | ~60 | L113-170, L1474-1575 | ❌ Shared infrastructure |
| File CRUD + undo/redo wiring | ~60 | L213-251 | ❌ `useFileOperations.ts` exists but unused |
| File operation callbacks (delete, rename, etc.) | ~80 | L550-688 | ❌ Inline |
| Tab management (close, switch, dirty) | ~40 | L691-726 | ❌ No module |
| Image proxy conversion | ~75 | L369-486 | ❌ Cross-cuts, stays in App.tsx |
| `handleSave` / `handleRestore` / `openFileWithConversion` | ~35 | L489-515 | ❌ Wires proxy + files |
| `handleFileSelect` (image + file) | ~30 | L517-548 | ❌ Cross-cuts dialogs + files |
| `handleCreateFileFromEditor` | ~25 | L554-580 | ❌ Cross-cuts files + proxy |
| Image insertion state | ~10 | L204-205 | ❌ No module |
| DOCX import/export, PDF export | ~120 | L776-930 | ❌ Cross-cuts 3+ features |
| `handleInsertImageUrl` | ~20 | L730-747 | ❌ Inline |
| `handleDownload` | ~25 | L750-773 | ❌ Inline |
| Keyboard shortcuts (Ctrl+S, Ctrl+Shift+N, F1) | ~20 | L945-964 | ❌ No module |
| `beforeunload` warning | ~15 | L967-982 | ❌ App-level |
| Session restore + persistence | ~45 | L306-351 | ❌ Cross-cuts nav + files |
| Auth transition + theme init effects | ~30 | L270-298 | ❌ App-level bootstrap |
| Computed values (dirty, canRestore, wordCount) | ~10 | L985-990 | ❌ Inline |
| Bookmark/Outline activity | ~30 | L1238-1262, L202 | ❌ NEW — `useBookmarks` |
| Image Generator activity + transcription | ~35 | L1171-1206 | ❌ NEW |
| Location Manager activity | ~10 | L1161-1170 | ❌ NEW |
| Timeline View activity | ~10 | L1151-1160 | ❌ NEW |
| Help Panel modal | ~15 | L75, L1524-1533 | ❌ NEW |
| Compile Story Bible modal | ~10 | L72, L1453-1459 | ❌ NEW |
| JSX rendering (layout shell) | ~200 | L1060-1576 | ❌ Orchestrator |

### 2.2 Feature Modules That Exist but are UNUSED

All 8 files compile but App.tsx imports zero of them:

| File | Purpose | Status |
|------|---------|--------|
| `features/layout/useLayout.ts` | Panel widths, drag handlers, AI sidebar toggle | ✅ Created, ❌ Unused |
| `features/layout/LayoutContext.tsx` | React context for layout state | ✅ Created, ❌ Unused |
| `features/layout/AppLayout.tsx` | Presentational grid component | ✅ Created, ❌ Unused |
| `features/auth/AuthProvider.tsx` | Auth context + login gate | ✅ Created, ❌ Unused |
| `features/navigation/useActivityRouter.ts` | Activity switching + tag sidebar | ✅ Created, ❌ Needs ActivityType update |
| `features/navigation/useSettings.ts` | Settings modal toggle | ✅ Created, ❌ Unused |
| `features/files/useFileOperations.ts` | File CRUD + undo/redo + DOCX | ✅ Created, ❌ Unused |
| (7th file — check directory) | — | — |

### 2.3 Feature Modules That Need to Be Created

| File | Purpose | Lines to Extract |
|------|---------|-----------------|
| `features/editor/useKeyboardShortcuts.ts` | Global keyboard shortcut registration | L945-964 |
| `features/editor/useTabManager.ts` | Tab CRUD + dirty state + computed values | L691-726, L985-990 |
| `features/graph/useGraphManager.ts` | Graph modal state + callbacks | L109-110, L1207-1231, L1511-1521 |

---

## 3. New Features Since Original Docs

The original `APP_TSX_REFACTOR.md` was written when App.tsx was ~908 lines. The following features were added afterward and are **not accounted for** in the original plan:

| Feature | Added In | Impact on Refactor |
|---------|----------|-------------------|
| **Sidebar icon visibility** (`hiddenIcons`, storage listener) | Post-docs | Must be absorbed into `useLayout.ts` |
| **Graph relationship feature** (`useGraph`, `RelationshipGraphSidebar`, `GraphModal`) | Post-docs | Needs new `useGraphManager.ts` module |
| **Bookmark/Outline activity** (`useBookmarks`, `BookmarkSidebar`) | Post-docs | New `ActivityType`, stays in App.tsx JSX |
| **Location Manager** (`LocationManager`) | Post-docs | New `ActivityType`, stays in App.tsx JSX |
| **Timeline View** (`TimelineView`) | Post-docs | New `ActivityType`, stays in App.tsx JSX |
| **Image Generator Panel** (`ImageGeneratorPanel`, transcription) | Post-docs | New `ActivityType`, transcription needs `createFileWithContent` in file ops |
| **Help Panel** (`HelpPanel`, F1 shortcut) | Post-docs | New modal, F1 shortcut in keyboard module |
| **Compile Story Bible Modal** (`CompileStoryBibleModal`) | Post-docs | New modal |
| **`reminders` activity type** | In type union | No rendering in JSX yet — placeholder |
| **Batch selection** (expanded) | Post-docs | 7 handlers, ~55 lines — stays in App.tsx |

---

## 4. Revised Target Architecture

### 4.1 File Structure After Refactor

```
client/src/
├── App.tsx                           ~360 lines — orchestrator + cross-cutting concerns
├── main.tsx                          Wrap <App> with <AuthProvider>
├── features/
│   ├── layout/
│   │   ├── useLayout.ts              Panel widths, drag, AI sidebar, icon visibility*
│   │   ├── LayoutContext.tsx         React context for layout state
│   │   └── AppLayout.tsx             Presentational grid (available but may not wire in)
│   ├── auth/
│   │   └── AuthProvider.tsx          Auth context + login gate
│   ├── navigation/
│   │   ├── useActivityRouter.ts      ActivityType (updated), switching, tag sidebar
│   │   └── useSettings.ts            Settings modal toggle
│   ├── files/
│   │   └── useFileOperations.ts      File CRUD + undo/redo + DOCX + createFileWithContent*
│   ├── editor/
│   │   ├── useKeyboardShortcuts.ts   Ctrl+S, Ctrl+Shift+N, F1          *NEW*
│   │   └── useTabManager.ts          Tab CRUD, dirty, canRestore        *NEW*
│   └── graph/
│       └── useGraphManager.ts        Graph modal state + callbacks      *NEW*
├── hooks/                            NO changes to existing hooks
│   ├── useAuth.ts                    Used internally by AuthProvider
│   ├── useFiles.ts                   Used internally by useFileOperations
│   ├── useFileSystemUndoRedo.ts      Used internally by useFileOperations
│   ├── useLLM.ts                     Called directly in App.tsx
│   ├── useRecents.ts                 Called directly in App.tsx
│   ├── useSearch.ts                  Called directly in App.tsx
│   ├── useBookmarks.ts               Called directly in App.tsx
│   ├── useSessionPersistence.ts      Called directly in App.tsx
│   ├── useGraph.ts                   Used by useGraphManager
│   └── useTheme.ts                   applyThemeColours in App.tsx
├── components/                       NO changes to component signatures
├── pages/
│   ├── Login.tsx                     Rendered by AuthProvider
│   └── Settings.tsx                  Rendered by App.tsx
└── services/
    └── api.ts                        NO changes
```

* = Extended from existing file  
**NEW** = New file to create

### 4.2 What STAYS in App.tsx (~360 lines)

These concerns wire across multiple feature boundaries and extracting them would create circular dependencies:

| Concern | Lines | Why It Stays |
|---------|-------|-------------|
| Image proxy conversion (3 functions) | ~75 | Cross-cuts files + editor + API |
| `handleSave` / `handleRestore` / `openFileWithConversion` | ~35 | Wires tabs + proxy conversion |
| Dialog state (confirm, prompt, folderPicker) | ~60 | Shared infrastructure used by everything |
| `handleFileSelect` | ~30 | Cross-cuts dialogs + files + images |
| `handleCreateFileFromEditor` | ~25 | Cross-cuts file ops + proxy + loadFiles |
| DOCX import/export, PDF export, download | ~120 | Each uses 3-4 features |
| `handleInsertImageUrl` | ~20 | Uses fetch + blob URLs |
| Batch selection handlers | ~55 | Thin wrappers around file ops + dialogs |
| Activity rendering switch (which panel) | ~60 | Orchestrator's job to compose panels |
| Modal rendering (template, compile, generate, graph, help) | ~50 | App-level composition |
| Session restore | ~45 | Cross-cuts nav + files |
| Auth transition + theme init + initial load | ~30 | App-level bootstrap |
| `beforeunload` effect | ~15 | App-level |
| `handleHandleTranscription` (image generator) | ~25 | Cross-cuts createFile + updateFile + proxy |
| Feature hook calls + destructuring | ~40 | Orchestrator composition |

**Total staying:** ~360 lines  
**Total extracted:** ~1,218 lines  
**Reduction:** 77%

---

## 5. Detailed Implementation Plan

### Step 1: Extend Existing Feature Modules (Prerequisite)

**Goal:** Prepare existing modules for the new features before wiring.

#### 1A: Extend `features/layout/useLayout.ts`

**Add:**
```ts
// Sidebar icon visibility
hiddenIcons: Set<HideableIcon>;
visibilityRefreshKey: number;
```

Move from App.tsx:
- `hiddenIcons` computation (`useMemo` with `visibilityRefreshKey`) — L89-103
- `visibilityRefreshKey` state + storage listener `useEffect` — L78-87
- `toggleLeftPanel` — L180-185 (already in the hook per docs, verify)
- `HideableIcon` type alias

**Verify:** `resizeLeftPanel`, `resizeRightPanel` use localStorage persistence for final width.

#### 1B: Extend `features/navigation/useActivityRouter.ts`

**Update `ActivityType`:**
```ts
export type ActivityType = 'explorer' | 'search' | 'starred' | 'tags'
  | 'timeline' | 'locations' | 'graph' | 'images' | 'outline' | 'reminders';
```

**Verify:** `handleActivitySwitch` behavior (same-activity toggles panel, different switches + unhides).

#### 1C: Extend `features/files/useFileOperations.ts`

**Add:**
```ts
createFileWithContent: (folder: string, name: string, content: string) => Promise<string | null>;
```

This wraps `newFile` + `updateFile` in one call, used by the Image Generator's transcription feature.

**Verify:** `isImageFile` and `isDocxFile` are exported.

---

### Step 2: Wire Layout into App.tsx

**Goal:** Replace inline layout state with `useLayout()`.

**In App.tsx, replace:**
```tsx
// REMOVE:
const [leftWidth, setLeftWidth] = useState(250);
const [rightWidth, setRightWidth] = useState(350);
const [searchWidth, setSearchWidth] = useState(250);
const [leftPanelHidden, setLeftPanelHidden] = useState(...);
const [showAISidebar, setShowAISidebar] = useState(...);
const [visibilityRefreshKey, setVisibilityRefreshKey] = useState(0);
// ... storage listener effect
// ... hiddenIcons useMemo
const toggleAISidebar = useCallback(...);
const toggleLeftPanel = useCallback(...);
```

**With:**
```tsx
import { useLayout } from './features/layout/useLayout';
const layout = useLayout();
const { leftWidth, setLeftWidth, rightWidth, setRightWidth, searchWidth, setSearchWidth,
         leftPanelHidden, setLeftPanelHidden, showAISidebar, setShowAISidebar,
         toggleAISidebar, toggleLeftPanel, resizeLeftPanel, resizeRightPanel,
         hiddenIcons, visibilityRefreshKey } = layout;
```

**In JSX, replace:**
- Inline resizer `onMouseDown` handlers (L1311-1326) with `resizeLeftPanel`
- Inline resizer `onMouseDown` handlers (L1397-1413) with `resizeRightPanel`

**Expected reduction:** ~80 lines

**Verification:** Panel resizing works, AI sidebar toggle persists, left panel hide/show works, sidebar icon visibility persists, widths persist across reload.

---

### Step 3: Wire Auth into App.tsx + main.tsx

**Goal:** Move auth gate to `AuthProvider`.

**In `main.tsx`:**
```tsx
import { AuthProvider } from './features/auth/AuthProvider';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <AuthProvider>
    <App />
  </AuthProvider>
);
```

**In App.tsx, remove:**
- `import useAuth from './hooks/useAuth';` — L34
- `const { user, isAuthenticated, login, logout } = useAuth();` — L56
- `if (!isAuthenticated) { return <Login onLogin={login} />; }` — L1055-1057
- `import Login from './pages/Login';` — L27

**Replace with:**
```tsx
import { useAuthContext } from './features/auth/AuthProvider';
const { user, isAuthenticated, login, logout } = useAuthContext();
```

Note: `isAuthenticated` will always be `true` in App.tsx since AuthProvider gates rendering. But we still need the value for passing to `useSessionPersistence`. Keep `isAuthenticated` in destructuring.

**Move auth transition effect** (L270-282) into AuthProvider if it makes sense there, or keep in App.tsx as it calls `setShowAISidebar` (layout) and `refreshLlmHealth` (LLM).

**Expected reduction:** ~20 lines (login gate + import cleanup)

**Verification:** Login screen appears when not authenticated, main UI appears after login, protected routes still require auth.

---

### Step 4: Wire Navigation into App.tsx

**Goal:** Replace activity routing + settings with feature hooks.

**In App.tsx, replace:**
```tsx
// REMOVE:
const [activeActivity, setActiveActivity] = useState<ActivityType>('explorer');
const [tagsShowAddTag, setTagsShowAddTag] = useState(false);
const [showSettings, setShowSettings] = useState(false);
const handleActivitySwitch = useCallback(...);
// ... tagsShowAddTag reset effect
```

**With:**
```tsx
import { useActivityRouter, type ActivityType } from './features/navigation/useActivityRouter';
import { useSettings } from './features/navigation/useSettings';

const nav = useActivityRouter(toggleLeftPanel, setLeftPanelHidden);
const { activeActivity, setActiveActivity, tagsShowAddTag, handleActivitySwitch } = nav;
const { showSettings, setShowSettings } = useSettings();
```

**Expected reduction:** ~20 lines

**Verification:** Activity switching works, same-activity click toggles panel, tag sidebar opens from + button, settings modal opens/closes, all 10 activity types work.

---

### Step 5: Wire File Operations into App.tsx

**Goal:** Replace `useFiles` + `useFileSystemUndoRedo` with `useFileOperations()`.

**In App.tsx, replace:**
```tsx
// REMOVE:
const fileUndoRedo = useFileSystemUndoRedo();
const { canUndo, canRedo, undo: undoFs, redo: redoFs, push: pushUndoOp, refreshRef } = fileUndoRedo;
const { files, currentPath, content, ...all useFiles returns } = useFiles(pushUndoOp, showFolderPicker);
useEffect(() => { refreshRef.current = () => loadFiles(explorerPath); }, ...);

// REMOVE all inline callbacks:
const handleNewFile = ...
const handleDelete = ...
const handleRename = ...
const handleCopy = ...
const handleMove = ...
const handleBack = ...
const handleBackToRoot = ...
const handleBackToSegment = ...
const handleNewFolder = ...
const handleUploadFiles = ...
const handleBatchDelete = ...
const handleBatchCopy = ...
const handleBatchMove = ...
```

**With:**
```tsx
import { useFileOperations } from './features/files/useFileOperations';

const fileOps = useFileOperations(showFolderPicker);
const { files, currentPath, content, loading, error, setContent, tabs, activeTabId,
         explorerPath, setExplorerPath, canUndo, canRedo, undoFs, redoFs,
         loadFiles, openFile, openTab, saveCurrentFile, restoreToOriginal,
         newFile, newFolder, deleteSelected, renameSelected, copySelected, moveSelected,
         uploadImageFile, uploadFileToFolder, closeTab, switchTab, updateTabContent,
         closeOtherTabs, closeAllTabs, batchDelete, batchCopy, batchMove,
         handleNewFile, handleDelete, handleRename, handleCopy, handleMove,
         handleBack, handleBackToRoot, handleBackToSegment, handleNewFolder,
         handleUploadFiles, createFileWithContent } = fileOps;
```

**Batch selection:** The inline handlers (`handleToggleSelectionMode`, `handleToggleSelect`, `handleSelectAll`, `handleClearSelection`, `handleBatchDelete`, `handleBatchCopy`, `handleBatchMove`) stay in App.tsx — they use dialog state + file ops.

**Expected reduction:** ~100 lines

**Verification:** All file operations work (create, delete, rename, copy, move, upload), undo/redo works, DOCX import/export works, batch operations work, explorer navigation works.

---

### Step 6: Create New Feature Modules

#### 6A: Create `features/editor/useKeyboardShortcuts.ts`

```ts
// Specification:
function useKeyboardShortcuts({
  onSave,              // Ctrl+S
  onNewFromTemplate,   // Ctrl+Shift+N
  onToggleHelp,        // F1
}: {
  onSave: () => Promise<void>;
  onNewFromTemplate: () => void;
  onToggleHelp: () => void;
}): void;
```

Move from App.tsx L945-964. Register `keydown` listener on `window`, handle `Ctrl+S`, `Ctrl+Shift+N`, `F1`. Cleanup on unmount.

**Expected reduction in App.tsx:** ~20 lines

#### 6B: Create `features/editor/useTabManager.ts`

```ts
// Specification:
function useTabManager({
  tabs,           // from useFileOperations
  activeTabId,    // from useFileOperations
  closeTab,       // from useFileOperations
  switchTab,      // from useFileOperations
  closeOtherTabs, // from useFileOperations
  closeAllTabs,   // from useFileOperations
  saveCurrentFile,// from useFileOperations
}: { ... }): {
  handleTabClose: (id: string) => void;
  handleConfirmDirtyClose: (tabId: string, tabName: string) => void;
  handleTabSwitch: (id: string) => void;
  handleTabCloseOthers: (id: string) => void;
  handleTabCloseAll: () => void;
  dirty: boolean;
  canRestore: boolean;
  wordCount: number;
  currentFileName: string | null;
};
```

**BUT** — `handleConfirmDirtyClose` uses `showConfirm` dialog state which lives in App.tsx. Two options:
- (a) Accept `showConfirm` as a parameter
- (b) Keep `handleConfirmDirtyClose` in App.tsx (it's the only one that uses dialogs)

**Recommendation:** Keep `handleConfirmDirtyClose` in App.tsx. Extract the simple tab handlers + computed values.

**Revised spec:**
```ts
function useTabManager({
  tabs, activeTabId, closeTab, switchTab, closeOtherTabs, closeAllTabs, content
}: { ... }): {
  handleTabClose: (id: string) => void;
  handleTabSwitch: (id: string) => void;
  handleTabCloseOthers: (id: string) => void;
  handleTabCloseAll: () => void;
  dirty: boolean;
  canRestore: boolean;
  wordCount: number;
  currentFileName: string | null;
};
```

**Expected reduction in App.tsx:** ~30 lines (keep handleConfirmDirtyClose inline)

#### 6C: Create `features/graph/useGraphManager.ts`

```ts
// Specification:
function useGraphManager(username: string | undefined): {
  graphModalData: { nodes: GraphNode[]; edges: GraphEdge[]; model: string } | null;
  setGraphModalData: React.Dispatch<...>;
  handleGraphGenerate: (seedPath: string | null, relTypes: string[], useAI: boolean, depth: number) => Promise<void>;
  handleGraphViewCached: () => void;
  handleGraphClear: () => void;
  loading: boolean;
  error: string | null;
  hasCache: boolean;
};
```

Internalize `useGraph(username)` call. Move callbacks from App.tsx L1211-1231. The `GraphModal` rendering stays in App.tsx JSX (it's composition).

**Expected reduction in App.tsx:** ~40 lines

---

### Step 7: Wire New Modules + Final Cleanup

**In App.tsx:**
```tsx
// Wire keyboard shortcuts
useKeyboardShortcuts({
  onSave: handleSave,
  onNewFromTemplate: () => setShowTemplateModal(true),
  onToggleHelp: () => setShowHelp(prev => !prev),
});

// Wire tab manager
const tabManager = useTabManager({ tabs, activeTabId, closeTab, switchTab, closeOtherTabs, closeAllTabs, content: fileOps.content });
const { handleTabClose, handleTabSwitch, handleTabCloseOthers, handleTabCloseAll, dirty, canRestore, wordCount, currentFileName } = tabManager;

// Wire graph manager
const graphManager = useGraphManager(user?.username);
```

**Remove from App.tsx:**
- `useEffect(keydown)` — replaced by useKeyboardShortcuts
- Inline tab handlers (except dirty close) — replaced by useTabManager
- `graph` / `graphModalData` state + callbacks — replaced by useGraphManager
- Computed `dirty`, `canRestore`, `wordCount` — from useTabManager
- `useGraph` import
- `useFileSystemUndoRedo` import

**Expected total reduction from Steps 6-7:** ~90 lines

---

## 6. Dependency Rules (Updated)

| Module | May Import From |
|--------|----------------|
| `features/layout/*` | React only |
| `features/auth/*` | `hooks/useAuth`, `pages/Login`, React |
| `features/navigation/*` | React only |
| `features/files/*` | `hooks/useFiles`, `hooks/useFileSystemUndoRedo`, `services/api`, React |
| `features/editor/*` | `features/files/*` (for tab params), React |
| `features/graph/*` | `hooks/useGraph`, `services/api` (types), React |
| `App.tsx` | ALL features, ALL hooks, ALL components |
| Components (`components/*`) | `features/layout/LayoutContext` (optional), `hooks/*`, `services/api`, React |
| Hooks (`hooks/*`) | `services/api`, React (never import from `features/*`) |

**Key rule:** Features can depend on hooks and services, but NOT on other features (except `editor` → `files` for tab parameters). App.tsx is the only file that imports from all domains.

---

## 7. Verification Checklist

### Functional Tests (after each step)
- [ ] App compiles with no TypeScript errors
- [ ] App renders without React console errors
- [ ] Login screen appears when not authenticated
- [ ] Main UI appears after login

### Layout (Step 2)
- [ ] Left panel resizing works (draggable divider)
- [ ] Right panel (AI sidebar) resizing works
- [ ] AI sidebar toggle works and state persists across reload
- [ ] Left panel hide/show works (state persists)
- [ ] Sidebar icon visibility works (icons hide/show via context menu)
- [ ] Panel widths persist across page reload

### Auth (Step 3)
- [ ] Login/logout still works
- [ ] Protected routes still require auth
- [ ] Auth transition resets AI sidebar on fresh login

### Navigation (Step 4)
- [ ] Activity switching works for ALL 10 types (explorer, search, starred, tags, timeline, locations, graph, images, outline, reminders)
- [ ] Same-activity click toggles left panel
- [ ] Different-activity click switches and unhides panel
- [ ] Tag sidebar opens from + button in editor toolbar
- [ ] Settings modal opens and closes

### File Operations (Step 5)
- [ ] Creating files works (new file button, Ctrl+N pattern)
- [ ] Deleting files/folders works (with confirm dialog)
- [ ] Renaming files works
- [ ] Copy and move file operations work
- [ ] Opening a file loads content into the editor
- [ ] Saving a file persists content to disk (Ctrl+S + toolbar)
- [ ] File upload works (drag/drop and upload button)
- [ ] DOCX import works (via Header Import button)
- [ ] DOCX upload (via file upload) works
- [ ] Tag sidebar opens from + button
- [ ] Batch selection works (select all, batch delete, batch copy, batch move)
- [ ] Explorer navigation works (back, back to root, back to segment)
- [ ] Undo/redo file operations work (Ctrl+Z/Ctrl+Y)
- [ ] Image insertion works (click image in explorer → confirm → insert)

### Editor (Step 6)
- [ ] All keyboard shortcuts work (Ctrl+S, Ctrl+Shift+N, F1)
- [ ] Tabs open/close/switch correctly
- [ ] Dirty tab close shows 3-button confirmation
- [ ] Tab close others / close all work
- [ ] `beforeunload` warning appears with unsaved changes

### Graph (Step 6)
- [ ] Graph generation works from RelationshipGraphSidebar
- [ ] Graph modal opens and displays nodes/edges
- [ ] View cached graph works
- [ ] Clear graph cache works
- [ ] Node click in graph modal opens the file

### Cross-Cutting
- [ ] Image proxy URLs convert correctly on save (proxy → server) and load (server → proxy)
- [ ] DOCX export preserves 2-column layout as table
- [ ] PDF export works
- [ ] Download file works
- [ ] Session restore works (tabs, activity, explorer path restored on reload)
- [ ] Welcome screen shows recent/starred files
- [ ] New from template modal works
- [ ] Compile Story Bible modal works
- [ ] Generate with AI modal works
- [ ] Help Panel opens/closes with F1
- [ ] Image Generator panel works (generate, select, insert)
- [ ] Image Generator transcription creates file correctly
- [ ] Bookmark/Outline sidebar works
- [ ] Location Manager works
- [ ] Timeline View works
- [ ] Search panel works

### Code Quality
- [ ] App.tsx is under 400 lines
- [ ] No circular import warnings
- [ ] No unused imports in App.tsx
- [ ] All feature hooks use `useCallback` with correct dependency arrays
- [ ] React DevTools shows clean component tree
- [ ] No feature regressions

---

## 8. Rollback Plan

1. **Each step is a separate git commit** on a feature branch (`refactor/app-split-v2`)
2. **Test thoroughly after each commit** before proceeding
3. **If a step introduces a bug**, revert that commit and fix in isolation
4. **The current App.tsx (1,578 lines) is the baseline** — if the refactor goes badly, revert all commits
5. **Feature modules are additive** — they can exist without being wired, so partial progress is safe

---

## 9. Line Count Projection

| Step | Lines Removed from App.tsx | Cumulative Removal | Remaining Lines |
|------|---------------------------|-------------------|-----------------|
| Baseline | — | — | 1,578 |
| Step 1 (extend modules) | 0 | 0 | 1,578 |
| Step 2 (wire layout) | ~80 | 80 | 1,498 |
| Step 3 (wire auth) | ~20 | 100 | 1,478 |
| Step 4 (wire navigation) | ~20 | 120 | 1,458 |
| Step 5 (wire file ops) | ~100 | 220 | 1,358 |
| Step 6 (create+wire new modules) | ~90 | 310 | 1,268 |
| Step 7 (final cleanup) | ~900* | 1,210 | ~368 |

*Step 7 removes the inline duplications that were replaced by feature modules (the big inline callback definitions, state declarations, effects, and the activity rendering switch can be streamlined).

**Final target: ~360 lines** (77% reduction from 1,578)

---

## 10. Relationship to Existing Docs

| Doc | Status | Notes |
|-----|--------|-------|
| `APP_TSX_REFACTOR.md` | **Superseded** | Written for 908-line App.tsx; target architecture still valid but line counts and feature list outdated |
| `APP_REFACTOR_HINTS.md` | **Needs Update** | Documents a target state (~595 lines) that was never reached; many "moved" sections still in App.tsx |
| `APP_REFACTOR_TASK.md` (this doc) | **Current** | Accounts for 1,578-line App.tsx with all post-doc features; revised target ~360 lines |

---

*Document version: 1.0 — matches WORBI App.tsx at 1,578 lines (2026-05-04)*