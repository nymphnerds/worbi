# WORBI Brand Identity

## Logo Mark

The WORBI logo consists of two elements on the same text baseline:

```
WORBI by Nymphs
```

- **WORBI**: The primary brand name, rendered in **Orbitron** (Google Font), `font-semibold`, `text-xl`, white color, with `tracking-wider` for a spaced, futuristic look.
- **by Nymphs**: A small trademark-style byline in `text-[10px]`, `text-gray-400`, sitting on the same baseline immediately after the "I" in WORBI (2px margin `ml-0.5`).

### Typography

| Element | Font | Weight | Size | Color |
|---------|------|--------|------|-------|
| WORBI | Orbitron | 600 (semibold) | text-xl (~20px) | White |
| by Nymphs | System sans-serif | 400 (normal) | 10px | Gray 400 |
| WorldBuilder UI | System sans-serif | 400 (normal) | text-sm (~14px) | Gray 500 (muted-foreground) |

### Implementation

**Header** (`client/src/components/Header.tsx`):
```tsx
<div className="flex items-baseline">
  <h1 className="text-xl font-semibold tracking-wider text-white"
      style={{ fontFamily: "'Orbitron', sans-serif" }}>WORBI</h1>
  <span className="text-[10px] text-gray-400 font-normal ml-0.5 leading-none">by Nymphs</span>
</div>
```

**Welcome Screen** (`client/src/components/Welcome.tsx`):
```tsx
<h1 className="text-5xl font-bold text-white tracking-wider"
    style={{ fontFamily: "'Orbitron', sans-serif" }}>WORBI</h1>
<span className="text-sm text-gray-500 font-medium mt-1">by Nymphs</span>
```

### Font Loading

The Orbitron font is loaded via Google Fonts in `client/index.html`:

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;600;700&display=swap" rel="stylesheet">
```

### Design Principles

1. **Same baseline**: WORBI and "by Nymphs" share the same text baseline (`items-baseline`), like writing on a ruled line.
2. **Trademark treatment**: "by Nymphs" is smaller and dimmer, acting like a ® symbol next to the brand name.
3. **Tight spacing**: Only 2px gap between "I" and "b", making them read as a single brand mark.
4. **Orbitron personality**: The futuristic, geometric font gives WORBI a sci-fi/world-building aesthetic.

---

*Last updated: 2026-04-30*