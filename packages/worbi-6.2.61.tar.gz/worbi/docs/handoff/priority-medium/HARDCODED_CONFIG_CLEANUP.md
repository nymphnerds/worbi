# Handoff: Hardcoded Configuration Cleanup & Environment-Aware Settings

**Target Version:** v5.2.0
**Priority:** Medium (removes development-only cruft, enables proper deployment)
**Dependencies:** None
**Status:** Partially completed — core LLM config work is done; remaining items scoped below.
**Last Updated:** 2026-05-09 (codebase audit — handoff revised to match actual state)

---

## 1. Original Problem Statement (Historical Context)

`server/src/config.js` contained hardcoded development-environment artifacts:

- Hardcoded LLM model name (`qwen3.6-27b`)
- Hardcoded LM Studio URL (`http://localhost:8000/v1`)
- Dummy API key (`'dummy'`)
- Development-only `lmsStartScript` reference
- No `.env.example` file
- No environment variable support for LLM settings
- No startup validation

**Most of these have been resolved.** The per-request settings pattern, provider catalog, and removal of hardcoded LLM values are already implemented. This document now tracks the **remaining work**.

---

## 2. What's Already Done (Completed in Prior Versions)

### 2.1 Per-Request LLM Settings Pattern ✅

`llmService.js` functions now accept a `llmConfig` parameter instead of importing from a global config:

- `sendChatMessage(messages, documentContent, systemPrompt, permissions, llmConfig)`
- `sendCompletion(context, documentTitle, maxTokens, llmConfig)`
- `generateDocument(prompt, docType, documentContext, llmConfig)`
- `fetchModels(llmConfig)`
- `transcribeImage(image, prompt, llmConfig)`
- `testConnection(llmConfig)`

### 2.2 Routes Load User Settings ✅

All LLM routes in `server/src/routes/llm.js` load per-user settings via `config.loadUserSettings(username)` and pass them to service functions. No longer uses a global `config.llm`.

### 2.3 No Hardcoded LLM Model/API Key ✅

- `defaultUserSettings.modelName` is `''` (empty — user must configure)
- `defaultUserSettings.apiKey` is `''` (empty)
- `defaultUserSettings.baseUrl` is `''` (empty)
- No `qwen3.6-27b`, `apiKey: 'dummy'`, or `baseUrl: 'http://localhost:8000/v1'` in config

### 2.4 `getSystemInfo()` Removed ✅

The `/api/llm/system-info` endpoint returns a static deprecated response. The old `getSystemInfo()` function (which read `lmsStartScript` and checked hardcoded URLs) no longer exists in `llmService.js`.

### 2.5 Provider Catalog ✅

`server/src/services/providerCatalog.js` provides a static catalog of 8 local + 10 cloud providers, exposed via `GET /api/llm/providers`. Client can fetch this dynamically.

### 2.6 Partial Environment Variable Support ✅

`config.js` already reads these env vars:
- `process.env.DATA_DIR` — root data directory (fallback: `/home/nymph/Nymphs-Brain/WORBI/server/data`)
- `process.env.JWT_SECRET` — JWT signing secret (generates + persists to `$DATA_DIR/.jwt-secret`)
- `process.env.PROXY_SECRET` — image proxy HMAC secret (fallback: `'secret'` — see §3.3)
- `process.env.Z_IMAGE_*` — Z-Image sub-service config (6 variables)

---

## 3. Remaining Work

### 3.1 Hardcoded `/home/nymph` Paths

**Problem:** Four locations hardcode the developer's home path, making the project non-portable.

| File | Line | Hardcoded Value | Should Be |
|------|------|----------------|-----------|
| `config.js` | ~40 | `dataDir` fallback: `/home/nymph/Nymphs-Brain/WORBI/server/data` | `path.resolve(__dirname, '../../data')` (relative to project root) |
| `config.js` | ~80 | `scriptsDir`: `/home/nymph/Nymphs-Brain/bin` | `process.env.Z_IMAGE_SCRIPTS_DIR` with relative fallback or empty |
| `config.js` | ~80 | `outputDir`: `/home/nymph/Z-Image/outputs` | `process.env.Z_IMAGE_OUTPUT_DIR` with relative fallback or empty |
| `imageGenLifecycle.js` | ~56 | `scriptsDir` fallback: `/home/nymph/Nymphs-Brain/bin` (startServer) | Read from `config.zImage?.scriptsDir` only (already does, but config has hardcoded default) |
| `imageGenLifecycle.js` | ~107 | `scriptsDir` fallback: `/home/nymph/Nymphs-Brain/bin` (stopServer) | Same — fix propagates when config.js is fixed |

**Fix:** Change `config.js` defaults to use `path.resolve(__dirname, ...)` for relative paths, or empty strings that require env var configuration.

### 3.2 `lmsStartScript` / `lmsStopScript` in config.js

**Problem:** Lines ~18-19 in `config.js` still define:
```js
const lmsStartScript = path.resolve(__dirname, '../../../bin/lms-start');
const lmsStopScript = path.resolve(__dirname, '../../../bin/lms-stop');
```

These reference scripts that only exist on the developer's machine. Search the codebase to confirm they're not actively imported anywhere, then remove.

### 3.3 `proxySecret` Weak Fallback

**Problem:** In `config.js`, when `process.env.PROXY_SECRET` is not set, it falls back to the literal string `'secret'`. This is insecure for production.

**Current code pattern (JWT is correct):**
```js
// JWT_SECRET — generates random + persists to file ✅
if (!jwtSecretFile || !fs.existsSync(jwtSecretFile)) {
  jwtSecret = crypto.randomBytes(32).toString('hex');
  fs.writeFileSync(jwtSecretFile, jwtSecret);
}
```

**Current code pattern (PROXY_SECRET — needs fix):**
```js
proxySecret = process.env.PROXY_SECRET || 'secret';  // ❌ weak fallback
```

**Fix:** Apply the same generate-and-persist pattern as `JWT_SECRET` for `PROXY_SECRET`.

### 3.4 No `.env.example` File

**Problem:** All `process.env.*` variables in `config.js` are undocumented. A new developer has no way to discover what's configurable.

**Fix:** Create `.env.example` at project root documenting every env var. Variables to document:

```
# Server Configuration
PORT=8082
DATA_DIR=./server/data
JWT_SECRET=
PROXY_SECRET=

# Z-Image Service Configuration
Z_IMAGE_BASE_URL=
Z_IMAGE_SCRIPTS_DIR=
Z_IMAGE_OUTPUT_DIR=
Z_IMAGE_TIMEOUT_MS=120000
Z_IMAGE_START_TIMEOUT_MS=60000
Z_IMAGE_MIN_VRAM_MB=8192
```

### 3.5 No `GET /api/settings/defaults` Endpoint

**Problem:** `server/src/routes/settings.js` has:
- `GET /` — returns authenticated user's saved settings
- `POST /user` — saves settings
- `POST /test` — tests connection

No endpoint to return the server-side default settings. The client has no way to know what defaults the server uses when a user has no saved settings.

**Fix:** Add `GET /defaults` endpoint that returns the `defaultUserSettings` object from config. This keeps client/server defaults in sync without duplication.

### 3.6 Minimal Startup Validation

**Problem:** `server/src/index.js` only logs the port and users root. No validation of configuration on startup.

**Current startup output:**
```
WBUI Server running on http://0.0.0.0:8082
Users root: /path/to/data
```

**Fix:** Add startup validation:
1. Verify `DATA_DIR` exists or can be created
2. Log the configured data directory path
3. If `PROXY_SECRET` was auto-generated, log a warning
4. In production (`NODE_ENV=production`), warn if using auto-generated secrets

### 3.7 `.gitignore` Missing `.env` Entry

**Problem:** Verify `.env` is listed in `.gitignore`. If not, add it to prevent accidental commits.

---

## 4. Implementation Plan (Remaining Steps Only)

### Step 1: Fix Hardcoded Paths in `config.js`

- Replace `/home/nymph/Nymphs-Brain/WORBI/server/data` with `path.resolve(__dirname, '../../data')`
- Replace `/home/nymph/Nymphs-Brain/bin` with env-var-only (no hardcoded fallback, or use a relative path)
- Replace `/home/nymph/Z-Image/outputs` with env-var-only (no hardcoded fallback)
- Remove `lmsStartScript` and `lmsStopScript` constants (verify no imports first)

### Step 2: Fix `proxySecret` Fallback in `config.js`

Apply the same generate-and-persist pattern as `jwtSecret`:
```js
const proxySecretFile = path.resolve(dataDir, '.proxy-secret');
if (proxySecretFile && fs.existsSync(proxySecretFile)) {
  proxySecret = fs.readFileSync(proxySecretFile, 'utf-8');
} else if (!proxySecret) {
  proxySecret = crypto.randomBytes(32).toString('hex');
  if (proxySecretFile) fs.writeFileSync(proxySecretFile, proxySecret);
}
```

### Step 3: Create `.env.example`

Document all configurable environment variables at project root.

### Step 4: Add `GET /api/settings/defaults` Endpoint

In `server/src/routes/settings.js`:
```js
router.get('/defaults', (req, res) => {
  res.json({ settings: config.defaultUserSettings });
});
```

### Step 5: Add Startup Validation in `index.js`

After loading config, add validation and logging:
- Check `DATA_DIR` exists
- Log data directory path
- Warn if auto-generated secrets in use
- Warn in production if secrets are auto-generated

### Step 6: Add `.env` to `.gitignore`

Ensure `.env` is listed.

---

## 5. Files to Modify

| File | Changes |
|------|---------|
| `server/src/config.js` | Remove hardcoded `/home/nymph` paths, remove `lmsStartScript`/`lmsStopScript`, fix `proxySecret` fallback |
| `server/src/routes/settings.js` | Add `GET /defaults` endpoint |
| `server/src/index.js` | Add startup validation and logging |
| `.gitignore` | Add `.env` entry (if not present) |

## 6. Files to Create

| File | Purpose |
|------|---------|
| `.env.example` | Documented template for all environment variables |

---

## 7. Verification Checklist

- [ ] No `/home/nymph` paths remain in codebase (`grep -r "/home/nymph" server/src/`)
- [ ] No `lmsStartScript` or `lmsStopScript` references remain
- [ ] `proxySecret` uses generate-and-persist pattern (same as `jwtSecret`)
- [ ] `.env.example` exists and documents all env vars
- [ ] `.env` is in `.gitignore`
- [ ] `GET /api/settings/defaults` returns server defaults
- [ ] Startup logs include data directory path
- [ ] Startup logs warn about auto-generated secrets
- [ ] Server starts without `.env` file (uses all defaults)
- [ ] Server starts with `.env` file (uses `.env` values)
- [ ] Existing user settings are loaded correctly and override server defaults
- [ ] No regression in existing LLM functionality

---

## 8. Security Notes

- `.env` must never be committed to version control
- In production, `PROXY_SECRET` should be set via environment variable, not auto-generated
- The auto-generated secret persistence to `$DATA_DIR/.proxy-secret` is acceptable for local development
- `LLM_API_KEY` in user settings files should be treated as a secret

---

## 9. Migration Path

### For the Developer (Original Machine)

No `.env` file needed for the LLM part (already uses per-user settings). For Z-Image integration, create `.env`:
```
Z_IMAGE_SCRIPTS_DIR=/home/nymph/Nymphs-Brain/bin
Z_IMAGE_OUTPUT_DIR=/home/nymph/Z-Image/outputs
```

This replicates the current hardcoded behavior without changing functionality.

### For New Users

1. Copy `.env.example` to `.env`
2. Edit `.env` for their environment (Z-Image paths if using image generation)
3. Start the server — auto-generated secrets are persisted in `$DATA_DIR`
4. Each user configures their LLM settings in the Settings UI