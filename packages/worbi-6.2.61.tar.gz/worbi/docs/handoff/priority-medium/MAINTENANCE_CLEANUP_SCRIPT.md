# Handoff: Maintenance Cleanup Script — Redundant Files, Broken Links, Orphaned Assets, and Stale Accounts

**Target Version:** v5.2.0
**Priority:** Low (maintenance utility — not user-facing)
**Dependencies:** None (can be done independently)

---

## 1. Problem Statement

Over time, WORBI's filesystem-based storage accumulates digital debris:

| Issue | How It Happens | Impact |
|-------|---------------|--------|
| Broken image links in HTML | Image deleted from assets but `<img>` tag remains in a document | Users see broken images, don't know which documents are affected |
| Orphaned images in assets | Image uploaded but never referenced, or all references deleted | Wasted disk space |
| Orphaned `.wbi-meta.json` sidecar files | Source file deleted but metadata file left behind | Clutters workspace, confuses tag queries |
| Orphaned `.wbi-meta.json` directory files | All content files removed from a directory but metadata remains | Tag queries may return ghost directories |
| Empty directories | All files moved/deleted but folder structure left behind | Clutters file explorer |
| Stale user accounts | Users who haven't logged in for months | Wasted disk space on inactive workspaces |
| User data without an account | Workspace directories exist but no entry in `users.json` | Impossible to clean up through normal means |
| Corrupted HTML files | Zero-byte or unparseable files | Causes errors when opening in editor |

There is currently no tool to detect or clean up any of these issues.

---

## 2. Recommended Solution

Create a standalone Node.js script at `server/src/scripts/maintenance.js` that can be run manually or on a schedule. The script:

1. Runs in **report-only mode** by default (lists all issues, makes no changes)
2. Has a `--fix` flag to automatically clean up safe-to-remove items
3. Has a `--review` flag for items requiring human judgment (stale accounts)
4. Outputs a structured JSON report and a human-readable summary
5. Logs all actions taken when running with `--fix`

### 2.1 NPM Script

Add to root `package.json`:
```
"maintenance": "node server/src/scripts/maintenance.js"
"maintenance:fix": "node server/src/scripts/maintenance.js --fix"
"maintenance:review": "node server/src/scripts/maintenance.js --review"
```

---

## 3. Script Architecture

### 3.1 Entry Point

The script at `server/src/scripts/maintenance.js` should:

1. Parse command-line arguments: `--fix`, `--review`, `--json` (output JSON instead of formatted text), `--user <username>` (scan only a specific user)
2. Run each detector module in sequence
3. Collect all findings into a structured report
4. If `--fix`: apply fixes for safe-to-automate issues
5. Output the report to stdout
6. Exit with code 0 if no issues, code 1 if issues found but not fixed, or code 2 if errors occurred during scanning

### 3.2 Detector Modules

Each detector should be a separate function in the script that returns an array of finding objects. Each finding has:
- `type`: string identifying the issue category
- `severity`: `'info'`, `'warning'`, or `'error'`
- `user`: the username affected
- `path`: the relative or absolute path to the affected file/directory
- `detail`: human-readable description of the issue
- `action`: what `--fix` would do about it
- `fixed`: boolean (set after fix is applied)

---

## 4. Detector Specifications

### 4.1 Broken Image Link Detector

**Purpose:** Find `<img>` tags in HTML documents where the `src` points to a file that no longer exists.

**Scanning logic:**
1. Iterate over all users in `users.json`
2. For each user, walk their `workspace/` directory recursively
3. For each `.html` file (and any other text file types if applicable), read the content
4. Parse HTML and extract all `<img src="...">` attributes
5. For each `src` value:
   - If it's a `blob:` URL — skip (these are ephemeral and handled by the blob URL bridge)
   - If it's a `/api/files/images/...` URL — extract the path component, resolve it against the user's assets directory, check if the file exists
   - If it's a `/api/files/workspace/...` URL — extract the path component, resolve it against the user's workspace directory, check if the file exists
   - If it's an external URL (`http://` or `https://`) — skip (can't check existence reliably without network requests; mark as `info` with "External URL — cannot verify")
   - If it's a `/api/images/proxy?...` URL (post blob URL fix) — extract the `file` query parameter, resolve against assets, check existence
   - If it's a relative path — resolve against the document's directory, check existence
6. For each image that does NOT exist, create a finding

**Finding format:**
```
type: 'broken_image_link'
severity: 'error'
user: 'rauty'
path: 'MainStory/chapter1.html'
detail: 'Broken image link: /api/files/images/Characters/old_portrait.png (file not found)'
action: 'Remove <img> tag from document (requires manual review — not auto-fixed)'
```

**Auto-fix behavior (--fix):**
Do NOT auto-fix broken image links. The document content is user data. Instead, create a separate file `maintenance-broken-links-<timestamp>.md` in the user's workspace root that lists all broken links found in each document. The user can review this and manually fix documents. This file acts as a todo list.

### 4.2 Orphaned Image Detector

**Purpose:** Find images in user assets that are not referenced by any document.

**Scanning logic:**
1. Iterate over all users
2. Build a set of all referenced image paths by scanning all HTML documents (using the same extraction logic as detector 4.1, but collecting all successfully resolved paths)
3. Walk the user's `assets/images/` directory recursively
4. For each image file, check if its relative path (from assets root) is in the referenced set
5. If not, it's orphaned

**Finding format:**
```
type: 'orphaned_image'
severity: 'warning'
user: 'rauty'
path: 'assets/images/Characters/unused_sketch.png'
detail: 'Orphaned image: 2048 KB, last modified 2026-03-15'
action: 'Delete file (safe — not referenced by any document)'
```

**Auto-fix behavior (--fix):**
Move orphaned images to a `assets/images/.orphaned-<timestamp>/` directory instead of deleting them. This gives the user a recovery path. Add a `.orphaned-info.txt` file in the orphaned directory explaining what happened and how to restore files (move them back to the parent directory).

**Size calculation:** Tally the total size of orphaned images and include in the report summary.

### 4.3 Orphaned Metadata File Detector

**Purpose:** Find `.wbi-meta.json` sidecar files that have no corresponding source file.

**Background:** When a file is tagged, `tagService.js` stores metadata in `.wbi-meta.json` files. There are two types:
- **Directory-level:** `someDir/.wbi-meta.json` — stores tags and relationships for all files in that directory
- **File-level sidecars:** In earlier versions, individual `.filename.wbi-meta.json` sidecar files (check `tagService.js` for the actual naming pattern)

**Scanning logic:**
1. Walk each user's workspace recursively
2. Find all `.wbi-meta.json` files (both directory-level and sidecar)
3. For directory-level: check if the directory still exists and contains at least one scannable file. If the directory exists but is empty, the metadata file is partially orphaned (low severity). If the directory doesn't exist, it's fully orphaned.
4. For sidecar-level: check if the corresponding source file exists (strip the `.wbi-meta.json` suffix to get the source filename)
5. Also check metadata entries within directory-level files: for each file entry in the JSON, verify that the referenced file actually exists on disk

**Finding format:**
```
type: 'orphaned_metadata'
severity: 'warning'
user: 'rauty'
path: 'MainStory/deleted_chapter.wbi-meta.json'
detail: 'Orphaned metadata file — source file "MainStory/deleted_chapter.html" does not exist'
action: 'Delete .wbi-meta.json file'
```

**Auto-fix behavior (--fix):**
Delete orphaned metadata sidecar files. For directory-level `.wbi-meta.json` files with ghost entries (referencing deleted files), rewrite the JSON to remove only the invalid entries while preserving valid ones.

### 4.4 Empty Directory Detector

**Purpose:** Find directories that contain no files (or only empty subdirectories).

**Scanning logic:**
1. Walk each user's workspace recursively
2. For each directory, check if it contains any files (recursively)
3. A directory is "empty" if it has zero files at any depth
4. Skip the default template directories if they're explicitly meant to exist (MainStory, Quests, Characters, World) — but still flag them if the user has been inactive for a long time

**Finding format:**
```
type: 'empty_directory'
severity: 'info'
user: 'rauty'
path: 'workspace/AbandonedProject/'
detail: 'Empty directory — no files found'
action: 'Remove directory'
```

**Auto-fix behavior (--fix):**
Remove empty directories. Work bottom-up (deepest first) so that a directory containing only empty subdirectories gets fully cleaned up.

### 4.5 Corrupted HTML File Detector

**Purpose:** Find HTML files that are zero bytes or contain no meaningful content.

**Scanning logic:**
1. For each `.html` file in user workspaces:
   - Check file size — 0 bytes is corrupted
   - Check if the file contains only whitespace (trimmed content is empty)
   - Check if the file starts with `<!DOCTYPE html>` or `<html>` — if not, it might be a misnamed binary file
   - Check if the file can be read as UTF-8 without errors (read with `fs.readFileSync(path, 'utf-8')` in a try/catch)

**Finding format:**
```
type: 'corrupted_file'
severity: 'error'
user: 'rauty'
path: 'MainStory/broken.html'
detail: 'Zero-byte HTML file'
action: 'Move to .corrupted-<timestamp>/ for review'
```

**Auto-fix behavior (--fix):**
Move corrupted files to a `.corrupted-<timestamp>/` directory in the user's workspace root instead of deleting them. Add a `.corrupted-info.txt` file explaining what happened.

### 4.6 Stale Account Detector

**Purpose:** Identify user accounts that haven't been accessed for a configurable threshold period.

**Scanning logic:**
1. Read `users.json`
2. For each user, check `lastLogin` field
3. Compute days since last login: `(Date.now() - new Date(lastLogin).getTime()) / (1000 * 60 * 60 * 24)`
4. Compare against thresholds:
   - **Inactive (90+ days):** Flag for review
   - **Dormant (180+ days):** Flag with higher severity
   - **Abandoned (365+ days):** Flag for potential cleanup
5. Also check file modification times in the user's workspace:
   - Find the most recent `mtime` across all files in the workspace
   - If the user last logged in recently but files haven't been touched in a long time, flag as "active account, inactive workspace"
   - If the user hasn't logged in but files were recently modified (impossible through WORBI's UI without login), flag as "possible external modification"

**Thresholds should be configurable** via environment variables:
- `MAINTENANCE_INACTIVE_DAYS` — default 90
- `MAINTENANCE_DORMANT_DAYS` — default 180
- `MAINTENANCE_ABANDONED_DAYS` — default 365

**Finding format:**
```
type: 'stale_account'
severity: 'warning' (90+ days) / 'error' (365+ days)
user: 'old_user'
path: 'N/A (account-level)'
detail: 'Account inactive for 217 days. Last login: 2025-09-25. Workspace: 45 files, 12.3 MB.'
action: 'Review account for removal. Run with --review to list files. Run with --fix --user old_user to remove.'
```

**Auto-fix behavior (--fix):**
Even with `--fix`, do NOT automatically delete stale accounts. Only delete if BOTH `--fix` AND `--user <username>` are specified together. When deleting:
1. Log the full workspace path and size
2. Move the user's workspace to a `.removed-users/` directory at the data root (not in the OS trash, not deleted permanently)
3. Remove the user entry from `users.json`
4. Remove the user's settings file from `user-settings/`
5. Remove the entry from the global tag registry if it's user-scoped

### 4.7 Orphaned User Directories Detector

**Purpose:** Find workspace directories on disk that have no corresponding entry in `users.json`.

**Scanning logic:**
1. Read the list of usernames from `users.json`
2. Read the list of directories in `server/data/users/`
3. For each directory that is NOT in `users.json`, it's an orphaned user directory
4. Skip the `user-settings` directory (it's a sibling, not a user)

**Finding format:**
```
type: 'orphaned_user_directory'
severity: 'warning'
user: 'unknown_user'
path: 'server/data/users/ghost_user/'
detail: 'User directory exists but no entry in users.json. Workspace: 12 files, 5.2 MB.'
action: 'Review for manual recovery or removal'
```

**Auto-fix behavior (--fix):**
Move to `.removed-users/` directory. Add a note in the report suggesting the user recreate their account and contact an admin to recover files.

### 4.8 Duplicate Image Detector

**Purpose:** Find identical images stored under different names in the same user's assets.

**Scanning logic:**
1. Walk each user's assets directory
2. For each image file, compute a SHA-256 hash of the first 64KB (or full file if smaller) for a fast pre-filter, then full-file hash if the pre-filter matches
3. Group images by hash
4. Any group with more than one file signals duplicates

**Finding format:**
```
type: 'duplicate_images'
severity: 'info'
user: 'rauty'
path: 'assets/images/dragon_v2.png'
detail: 'Duplicate of dragon.png (same content, different name). Sizes: 2048 KB each.'
action: 'Review for manual deduplication (not auto-fixed)'
```

**Auto-fix behavior (--fix):**
Do NOT auto-fix duplicates. The user may have intentionally stored copies in different folders. Report only.

---

## 5. Report Structure

### 5.1 JSON Output (`--json` flag)

The script should output a single JSON object:

```
{
  "generatedAt": "2026-05-01T14:30:00.000Z",
  "scanDurationMs": 1234,
  "summary": {
    "totalFindings": 42,
    "bySeverity": { "info": 10, "warning": 25, "error": 7 },
    "byCategory": {
      "broken_image_link": 5,
      "orphaned_image": 12,
      "orphaned_metadata": 8,
      "empty_directory": 3,
      "corrupted_file": 2,
      "stale_account": 4,
      "orphaned_user_directory": 1,
      "duplicate_images": 7
    },
    "totalOrphanedImageSizeMB": 45.3,
    "fixableAutomatically": 25,
    "requiresManualReview": 17
  },
  "findings": [
    {
      "type": "broken_image_link",
      "severity": "error",
      "user": "rauty",
      "path": "MainStory/chapter1.html",
      "detail": "Broken image link: ...",
      "action": "...",
      "fixed": false
    }
    // ...
  ],
  "staleAccounts": [
    {
      "username": "old_user",
      "daysSinceLastLogin": 217,
      "lastLogin": "2025-09-25T...",
      "createdAt": "2025-01-15T...",
      "workspaceSizeMB": 12.3,
      "fileCount": 45,
      "newestFileDate": "2025-08-12T..."
    }
  ]
}
```

### 5.2 Human-Readable Output (default)

Group findings by user, then by category, with clear headers and counts. Use ANSI color codes if output is to a terminal:
- Red for `error`
- Yellow for `warning`
- Cyan for `info`

Example format:
```
═══════════════════════════════════════════
  WORBI Maintenance Report
  2026-05-01 14:30:00
  Scan duration: 1.2s
═══════════════════════════════════════════

SUMMARY
  Total findings: 42
  ⚠ Errors: 7   Warnings: 25   Info: 10
  Fixable automatically: 25
  Requires review: 17

── User: rauty ──────────────────────────

  BROKEN IMAGE LINKS (5)
  ⚠ MainStory/chapter1.html
    → Broken: /api/files/images/Characters/old_portrait.png
    → Broken: /api/files/images/World/map_v1.jpg
  ...

  ORPHANED IMAGES (12) — 45.3 MB recoverable
  ⚠ Characters/unused_sketch.png (2048 KB)
  ⚠ World/draft_banner.webp (512 KB)
  ...

── User: old_user ───────────────────────

  STALE ACCOUNT (1)
  ⚠ Account inactive for 217 days
    Last login: 2025-09-25
    Workspace: 45 files, 12.3 MB
    → Review with: npm run maintenance:review

═══════════════════════════════════════════
Run with --fix to auto-fix 25 issues
Run with --review to open stale account details
═══════════════════════════════════════════
```

---

## 6. The `--review` Flag

When `--review` is passed, the script should provide detailed information about items that require human judgment:

1. For stale accounts: List every file in the user's workspace with its size and last modified date
2. For broken image links: Show the surrounding HTML context (the `<img>` tag and 100 characters before/after)
3. For duplicate images: Show all duplicate groups with their full paths

This output should be plain text (or JSON with `--json`) suitable for piping to a file for later review.

---

## 7. Safety Measures

### 7.1 Dry-Run is Default

The script MUST NOT make any changes unless `--fix` is explicitly passed. Without `--fix`, it is read-only.

### 7.2 Backups Before Deletion

When `--fix` removes files:
- Orphaned images go to `assets/images/.orphaned-<ISO-timestamp>/`
- Corrupted files go to `workspace/.corrupted-<ISO-timestamp>/`
- Removed user accounts go to `<dataDir>/.removed-users/<username>-<ISO-timestamp>/`
- Orphaned user directories go to `<dataDir>/.removed-users/<dirname>-<ISO-timestamp>/`

Nothing is ever permanently deleted. Users (or admins) can manually restore files by moving them back from these directories. Add a `maintenance:purge` script that cleans up `.orphaned-*` and `.corrupted-*` directories older than 30 days. Do NOT implement this purge script yet — just document it.

### 7.3 Lock File

Before making any changes with `--fix`, the script should:
1. Create a lock file: `server/data/.maintenance-lock`
2. If the lock file already exists and is less than 1 hour old, refuse to run and print "Maintenance already running or recently completed. Remove lock file to force."
3. Delete the lock file on completion (even on error, via a `finally` block or `process.on('exit')` handler)

### 7.4 User-Scoped Runs

The `--user <username>` flag limits scanning to a single user. All detectors only check that user's data. This is useful for targeted cleanup.

---

## 8. Files to Create

| File | Purpose |
|------|---------|
| `server/src/scripts/maintenance.js` | The maintenance script with all detectors, report formatting, and fix logic |

## 9. Files to Modify

| File | Changes |
|------|---------|
| `package.json` (root) | Add `maintenance`, `maintenance:fix`, `maintenance:review` npm scripts |

## 10. Configuration (add to `env.js` and `.env.example`)

| Variable | Default | Description |
|----------|---------|-------------|
| `MAINTENANCE_INACTIVE_DAYS` | `90` | Days since last login before account is flagged as inactive |
| `MAINTENANCE_DORMANT_DAYS` | `180` | Days before account is flagged as dormant |
| `MAINTENANCE_ABANDONED_DAYS` | `365` | Days before account is flagged as abandoned |

## 11. Implementation Order

1. **Phase 1:** Script skeleton — argument parsing, user iteration, report structure, JSON output, lock file
2. **Phase 2:** Image link scanner (detector 4.1) and orphaned image scanner (detector 4.2)
3. **Phase 3:** Metadata scanner (detector 4.3), empty directory scanner (detector 4.4), corrupted file scanner (detector 4.5)
4. **Phase 4:** Stale account scanner (detector 4.6) and orphaned user directory scanner (detector 4.7)
5. **Phase 5 (0.5–1 hour):** Duplicate image scanner (detector 4.8) — optional, can be deferred
6. **Phase 6 (1 hour):** `--fix` logic with safe move-to-backup-directory behavior
7. **Phase 7 (0.5 hour):** `--review` detailed output, npm scripts, documentation

## 12. Verification Checklist

- [ ] `npm run maintenance` runs without errors and produces a report
- [ ] `npm run maintenance -- --json` outputs valid JSON
- [ ] `npm run maintenance -- --user rauty` scans only the specified user
- [ ] Broken image links are correctly detected (create a test file with a broken `<img>` tag)
- [ ] Orphaned images are correctly detected (upload an image, verify it appears as "not orphaned" when referenced, delete the reference, verify it appears as orphaned)
- [ ] Orphaned metadata files are correctly detected
- [ ] Empty directories are correctly detected
- [ ] Corrupted HTML files are detected (create a zero-byte .html file)
- [ ] Stale accounts are flagged at the correct thresholds (modify `lastLogin` in users.json to test)
- [ ] Orphaned user directories are detected (create a directory in `data/users/` without a users.json entry)
- [ ] `--fix` moves files to backup directories instead of deleting
- [ ] `--fix` does NOT remove user accounts unless `--user` is also specified
- [ ] Lock file prevents concurrent maintenance runs
- [ ] Lock file is cleaned up on script exit (even on error)
- [ ] The report summary includes total orphaned image size
- [ ] The stale account list includes workspace size and file count
- [ ] External image URLs are reported as "cannot verify" rather than "broken"
- [ ] `blob:` URLs are skipped (not reported as broken)
- [ ] Script exits with appropriate exit codes (0 = clean, 1 = issues found, 2 = errors)

## 13. Example Usage

```bash
# View report (read-only)
npm run maintenance

# View report as JSON for scripting
npm run maintenance -- --json > maintenance-report.json

# Fix all safe-to-automate issues
npm run maintenance:fix

# Review details about items needing human judgment
npm run maintenance:review

# Scan only one user
npm run maintenance -- --user rauty

# Fix only one user's issues
npm run maintenance -- --fix --user rauty

# Full cleanup with review
npm run maintenance -- --fix --json > report.json