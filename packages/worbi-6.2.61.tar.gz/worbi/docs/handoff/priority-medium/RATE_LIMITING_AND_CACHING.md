# Handoff: Rate Limiting, Request Throttling, and Search Result Caching

**Target Version:** v5.2.0
**Priority:** Low (defense-in-depth; not currently causing problems)
**Dependencies:** None (can be done independently)

---

## 1. Problem Statement

WORBI's server currently has no rate limiting, no request throttling, and no caching. Every request is processed fresh without any abuse prevention.

### 1.1 No Rate Limiting

Any client (authenticated or not) can:
- Hammer `/api/auth/login` with brute-force attempts
- Send unlimited requests to any endpoint
- Exhaust server resources (CPU, memory, file descriptors) with rapid successive requests
- Call `POST /api/llm/chat` in a tight loop, flooding the LLM server

### 1.2 No LLM Request Throttling

The `POST /api/llm/chat` endpoint:
- Makes outbound HTTP requests to the configured LLM server
- The tool-calling loop can make up to 10 iterations, each sending a request to the LLM
- The `web_search` tool makes outbound HTTP requests to DuckDuckGo
- If a user sends rapid chat messages, the server could overwhelm the LLM server, DuckDuckGo, or itself

### 1.3 No Web Search Caching

The `webSearch()` function in `toolService.js`:
- Makes an outbound HTTP request to DuckDuckGo for every search
- Fetches the top result's webpage content
- Multiple searches for the same query within a session result in duplicate outbound requests
- If the LLM tool-calling loop searches for similar terms, it generates redundant traffic

### 1.4 No Brutal Force Protection

The auth endpoint has no protection against credential guessing:
- No account lockout after failed attempts
- No IP-based rate limiting
- No progressive delay on failed attempts

---

## 2. Recommended Solution

Implement three independent but complementary protections:

1. **Express rate limiter middleware** for global API protection
2. **LLM-specific concurrency limiter** for chat endpoint throttling
3. **In-memory search cache** for DuckDuckGo results

---

## 3. Implementation Plan

### Step 1: Install and Configure `express-rate-limit`

**Package:** `express-rate-limit` (popular, well-maintained, zero-config defaults)

**Install:** Add to `server/package.json` dependencies.

**Implementation:**

1. Create `server/src/middleware/rateLimiter.js` that exports pre-configured rate limiter instances.

2. Configure two tiers of rate limits:

**Global API limiter (applies to all `/api/*` routes):**
- Window: 1 minute
- Max requests: 120 per window (allows 2 requests/second average, bursts up to 120)
- Standard headers: include `RateLimit-Limit`, `RateLimit-Remaining`, `RateLimit-Reset` in responses
- Skip rate limiting for the health check endpoint `/api/health`
- When exceeded: return 429 Too Many Requests with body `{ error: 'Too many requests. Please try again in X seconds.', retryAfter: X }`

**Auth limiter (stricter, applies only to `/api/auth/*`):**
- Window: 15 minutes
- Max requests: 20 per window (prevents brute force — ~1.3 attempts/minute)
- Skip for successful logins (don't count against the limit)
- When exceeded: return 429 Too Many Requests with body `{ error: 'Too many login attempts. Please try again in N minutes.', retryAfterMinutes: N }`
- This applies per IP address (use `req.ip` as the key)

**LLM chat limiter (applies only to `/api/llm/chat`):**
- Window: 1 minute
- Max requests: 10 per window (allows reasonable chat pace)
- When exceeded: return 429 with body `{ error: 'Please wait before sending another message.', retryAfter: X }`

3. Apply limiters in `server/src/index.js`:
   - Global limiter: `app.use('/api', globalLimiter)` — after auth middleware routes but before protected routes (so it covers all API routes)
   - Auth limiter: `app.use('/api/auth', authLimiter)` — before auth routes are mounted
   - LLM limiter: Apply in `server/src/routes/llm.js` to the specific chat route

### Step 2: Implement LLM Chat Concurrency Limiter

The rate limiter prevents rapid API calls, but doesn't prevent concurrent calls from piling up. Add a concurrency limiter to the LLM service.

1. Create `server/src/services/concurrencyLimiter.js`:

   **Simple semaphore pattern:**
   - Export a function `createConcurrencyLimiter(maxConcurrent)` that returns:
     - `acquire()`: Returns a Promise that resolves when a slot is available (wait if all slots are taken)
     - `release()`: Releases a slot so another caller can acquire it
   - Use a queue: when all slots are taken, incoming callers are queued in FIFO order
   - Set `maxConcurrent = 2` for LLM chat (at most 2 concurrent LLM requests being processed)

2. In `llmService.js`, wrap `sendChatMessage()`:
   - At the start of the function: `await limiter.acquire()`
   - In a `try...finally` block: call `limiter.release()` in the `finally` clause
   - This ensures the slot is always released, even if the LLM request errors

3. If a caller has been waiting more than 30 seconds for a slot:
   - The `acquire()` function should reject with a timeout error
   - The LLM service should catch this and return a `{ role: 'assistant', content: 'The AI is currently busy. Please try again in a moment.' }` message

### Step 3: Implement Search Result Cache

Create an in-memory cache for DuckDuckGo search results.

1. Create `server/src/services/searchCache.js`:

   **Simple TTL cache:**
   - Use a `Map<string, { data: string, timestamp: number }>`
   - Key: the search query string, normalized (lowercase, trimmed)
   - Value: the formatted search result string + timestamp of when it was cached

   **Functions:**
   - `getSearchCache(query)`: Returns cached result if exists and not expired; returns `null` otherwise
   - `setSearchCache(query, result)`: Stores the result with current timestamp
   - `clearExpired()`: Removes all expired entries (called periodically or on cache size threshold)
   - `clear()`: Empties the entire cache

   **Configuration:**
   - TTL: 5 minutes (300,000 ms) — search results are fresh for 5 minutes
   - Max cache size: 500 entries — prevent unbounded memory growth
   - If cache exceeds max size, evict the 50 oldest entries (LRU-like eviction)

2. In `toolService.js`, modify `webSearch()`:
   - Before making the outbound request, check `searchCache.getSearchCache(query)`
   - If a non-expired cached result exists, return it immediately (add a `[cached]` prefix or note)
   - If no cache entry or expired, proceed with the HTTP request
   - After getting results, call `searchCache.setSearchCache(query, result)`

3. Add a `GET /api/admin/search-cache/stats` endpoint (admin-only, or just for debugging):
   - Returns `{ size: N, maxSize: 500, ttlSeconds: 300 }`
   - Useful for monitoring during development

### Step 4: Add Progressive Delay on Failed Login (Optional Enhancement)

If the auth rate limiter alone isn't considered sufficient:

1. Track failed login attempts per username in an in-memory map: `Map<string, { count: number, lastAttempt: number }>`
2. After 3 failed attempts, introduce a delay: `delay = Math.min(1000 * Math.pow(2, count - 3), 30000)` — exponential backoff capped at 30 seconds
3. Before checking the password, if there's an active delay, `await new Promise(resolve => setTimeout(resolve, delay))`
4. Reset the counter on successful login
5. Clear entries older than 15 minutes to prevent memory leaks

This is a defense-in-depth measure on top of the auth rate limiter.

---

## 4. Files to Create

| File | Purpose |
|------|---------|
| `server/src/middleware/rateLimiter.js` | Configured rate limiter instances (global, auth, LLM) |
| `server/src/services/concurrencyLimiter.js` | Simple semaphore-based concurrency limiter for LLM chat |
| `server/src/services/searchCache.js` | TTL-based in-memory cache for DuckDuckGo search results |

## 5. Files to Modify

| File | Changes |
|------|---------|
| `server/package.json` | Add `express-rate-limit` dependency |
| `server/src/index.js` | Apply global and auth rate limiters to Express app |
| `server/src/routes/llm.js` | Apply LLM rate limiter to chat route |
| `server/src/services/llmService.js` | Wrap `sendChatMessage()` with concurrency limiter acquire/release |
| `server/src/services/toolService.js` | Add cache check in `webSearch()` before HTTP request |
| `client/src/services/api.ts` | Handle 429 responses: show a toast/notification with the `retryAfter` message |
| `client/src/hooks/useLLM.ts` | Handle LLM "AI is busy" responses gracefully in chat UI |

## 6. Client-Side 429 Handling

Update `client/src/services/api.ts` or the API call wrappers to handle 429 responses:

1. When any API call receives a 429 response:
   - Parse the `retryAfter` or `retryAfterMinutes` field from the response body
   - Show a user-friendly toast/notification
   - For auth 429s: "Too many login attempts. Please wait N minutes."
   - For global 429s: "Server is busy. Please try again in N seconds."
   - For LLM 429s: "Please wait N seconds before sending another message."

2. Do NOT auto-retry 429 responses — respect the rate limit.

3. Update `useLLM.ts`:
   - Add error state handling for the "AI is currently busy" message
   - Display this as a system message in the chat rather than an error toast

---

## 7. Configuration

### 7.1 Environment Variables (add to `env.js` and `.env.example`)

| Variable | Default | Description |
|----------|---------|-------------|
| `RATE_LIMIT_GLOBAL_MAX` | `120` | Max requests per minute for global API |
| `RATE_LIMIT_AUTH_MAX` | `20` | Max requests per 15 minutes for auth endpoints |
| `RATE_LIMIT_LLM_MAX` | `10` | Max requests per minute for LLM chat |
| `LLM_CONCURRENCY_MAX` | `2` | Max concurrent LLM chat requests |
| `SEARCH_CACHE_TTL` | `300` | Search cache TTL in seconds |

### 7.2 When to Disable Rate Limiting

- In `NODE_ENV=test`: disable all rate limiting (tests should run at full speed)
- In `NODE_ENV=development`: use defaults or relaxed limits
- In `NODE_ENV=production`: use strict limits

Implementation: In `rateLimiter.js`, check `process.env.NODE_ENV` and skip rate limiting entirely when `test`.

---

## 8. Edge Cases and Considerations

### 8.1 Rate Limit Keys

- Use `req.ip` as the default key for rate limiting
- If the server is behind a reverse proxy (nginx, Cloudflare), `req.ip` may show `127.0.0.1`
- Trust proxy headers: add `app.set('trust proxy', 1)` in `server/src/index.js` if behind a reverse proxy
- For local development, `req.ip` is `::1` (IPv6 localhost) or `127.0.0.1` — this is fine for a single-user tool

### 8.2 Rate Limit Headers

The `express-rate-limit` package automatically adds:
- `RateLimit-Limit`: The maximum requests in the window
- `RateLimit-Remaining`: How many requests remain in the current window
- `RateLimit-Reset`: Unix timestamp when the window resets

These are informational for the client. The frontend doesn't need to read them (the 429 response is sufficient), but they're useful for debugging and could be displayed in the StatusBar.

### 8.3 Search Cache Memory

- At 500 entries, with each entry being approximately 2-5KB of search result text, total memory usage is ~1-3MB
- This is negligible for a desktop application
- If the server runs for weeks, the cache might accumulate stale entries; the periodic cleanup (`clearExpired()`) prevents this
- Add `clearExpired()` call on an interval: `setInterval(() => searchCache.clearExpired(), 60000)` — clean up every minute

### 8.4 Concurrency Limiter Fairness

- The simple semaphore pattern with a FIFO queue ensures fair queuing
- If a request waits too long, it times out gracefully rather than hanging indefinitely
- The queue is unbounded (can grow large if the LLM server is slow), but with a 30-second timeout, queued requests will expire before the queue grows too large

### 8.5 Memory for Failed Login Tracking

- The failed login map grows by one entry per unique username that fails to log in
- Clean up entries older than 15 minutes: `setInterval(() => cleanupFailedLogins(), 300000)` — every 5 minutes
- This prevents memory leaks from attackers probing many usernames

---

## 9. Verification Checklist

- [ ] Server starts with rate limiting enabled
- [ ] Sending more than 120 requests in 1 minute to non-auth API returns 429
- [ ] Sending more than 20 login attempts in 15 minutes returns 429
- [ ] Sending more than 10 chat messages in 1 minute returns 429
- [ ] `GET /api/health` is NOT rate limited (always returns 200)
- [ ] Successful logins don't count toward the auth rate limit
- [ ] 429 responses include a `retryAfter` field in the body
- [ ] Client shows appropriate notification on 429 responses
- [ ] Only 2 LLM requests are processed concurrently; a 3rd waits in queue
- [ ] An LLM request that waits more than 30 seconds in queue returns "AI is busy" message
- [ ] Concurrency slot is released even when an LLM request errors
- [ ] Search results for the same query within 5 minutes return cached results
- [ ] Search cache doesn't grow beyond 500 entries
- [ ] Expired cache entries are cleaned up
- [ ] Rate limiting is disabled in test mode (`NODE_ENV=test`)
- [ ] Memory usage doesn't grow unbounded over time

## 10. Testing

Add test files:

**File: `server/tests/unit/services/searchCache.test.ts`**

- `setSearchCache('test', 'results')` stores the result
- `getSearchCache('test')` returns the cached result within TTL
- `getSearchCache('test')` returns null after TTL expires
- `getSearchCache('nonexistent')` returns null
- Query normalization: `getSearchCache('  TEST QUERY  ')` matches `setSearchCache('test query', ...)`
- Cache respects max size: after 501 inserts, the first 50 are evicted
- `clear()` empties the cache
- `clearExpired()` removes only expired entries

**File: `server/tests/unit/services/concurrencyLimiter.test.ts`**

- `acquire()` resolves immediately when slots are available
- `acquire()` waits when all slots are taken
- `release()` frees a slot so the next waiter can proceed
- Multiple waiters are served in FIFO order
- `acquire()` rejects after timeout when no slots become available
- `release()` on an already-full limiter doesn't increase slots beyond max

**File: `server/tests/integration/rateLimiter.test.ts`** (using supertest)

- Global rate limit: 121st request returns 429
- Auth rate limit: 21st login attempt returns 429
- Health check is not rate limited
- Rate limit headers are present on responses

---

## 11. Security Notes

- Rate limiting is NOT a replacement for strong passwords and proper auth — it's a supplementary defense
- IP-based rate limiting can be circumvented with IP rotation (but this is unlikely for a local desktop app)
- For a multi-user deployment behind a proxy, ensure `trust proxy` is configured correctly so `req.ip` reflects the actual client IP
- The search cache should NOT be used for caching sensitive or user-specific data — it only caches public DuckDuckGo search results