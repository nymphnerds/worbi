# WORBI &times; NymphsCore Manager — Integration Recommendations Handoff

**Author**: Agent Analysis (Cline)  
**Date**: 2026-05-07  
**WORBI Version**: 6.2.51  
**Purpose**: Synthesize RautysIdeas vision with current WORBI codebase state; provide actionable, prioritized recommendations for making WORBI a polished NymphsCore Manager module.

---

## 1. Executive Summary

WORBI v6.2.51 is already **closer to Manager-ready** than the Rauty handoff documents suggest. Several improvements they flagged are already implemented. However, critical gaps remain around packaging robustness, path portability, and runtime hardening.

**Current alignment**: ~70% complete. The foundation is solid. The remaining ~30% focuses on reliability, portability, and polish.

**Top 3 priorities**:
1. Harden the production build pipeline so `npm run build` + `npm start` works reliably
2. Decouple hardcoded paths for cross-user portability
3. Repair install script error handling and upgrade/backup logic

---

## 2. Current State Audit

### 2.1 What's Already Done (Good News)

| Rauty Document Flag | Status | Notes |
|---|---|---|
| Production static file serving | **DONE** | `server/src/index.js` lines 60-72 already serve `../dist/` when it exists, falls back to API-only mode |
| SPA catch-all route | **DONE** | `app.get('*', ...)` serves `index.html` for client-side routing |
| `npm start` vs `npm run dev` separation | **DONE** | Server has `"start": "node src/index.js"` (production) vs `"dev": "node --watch src/index.js"` (dev) |
| Module repo on GitHub | **DONE** | `github.com/nymphnerds/worbi` with `nymph.json`, scripts, packages |
| Registry entry | **DONE** | WORBI listed in `nymphs-registry/nymphs.json` |
| Wrapper scripts | **DONE** | install, status, start, stop, open, logs, uninstall |
| Archive-based packaging | **DONE** | `worbi-6.2.50.tar.gz` in module repo |
| Manager contract (status fields) | **DONE** | Outputs `installed=`, `version=`, `running=`, `health=`, etc. |

### 2.2 What's Still Gap

| Issue | Severity | Location |
|-------|----------|----------|
| **LLM config hardcoded** — `/home/nymph/`, `localhost:8000`, model names | High | `server/src/config.js` |
| **Users root hardcoded** — `path.join(__dirname, '../../../data/users')` | High | `server/src/index.js` |
| **Client build not integrated** — `npm run build` only builds client, doesn't place `dist/` where server expects | Medium | `package.json` scripts |
| **Install script fragility** — `|| true` masks failures | Medium | Module repo install script |
| **Upgrade/backup logic** — needs cleanup pass | Medium | Module repo install script |
| **Version drift** — docs say 6.2.18/6.2.50, code is 6.2.51 | Low | Documentation |
| **LLM status indicator** — always shows "Disconnected" | Low | Client StatusBar |
| **Chat history** — in-memory only, lost on refresh | Low | Client chat state |
| **Test coverage** — no tests for Manager integration flow | Medium | Test suite |

---

## 3. Recommendations (Prioritized)

### Phase 1: Critical — Portability (Must Do Before Shipping)

**Goal**: Make WORBI installable by any user on any Linux machine without editing config files.

#### 3.1.1 Decouple `usersRoot` from Hardcoded Path

**Problem**: `server/src/index.js` uses:
```js
const usersRoot = path.join(__dirname, '../../../data/users');
```
This assumes the data directory is relative to the server source. For installed packages at `~/worbi/`, this path breaks.

**Recommendation**: Make `usersRoot` configurable via environment variable:
```js
const usersRoot = process.env.WORBI_DATA_ROOT || path.join(__dirname, '../../../data/users');
```

**Files**: `server/src/index.js` (1 line change)

#### 3.1.2 Externalize LLM Config

**Problem**: `server/src/config.js` hardcodes:
- `LLM_URL: 'http://localhost:8000'`
- `LLM_MODEL: 'meta-llama/Llama-3.1-8B-Instruct'`
- `IMAGE_API_URL: 'http://localhost:8000'`
- `IMAGE_MODEL: 'stabilityai/stable-diffusion-3-5-large'`

**Recommendation**: Introduce a user-writable config file at `~/.worbi/config.json` (or `~/worbi/config.json`) that the server reads on startup. Ship a `config.example.json` with defaults.

**Files**: `server/src/config.js` (new logic), new `config.example.json`

**Example `config.example.json`**:
```json
{
  "port": 8082,
  "jwt": {
    "secretEnv": "JWT_SECRET",
    "expiry": "7d"
  },
  "llm": {
    "url": "http://localhost:8000",
    "model": "meta-llama/Llama-3.1-8B-Instruct",
    "timeout": 10000
  },
  "imageGen": {
    "apiUrl": "http://localhost:8000",
    "model": "stabilityai/stable-diffusion-3-5-large"
  },
  "usersRootEnv": "WORBI_DATA_ROOT"
}
```

#### 3.1.3 Make Port Configurable

**Problem**: Port `8082` is hardcoded in `config.js`.

**Recommendation**: Already supported via `config.port`, but make it overridable via `PORT` env var:
```js
port: parseInt(process.env.PORT, 10) || 8082
```

**Files**: `server/src/config.js` (1 line change)

---

### Phase 2: Build Pipeline (Should Do)

**Goal**: `npm run build` at the monorepo root produces a self-contained production artifact.

#### 3.2.1 Add Monorepo Build Script

**Problem**: Current `npm run build` only runs `npm run build --prefix client`. It does not place `dist/` where the server expects it.

**Recommendation**: Add a top-level `build:prod` script:
```json
{
  "build:prod": "npm run build --prefix client && cp -r client/dist server/dist"
}
```

**Files**: `package.json` (1 new script)

#### 3.2.2 Add Pre-package Validation

**Recommendation**: Add a `verify:prod` script that:
1. Runs `npx tsc --noEmit` on both client and server
2. Runs the test suite
3. Builds the production bundle
4. Starts the server in test mode and hits the health endpoint

**Files**: `package.json` (1 new script), new verification script

---

### Phase 3: Packaging Hardening (Should Do)

**Goal**: The archive and install scripts are robust, idempotent, and safe.

#### 3.3.1 Remove `|| true` from Install Script

**Problem**: `npm install ... || true` in the install script silently swallows dependency installation failures.

**Recommendation**: Replace with proper error handling:
```bash
if ! npm install --production --prefix "$INSTALL_DIR"; then
  echo "ERROR: Failed to install production dependencies"
  exit 1
fi
```

**Files**: Module repo `scripts/install_worbi.sh`

#### 3.3.2 Implement Upgrade Backup

**Problem**: When a new version is installed over an existing one, user data should be preserved.

**Recommendation**: Before extracting a new archive:
1. Detect existing install
2. Back up user data directory to `~/NymphsModuleBackups/worbi-<old_version>-<timestamp>/`
3. Extract new version
4. Migrate user data back

**Files**: Module repo `scripts/install_worbi.sh`

#### 3.3.3 Archive Contents Audit

**Problem**: Ensure the archive contains only what's needed for production.

**Recommended archive structure**:
```
worbi-6.2.51.tar.gz
├── server/
│   ├── src/              (compiled JS, NOT TypeScript)
│   ├── package.json
│   ├── dist/             (pre-built client static files)
│   └── config.example.json
├── data/
│   └── users/            (empty placeholder)
├── logs/                 (empty placeholder)
├── worbi-start           (entrypoint script)
├── worbi-stop            (stop script)
└── worbi-status          (status script)
```

**Must NOT include**: `.git/`, `node_modules/` (install fresh), test files, source TypeScript, dev dependencies, `.vscode/`

---

### Phase 4: Manager Contract Polish (Nice to Have)

**Goal**: The status script and Manager integration surface is reliable and informative.

#### 3.4.1 Status Script Health Check

**Recommendation**: `worbi_status.sh` should curl the backend health endpoint to determine `health=`:
```bash
health=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:8082/health 2>/dev/null)
if [ "$health" = "200" ]; then
  echo "health=ok"
else
  echo "health=failed"
  health="failed"
fi
```

**Files**: Module repo `scripts/worbi_status.sh`

#### 3.4.2 Version Detection

**Recommendation**: `worbi_status.sh` should read the installed version from a file in the install directory (e.g., `~/worbi/VERSION`), not rely on the manifest version.

**Files**: Module repo `scripts/worbi_status.sh`, include `VERSION` file in archive

#### 3.4.3 Update Available Indicator

**Future**: Once the Manager supports update detection, `worbi_status.sh` could output:
```
update_available=true
latest_version=6.2.52
```

---

### Phase 5: Feature Gaps (Backlog)

These don't block Manager integration but affect user experience:

| Feature | Impact | Effort |
|---------|--------|--------|
| LLM connection status indicator | Users can't tell if LLM backend is reachable | Medium |
| Chat history persistence | Conversations lost on refresh | Medium |
| Settings persistence across restarts | Low if using file-based settings already | Check current state |
| User profile management | Single-user vs multi-user | Design decision |

---

## 4. Risk Assessment

| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| Build script places `dist/` in wrong location | High | App won't serve frontend | Add verification step |
| User data loss during upgrade | Medium | Critical | Backup before overwrite |
| LLM config breaks on different machines | High | LLM features broken | Externalize config |
| Port conflict with another service | Medium | Server fails to start | Document port, allow env override |
| Archive too large | Low | Slow installs | Audit included files |
| `npm install` fails on target machine | Medium | Install fails | Log errors, don't suppress |

---

## 5. Files Involved by Phase

| Phase | Files to Modify |
|-------|----------------|
| 1. Portability | `server/src/index.js`, `server/src/config.js`, new `server/config.example.json` |
| 2. Build Pipeline | Root `package.json`, new verification script |
| 3. Packaging | Module repo `scripts/install_worbi.sh`, archive contents |
| 4. Manager Polish | Module repo `scripts/worbi_status.sh`, new `VERSION` file |
| 5. Feature Gaps | Client components, chat state management |

---

## 6. Suggested Implementation Order

Execute phases sequentially. Do not skip ahead — each phase builds on the previous one.

```
Phase 1 (Portability)  →  ~2 hours, 3 files, low risk
Phase 2 (Build Pipeline) →  ~1 hour, 2 files, low risk
Phase 3 (Packaging)     →  ~2 hours, install script + archive, medium risk
Phase 4 (Manager Polish) →  ~1 hour, status script, low risk
Phase 5 (Feature Gaps)  →  Backlog, estimate per feature
```

**Total estimated effort for Phases 1-4**: ~6 hours of focused work

---

## 7. What Was NOT Addressed

The following topics from RautysIdeas were **out of scope** for this handoff:

- Manager WPF UI design (covered in UI handoff docs)
- Cross-module integration (Brain ↔ WORBI data sharing)
- NymphsCore core architecture changes
- Registry channel system (stable/test/latest)
- External plugin interfaces (Blender, Unity)
- Paid plugin model

---

## 8. Reference Documents

These RautysIdeas files informed this handoff:

| Document | Relevance |
|----------|-----------|
| `WORBI_MANAGER_HANDOFF.md` | Primary — 8 improvement areas |
| `WORBI_GIT_MODULE_HOSTING_HANDOFF.md` | Module repo shape, `nymph.json` spec |
| `WORBI_GIT_TASK.md` | Task checklist, phases |
| `RAUTY_MODULE_LIFECYCLE_HANDOFF.md` | Current lifecycle state, blockers |
| `MODULAR_NYMPHSCORE_PLAN.md` | Platform vision, Nymph contract |
| `WORLD_BUILDER_SERVER_HANDOFF.md` | Server architecture reference |
| `WORLD_BUILDER_CLIENT_HANDOFF.md` | Client architecture reference |

---

## 9. Sign-off Checklist

Before declaring WORBI "Manager-ready":

- [ ] Phase 1 complete — WORBI runs on a fresh machine with zero config edits
- [ ] Phase 2 complete — `npm run build:prod` produces working artifact
- [ ] Phase 3 complete — install script is idempotent, preserves data on upgrade
- [ ] Phase 4 complete — status script accurately reports state
- [ ] Full lifecycle test: install → start → use → stop → update → verify data preserved → uninstall → reinstall
- [ ] CHANGELOG updated
- [ ] Module repo pushed with new version
- [ ] Registry updated if version changes

---

*End of handoff document.*