# Handoff: Filesystem-to-Database Migration

**Target Version:** v5.2.0  
**Priority:** High (architectural foundation for all future scalability)  
**Dependencies:** None (can be done independently)

---

## 1. Problem Statement

WORBI currently stores all persistent data as flat files on disk:

| Data Type | Current Storage | Current Path |
|-----------|----------------|-------------|
| User documents | HTML files | `server/data/users/<username>/workspace/` |
| Uploaded images | Binary files | `server/data/users/<username>/assets/images/` |
| User accounts | JSON file | `server/src/data/users.json` |
| User settings | JSON files | `server/data/user-settings/<username>-settings.json` |
| Tag registry | JSON file per directory | `<workspaceDir>/.wbi-meta.json` |
| File metadata | JSON sidecar | `<sameDir>/.<filename>.meta.json` |

**Consequences:**
- **No concurrency** — Two requests writing the same file race each other
- **No transactional integrity** — A crash mid-write leaves corrupted state
- **Full-scan queries** — `searchWorkspace()` and `getFilesByTag()` walk the entire directory tree reading every file line-by-line (O(n) time, O(n) I/O)
- **No relational querying** — "Show me all files tagged 'character' that reference files tagged 'location'" requires N+1 file reads
- **No indexing** — Every operation is a linear scan
- **No referential integrity** — Tag references can point to deleted files

---

## 2. Recommended Solution: SQLite

Use **SQLite** (via the `better-sqlite3` npm package) as the primary data store.

### 2.1 Justification

| Factor | SQLite | PostgreSQL | Filesystem (current) |
|--------|--------|------------|---------------------|
| Setup complexity | Zero (single file) | Requires running server | Zero |
| WORBI's deployment model | Single-user, local | Overkill | Current |
| Concurrency | WAL mode handles reads | Excellent | None |
| Transactional | Yes (ACID) | Yes (ACID) | No |
| Query power | SQL | SQL | grep/fs |
| Migration path | Simple | Complex | N/A |
| Backup | Copy one file | pg_dump | Copy directory |

SQLite matches WORBI's single-user, locally-deployed nature perfectly while solving every architectural problem. The database file should live at `server/data/worbi.db`.

---

## 3. Database Schema

### 3.1 Table: `users`

Stores authentication credentials. Replaces `server/src/data/users.json`.

| Column | Type | Constraints | Notes |
|--------|------|------------|-------|
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | Internal user ID |
| `username` | TEXT | UNIQUE NOT NULL | Login username |
| `password_hash` | TEXT | NOT NULL | bcrypt hash (keep existing hashing) |
| `created_at` | TEXT | NOT NULL DEFAULT (datetime('now')) | ISO 8601 timestamp |
| `updated_at` | TEXT | NOT NULL DEFAULT (datetime('now')) | ISO 8601 timestamp |

- Add an index on `username` for login lookups.
- Existing users in `users.json` must be migrated with their current bcrypt hashes intact.

### 3.2 Table: `user_settings`

Stores per-user LLM configuration and tool permissions. Replaces `server/data/user-settings/<username>-settings.json`.

| Column | Type | Constraints | Notes |
|--------|------|------------|-------|
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | |
| `user_id` | INTEGER | NOT NULL REFERENCES users(id) ON DELETE CASCADE | Foreign key to users |
| `server_type` | TEXT | NOT NULL DEFAULT 'lm-studio' | |
| `base_url` | TEXT | NOT NULL DEFAULT 'http://localhost:1234/v1' | |
| `api_key` | TEXT | NOT NULL DEFAULT '' | |
| `model_name` | TEXT | NOT NULL DEFAULT '' | |
| `max_tokens` | INTEGER | NOT NULL DEFAULT 4096 | |
| `temperature` | REAL | NOT NULL DEFAULT 0.7 | |
| `top_p` | REAL | NOT NULL DEFAULT 1.0 | |
| `top_k` | INTEGER | NOT NULL DEFAULT 50 | |
| `frequency_penalty` | REAL | NOT NULL DEFAULT 0.0 | |
| `presence_penalty` | REAL | NOT NULL DEFAULT 0.0 | |
| `stop_sequences` | TEXT | NOT NULL DEFAULT '' | |
| `seed` | INTEGER | NOT NULL DEFAULT 0 | |
| `tool_web_search` | INTEGER | NOT NULL DEFAULT 1 | Boolean (0/1) |
| `tool_file_access_level` | TEXT | NOT NULL DEFAULT 'read' | 'none'/'read'/'readwrite'/'full' |
| `tool_allow_create` | INTEGER | NOT NULL DEFAULT 0 | Boolean |
| `tool_allow_edit` | INTEGER | NOT NULL DEFAULT 0 | Boolean |
| `tool_allow_delete` | INTEGER | NOT NULL DEFAULT 0 | Boolean |
| `tool_allow_rename` | INTEGER | NOT NULL DEFAULT 0 | Boolean |
| `tool_max_search_results` | INTEGER | NOT NULL DEFAULT 5 | 1–20 |
| `created_at` | TEXT | NOT NULL DEFAULT (datetime('now')) | |
| `updated_at` | TEXT | NOT NULL DEFAULT (datetime('now')) | |

- Add a UNIQUE constraint on `user_id` (one settings row per user).
- Flatten the nested `toolPermissions` JSON object into individual columns for queryability.

### 3.3 Table: `files`

Stores document metadata. Documents themselves remain on filesystem for now (see Section 6 for phased approach), but metadata and content indexing moves to the database.

| Column | Type | Constraints | Notes |
|--------|------|------------|-------|
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | |
| `user_id` | INTEGER | NOT NULL REFERENCES users(id) ON DELETE CASCADE | |
| `name` | TEXT | NOT NULL | Filename with extension |
| `relative_path` | TEXT | NOT NULL | Path relative to user's workspace root |
| `type` | TEXT | NOT NULL DEFAULT 'file' | 'file' or 'folder' |
| `size_bytes` | INTEGER | | NULL for folders |
| `content_text` | TEXT | | Plain text extraction for full-text search |
| `hero_image_path` | TEXT | | Relative path to hero image asset |
| `created_at` | TEXT | NOT NULL DEFAULT (datetime('now')) | |
| `updated_at` | TEXT | NOT NULL DEFAULT (datetime('now')) | |
| `modified` | TEXT | | Filesystem mtime, for sync |

- Add a UNIQUE constraint on `(user_id, relative_path)`.
- Add a FULLTEXT INDEX (FTS5 virtual table) on `content_text` and `name` for instant full-text search.
- Add an index on `user_id` for user-scoped queries.
- The `content_text` column stores the plain text extraction of the HTML document to enable SQL full-text search without needing to read every file.

### 3.4 Table: `tags`

Stores the global tag registry. Replaces the JSON structure in `.wbi-meta.json`.

| Column | Type | Constraints | Notes |
|--------|------|------------|-------|
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | |
| `user_id` | INTEGER | NOT NULL REFERENCES users(id) ON DELETE CASCADE | |
| `name` | TEXT | NOT NULL | Tag display name |
| `color` | TEXT | NOT NULL DEFAULT '#6366f1' | Hex color for UI |
| `description` | TEXT | | Optional description |
| `created_at` | TEXT | NOT NULL DEFAULT (datetime('now')) | |
| `updated_at` | TEXT | NOT NULL DEFAULT (datetime('now')) | |

- Add a UNIQUE constraint on `(user_id, name)`.
- Add an index on `user_id`.

### 3.5 Table: `file_tags`

Junction table linking files to tags. Many-to-many.

| Column | Type | Constraints | Notes |
|--------|------|------------|-------|
| `file_id` | INTEGER | NOT NULL REFERENCES files(id) ON DELETE CASCADE | |
| `tag_id` | INTEGER | NOT NULL REFERENCES tags(id) ON DELETE CASCADE | |

- PRIMARY KEY on `(file_id, tag_id)`.
- Add indexes on `file_id` and `tag_id` for bidirectional lookups.

### 3.6 Table: `tag_relationships`

Stores relationships between tags (e.g., "character" relates to "plot").

| Column | Type | Constraints | Notes |
|--------|------|------------|-------|
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | |
| `tag_id_1` | INTEGER | NOT NULL REFERENCES tags(id) ON DELETE CASCADE | |
| `tag_id_2` | INTEGER | NOT NULL REFERENCES tags(id) ON DELETE CASCADE | |
| `relationship_type` | TEXT | NOT NULL | e.g., 'related', 'parent', 'child' |
| `created_at` | TEXT | NOT NULL DEFAULT (datetime('now')) | |

- Add a UNIQUE constraint on `(tag_id_1, tag_id_2, relationship_type)` to prevent duplicates.
- Add indexes on both tag ID columns.

### 3.7 Table: `images`

Tracks uploaded images. Replaces loose files in `assets/images/`.

| Column | Type | Constraints | Notes |
|--------|------|------------|-------|
| `id` | INTEGER | PRIMARY KEY AUTOINCREMENT | |
| `user_id` | INTEGER | NOT NULL REFERENCES users(id) ON DELETE CASCADE | |
| `filename` | TEXT | NOT NULL | Unique generated filename |
| `original_name` | TEXT | NOT NULL | Original upload filename |
| `relative_path` | TEXT | NOT NULL | Path relative to user's assets dir |
| `mime_type` | TEXT | NOT NULL | e.g., 'image/png' |
| `size_bytes` | INTEGER | NOT NULL | |
| `folder_path` | TEXT | NOT NULL DEFAULT '' | Subdirectory within assets |
| `created_at` | TEXT | NOT NULL DEFAULT (datetime('now')) | |

- Add a UNIQUE constraint on `(user_id, relative_path)`.

### 3.8 FTS5 Virtual Table: `files_fts`

For full-text search across document content.

- Create as: `CREATE VIRTUAL TABLE files_fts USING fts5(name, content_text, content='files', content_rowid='id')`
- Use triggers to keep FTS in sync with the `files` table on INSERT, UPDATE, DELETE.
- This replaces the `searchWorkspace()` function's line-by-line file reading entirely.

---

## 4. Implementation Plan

### Phase 1: Database Infrastructure

1. Add `better-sqlite3` to `server/package.json` dependencies.
2. Create a new file `server/src/database.js` containing:
   - A `getDatabase()` function that opens (or creates) the SQLite file at `server/data/worbi.db`
   - Use WAL journal mode for concurrent read performance
   - Enable foreign keys: `PRAGMA foreign_keys = ON`
   - A module-level singleton pattern so the database connection is reused
3. Create `server/src/database/migrate.js` containing:
   - A `runMigrations()` function that executes schema creation
   - Use a `schema_version` table (single row with version integer) for migration tracking
   - Each migration step is idempotent (CREATE TABLE IF NOT EXISTS)
   - Call `runMigrations()` from `server/src/index.js` during server startup, before routes are mounted
4. Create a migration function that reads the current schema version and applies any pending migrations sequentially. Migration steps: v0→v1 creates all tables above. Future schema changes add rows to this function.

### Phase 2: Data Migration Script

1. Create `server/src/database/seed.js` containing a `migrateExistingData()` function:
   - Read `server/src/data/users.json`, insert each user into `users` table
   - For each user, read their settings JSON file, insert into `user_settings`
   - For each user, walk their workspace directory, insert file/folder metadata into `files`
   - Extract plain text from HTML files (strip tags, decode entities) for the `content_text` column
   - Walk `assets/images/` directories, insert image metadata into `images`
   - Parse `.wbi-meta.json` files: insert tags into `tags`, file-tag associations into `file_tags`
   - Parse tag relationships from `.wbi-meta.json` into `tag_relationships`
2. This script must be idempotent — running it twice produces no duplicates (use INSERT OR IGNORE).
3. Run this script once after Phase 1 migrations complete, or provide a CLI command like `npm run db:seed`.
4. Keep all existing files on disk — do NOT delete the filesystem copies yet (see Phase 4).

### Phase 3: Service Layer Refactor

Rewrite each service to use the database as the source of truth. The filesystem remains as secondary storage for actual file content (HTML documents, image binaries).

**3a. `authService.js` changes:**
- `authenticateUser(username, password)`: Query `users` table instead of reading `users.json`
- `createUser(username, password)`: INSERT into `users` table instead of writing `users.json`
- `getUserWorkspaceDir()` and `getUserAssetsDir()`: Keep these — they still need to return filesystem paths for actual file storage. But add a `getUserId(username)` helper that queries the DB.
- Remove all `fs.readFileSync`/`fs.writeFileSync` calls to `users.json`.

**3b. `config.js` changes:**
- `loadUserSettings(username)`: Query `user_settings` table instead of reading JSON file
- `saveUserSettings(username, settings)`: UPSERT into `user_settings` table instead of writing JSON file
- Flatten the `toolPermissions` object to individual columns on read/write
- Remove the `ensureSettingsDir()` function (no longer needed)

**3c. `fileService.js` changes — metadata operations read from DB:**
- `listDirectory()`: Query `files` table WHERE `relative_path` starts with dirPath and depth is exactly one level deeper
- File metadata (`size`, `modified`) from DB instead of `fs.statSync`
- `readFile()` and `writeFile()`: Keep reading/writing file content to disk, but update the `files` table `content_text` and `updated_at` on every write. Extract plain text from HTML before storing in `content_text`.
- `createFolder()`: INSERT into `files` table with `type='folder'` AND create the directory on disk
- `deleteItem()`: DELETE from `files` table (cascade deletes file_tags) AND remove from disk
- `renameItem()`: UPDATE `files.relative_path` AND `files.name` AND rename on disk. Also update any `files.relative_path` rows that are children of a renamed folder.
- `copyItem()` and `moveItem()`: Create new `files` row(s) AND perform filesystem operations
- `saveImage()` and `saveImageFromBuffer()`: INSERT into `images` table AND save to disk
- `saveUploadedFile()`: INSERT into `files` table AND save to disk

**3d. `fileService.js` changes — search:**
- `searchWorkspace()`: Replace the recursive directory walk with an FTS5 query:
  - Search `files_fts` for matching content or name
  - Return results from the database, with snippet extraction handled by FTS5's `snippet()` function
  - This reduces search from O(n) file reads to a single indexed query
  - Keep the same return shape (`{ results, total }`) for API compatibility

**3e. `tagService.js` changes:**
- Rewrite entirely to use the `tags`, `file_tags`, and `tag_relationships` tables
- All CRUD operations become SQL queries
- `getFilesByTag()`: JOIN `file_tags` with `files` — instantaneous instead of walking directory trees
- `getFileRelationships()`: JOIN-based query instead of parsing JSON sidecar files
- Remove all `.wbi-meta.json` file I/O
- Keep the same exported function signatures for API compatibility

**3f. API routes should require no changes** — the service layer absorbs the database migration transparently.

### Phase 4: Phased Filesystem Deprecation

Do NOT delete filesystem files immediately. Instead, implement a hybrid period:

1. **Write-both mode**: On write operations, update the database AND write to filesystem (current behavior). On read operations, prefer the database but fall back to filesystem if the DB row is missing.
2. **Add a DB consistency check**: Create a `GET /api/admin/db-health` endpoint (admin-only) that compares DB records against filesystem files and reports discrepancies.
3. **After 2–4 weeks of stable operation**, add a migration that deletes `.wbi-meta.json` files (metadata is now in DB). Keep HTML files and images on disk (they are the actual content, not metadata).
4. **Mark the old functions as deprecated** with comments pointing to their DB-based replacements. Remove them in a future version.

---

## 5. Full-Text Search Upgrade

### 5.1 FTS5 Query Implementation

The current `searchWorkspace()` in `fileService.js` does:
- Recursively walk every directory
- Check every filename (case-insensitive includes)
- Open every text file, read line by line, check each line
- Return up to `limit` results

Replace with:

1. On every file save (`writeFile()`), extract plain text from the HTML content (strip all tags, decode HTML entities like `&`, `<`, normalize whitespace) and store it in `files.content_text`.
2. Create an FTS5 virtual table `files_fts` with columns `name` and `content_text`, content-synced to the `files` table.
3. Keep FTS5 in sync via triggers:
   - AFTER INSERT on `files`: INSERT into `files_fts`
   - AFTER UPDATE on `files`: UPDATE `files_fts` (or delete+insert)
   - AFTER DELETE on `files`: DELETE from `files_fts`
4. `searchWorkspace()` becomes: `SELECT name, relative_path, snippet(files_fts, 2, '<mark>', '</mark>', '...', 32) as snippet FROM files_fts WHERE files_fts MATCH ? ORDER BY rank LIMIT ?`
5. Parse the snippet back into the existing `{ line, context }` match format for API compatibility.

### 5.2 Content Text Extraction

When extracting plain text from HTML for FTS indexing:
- Strip all `<script>`, `<style>`, `<svg>` elements completely
- Replace block-level elements (`<p>`, `<div>`, `<h1>`–`<h6>`, `<li>`, `<br>`) with newlines
- Strip all remaining tags
- Decode HTML entities (`&` → `&`, `<` → `<`, `&#39;` → `'`, etc.)
- Collapse multiple whitespace/newlines into single spaces
- Trim to some reasonable limit (e.g., 1MB) for the FTS column

---

## 6. Transaction Strategy

All write operations that touch multiple tables must use SQLite transactions:

- **File creation**: INSERT into `files` + write to disk → wrap in transaction. If disk write fails, rollback DB.
- **Tag operations**: INSERT into `tags` + INSERT into `file_tags` → single transaction
- **Delete operations**: DELETE from `files` (cascade deletes `file_tags`) + remove from disk → transaction
- **Rename folder**: UPDATE all affected `files` rows + rename on disk → transaction

Use `db.transaction(() => { ... })()` (better-sqlite3's synchronous transaction API). If any operation throws, the transaction rolls back automatically.

---

## 7. Files to Create

| File | Purpose |
|------|---------|
| `server/src/database.js` | Database connection singleton, WAL mode, foreign keys |
| `server/src/database/migrate.js` | Schema creation and versioned migrations |
| `server/src/database/seed.js` | One-time migration from filesystem to database |

## 8. Files to Modify

| File | Changes |
|------|---------|
| `server/package.json` | Add `better-sqlite3` dependency |
| `server/src/index.js` | Import and call `runMigrations()` during startup |
| `server/src/services/authService.js` | Replace JSON file I/O with DB queries |
| `server/src/config.js` | Replace settings JSON file I/O with DB queries, flatten toolPermissions |
| `server/src/services/fileService.js` | Replace directory walking with DB queries, replace search with FTS5 |
| `server/src/services/tagService.js` | Complete rewrite to use DB tables |

## 9. Files to Eventually Remove (Phase 4)

| File | Reason |
|------|--------|
| `server/src/data/users.json` | Replaced by `users` table |
| `server/data/user-settings/*.json` | Replaced by `user_settings` table |
| `<workspace>/.wbi-meta.json` (all instances) | Replaced by `tags` + `file_tags` + `tag_relationships` tables |

## 10. Verification Checklist

- [ ] Server starts and connects to SQLite without errors
- [ ] Existing user can log in with same credentials
- [ ] After seeding, all files appear in file explorer with correct paths and sizes
- [ ] Creating a new file inserts a `files` row
- [ ] Full-text search returns results faster than the old `searchWorkspace()`
- [ ] Tag operations (create, assign, filter) work correctly
- [ ] Tag relationships display in Information Panel
- [ ] User settings persist across server restarts
- [ ] Delete cascade works: deleting a file removes its tag associations
- [ ] Delete cascade works: deleting a tag removes its file associations
- [ ] Transaction rollback: if disk write fails, DB state is unchanged
- [ ] WAL mode allows concurrent reads during a write
- [ ] Database file is not corrupted after killing the server mid-write

## 11. Rollback Plan

If the migration fails:
1. The filesystem files are NOT deleted during Phase 1–3
2. The existing code path reads from filesystem; the DB path is added alongside it
3. Use a feature flag or environment variable to toggle between old (filesystem) and new (database) code paths during testing
4. Only remove the filesystem code path after Phase 4 verification is complete