# Handoff: Document Statistics Panel

**Target Version:** v5.3.0
**Priority:** Low (small feature, quick win)
**Dependencies:** None

---

## 1. Problem Statement

Writers often want to know basic statistics about their document: word count, character count, estimated reading time, and when it was last saved. Currently, WORBI provides none of this information. A small statistics panel gives writers immediate feedback on their progress.

---

## 2. Target Behavior

Add a collapsible "Statistics" section to the Information Panel (below the Images/Notes section) or display stats inline in the StatusBar:

**Option A — Information Panel section:**
```
┌─────────────────────────────────┐
│  Document Statistics            │
├─────────────────────────────────┤
│  Words:           1,247         │
│  Characters:       7,482        │
│  Characters (no spaces): 6,235  │
│  Paragraphs:          42        │
│  Headings:            12        │
│  Images:               3        │
│  Wiki Links:           5        │
│  Reading Time:      ~5 min      │
│  Last Saved:   2:31 PM today    │
└─────────────────────────────────┘
```

**Option B — StatusBar (simpler):**
```
┌─────────────────────────────────────────────────┐
│  Words: 1,247  ● Saved  2:31 PM                │
└─────────────────────────────────────────────────┘
```

**Recommendation: Both.** The StatusBar shows word count + save status (always visible). The Information Panel section shows the full breakdown (collapsible, for when the user wants detail).

---

## 3. Implementation

### 3.1 Statistics Computation

All statistics are computed client-side from the TipTap editor state:

```typescript
// In client/src/utils/documentStats.ts

export interface DocumentStats {
  wordCount: number;
  characterCount: number;
  characterCountNoSpaces: number;
  paragraphCount: number;
  headingCount: number;
  imageCount: number;
  wikiLinkCount: number;
  readingTimeMinutes: number;
}

export function computeDocumentStats(editor: Editor): DocumentStats {
  const text = editor.state.doc.textContent;
  const html = editor.getHTML();
  
  const wordCount = text.trim() ? text.trim().split(/\s+/).length : 0;
  const characterCount = text.length;
  const characterCountNoSpaces = text.replace(/\s/g, '').length;
  
  // Count paragraphs (ProseMirror paragraph nodes)
  let paragraphCount = 0;
  let headingCount = 0;
  editor.state.doc.descendants((node) => {
    if (node.type.name === 'paragraph') paragraphCount++;
    if (node.type.name === 'heading') headingCount++;
  });
  
  // Count images
  const imageMatches = html.match(/<img[^>]*>/g);
  const imageCount = imageMatches ? imageMatches.length : 0;
  
  // Count wiki links
  const wikiLinkMatches = html.match(/data-wiki-link/g);
  const wikiLinkCount = wikiLinkMatches ? wikiLinkMatches.length : 0;
  
  // Reading time (average 200 words per minute)
  const readingTimeMinutes = Math.max(1, Math.ceil(wordCount / 200));
  
  return {
    wordCount,
    characterCount,
    characterCountNoSpaces,
    paragraphCount,
    headingCount,
    imageCount,
    wikiLinkCount,
    readingTimeMinutes,
  };
}
```

### 3.2 Statistics Panel Component

New component: `client/src/components/DocumentStatistics.tsx`

```typescript
// Receives the editor instance and computes stats
// Uses the same collapsible section pattern as other Information Panel sections
// Resizable vertically (like other Info Panel sections)
```

### 3.3 StatusBar Integration

Modify `StatusBar.tsx` to show word count + save status:

```
Words: 1,247  ● Saved
```

- Word count updates on editor content change (debounced to every 2 seconds to avoid excessive recomputation)
- Save status: green dot + "Saved" when clean, amber dot + "Unsaved" when dirty

### 3.4 Reading Time Formula

Standard formula: words / 200 words per minute, rounded up:
- 0–200 words → 1 min
- 201–400 words → 2 min
- 1,247 words → ~7 min

---

## 4. Files to Create

| File | Purpose |
|------|---------|
| `client/src/utils/documentStats.ts` | Statistics computation utilities |
| `client/src/components/DocumentStatistics.tsx` | Statistics display component for Information Panel |

## 5. Files to Modify

| File | Changes |
|------|---------|
| `client/src/components/InformationPanel.tsx` | Add Statistics section (below Images/Notes) |
| `client/src/components/StatusBar.tsx` | Add word count and save status display |
| `client/src/components/DocumentEditor.tsx` | Pass editor ref or content change events to update stats |

---

## 6. Edge Cases

| Scenario | Handling |
|----------|----------|
| **Empty document** | Show all zeros. Reading time: "< 1 min" |
| **Very large document (>100K words)** | Stats computation is O(n) on document size. For extreme cases, debounce updates |
| **Margin editor stats** | Compute stats for main + margin combined, or show separate stats for each column |
| **Document with only images** | Word count 0, image count > 0. Reading time: "< 1 min" |
| **Stats for non-active tabs** | Only compute stats for the active document (saves CPU) |
| **Selection stats** | Future: show stats for selected text only (e.g., "Selected: 42 words") |

---

## 7. Verification Checklist

- [ ] Word count updates as text is typed
- [ ] Character count matches actual document length
- [ ] Character count (no spaces) excludes whitespace
- [ ] Paragraph count increments with new paragraphs
- [ ] Heading count includes all heading levels (h1–h6)
- [ ] Image count matches `<img>` tags in the document
- [ ] Wiki link count matches `[[...]]` references (if wiki links are implemented)
- [ ] Reading time is accurate (words / 200, rounded up)
- [ ] Statistics section is collapsible in the Information Panel
- [ ] StatusBar shows word count and save status
- [ ] Empty document shows zeros with "< 1 min" reading time

---

## 8. Future Enhancements

- **Selection stats:** "Selected: 142 words, 3 paragraphs"
- **Session stats:** "Words written this session: 847"
- **Readability scores:** Flesch-Kincaid, Gunning Fog index
- **Character/sentence/paragraph averages:** Average words per sentence, sentences per paragraph
- **Writing goals:** Set a daily word count goal with a progress bar