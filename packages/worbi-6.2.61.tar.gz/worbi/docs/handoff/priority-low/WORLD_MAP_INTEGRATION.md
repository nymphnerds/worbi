# Handoff: World Map Integration

**Target Version:** v5.6.0
**Priority:** Low (ambitious feature, large scope)
**Dependencies:**
- BLOB_URL_BRIDGE_FIX.md (signed image proxy for map images)
- Z-Image / Nymphs2D2 backend (for AI-generated map images, optional)
- CROSS_DOCUMENT_WIKILINKS.md (markers link to documents)

---

## 1. Problem Statement

World-building often revolves around geography. Writers create locations with detailed descriptions, but have no way to place them on a map. A World Map feature would allow users to upload (or generate) a map image, place clickable markers on it, and link each marker to its corresponding location document. This transforms WORBI from a text-only tool into a spatial world-building platform.

---

## 2. Target Behavior

A new Activity Bar panel with a map icon (`Map` from lucide-react) that shows an interactive map viewer:

```
┌─────────────────────────────────────┐
│  World Map                          │
├─────────────────────────────────────┤
│  [Map: Main Continent ▾]  [+]      │
│                                     │
│  ┌─────────────────────────────┐   │
│  │                             │   │
│  │    📍 Goblin Mines          │   │
│  │          📍 Underdark City  │   │
│  │   📍 Elven Forest           │   │
│  │                 📍 Dragon   │   │
│  │                   Peak      │   │
│  │        📍 Human Kingdom  🌊 │   │
│  │     🌊               🌊     │   │
│  └─────────────────────────────┘   │
│                                     │
│  Click a marker to open document    │
│  Right-click to add new marker      │
│  Drag markers to reposition         │
│  Pinch/scroll to zoom               │
└─────────────────────────────────────┘
```

- **Map image:** Uploaded/pasted into a dedicated `/World/Maps/` folder
- **Markers:** Clickable pins positioned by x/y coordinates (0–100% of map dimensions)
- **Marker → document link:** Each marker is associated with a workspace document
- **Marker popover:** Hovering shows document name, first few lines, and tags
- **Multiple maps:** Support for multiple map images (region maps, city maps, dungeon maps)
- **Base map generation:** Optional AI generation via Z-Image/Nymphs2D2

---

## 3. Data Model

### 3.1 Map Metadata

Stored alongside the map image as a `.map.json` file:

```json
{
  "version": 1,
  "mapImage": "/World/Maps/Main Continent.png",
  "markers": [
    {
      "id": "a1b2c3d4",
      "name": "Goblin Mines",
      "x": 0.35,
      "y": 0.22,
      "documentPath": "/World/Goblin Mines.html",
      "color": "#f59e0b",
      "icon": "cave",
      "description": "Deep mining tunnels beneath the mountains",
      "createdAt": "2026-05-01T14:30:00Z",
      "updatedAt": "2026-05-01T14:30:00Z"
    },
    {
      "id": "e5f6g7h8",
      "name": "Elven Forest",
      "x": 0.15,
      "y": 0.45,
      "documentPath": "/World/Elven Forest.html",
      "color": "#22c55e",
      "icon": "forest",
      "description": "Ancient woodland realm of the elves",
      "createdAt": "2026-05-01T13:00:00Z",
      "updatedAt": "2026-05-01T13:00:00Z"
    }
  ],
  "createdAt": "2026-05-01T12:00:00Z",
  "updatedAt": "2026-05-01T14:30:00Z"
}
```

**Coordinates:** Percentage-based (0.0 to 1.0) so markers scale with any map display size.

### 3.2 Marker Icons

| Icon | Use Case | Lucide Icon |
|------|----------|-------------|
| 🏰 | City / Settlement | `Castle` |
| ⛰️ | Mountain / Peak | `Mountain` |
| 🌲 | Forest / Woods | `TreePine` |
| 🏛️ | Ruin / Temple | `Landmark` |
| ⛏️ | Mine / Cave / Dungeon | `Pickaxe` |
| 🌊 | Ocean / Lake / River | `Waves` |
| 🏘️ | Village / Hamlet | `Home` |
| 🗼 | Tower / Fortress | `TowerControl` |
| ⚔️ | Battle Site | `Swords` |
| ⭐ | Point of Interest | `Star` |
| 📍 | Default / Unknown | `MapPin` |

---

## 4. Map Viewer Component

New component: `client/src/components/WorldMapViewer.tsx`

### 4.1 Map Display

The map image renders inside a container with `overflow: hidden`. The user can:

| Action | Implementation |
|--------|---------------|
| **Pan** | `mousedown` + drag → translate the image |
| **Zoom** | Mouse wheel → CSS `transform: scale()` |
| **Fit to view** | Button to reset pan/zoom to fit the map in the container |
| **Full resolution** | Button to toggle 1:1 pixel-perfect view |

Uses a combination of `transform: translate(x, y) scale(s)` on the map `<img>` element.

### 4.2 Markers

Markers are absolutely-positioned `<div>` elements overlaid on the map. Their position is calculated from the stored percentage coordinates:

```typescript
const markerStyle = {
  left: `${marker.x * 100}%`,
  top: `${marker.y * 100}%`,
  transform: `translate(-50%, -50%) scale(${1 / zoom})`, // counter-scale so markers stay same size
};
```

**Clicking a marker:** Opens the linked document in a new tab.

**Hovering a marker:** Shows a popover:

```
┌──────────────────────────┐
│ 🏰 Human Kingdom         │
│ /World/Human Kingdom.html│
│                          │
│ The Human Kingdom is the │
│ largest realm in the...  │
│                          │
│ Tags: human, kingdom     │
│ [Open Document]          │
└──────────────────────────┘
```

**Right-click on map:** Opens a context menu to add a new marker:
- "Add Marker" → opens a small form to name the marker and optionally link a document
- If no document is linked yet, the marker appears as a "draft" (hollow pin with dashed border)

**Dragging markers:** Click and drag an existing marker to reposition it. Saves the new position to the `.map.json` file.

### 4.3 Map Selector

A dropdown at the top of the panel lists all available maps. Maps are `.png`, `.jpg`, or `.webp` images found in `/World/Maps/` (or loaded from `assets/images/`).

A "+" button lets the user:
1. Upload a new map image
2. Generate a map with AI (if Z-Image is available)
3. Create a "scratch" map (blank canvas for free-form placement)

---

## 5. API Endpoints

### 5.1 Map Data

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| `GET` | `/api/maps` | Yes | List all maps |
| `GET` | `/api/maps/:id` | Yes | Get map data (image URL + markers) |
| `POST` | `/api/maps` | Yes | Create a new map `{ name, imagePath }` |
| `PUT` | `/api/maps/:id/markers` | Yes | Update all markers for a map |
| `POST` | `/api/maps/:id/markers` | Yes | Add a single marker |
| `PUT` | `/api/maps/:id/markers/:markerId` | Yes | Update a marker (position, name, etc.) |
| `DELETE` | `/api/maps/:id/markers/:markerId` | Yes | Delete a marker |
| `DELETE` | `/api/maps/:id` | Yes | Delete a map and its markers |

### 5.2 Example: Add Marker

`POST /api/maps/a1b2c3d4/markers`

```json
{
  "name": "Goblin Mines",
  "x": 0.35,
  "y": 0.22,
  "documentPath": "/World/Goblin Mines.html",
  "icon": "cave",
  "color": "#f59e0b"
}
```

### 5.3 Map Image Storage

Map images are stored in the user's `assets/images/` directory. Map metadata (`.map.json`) is stored alongside the image in the same directory, or in `/World/Maps/` as a dedicated folder.

---

## 6. Integration with Other Features

### 6.1 With Wiki Links
Documents linked from map markers can have wiki links back to other documents. The map serves as a spatial entry point into the knowledge base.

### 6.2 With Relationship Graph
Map markers could optionally show as nodes in the Relationship Graph, positioned according to their map coordinates rather than force-directed layout. This creates a "geographic mode" toggle for the graph.

### 6.3 With Z-Image Generation
- "Generate Map" button uses the `POST /api/llm/generate-image` endpoint with a prompt like: "fantasy world map, top-down view, parchment style, mountains, forests, rivers, medieval"
- The generated map is saved to `/World/Maps/` and opened in the map viewer
- Users can also generate region-specific maps: "close-up map of the goblin mountain region"

### 6.4 With Templates
A "World Map" template pre-populates the `/World/Maps/` folder and includes a README document explaining how to use the map feature.

---

## 7. Files to Create

| File | Purpose |
|------|---------|
| `server/src/services/mapService.js` | Map CRUD, marker management, `.map.json` read/write |
| `server/src/routes/maps.js` | Map API endpoints |
| `client/src/components/WorldMapViewer.tsx` | Interactive map with zoom/pan and markers |
| `client/src/components/MapMarkerForm.tsx` | Form for adding/editing markers |
| `client/src/components/MapSelector.tsx` | Dropdown to switch between maps |
| `client/src/hooks/useMaps.ts` | Map data fetching and state |

## 8. Files to Modify

| File | Changes |
|------|---------|
| `server/src/index.js` | Register `/api/maps` routes |
| `client/src/components/ActivityBar.tsx` | Add `Map` icon for Map activity |
| `client/src/App.tsx` | Add `'map'` to ActivityType, render `<WorldMapViewer>` in left panel |
| `client/src/services/api.ts` | Add map API functions and types |
| `client/src/styles/globals.css` | Add map viewer and marker styles |

---

## 9. Edge Cases

| Scenario | Handling |
|----------|----------|
| **Very large map image (>10MB)** | Resize or compress on upload. Limit to 4096×4096px |
| **Map image deleted** | Markers remain in `.map.json` but the map viewer shows "Map image not found" |
| **Linked document deleted** | Marker still appears but shows "Document not found" on hover |
| **Marker outside visible area** | Marker still exists but may not be visible. "List all markers" view shows them |
| **Duplicate marker names** | Allowed — disambiguated by position and document link |
| **Very many markers (100+)** | Show markers at lower zoom levels, cluster nearby markers at high zoom |
| **Map without markers** | Show empty state: "Right-click on the map to add your first marker" |
| **Concurrent marker edits** | Last write wins. Marker updates are atomic per-marker |
| **Panning outside map bounds** | Clamp panning so at least 25% of the map is always visible |

---

## 10. Verification Checklist

- [ ] Map icon appears in the Activity Bar
- [ ] Map Viewer renders uploaded map image
- [ ] Pan and zoom work with mouse
- [ ] "Fit to view" resets the view
- [ ] Right-click on map opens "Add Marker" context menu
- [ ] Markers render at correct positions
- [ ] Markers maintain consistent size during zoom
- [ ] Clicking a marker opens the linked document
- [ ] Hovering a marker shows popover with document info
- [ ] Dragging a marker repositions it
- [ ] Multiple maps can be switched via dropdown
- [ ] New map can be uploaded via "+" button
- [ ] Map + markers survive page reload
- [ ] Empty map shows helpful onboarding message
- [ ] Deleted document linked from marker shows "not found" state
- [ ] Marker form validates coordinate range (0.0–1.0)

---

## 11. Future Enhancements

- **Region maps:** Nest maps — a marker on the world map links to a detailed region map
- **Distance measurement:** Click two points to measure the distance between them (with a configurable scale: 1px = X miles)
- **Route drawing:** Draw paths between markers (e.g., trade routes, quest paths)
- **Fog of war:** Toggle visibility of map sections — reveal regions as the story progresses
- **Map layers:** Overlay multiple map images (e.g., political, geographic, climate layers)
- **Hex grid overlay:** Overlay a hexagonal grid for tabletop RPG campaign planning
- **Export map as image:** Render the map with markers as a single PNG for sharing
- **Collaborative marker editing:** Real-time collaborative marker placement (depends on multi-user support)