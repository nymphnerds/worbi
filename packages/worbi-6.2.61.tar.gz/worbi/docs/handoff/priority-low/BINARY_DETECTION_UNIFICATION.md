# Handoff: Binary File Detection Unification

**Target Version:** v5.2.0
**Priority:** Low (latent inconsistency — no known bugs, but a time bomb)
**Dependencies:** None (can be done independently)
**Note:** Section 11 specifies a test file (`binaryDetection.test.ts`). If writing that test, `TEST_SUITE_SETUP.md` must be completed first to have the Vitest infrastructure in place.

---

## 1. Problem Statement

WORBI has two completely different implementations for detecting whether a file is binary:

### 1.1 Extension-Based Detection in `fileService.js` (lines 367–378)

```javascript
const BINARY_EXTENSIONS = new Set([
  'jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'svg', 'ico',
  'pdf', 'zip', 'tar', 'gz', 'rar', '7z',
  'mp3', 'mp4', 'avi', 'mov', 'wmv',
  'exe', 'dll', 'so', 'dylib',
  'docx', 'xlsx', 'pptx',
]);

function isBinaryFile(filename) {
  const ext = path.extname(filename).toLowerCase().slice(1);
  return BINARY_EXTENSIONS.has(ext);
}
```

This is used by `searchWorkspace()` to skip binary files during content search.

### 1.2 Content-Based Detection in `toolService.js` (lines 43–51)

```javascript
function isBinary(filePath) {
  try {
    const chunk = fs.readFileSync(filePath, { encoding: 'latin1', length: 8192, flag: 'r' });
    const binaryPattern = /[\x00-\x08\x0E-\x1F]/;
    return binaryPattern.test(chunk);
  } catch {
    return true; // If we can't read it, treat as binary
  }
}
```

This is used by `readFile()` and `editFile()` in the AI tools to reject binary files.

### 1.3 Extension-Based Detection in `tagService.js` (added in v5.1.6)

The changelog for v5.1.6 mentions adding `BINARY_EXTENSIONS` set and `isScannableFile()` helper to `tagService.js`, mirroring the `fileService.js` approach. This means a THIRD copy of the binary extension list now exists.

---

## 2. The Inconsistency Problem

These two approaches can disagree:

| Scenario | Extension-based result | Content-based result | Actual |
|----------|----------------------|---------------------|--------|
| `.txt` file containing null bytes | "Not binary" | "Binary" | Binary (corrupted or binary misnamed) |
| `.png` file (valid image) | "Binary" | "Binary" | Binary (both agree) |
| `.dat` file containing plain text | "Not binary" | "Not binary" | Text (both agree) |
| `.bin` file actually a JPEG | "Not binary" | "Binary" | Binary (extension missed it) |
| Empty file with `.exe` extension | "Binary" | "Not binary" (empty = no null bytes) | Probably binary (extension says so) |

Currently, different parts of the codebase would make different decisions about the same file. If the AI tool `read_file` reads a `.bin` file that's actually a JPEG (passes the content check?), the content-based check might let it through if the first 8KB doesn't contain null bytes, while `searchWorkspace` would also let it through since `.bin` isn't in `BINARY_EXTENSIONS`.

While no bugs have been reported from this inconsistency, it creates a maintenance burden (three separate extension lists to keep in sync) and could cause surprising behavior.

---

## 3. Recommended Solution

Create a single, unified binary detection module and use it everywhere.

### 3.1 The Unified Approach

Use a **two-layer detection strategy**:

1. **Layer 1 (fast): Extension check** — If the extension is in a known-binary set, it's binary. This catches 95% of cases.
2. **Layer 2 (thorough): Content check** — If the extension is not in the known set, read the first 8KB and check for null bytes. This catches misnamed files and files with unknown extensions.

The unified function should work with both a filename (for the extension check) and a full path (for the content check).

### 3.2 Implementation

Create a single module `server/src/services/binaryDetection.js` that exports:

**`BINARY_EXTENSIONS` set:**
- The combined set of all extensions from both existing lists
- Add any extensions that were only in one list but not the other
- Specifically: include everything from `fileService.js` + any additional from `tagService.js`

**`isBinaryFile(filename)` — extension-only check:**
- Takes a filename (string)
- Extracts the extension
- Checks against `BINARY_EXTENSIONS`
- Returns boolean
- Used by: `searchWorkspace()` (where reading file content just for a binary check would be wasteful since search already skips by extension)

**`isBinaryContent(filePath)` — content-based check:**
- Takes a full file path
- Reads the first 8KB in `latin1` encoding
- Checks for control characters using the existing null-byte pattern
- Returns boolean
- Gracefully handles errors: if the file cannot be read, returns true (treat as binary for safety)
- Used by: AI tool `read_file` and `edit_file` (where reading the file is necessary anyway, so the content check adds safety)

**`isBinary(filePathOrName, options?)` — comprehensive check:**
- If `options.full` is true or not provided:
  - Check extension first
  - If extension is not in the binary set, check content
  - If extension IS in the binary set, return true immediately (skip content read for performance)
- If `options.extensionOnly` is true:
  - Only check the filename extension
- Returns boolean
- This is the recommended function for most callers

### 3.3 Where Each Function Should Be Used

| Caller | Function to Use | Rationale |
|--------|----------------|-----------|
| `fileService.searchWorkspace()` | `isBinaryFile(filename)` | Already scanning many files — extension check is fast and sufficient for search skipping |
| `tagService.isScannableFile()` | `isBinaryFile(filename)` | Already scanning many files for metadata purposes |
| `toolService.readFile()` (AI tool) | `isBinary(filePath)` | Secure — extra content check prevents reading binary files misnamed as .txt |
| `toolService.editFile()` (AI tool) | `isBinary(filePath)` | Same as readFile — safety first |
| Any future file preview feature | `isBinary(filePath)` | Safer to do full check before rendering |

---

## 4. Extension List Consolidation

Merge the extension lists from all three locations. The final unified list should be the UNION of all current lists.

From `fileService.js`:
`jpg, jpeg, png, gif, bmp, webp, svg, ico, pdf, zip, tar, gz, rar, 7z, mp3, mp4, avi, mov, wmv, exe, dll, so, dylib, docx, xlsx, pptx`

From `tagService.js` (v5.1.6): Verify by reading the file. The changelog says "Added `BINARY_EXTENSIONS` set and `isScannableFile()` helper that skips hidden/meta files (starting with `.`) and binary file types (images, PDFs, archives, media, etc.), matching the same pattern used by the workspace search." — so it should be the same or similar.

Also add common binary formats that neither list currently includes:
- `ttf, otf, woff, woff2` — font files
- `eot` — Embedded OpenType
- `wasm` — WebAssembly (binary)
- `map` — Source maps can be large JSON but are typically not user-editable; skip for search but allow for AI tools
- `db, sqlite, sqlite3` — database files
- `class` — Java bytecode
- `pyc` — Python bytecode
- `o, obj, a, lib` — compiled objects and static libraries
- `DS_Store` — macOS metadata (not an extension, a filename)
- `Thumbs.db` — Windows metadata

**Categories in the unified list:**
- **Images:** jpg, jpeg, png, gif, bmp, webp, svg, ico, tiff, tif, heic, heif, raw, cr2, nef, arw
- **Archives:** zip, tar, gz, bz2, xz, rar, 7z, zst, lz4
- **Media:** mp3, mp4, avi, mov, wmv, flv, mkv, webm, wav, flac, ogg, aac, wma, m4a
- **Documents:** pdf, docx, xlsx, pptx, doc, xls, ppt, odt, ods, odp
- **Fonts:** ttf, otf, woff, woff2, eot
- **Executables:** exe, dll, so, dylib, wasm, class
- **Compiled objects:** o, obj, a, lib, pyc
- **Databases:** db, sqlite, sqlite3, mdb, accdb
- **Other:** ico, icns

---

## 5. Files to Create

| File | Purpose |
|------|---------|
| `server/src/services/binaryDetection.js` | Unified binary detection module with `BINARY_EXTENSIONS`, `isBinaryFile()`, `isBinaryContent()`, `isBinary()` |

## 6. Files to Modify

| File | Changes |
|------|---------|
| `server/src/services/fileService.js` | Remove local `BINARY_EXTENSIONS` set (lines 367–373) and local `isBinaryFile()` function (lines 375–378). Import from `binaryDetection.js` instead. Use `isBinaryFile()` in `searchWorkspace()`. |
| `server/src/services/toolService.js` | Remove local `isBinary()` function (lines 43–51). Import `isBinary()` from `binaryDetection.js` instead. Use it in `readFile()` and `editFile()`. |
| `server/src/services/tagService.js` | Remove local `BINARY_EXTENSIONS` set and `isScannableFile()` helper. Import from `binaryDetection.js` instead. Use `isBinaryFile()` in `getFilesByTag()`, `getFileRelationships()`, and `listDirectoryWithTags()`. |

## 7. Files With No Changes Required

None — every file that does binary detection must be updated to use the unified module.

---

## 8. Backward Compatibility

- The function signatures match the existing ones: `isBinaryFile(filename)` and `isBinary(filePath)`
- The behavior is identical for files that were already correctly detected
- The new unified function is slightly more accurate for edge cases (misnamed files)
- No API changes, no frontend changes, no data changes

---

## 9. Edge Cases

| File | Extension Check | Content Check | Unified Result | Rationale |
|------|----------------|---------------|----------------|-----------|
| `photo.png` | Binary (png in set) | N/A (skipped) | Binary | Known image extension |
| `readme.txt` | Not binary | Depends on content | Not binary (usually) | Text file |
| `data.bin` (actually text) | Not binary (.bin not in set) | Not binary (no nulls) | Not binary | Content check catches it |
| `data.bin` (actually JPEG) | Not binary (.bin not in set) | Binary (nulls from header) | Binary | Content check catches misnamed binary |
| `empty.exe` | Binary (exe in set) | N/A (skipped) | Binary | Extension says binary — safer to skip |
| `notes` (no extension) | Not binary (no ext) | Depends on content | Variable | Content check is the deciding factor |
| `.gitignore` | Not binary | Not binary | Not binary | Hidden file but text |
| `.DS_Store` | N/A (filename match) | N/A | Binary | Special case: filename match, not extension |

For files with no extension, the extension check passes (no extension = not in binary set), and the content check determines the result. This is correct behavior.

For `.DS_Store` (macOS), add a special case: the unified `isBinary()` function should check the basename against a set of known binary filenames (`.DS_Store`, `Thumbs.db`). This set should be small and well-known.

---

## 10. Verification Checklist

- [ ] New `binaryDetection.js` module exports all three functions correctly
- [ ] `fileService.searchWorkspace()` still skips the same binary files as before
- [ ] `toolService.readFile()` still rejects binary files when called by AI
- [ ] `toolService.editFile()` still rejects binary files when called by AI
- [ ] `tagService.getFilesByTag()` still skips binary files
- [ ] `tagService.getFileRelationships()` still skips binary files
- [ ] `tagService.listDirectoryWithTags()` still skips binary files
- [ ] A `.txt` file containing null bytes is detected as binary by `isBinary()` (full check)
- [ ] A `.bin` file that is actually plain text is NOT detected as binary
- [ ] A file with no extension that contains null bytes is detected as binary
- [ ] `isBinaryFile('photo.png')` returns true (extension check, fast path)
- [ ] `isBinaryFile('readme.md')` returns false (extension check)
- [ ] No duplicate `BINARY_EXTENSIONS` sets remain anywhere in the codebase
- [ ] All three previous locations that had binary detection code now import from the unified module
- [ ] `npm run server` starts without import errors
- [ ] The AI tools can still read text files and reject binary files in chat

## 11. Testing

Add a test file `server/tests/unit/services/binaryDetection.test.ts`:

- `isBinaryFile('photo.png')` → true
- `isBinaryFile('readme.md')` → false
- `isBinaryFile('archive.zip')` → true
- `isBinaryFile('document.docx')` → true
- `isBinaryFile('script.js')` → false
- `isBinaryFile('notes')` → false (no extension)
- `isBinaryFile('Makefile')` → false (no extension)
- `isBinaryContent(pathToActualTextFile)` → false
- `isBinaryContent(pathToActualImageFile)` → true
- `isBinaryContent(pathToFileWithNullBytesInFirst8KB)` → true
- `isBinaryContent(nonExistentPath)` → true (safety: can't read = treat as binary)
- `isBinary(pathToTextFile)` → false (extension check passes, content check confirms)
- `isBinary(pathToImageFile)` → true (extension check catches it, short-circuits)
- `isBinary(pathToTextFile, { extensionOnly: true })` → false
- `isBinary(pathToImageFile, { extensionOnly: true })` → true