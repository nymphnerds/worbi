# Handoff: Document Version History

**Target Version:** v5.4.0
**Priority:** High (high user value, enabled by SQLite migration)
**Dependencies:**
- DATABASE_MIGRATION.md (SQLite must be implemented first — revision storage depends on it)
- BLOB_URL_BRIDGE_FIX.md (version diffs that reference images must resolve URLs correctly)

---

## 1. Problem Statement

WORBI currently has no version history for documents. The undo/redo system (`useFileSystemUndoRedo`) provides ephemeral undo of file operations (create, delete, rename) but does not preserve document content history across saves. Writers working on world-building documents need to:

- Revert to a previous version of a document after rewriting a section they later regret
- Compare two versions side-by-side to see what changed (diff view)
- Browse a timeline of how a document evolved over time
- Recover content accidentally deleted and saved over

The SQLite migration (DATABASE_MIGRATION.md) makes this feasible by providing structured storage with FTS5 for searching revision content.

---

## 2. Target Architecture

### 2.1 Database Schema

Add a `file_revisions` table to the SQLite database:

```sql
CREATE TABLE IF NOT EXISTS file_revisions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    file_path TEXT NOT NULL,
    username TEXT NOT NULL,
    revision_number INTEGER NOT NULL,
    content TEXT NOT NULL,
    content_size INTEGER NOT NULL,
    delta_from_previous TEXT,         -- JSON diff payload (optional, for space optimization)
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    save_source TEXT NOT NULL DEFAULT 'manual',  -- 'manual', 'auto', 'import'
    UNIQUE(file_path, username, revision_number)
);

CREATE INDEX idx_file_revisions_path_user ON file_revisions(file_path, username);
CREATE INDEX idx_file_revisions_created ON file_revisions(created_at);
```

**Design decisions:**

- **Full content storage (not delta-only):** Revision counts per file are expected to be small (tens, not thousands). Full content makes restoration and diffing simpler. The `delta_from_previous` column is optional for future space optimization.
- **Natural key:** `(file_path, username, revision_number)` — each file has its own revision counter.
- **No FK to files table:** Files can be deleted while revisions are preserved (intentional — you may want to recover a deleted file from its revision history).

### 2.2 Server-Side: Revision Service

New file: `server/src/services/revisionService.js`

```javascript
// Core functions:
createRevision(username, filePath, content, saveSource)  // Create a revision snapshot
getRevisions(username, filePath)                          // List all revisions for a file
getRevision(username, filePath, revisionNumber)           // Fetch a specific revision
restoreRevision(username, filePath, revisionNumber)       // Restore content to a revision
deleteRevisions(username, filePath)                        // Delete all revisions for a file
compareRevisions(username, filePath, rev1, rev2)           // Compute diff between two revisions
getTotalRevisionSize(username)                              // Get total storage used by revisions
```

**Retention policy:**
- Maximum 50 revisions per file (configurable via env var `WORBI_MAX_REVISIONS_PER_FILE`)
- When the limit is reached, the oldest revision is dropped before inserting the new one
- Deleted files retain their revision history for 30 days (configurable via `WORBI_REVISION_RETENTION_DAYS`), after which a maintenance cleanup removes orphaned revisions
- A `GET /api/revisions/stats` endpoint returns per-user storage usage

**Auto-save snapshots:**
- The server creates a revision automatically every 5 minutes if the document content has changed (debounced, only if dirty)
- Manual saves (Ctrl+S) always create a revision with `save_source='manual'`
- DOCX imports create a revision with `save_source='import'`

### 2.3 API Endpoints

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| `GET` | `/api/revisions?path=` | Yes | List revisions for a file (metadata only: rev number, size, timestamp, source) |
| `GET` | `/api/revisions/content?path=&rev=` | Yes | Fetch full content of a specific revision |
| `POST` | `/api/revisions/restore` | Yes | `{ path, revisionNumber }` — restore file to a revision |
| `GET` | `/api/revisions/diff?path=&rev1=&rev2=` | Yes | Compute diff between two revisions (returns unified diff) |
| `GET` | `/api/revisions/stats` | Yes | Total revision count, storage usage per user |

**All revision endpoints use the standard auth middleware.** The file path must pass through `getSafePath()` before any DB operation.

### 2.4 Client-Side: Revision Panel

New component: `client/src/components/RevisionHistory.tsx`

**Layout:** A slide-out panel from the right side of the editor area (similar to the AI sidebar but from the opposite edge). Toggled via a clock icon button in the editor toolbar.

**UI structure:**
```
┌─────────────────────────────────┐
│  Revision History    [X]        │  ← Header with close button
├─────────────────────────────────┤
│  "My Story.html"                │  ← File name
│                                 │
│  ● v12  May 1, 2:31 PM  4.2 KB │  ← Current revision (highlighted)
│    Manual save                  │
│                                 │
│  ○ v11  May 1, 2:15 PM  4.1 KB │
│    Manual save                  │
│                                 │
│  ○ v10  May 1, 2:10 PM  3.9 KB │
│    Auto-save                    │
│                                 │
│  ○ v9   May 1, 1:45 PM  3.7 KB │
│    Manual save                  │
│      ...                        │
│                                 │
│  ─── Compare Selected ───       │  ← Compare button
│  ─── Restore This Version ───   │  ← Restore button
└─────────────────────────────────┘
```

**Interaction model:**
- Click a revision row to preview it in a read-only editor panel below the list
- Select two revisions with checkboxes, then click "Compare" to open the diff view
- Click "Restore This Version" to revert the document to that revision (with a confirmation dialog: "This will overwrite the current document. A new revision will be created. Continue?")
- Auto-save revisions are shown with a smaller, lighter icon; manual saves get a bold circle

### 2.5 Diff View

When comparing two revisions, show a side-by-side diff:

```
┌──────────────────┬──────────────────┐
│  v5 (Older)      │  v12 (Newer)     │
├──────────────────┼──────────────────┤
│ The old forest   │ The ancient      │  ← Changed text highlighted
│ was dark...      │ forest was dark  │
│                  │ and mysterious   │  ← Added text (green)
│ The goblin       │ The goblin       │
└──────────────────┴──────────────────┘
```

- Use a lightweight JS diff library (e.g., `diff` from npm) to compute word/line-level diffs
- Changed text highlighted in yellow, additions in green, deletions in red
- Images show as `[Image: filename]` placeholder text in the diff view
- Scroll positions are synchronized between the two panels

### 2.6 Editor Integration

- **Save hook:** `POST /api/files/write` → after successful write, `POST /api/revisions` (create revision). The revision creation is non-blocking — if it fails, the file save is still valid.
- **Auto-save hook:** A `setInterval` in `useFileOperations` (or the extracted editor feature) checks if content is dirty, and if so, creates an auto-save revision via the API.
- **Restore hook:** When a revision is restored, the server creates a NEW revision (the current state before overwrite) and then writes the restored content. This means you can always undo a restore.
- **Delete file hook:** When a file is deleted via `DELETE /api/files`, revisions are preserved for 30 days. After that, `POST /api/revisions/purge?path=` (admin endpoint) or the maintenance script cleans them up.

---

## 3. Files to Create

| File | Purpose |
|------|---------|
| `server/src/services/revisionService.js` | Revision CRUD, diff computation, retention enforcement |
| `server/src/routes/revisions.js` | Express routes for revision endpoints |
| `client/src/components/RevisionHistory.tsx` | Slide-out panel with revision list, preview, diff viewer |
| `client/src/components/DiffViewer.tsx` | Side-by-side diff display component |

## 4. Files to Modify

| File | Changes |
|------|---------|
| `server/src/index.js` | Register `/api/revisions` route |
| `server/src/services/fileService.js` | After `writeFile()`, call `createRevision()`. After `deleteFile()`, mark revisions for retention. |
| `client/src/components/DocumentEditor.tsx` | Add clock icon button to toolbar; wire revision panel toggle |
| `client/src/services/api.ts` | Add revision API functions and types |
| `server/data/file_revisions.db` | New SQLite database file (or add table to main DB after DATABASE_MIGRATION) |

---

## 5. Implementation Order

### Phase 1: Server-Side Revision Storage

1. Create `revisionService.js` with `createRevision()`, `getRevisions()`, `getRevision()`, `restoreRevision()`, `deleteRevisions()`
2. Create `routes/revisions.js` with all 6 endpoints
3. Register routes in `server/src/index.js`
4. Wire `createRevision()` call into `fileService.js` after `writeFile()`
5. Add retention configuration env vars to config

**Verification:** Manual curl/postman tests — create a revision, list revisions, fetch content, restore.

### Phase 2: Client-Side Revision Panel

1. Create `RevisionHistory.tsx` with revision list UI
2. Create `DiffViewer.tsx` with side-by-side diff
3. Add revision panel toggle to `DocumentEditor.tsx` toolbar
4. Add API functions to `client/src/services/api.ts`
5. Wire save hook to create revisions after file saves

**Verification:** Save a document multiple times, open the revision panel, see the timeline, preview a revision, restore.

### Phase 3: Auto-Save and Polish

1. Implement `setInterval`-based auto-save revision creation
2. Add confirmation dialog for restore
3. Handle large documents gracefully (pagination in revision list, virtualization for diff view)
4. Add revision count badge to the clock icon in the toolbar

---

## 6. Edge Cases

| Scenario | Handling |
|----------|----------|
| **File deleted then recreated** | New file starts at revision number 1; old revisions remain with their path+user key until retention expires |
| **File renamed** | Revisions follow the old path. Consider adding a `POST /api/revisions/migrate-path` endpoint to update revision paths after rename (optional future enhancement) |
| **Very large documents** | Revisions over 500KB should not be stored as full content — store only a diff from the previous revision for documents over this threshold |
| **Concurrent saves** | SQLite handles this via its write lock; the second save will create revision N+1, which is correct behavior |
| **Restore while document is dirty** | Prompt: "You have unsaved changes. Save before restoring?" with three options: Save & Restore, Discard & Restore, Cancel |
| **Revision panel open while switching tabs** | Panel refreshes to show the newly active file's revision history |
| **No revisions exist** | Panel shows empty state: "No revisions yet. Revisions are created when you save this document." |

---

## 7. Verification Checklist

- [ ] Save a document multiple times with different content; all revisions appear in the panel
- [ ] Preview a revision — content is read-only and matches the saved state
- [ ] Restore a revision — document content is replaced, a new revision is created
- [ ] Compare two revisions — diff view shows added/removed/changed text
- [ ] Delete a file — revisions persist for 30 days
- [ ] Auto-save creates revisions at the configured interval
- [ ] Revision panel works with multiple tabs open (shows correct file's history)
- [ ] Revision count limit is enforced (oldest drops when limit reached)
- [ ] Large document (>500KB) uses delta storage instead of full content
- [ ] Empty document creates a revision (edge case — empty string content)
- [ ] Concurrent saves produce correct sequential revision numbers

---

## 8. Future Enhancements (Out of Scope for v1)

- **Named versions / tags:** Allow users to name specific revisions (e.g., "Chapter 3 complete", "Before major rewrite")
- **Branching history:** Create alternate timelines of a document (like git branches)
- **Visual timeline graph:** D3-based graphical representation of revision history
- **Revision notes:** Optional user-written note attached to a revision ("Rewrote the goblin dialogue")
- **Export revision as new document:** Save a specific revision as a separate file
- **Bulk restore across workspace:** Restore multiple files to a common timestamp