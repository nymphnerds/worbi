# Handoff: Focus Mode

**Target Version:** v5.3.0
**Priority:** Low (quality-of-life feature, pure frontend)
**Dependencies:** APP_TSX_REFACTOR.md (ideally after, since layout state is cleaner post-refactor)

---

## 1. Problem Statement

WORBI's VS Code-style shell is powerful but visually busy. The Activity Bar, left panel, AI sidebar, Information Panel, and StatusBar all compete for screen real estate. Writers sometimes want to focus entirely on the text — especially when working on the two-column editor that benefits from maximum horizontal width.

Focus Mode collapses ALL panels, leaving only the editor at full width with minimal chrome. It's a one-press toggle (like F11 or a button in the StatusBar) that gives the writer an undistracted writing environment.

---

## 2. Target Behavior

**Before (normal mode):**
```
┌──────┬──────────────────┬──────────────┐
│ Act- │  File Explorer   │  Editor      │ AI
│ ivity│                  │  ┌────────┐  │
│ Bar  │                  │  │ Header │  │ Sidebar
│      │                  │  │ TabBar │  │
│      │                  │  │ Main│Mr│  │
│      │                  │  │ Editor │  │
│      │                  │  ├────────┤  │
│      │                  │  │Info Pnl│  │
│      │                  │  ├────────┤  │
│      │                  │  │StatusBr│  │
└──────┴──────────────────┴──────────────┘
```

**After (focus mode):**
```
┌──────────────────────────────────────┐
│  [≡] WORBI              [Exit Focus]│  ← Minimal header
├──────────────────────────────────────┤
│  Main Editor    │  Margin Editor     │
│                 │                    │
│                 │                    │
│                 │                    │
│                 │                    │
│                 │                    │
│                 │                    │
│                 │                    │
├──────────────────────────────────────┤
│  Words: 1,247  ● Saved              │  ← Minimal status bar
└──────────────────────────────────────┘
```

### 2.2 What Gets Hidden

| Element | Hidden? | Notes |
|---------|---------|-------|
| Activity Bar | Yes | |
| Left Panel (Explorer/Search/Tags/Starred) | Yes | |
| AI Sidebar | Yes | |
| Information Panel | Yes | Below the editor |
| TabBar | Yes | Show current document name in the header instead |
| Header | Partially | Reduced to a thin bar with hamburger menu and exit button |
| StatusBar | Partially | Reduced to word count + save status only |

### 2.3 What Stays

- Both editor columns (main + margin) — these expand to fill the full viewport width
- A minimal header bar with:
  - Hamburger menu (≡) on the left — opens a slim dropdown with File actions (Save, New, Export, etc.)
  - "Focus Mode" indicator on the right with an "Exit" button (or Esc key)

### 2.4 How to Toggle

| Trigger | Action |
|---------|--------|
| `F11` key | Toggle focus mode on/off |
| StatusBar button | Click to toggle |
| `Escape` key | Exit focus mode (only when no modal/dropdown is open) |
| `Ctrl+Shift+F` | Toggle focus mode (alternative shortcut, configurable) |

---

## 3. Implementation

### 3.1 State Management

A single boolean state: `focusMode` in the layout hook (or in `App.tsx` directly for simplicity):

```typescript
// In useLayout.ts (if after refactor) or App.tsx
const [focusMode, setFocusMode] = useState(false);

// Persist preference
useEffect(() => {
  localStorage.setItem('wbu-focus-mode', String(focusMode));
}, [focusMode]);

// Restore on load
useEffect(() => {
  const saved = localStorage.getItem('wbu-focus-mode');
  if (saved === 'true') setFocusMode(true);
}, []);
```

### 3.2 CSS Transition

Panels animate in/out with a smooth transition:

```css
/* In globals.css */
.focus-mode .activity-bar,
.focus-mode .left-panel,
.focus-mode .ai-sidebar,
.focus-mode .information-panel {
  width: 0 !important;
  min-width: 0 !important;
  max-width: 0 !important;
  overflow: hidden;
  opacity: 0;
  pointer-events: none;
  transition: width 0.3s ease, opacity 0.3s ease, min-width 0.3s ease;
}

.focus-mode .tab-bar {
  display: none;
}

.focus-mode .header {
  height: 36px;
  padding: 0 12px;
}

.focus-mode .status-bar {
  height: 24px;
}

.focus-mode .editor-area {
  width: 100% !important;
}
```

### 3.3 Minimal Header

When in focus mode, the header reduces to:

```
┌──────────────────────────────────────┐
│ [≡] WORBI — Goblin King.html  [✕]   │
└──────────────────────────────────────┘
```

- **Hamburger (≡):** Opens a slim dropdown with essential actions:
  - Save (Ctrl+S)
  - Save As...
  - New File
  - Export DOCX
  - Exit Focus Mode (Esc)
- **Document name:** Shows the active document's filename
- **Exit (✕):** Exits focus mode

### 3.4 Minimal StatusBar

When in focus mode, the StatusBar reduces to:

```
┌──────────────────────────────────────┐
│  Words: 1,247  ● Saved              │
└──────────────────────────────────────┘
```

- Left: Word count (updated on content change)
- Right: Save status indicator (● green = saved, ● amber = dirty)

### 3.5 Keyboard Shortcut

Register in the existing keyboard handler (or `useKeyboardShortcuts` hook after refactor):

```typescript
if (event.key === 'F11') {
  event.preventDefault();
  setFocusMode(prev => !prev);
}
```

---

## 4. Files to Create

| File | Purpose |
|------|---------|
| `client/src/components/FocusHeader.tsx` | Minimal header for focus mode (or inline it in App.tsx — it's small) |

## 5. Files to Modify

| File | Changes |
|------|---------|
| `client/src/App.tsx` | Add `focusMode` state, conditional rendering of panels, CSS class toggle, F11 handler |
| `client/src/components/Header.tsx` | Support a `minimal` prop for focus mode rendering |
| `client/src/components/StatusBar.tsx` | Support a `minimal` prop for focus mode rendering |
| `client/src/styles/globals.css` | Add `.focus-mode` CSS rules for panel transitions |

**If APP_TSX_REFACTOR is already done:**
| `client/src/features/layout/useLayout.ts` | Add `focusMode` state and `toggleFocusMode()` |
| `client/src/features/editor/useKeyboardShortcuts.ts` | Add F11 handler |

---

## 6. Edge Cases

| Scenario | Handling |
|----------|----------|
| **Focus mode + AI chat panel open** | AI sidebar closes. Chat history is preserved — it reopens when exiting focus mode |
| **Focus mode + Find & Replace open** | Find & Replace stays open — it's part of the editor, not a panel |
| **Focus mode + Settings modal open** | Settings modal stays open — it's an overlay, not a panel. Exiting focus mode does not close the modal |
| **Focus mode + unsaved changes** | Unsaved changes indicator shows in the minimal status bar. Ctrl+S still works |
| **Save in focus mode** | Ctrl+S saves and shows the green "Saved" indicator briefly |
| **File rename in focus mode** | Hamburger menu → "Rename" opens a small inline input in the minimal header |
| **Focus mode persists across reload** | `localStorage` key `wbu-focus-mode` stores the preference |
| **Focus mode + Welcome screen** | Focus mode is irrelevant when no document is open — disabled when `tabs.length === 0` |
| **Browser F11 (fullscreen)** | Browser F11 is different from WORBI focus mode. The keyboard shortcut uses `event.preventDefault()` to avoid triggering browser fullscreen |

---

## 7. Verification Checklist

- [ ] F11 toggles focus mode on
- [ ] F11 toggles focus mode off
- [ ] Activity Bar collapses in focus mode
- [ ] Left panel collapses in focus mode
- [ ] AI sidebar collapses in focus mode
- [ ] Information panel collapses in focus mode
- [ ] TabBar hides in focus mode
- [ ] Header reduces to minimal bar
- [ ] StatusBar reduces to word count + save status
- [ ] Editor expands to fill full viewport
- [ ] Both editor columns (main + margin) remain visible and functional
- [ ] Escape exits focus mode
- [ ] Hamburger menu opens essential actions
- [ ] Save (Ctrl+S) works in focus mode
- [ ] Focus mode preference persists across page reload
- [ ] Focus mode does not activate when no document is open
- [ ] Exiting focus mode restores all panels to their previous state (widths, visibility)
- [ ] Transitions are smooth (0.3s ease)

---

## 8. Design Notes

- The transition animation should feel snappy, not sluggish — 0.3s is the sweet spot
- Consider a subtle background darkening or vignette effect when entering focus mode to reinforce the "focus" metaphor (optional)
- The hamburger menu should use the same `bg-[#1e1e2e]` dropdown background as other WORBI dropdowns
- Exit focus mode button should be subtle — a simple ✕ icon in `text-[#888]` that brightens on hover