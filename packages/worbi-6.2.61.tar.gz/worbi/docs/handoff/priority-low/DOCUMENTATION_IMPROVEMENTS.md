# Handoff: Documentation Improvements — Developer Setup, API Reference, Architecture Guide, and Contribution Guide

**Target Version:** v5.2.0
**Priority:** Medium (improves onboarding for new users and contributors)
**Dependencies:** None (can be done independently)

---

## 1. Problem Statement

WORBI currently has solid architectural documentation for specific systems (BRANDING.md, SPELLCHECK_SYSTEM.md, TAG_SYSTEM_ENHANCEMENT.md, TAG_RELATIONSHIP_SYSTEM.md, INFORMATION_PANEL_SYSTEM.md, AI_TOOLS_INTEGRATION.md) but is missing essential onboarding and reference documentation:

| Missing Document | Consequence |
|-----------------|-------------|
| Developer Setup Guide | A new developer cannot get the project running without guessing |
| API Reference | API consumers (including the frontend code itself) have no contract to reference |
| Architecture Overview | No high-level map of how the system fits together |
| Contribution Guide | No process for external contributors to submit changes |

Additionally, the existing README is excellent for end users but lacks a "Development" section.

---

## 2. Documents to Create

### 2.1 Developer Setup Guide (`docs/DEVELOPMENT.md`)

This is the highest-priority missing document. It should enable a developer to go from `git clone` to a running development environment in under 10 minutes.

**Required Sections:**

**Prerequisites:**
- Node.js version requirement (18+ as stated in README)
- npm version (comes with Node.js)
- Git
- Optional: LM Studio or Ollama for LLM features (note that the app works without it, just the AI chat won't respond)

**Quick Start:**
- Clone the repository
- `npm install` at the root (workspaces install both server and client)
- Copy `.env.example` to `.env` (explain which values to change)
- `npm run dev` to start both server (port 8082) and client (port 5173)
- Open `http://localhost:5173` in a browser

**Project Layout:**
- Explain the monorepo structure with npm workspaces
- Describe what each top-level directory contains (server, client, docs)
- Describe key files: `package.json` (workspace root), `server/src/index.js` (server entry), `client/src/App.tsx` (client entry)

**Development Workflow:**
- `npm run dev` — starts both server and client concurrently
- `npm run server` — starts only the server
- `npm run client` — starts only the client
- `npm run build` — builds the client for production
- `npm test` — runs the test suite (once tests exist)
- `npm run test:watch` — runs tests in watch mode
- Describe how hot reload works (Vite HMR for client, nodemon for server)
- Explain that the server must be running for the client to work (API calls)

**Environment Variables:**
- List all variables from `.env.example` with explanations
- Mark which are required vs optional
- Explain how `.env` is loaded (if using dotenv, if it's manual, etc.)

**LLM Setup (Optional):**
- Explain that the AI chat feature requires a running LLM server
- Provide instructions for LM Studio: Download → Load a model → Start local server (defaults to port 1234)
- Provide instructions for Ollama: `ollama serve` then configure model name in Settings
- Provide instructions for llama.cpp server: `llama-server -m model.gguf --port 8000`
- Note that the app is fully functional for document editing even without an LLM

**Project Conventions:**
- Code formatting: is there a prettier config? ESLint config? If not, note that.
- File naming: PascalCase for components, camelCase for hooks and services
- Import ordering convention (React → third-party → local)
- CSS approach (Tailwind utility classes + globals.css for custom styles)
- Git commit style (reference the CHANGELOG format — "vX.Y.Z — Title" style)

**Debugging:**
- How to view server logs (terminal where `npm run dev` runs, or use `npm run server` for dedicated output)
- How to view client errors (browser DevTools console)
- How to test API endpoints directly (curl examples for `/api/health`, `/api/auth/login`)
- Common issues: "LLM not responding" → check Settings → LLM configuration; "Images broken" → check that server is running; "White screen" → check browser console for errors

**Building for Production:**
- `npm run build` builds the client
- `npm start` starts the server in production mode
- Note that the client build is served by... (currently it's Vite dev server; production serving may need a static file route in Express — mention this if not yet implemented)

---

### 2.2 API Reference (`docs/API_REFERENCE.md`)

Document every API endpoint with request/response examples.

**Required Structure:**

**Base URL:** `http://localhost:8082/api`

**Authentication:**
- Describe the JWT auth flow: `POST /api/auth/login` returns `{ token }`, all other endpoints require `Authorization: Bearer <token>`
- Token format, expiry (if defined)
- How to get a token for testing

**Endpoint Documentation Format (repeat for each endpoint):**
```
### `POST /api/auth/login`

Authenticate a user and receive a JWT token.

**Request Body:**
| Field | Type | Required | Description |
|-------|------|----------|-------------|
| username | string | yes | User's login name |
| password | string | yes | User's password |

**Response (200):**
{
  "token": "eyJhbGciOi...",
  "user": { "username": "rauty" }
}

**Response (401):**
{
  "error": "Invalid credentials"
}
```

**Endpoints to Document:**

**Auth:**
- `POST /api/auth/login` — authenticate
- `POST /api/auth/register` — create account

**Files:**
- `GET /api/files?path=` — list directory contents
- `GET /api/files/read?path=` — read file content
- `POST /api/files/write` — write/create file
- `POST /api/files/folder` — create folder
- `DELETE /api/files?path=` — delete file/folder
- `PUT /api/files/rename` — rename file/folder
- `POST /api/files/copy` — copy file
- `POST /api/files/move` — move file
- `POST /api/files/upload` — upload file
- `GET /api/files/search?q=` — search workspace
- `GET /api/files/workspace/*` — serve workspace files (images in HTML content)
- `GET /api/files/images/*` — serve uploaded images (requires auth — note this is the problem the blob URL fix solves)

**Tags (routes embedded in files.js):**
- `GET /api/tags` — list all tags
- `POST /api/tags` — create tag
- `PUT /api/tags/:id` — update tag
- `DELETE /api/tags/:id` — delete tag
- `GET /api/tags/:id/files` — get files with tag
- `POST /api/files/:path/tags` — add tags to file
- `DELETE /api/files/:path/tags/:tagId` — remove tag from file

**LLM:**
- `POST /api/llm/chat` — send chat message
- `GET /api/llm/models` — list available models
- `POST /api/llm/test` — test LLM connection
- `GET /api/llm/system-info` — get system info

**Settings:**
- `GET /api/settings` — get user settings
- `PUT /api/settings` — update user settings

**System:**
- `GET /api/health` — health check (public, no auth)

**Common Error Responses:**
- 400 — Bad request (invalid parameters)
- 401 — Unauthorized (missing or invalid token)
- 404 — Not found
- 409 — Conflict (duplicate resource)
- 500 — Internal server error

---

### 2.3 Architecture Overview (`docs/ARCHITECTURE.md`)

A high-level guide to how WORBI is structured, aimed at developers who need to understand the system before making changes.

**Required Sections:**

**System Diagram (text-based):**
```
┌─────────────────────────────────────────────────────┐
│                    Browser                          │
│  ┌──────────┐  ┌──────────┐  ┌──────────────────┐  │
│  │ TipTap   │  │ React    │  │ API Service      │  │
│  │ Editor   │  │ Components│  │ Layer (api.ts)  │  │
│  └──────────┘  └──────────┘  └────────┬─────────┘  │
│                                        │            │
└────────────────────────────────────────┼────────────┘
                                         │ HTTP (JWT)
┌────────────────────────────────────────┼────────────┐
│                    Express Server      │            │
│  ┌──────────┐  ┌──────────┐  ┌────────┴─────────┐  │
│  │ Auth     │  │ Routes   │  │ Services         │  │
│  │ Middleware│  │ (REST)   │  │ (Business Logic) │  │
│  └──────────┘  └──────────┘  └────────┬─────────┘  │
│                                        │            │
│  ┌─────────────────────────────────────┴─────────┐  │
│  │              File System                      │  │
│  │  /data/users/<user>/workspace/  (documents)   │  │
│  │  /data/users/<user>/assets/     (images)      │  │
│  │  /data/user-settings/           (settings)    │  │
│  └───────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────┘
```

(If the database migration has been completed, update this diagram to include SQLite.)

**Data Flow Diagrams:**

1. **File Open Flow:**
   User clicks file → `FileExplorer` calls `openFile(path)` → `api.ts` sends `GET /api/files/read?path=` → `fileService.readFile()` reads from disk → returns HTML content → `App.tsx` (or `useTabManager`) loads content into TipTap editor → if blob URL bridge exists, images are converted; if proxy fix is done, images are signed

2. **File Save Flow:**
   User presses Ctrl+S → `handleSave()` in App.tsx → gets HTML from TipTap editor → if blob URL bridge exists, blob URLs are converted back to server URLs; if proxy fix is done, tokens are stripped → `api.ts` sends `POST /api/files/write` → `fileService.writeFile()` writes to disk

3. **LLM Chat Flow:**
   User types message → `ChatPanel` → `useLLM.sendChat()` → `api.ts` sends `POST /api/llm/chat` with messages + document content + permissions → `llmService.sendChatMessage()` builds system prompt → sends to LLM server → if LLM returns tool_calls → `toolService.executeTool()` runs the tool → results fed back to LLM → repeat up to 10 times → final response returned to client

4. **Tag Assignment Flow:**
   User clicks + on tag dropdown → `TagInsertControl` calls `addTags()` → `api.ts` sends `POST /api/files/<path>/tags` → `tagService` updates `.wbi-meta.json` → dispatches `wbu-tags-changed` event → `InformationPanel` listens and refetches

**Key Architectural Decisions:**
- Why TipTap/ProseMirror over Slate/Quill/Draft.js (rich text with collaborative potential, extensible through extensions)
- Why Express over Fastify/Koa (simplicity, middleware ecosystem)
- Why filesystem storage over a database (simplicity for single-user; this doc should note that a DB migration is planned — link to the handoff doc)
- Why JWT auth over sessions (stateless, works with both REST API and future WebSocket connections)
- Why Vite over Create React App (faster builds, native ESM, better TypeScript support)
- Why the two-column editor split (main content vs. margin notes — worldbuilding use case)

**Component Hierarchy:**
```
<App>
├── <AuthProvider> (after refactor)
├── <AppLayout>
│   ├── <ActivityBar>
│   ├── Left Panel (conditional)
│   │   ├── <FileExplorer>
│   │   ├── <SearchPanel>
│   │   ├── <TagManager>
│   │   └── <StarredFiles>
│   ├── Main Content
│   │   ├── <Header>
│   │   ├── <TabBar>
│   │   ├── <DocumentEditor> (conditional: has tabs? editor : welcome)
│   │   │   ├── Main Editor (TipTap)
│   │   │   ├── Margin Editor (TipTap)
│   │   │   ├── <InformationPanel>
│   │   │   └── <TagInsertControl>
│   │   ├── <Welcome> (conditional: no tabs)
│   │   └── <StatusBar>
│   ├── Right Panel (conditional: AI sidebar shown)
│   │   └── <ChatPanel>
│   └── <Settings> (modal overlay)
```

**Extension Points:**
- Adding a new AI tool: define in `toolService.js` getToolDefinitions() and executeTool(), add permission in config, add UI toggle in Settings
- Adding a new Activity Bar item: add to ActivityType union, create component, add conditional render in App/AppLayout
- Adding a new TipTap extension: create in `client/src/extensions/`, register in DocumentEditor's extension array
- Adding a new file export format: add handler in App/fileOperations, add button in DocumentEditor toolbar

---

### 2.4 Contribution Guide (`docs/CONTRIBUTING.md`)

A guide for external contributors (and a reminder for the primary developer).

**Required Sections:**

**Code of Conduct:**
- Brief statement: be respectful, constructive, and inclusive

**How to Contribute:**
- Find or create an issue describing the bug or feature
- Fork the repository
- Create a feature branch: `feature/description` or `fix/description`
- Make changes following project conventions
- Write or update tests for your changes
- Ensure `npm test` passes
- Submit a pull request with a clear description

**Pull Request Guidelines:**
- Keep PRs focused on a single change
- Reference the issue number in the PR description
- Include screenshots or screen recordings for UI changes
- Update CHANGELOG.md under an "Unreleased" section
- Update relevant documentation files

**Commit Message Format:**
- Follow the existing CHANGELOG style: `## vX.Y.Z — Short Title (date)`
- For commits: `category: description` where category is `feat`, `fix`, `docs`, `refactor`, `test`, `chore`
- Example: `feat: add web_search tool with DuckDuckGo parsing`

**Development Environment:**
- Link to DEVELOPMENT.md for setup instructions

**Testing:**
- Link to the test suite documentation
- Require tests for new features and bug fixes
- Explain how to run specific test suites

**Documentation:**
- Update API_REFERENCE.md for new endpoints
- Update ARCHITECTURE.md for significant architectural changes
- Update README.md for user-facing feature changes

**Issue Reporting:**
- Use the GitHub issue tracker
- Bug reports: include steps to reproduce, expected behavior, actual behavior, screenshots, environment (OS, Node version, browser)
- Feature requests: describe the use case, proposed solution, alternatives considered

**Release Process:**
1. All changes are merged to `main` via PRs
2. Version bump in `package.json` (root)
3. Update CHANGELOG.md with the new version and release notes
4. Tag the release: `git tag vX.Y.Z`
5. Push the tag: `git push origin vX.Y.Z`

---

## 3. README Updates

Add a **Development** section to the existing README between "Tech Stack" and "Keyboard Shortcuts":

```markdown
## Development

### Prerequisites
- Node.js 18+
- npm 9+
- Git

### Setup
```bash
git clone git@github.com:rauty79/worbi.git
cd worbi
npm install
cp .env.example .env
# Edit .env with your LLM configuration (optional for AI features)
npm run dev
```

The server runs on `http://localhost:8082` and the client on `http://localhost:5173`.

### Documentation
- [docs/DEVELOPMENT.md](./docs/DEVELOPMENT.md) — Full developer setup guide
- [docs/ARCHITECTURE.md](./docs/ARCHITECTURE.md) — System architecture and data flows
- [docs/API_REFERENCE.md](./docs/API_REFERENCE.md) — REST API documentation
- [docs/CONTRIBUTING.md](./docs/CONTRIBUTING.md) — How to contribute
```

---

## 4. Cross-Linking

Ensure all new documents link to each other and to existing docs:

- `DEVELOPMENT.md` links to: `ARCHITECTURE.md`, `API_REFERENCE.md`, `CONTRIBUTING.md`, `README.md`
- `ARCHITECTURE.md` links to: `DEVELOPMENT.md`, specific system docs (BRANDING.md, SPELLCHECK_SYSTEM.md, etc.), relevant handoff docs for planned changes
- `API_REFERENCE.md` links to: `ARCHITECTURE.md`, `DEVELOPMENT.md`
- `CONTRIBUTING.md` links to: `DEVELOPMENT.md`, `ARCHITECTURE.md`
- `README.md` links to: all new docs in the Documentation section

Add forward-looking notes in `ARCHITECTURE.md` about planned changes:
- "The filesystem-as-database approach is planned for migration to SQLite (see `docs/handoff/DATABASE_MIGRATION.md`)"
- "Image URLs currently use a blob URL bridge pattern; a signed-URL proxy is planned (see `docs/handoff/BLOB_URL_BRIDGE_FIX.md`)"

---

## 5. Files to Create

| File | Purpose |
|------|---------|
| `docs/DEVELOPMENT.md` | Developer setup and workflow guide |
| `docs/API_REFERENCE.md` | Complete REST API documentation |
| `docs/ARCHITECTURE.md` | System architecture, data flows, design decisions |
| `docs/CONTRIBUTING.md` | Contribution process and guidelines |

## 6. Files to Modify

| File | Changes |
|------|---------|
| `README.md` | Add "Development" section with links to new docs |

## 7. Existing Files to Reference (Do Not Modify Unless Needed)

| File | Purpose |
|------|---------|
| `docs/BRANDING.md` | Brand identity system |
| `docs/SPELLCHECK_SYSTEM.md` | Spellcheck implementation details |
| `docs/TAG_SYSTEM_ENHANCEMENT.md` | Tag system architecture tracking |
| `docs/TAG_RELATIONSHIP_SYSTEM.md` | Tag relationship design |
| `docs/INFORMATION_PANEL_SYSTEM.md` | Information panel with hero images |
| `docs/AI_TOOLS_INTEGRATION.md` | AI tools engine documentation |
| `docs/legacy/*.md` | Historical handoff documents (for reference, not linked from new docs) |

---

## 8. Writing Guidelines for All Documents

- **Audience:** A developer who has just cloned the repository for the first time
- **Tone:** Professional, concise, instructional
- **Format:** Markdown with proper headings, code blocks, and tables
- **Completeness:** Every API endpoint should have a request and response example
- **Accuracy:** Verify every command by running it. Verify every API endpoint exists by reading the route files
- **Maintainability:** Note where content will become stale (e.g., architecture sections that reference the blob URL bridge should include a note that this is planned for replacement)

---

## 9. Verification Checklist

- [ ] `docs/DEVELOPMENT.md` exists and covers all required sections
- [ ] `docs/API_REFERENCE.md` exists and documents every endpoint in `server/src/routes/`
- [ ] `docs/ARCHITECTURE.md` exists with diagrams, data flows, and design decisions
- [ ] `docs/CONTRIBUTING.md` exists with PR guidelines and release process
- [ ] `README.md` has a "Development" section linking to the new docs
- [ ] All cross-links between documents are valid (no broken links)
- [ ] All API endpoint signatures match the actual route implementations (verify by reading the route files)
- [ ] All shell commands in DEVELOPMENT.md are tested and work
- [ ] The component hierarchy diagram in ARCHITECTURE.md matches the actual component tree
- [ ] No references to `lmsStartScript` or other development-only artifacts remain in the docs (except where called out as configuration options)
- [ ] The LLM setup section in DEVELOPMENT.md includes instructions for all three common local LLM servers (LM Studio, Ollama, llama.cpp)