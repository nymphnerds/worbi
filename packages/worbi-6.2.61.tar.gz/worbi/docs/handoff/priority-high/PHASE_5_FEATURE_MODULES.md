# Phase 5: Feature Module Tests

**Target Version:** v6.2.40
**Priority:** Medium (feature-specific logic)
**Dependencies:** Phase 0-4
**Status:** ✅ COMPLETE — 31/31 tests passing (5 files)

---

## 1. Overview

Tests feature modules that bridge server and client: Document Editor, Information Panel, Reminder Sidebar, Tag Manager, and Timeline View.

---

## 2. Test Files

| File | Module | Tests | Status |
|------|--------|-------|--------|
| `client/src/components/InformationPanel.test.tsx` | Information Panel | 5 | ✅ Done |
| `client/src/components/DocumentEditor.test.tsx` | Editor features | 5 | ✅ Done |
| `client/src/components/ReminderSidebar.test.tsx` | Reminders panel | 8 | ✅ Done |
| `client/src/components/TagManager.test.tsx` | Tag panel | 5 | ✅ Done |
| `client/src/components/TimelineView.test.tsx` | Timeline panel | 8 | ✅ Done |
| **Total** | | **31** | **5 files, all passing** |

---

## 3. Key Tests

### InformationPanel (5 tests)
- Renders panel with file info
- Renders tags section
- Renders locations section
- Displays file metadata (name, path)
- Handles empty/missing data gracefully

### DocumentEditor (5 tests)
- Renders the editor without crashing
- Renders toolbar with formatting buttons (Bold, Italic, Underline)
- Renders the save button
- Calls onSave when save button is clicked
- Renders the InformationPanel sub-component

### ReminderSidebar (8 tests)
- Renders the header with Reminders title
- Renders empty state when no reminders exist
- Renders loading state
- Renders error state
- Renders the create reminder form
- Shows form validation error when title is missing
- Calls createReminder when form is valid
- Calls removeReminder when delete button is clicked

### TagManager (5 tests)
- Renders tag list with all tags
- Displays active file tags
- Creates a new tag when form is submitted
- Deletes a tag after confirmation
- Filters files by tag when tag is clicked

### TimelineView (8 tests)
- Renders timeline entries
- Renders empty state when no entries
- Renders loading state
- Expands/collapses entry details
- Drag reorders entries
- Adds new entry
- Deletes entry
- Calls onFileSelect for file links

---

## 4. Skipped Components

| Component | Reason |
|-----------|--------|
| `LLMProviderSelector.test.ts` | Component doesn't exist — LLM provider selection is inline in settings |
| `LLMConfigPanel.test.ts` | Component doesn't exist — LLM config is inline in settings |
| `RemindersManager.test.ts` | Replaced by `ReminderSidebar` component |
| `StoryTimeline.test.ts` | Replaced by `TimelineView` component |
| `InfoPanelTagEditor.test.tsx` | Tag editing covered by `TagManager` test |
| `InfoPanelLocationEditor.test.tsx` | Component doesn't exist as separate file |

---

## 5. Mock Strategy

### TipTap Mocking (DocumentEditor)
```ts
vi.mock('@tiptap/react', () => {
  const mockChain = { run: vi.fn(), focus: vi.fn(), insertContent: vi.fn().mockReturnThis() };
  const mockCanChain = { undo: vi.fn().mockReturnValue(false), redo: vi.fn().mockReturnValue(false) };
  const mockCommands = { focus: vi.fn(), insertContent: vi.fn(), undo: vi.fn(), redo: vi.fn(),
    toggleBold: vi.fn(), toggleItalic: vi.fn(), toggleUnderline: vi.fn(),
    toggleBulletList: vi.fn(), toggleOrderedList: vi.fn(), toggleHeading: vi.fn(),
    createParagraphNear: vi.fn(), setContent: vi.fn(), clearContent: vi.fn() };
  const mockEditor = {
    chain: vi.fn().mockReturnValue(mockChain),
    focus: vi.fn(), setContent: vi.fn(), getHTML: vi.fn(), getText: vi.fn(),
    isActive: vi.fn(), isFocused: vi.fn(), can: vi.fn().mockReturnValue(mockCanChain),
    commands: mockCommands, state: { doc: {}, selection: {} },
    view: { dispatch: vi.fn(), props: {} }, on: vi.fn(), off: vi.fn(), destroy: vi.fn(),
  };
  return { useEditor: vi.fn().mockReturnValue(mockEditor), EditorContent, BubbleMenu, FloatingMenu };
});
```

### Icon Mocking (lucide-react)
```ts
vi.mock('lucide-react', () => {
  const icons: Record<string, React.FC> = {};
  for (const n of iconNames) {
    icons[n] = vi.fn((props: any) => <svg data-testid={n} {...props} />);
  }
  return icons;
});
```

### Hook Mocking
```ts
vi.mock('../hooks/useReminders', () => ({
  useReminders: () => mockUseReminders(),
}));
```

### Key Patterns
- **TipTap mocking:** Full editor mock with chain(), commands, and can() return values
- **Icon mocking:** Generic SVG with data-testid for icon name lookup
- **Container-based querying:** Use `container.querySelectorAll()` for complex selectors where screen.getByRole fails due to duplicate elements
- **Group expand pattern:** Click group header button first, then wait for child elements before interacting
- **Sub-component mocking:** Mock heavy sub-components (TagInsertControl, InformationPanel, WikiLinkPopover) to isolate tests

---

## 6. Bugs Fixed During Testing

| File | Issue | Fix |
|------|-------|-----|
| `DocumentEditor.test.tsx` | Missing `can()` chain return value caused `TypeError: Cannot read properties of undefined (reading 'undo')` | Added `mockCanChain` object returned by `can()` mock |
| `DocumentEditor.test.tsx` | Missing `commands.setContent` caused `TypeError: mainEditor.commands.setContent is not a function` | Added `setContent` and `clearContent` to mockCommands |
| `ReminderSidebar.test.tsx` | `getAllByTitle('Delete')` failed because lucide-react wasn't mocked | Added lucide-react mock with data-testid icons |
| `ReminderSidebar.test.tsx` | Delete button not found — reminders are in collapsible file groups | Click group header button first, then locate Trash2 icon |
| `TagManager.test.tsx` | `getByText('lore')` failed — "Found multiple elements" | Used `container.querySelectorAll('.tag-filter-btn')` with textContent check |
| `TagManager.test.tsx` | `getByRole('button', { name: 'Add Tag' })` failed | Used `container.querySelector('button.tag-add-btn')` (title attr) |

---

## 7. Verification

- [x] All feature module tests pass (31/31)
- [x] State transitions correct
- [x] Error paths covered
- [x] Mock strategy documented
- [x] Bug fixes documented

---

## 8. Next Phase

Proceed to **PHASE_6_COMPONENT_SMOKE_TESTS.md**.