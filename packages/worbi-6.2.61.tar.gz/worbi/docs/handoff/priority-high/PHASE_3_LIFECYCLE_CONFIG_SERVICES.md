# Phase 3: Lifecycle, Config & Supporting Services Tests

**Target Version:** v6.2.40
**Priority:** Medium (infrastructure services)
**Dependencies:** Phase 0, Phase 1, Phase 2
**Supersedes:** Remaining server service tests from TEST_SUITE_SETUP.md
**Status:** ✅ COMPLETE (v6.2.40)

---

## 1. Problem Statement

Beyond the core CRUD services, WORBI has several supporting services:
- **llmLifecycle** — Starts/stops the LLM server process
- **llmDetector** — Auto-detects local LLM providers (Ollama, LM Studio)
- **imageGenLifecycle** — Starts/stops the image generation server
- **providerCatalog** — Registry of LLM providers (local + cloud)
- **templateService** — Document templates, story bible, wiki-link resolution

These are tested with mocked `child_process.spawn` and real network behavior (no local LLM servers running in test env).

---

## 2. Test Files

| File | Service | Tests |
|------|---------|-------|
| `server/tests/unit/services/llmLifecycle.test.ts` | llmLifecycle | 11 |
| `server/tests/unit/services/llmDetector.test.ts` | llmDetector | 10 |
| `server/tests/unit/services/imageGenLifecycle.test.ts` | imageGenLifecycle | 9 |
| `server/tests/unit/services/providerCatalog.test.ts` | providerCatalog | 14 |
| `server/tests/unit/services/templateService.test.ts` | templateService | 23 |
| `server/tests/integration/graph.test.ts` | graph routes | 6 |
| `server/tests/integration/timeline.test.ts` | timeline routes | 8 |
| `server/tests/integration/imageGeneration.test.ts` | image gen routes | 12 |
| `server/tests/integration/settings.test.ts` | settings routes | 7 |
| **Total** | | **99 tests** |

---

## 3. LLM Lifecycle Tests

**Mock:** `child_process.spawn` via `vi.spyOn(cp, 'spawn')`

- `startServer()` spawns the zllm-start script with correct args
- `startServer()` resolves when server health check passes
- `startServer()` throws when server not ready after timeout
- `startServer()` returns already-running state when server up
- `stopServer()` spawns the zllm-stop script
- `stopServer()` returns success:true when stop script exits 0
- `stopServer()` returns success:false when stop script fails
- `isRunning()` returns true when process exists
- `isRunning()` returns false when process not found
- `isRunning()` uses health check HTTP request
- Process events (exit, close, error) are handled without crashing

---

## 4. LLM Detector Tests

**Approach:** Real network behavior (no mocking `fetch` — no local LLM servers run in test env, so all probes fail and validate the `notDetected` code path)

- Returns result object with `detected` and `notDetected` arrays
- Marks all providers as `notDetected` when no local servers running
- `notDetected` providers have correct shape (id, name, url)
- Deduplicates providers by port (first provider per port wins)
- Filters out providers with null/undefined ports (e.g., `custom-local`)
- Caches results — second call within TTL does not re-probe
- `detected` providers have correct shape with models array
- `defaultModel` is first model in the list
- `clearCache()` allows results to be re-probed after invalidation
- `clearCache()` can be called multiple times safely

---

## 5. Image Gen Lifecycle Tests

**Mock:** `child_process.spawn` via `vi.spyOn(cp, 'spawn')`

- `startServer()` spawns the zimage-start script
- `startServer()` resolves when server health check passes
- `startServer()` throws when server not ready after timeout
- `startServer()` returns already-running state when server up
- `stopServer()` spawns the zimage-stop script
- `stopServer()` returns success:true when stop script exits 0
- `stopServer()` returns success:false when stop script fails
- `isRunning()` returns true when server is up
- `isRunning()` returns false when server is down

---

## 6. Provider Catalog Tests

**No mocks needed** — pure data functions.

- `getLocalProviders()` returns local provider list
- `getCloudProviders()` returns cloud provider list
- `getAllProviders()` returns combined list
- `getProviderById()` returns single provider by ID
- `getProviderById()` returns undefined for non-existent ID
- Local providers have correct shape (id, name, defaultUrl, defaultPort, etc.)
- Cloud providers have correct shape
- `custom-local` provider has no default port (port: null)
- Provider IDs are unique across all providers
- `getAllProviders()` contains all local + cloud providers
- Provider count is correct
- Local providers include `ollama`, `lmstudio`, `llamacpp`, etc.
- Cloud providers include `openai`, `anthropic`, `google`, etc.
- `custom-local` has type 'openai' for OpenAI-compatible custom servers
- Providers have consistent required fields

---

## 7. Template Service Tests

**Mock:** Filesystem via temp workspace + `createTestFile()`

- `getAvailableTemplates()` returns template list
- `getAvailableTemplates()` returns empty when templates dir missing
- `sanitizeName()` removes invalid characters
- `sanitizeName()` handles edge cases (empty, special chars)
- `findUniqueFileName()` returns name when no conflict
- `findUniqueFileName()` appends counter on conflict
- `createFromTemplate()` creates file from template HTML
- `createFromTemplate()` replaces {{TITLE}} placeholder
- `compileStoryBible()` aggregates story data
- `compileStoryBible()` returns empty when no story files
- `extractTitle()` pulls title from HTML `<title>` tag
- `extractTitle()` returns filename when no title tag
- `stripMarginNotes()` removes margin note annotations
- `resolveWikiLinks()` resolves internal links
- `resolveWikiLinks()` returns content unchanged when no links
- Edge cases: empty content, multiple replacements, nested paths

---

## 8. Integration Tests

### Graph Routes (`/api/llm/graph/*`)
- `GET /api/llm/graph/eras` — returns 401 without auth
- `GET /api/llm/graph/eras` — returns 200 with eras array when authenticated
- `POST /api/llm/graph/from-seed` — returns 401 without auth
- `POST /api/llm/graph/from-seed` — returns 400 when seedPath missing
- `POST /api/llm/graph/from-seed` — returns 400 when seedPath does not exist
- `POST /api/llm/graph/from-seed` — handles empty workspace

### Timeline Routes (`/api/files/timeline*`)
- `GET /api/files/timeline` — returns 401 without auth
- `GET /api/files/timeline` — returns 200 with eras array when authenticated
- `GET /api/files/timeline/suggest-date?era=X` — returns 401 without auth
- `GET /api/files/timeline/suggest-date?era=X` — returns suggested date
- `PUT /api/files/timeline/metadata` — returns 401 without auth
- `PUT /api/files/timeline/metadata` — returns 400 when filePath/metadata missing
- `PUT /api/files/timeline/metadata` — persists and retrieves metadata
- `PUT /api/files/timeline/metadata` — deletes keys set to empty string

### Image Generation Routes (`/api/llm/*`)
- `GET /api/llm/image-generation/status` — returns 401 without auth
- `GET /api/llm/image-generation/status` — returns 200 with running status
- `GET /api/llm/image-generation/progress` — returns 401 without auth
- `GET /api/llm/image-generation/progress` — returns 200 when authenticated
- `POST /api/llm/image-generation/test` — returns 401 without auth
- `POST /api/llm/image-generation/test` — returns 200 when authenticated
- `POST /api/llm/image-generation/start` — returns 401 without auth
- `POST /api/llm/image-generation/start` — returns 200 when authenticated
- `POST /api/llm/image-generation/stop` — returns 401 without auth
- `POST /api/llm/image-generation/stop` — returns 200 when authenticated
- `POST /api/llm/generate-image` — returns 401 without auth
- `POST /api/llm/generate-image` — returns 400 when prompt missing

### Settings Routes (`/api/settings*`)
- `GET /api/settings` — returns 401 without auth
- `GET /api/settings` — returns 200 with settings object
- `POST /api/settings/user` — returns 401 without auth
- `POST /api/settings/user` — returns 200 and updates settings
- `POST /api/settings/user` — persists settings across requests
- `POST /api/settings/test` — returns 401 without auth
- `POST /api/settings/test` — returns 200 when authenticated

---

## 9. Mock Strategy

| Service | What to Mock | How |
|---------|-------------|-----|
| llmLifecycle | child_process.spawn | `vi.spyOn(cp, 'spawn').mockReturnValue(mockChildProcess)` |
| llmDetector | **None** — real fetch behavior (no local LLM servers in test env, validates notDetected path) | No mocks needed |
| imageGenLifecycle | child_process.spawn | `vi.spyOn(cp, 'spawn').mockReturnValue(mockChildProcess)` |
| providerCatalog | None (pure data) | No mocks needed |
| templateService | Filesystem (templates dir) | Temp workspace + `createTestFile()` |
| All integration tests | Express app + auth | `getTestApp()` + `getAuthedApp()` helpers |

---

## 10. Verification Checklist

- [x] All lifecycle service tests pass (11 tests)
- [x] All detector tests pass (10 tests)
- [x] All provider catalog tests pass (14 tests)
- [x] All template service tests pass (23 tests)
- [x] All integration tests pass (32 tests)
- [x] No spawned processes leak after tests
- [x] Total: 99 tests passing across 9 test files

---

## 11. Configuration Changes

### vitest.config.ts
Added `~` resolve alias to enable clean imports in tests:
```ts
resolve: {
  alias: {
    '~': '/home/nymph/Nymphs-Brain/WORBI/server/src',
  },
},
```

### tests/setup.ts
Added `net.isIPv6` mock to prevent test failures in containerized environments:
```ts
vi.mock('node:net', async (importOriginal) => {
  const net = await importOriginal<typeof import('node:net')>();
  return { ...net, isIPv6: vi.fn(() => false) };
});
```

---

## 12. Next Phase

After all server tests pass, proceed to **PHASE_4_CLIENT_HOOKS.md**.