# Phase 4: Client Hook Tests

**Target Version:** v6.2.40
**Priority:** High (client state management)
**Dependencies:** Phase 0-3
**Status:** ✅ COMPLETE — 72/72 tests passing (8 files)

---

## 1. Overview

Tests all client React hooks that manage state. Mock `services/api` calls.

---

## 2. Test Files

| File | Hook | Tests | Status |
|------|------|-------|--------|
| `client/src/hooks/useAuth.test.ts` | useAuth | 10 | ✅ Done |
| `client/src/hooks/useFileSystemUndoRedo.test.ts` | useFileSystemUndoRedo | 10 | ✅ Done |
| `client/src/hooks/useRecents.test.ts` | useRecents | 12 | ✅ Done |
| `client/src/hooks/useTags.test.ts` | useTags, useFileTags | 10 | ✅ Done |
| `client/src/hooks/useSearch.test.ts` | useSearch | 5 | ✅ Done |
| `client/src/hooks/useLLM.test.ts` | useLLM | 10 | ✅ Done |
| `client/src/hooks/useReminders.test.ts` | useReminders | 7 | ✅ Done |
| `client/src/hooks/useLocations.test.ts` | useLocations, useFileLocations | 8 | ✅ Done |
| `client/src/hooks/useFiles.test.ts` | useFiles | — | ⏸ Skipped (complex dependencies) |
| `client/src/hooks/useTimeline.test.ts` | useTimeline | — | ❌ N/A (hook doesn't exist) |
| `client/src/hooks/useImageSettings.test.ts` | useImageSettings | — | ⏸ Skipped |
| **Total** | | **72** | **8 files, all passing** |

---

## 3. Key Test Patterns

### useAuth (10 tests)
- Initial: not authenticated, user null
- `login()`: calls API, sets user+token in localStorage
- `logout()`: clears user+token
- Token loaded from localStorage on mount
- Expired token detected, auto logout
- Error states on login failure
- User object populated after login

### useFileSystemUndoRedo (10 tests)
- Push create op, undo removes file
- Redo recreates
- Multiple ops undone in reverse order
- Push after undo clears redo stack
- Cannot undo/redo when empty
- Clear empties both stacks
- refreshRef callback called after undo

### useRecents (12 tests)
- `addRecentFile()` adds, most recent first
- Same file moved to top (no duplicate)
- Capped at limit (50)
- `toggleStar()` add/remove
- Persists in localStorage
- `clearRecents()` empties list
- `removeRecentFile()` removes single entry
- Starred list managed separately

### useTags (10 tests)
- `useTags`: load tags on mount, CRUD operations, get color by name, error handling
- `useFileTags`: load file tags, empty when path null, add/remove tags

### useSearch (5 tests)
- Initial state: empty query/results
- Search triggers after debounce (300ms), returns results
- Empty query clears results synchronously
- Error on search failure
- Query state updates correctly

### useLLM (10 tests)
- Load settings on mount, health check via detect endpoint
- Health check failure sets `llmConnected=false`
- `sendMessage()` adds to chat history
- Error when sendChat fails
- `clearChat()` empties history
- `testConn()` tests connection
- `loadModels()` fetches and sets model list
- `updateSettings()` updates partial settings
- `aiOffline` derived state correct
- Settings fetch failure handled

### useReminders (7 tests)
- Load reminders on mount
- `createReminder()` adds new reminder
- `removeReminder()` deletes by ID
- Error handling on fetch failure
- `checkFired()` shows toast notifications for fired reminders
- Active/completed grouping based on status
- `dismissToast()` marks toast dismissed

### useLocations (8 tests)
- `useLocations`: load on mount, CRUD, get color by name, error handling
- `useFileLocations`: load file locations, empty when path null

---

## 4. Mock Strategy

```ts
vi.mock('../services/api', async () => ({
  getFiles: vi.fn(),
  readFile: vi.fn(),
  // ... all API functions used by the hook
}));

import * as api from '../services/api';
const mockGetFiles = api.getFiles as ReturnType<typeof vi.fn>;
mockGetFiles.mockResolvedValue([...]);
```

**Key patterns:**
- **API mocking:** `vi.mock('../services/api', async () => ({ ... }))` with `vi.fn()` stubs
- **Fetch mocking:** `vi.spyOn(global, 'fetch').mockResolvedValueOnce(...)` per test (use `mockResolvedValueOnce` not `mockResolvedValue` to avoid test interference)
- **Utility mocking:** `vi.mock('../utils/tokenCounter', () => ({ ... }))` for pure functions
- **Fake timers:** Avoided — use real timers with `waitFor` instead of `vi.useFakeTimers()` (fake timers interfere with async promise resolution in React Testing Library)
- **BeforeEach:** `vi.clearAllMocks()` + set default resolved values
- **AfterEach:** `vi.restoreAllMocks()` only when global spies used at module scope

---

## 5. Skipped Hooks

| Hook | Reason |
|------|--------|
| `useFiles` | Complex dependencies (tabs, undo stack, file system state) — requires integration test infrastructure |
| `useImageSettings` | Minimal state logic, covered by component tests |
| `useTimeline` | Hook file doesn't exist in codebase |

---

## 6. Verification

- [x] All hook tests pass (72/72)
- [x] State transitions correct
- [x] localStorage persistence verified
- [x] Error paths covered
- [x] Mock strategy documented

---

## 7. Next Phase

Proceed to **PHASE_5_FEATURE_MODULES.md**.