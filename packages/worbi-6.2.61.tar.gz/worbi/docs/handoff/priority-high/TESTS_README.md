# WORBI Tests — Plain English Guide

> What are these tests, why do they exist, and how do they help you build WORBI?

---

## The Short Version

WORBI has a collection of **automated tests** — small programs that check whether other programs work correctly. You run them, they either pass (green ✓) or fail (red ✗). Green means your code works. Red means you broke something.

Right now there are **~488 tests** covering the server, the client, and the API. They run in about a second.

---

## Why Bother?

Imagine you're refactoring the file service to fix a bug. Without tests, you'd need to:

1. Manually create a file
2. Manually rename it
3. Manually delete it
4. Manually check the tags still work
5. Manually verify the AI can still read it
6. Manually test that auth still works
7. Repeat after every change

**With tests:** you type `npm test`, wait a second, and instantly know if anything is broken. This gives you **confidence to change code** without fearing you'll break something invisible.

---

## How It Works (No Jargon)

### The Test Runner: Vitest

Think of Vitest as a **checker**. You give it a list of things to check, and it runs them all and tells you which ones passed and which failed. It's fast (runs in ~1 second) and works with both our server (JavaScript) and client (TypeScript/React).

### Two Sides to Test

WORBI has two halves, and each half gets tested differently:

| Half | What it is | How we test it |
|------|-----------|----------------|
| **Server** | Node.js backend — files, auth, LLM, tags, reminders | Unit tests (check one function) + Integration tests (check full API calls) |
| **Client** | React frontend — hooks, components, UI | Hook tests (check state logic) + Component tests (check rendering) |

---

## Test Types Explained

### 1. Unit Tests — "Does This One Function Work?"

A unit test checks a single function in isolation.

**Example:** Does `getSafePath()` block someone from reading `/etc/passwd`?

```
Test: try to escape the workspace using "../.."
Expected: it should throw an error
Result: ✓ PASS — the guard works
```

**Why it helps:** You can change the inside of `getSafePath()` with confidence. If the test still passes, the guard still works.

### 2. Integration Tests — "Do These Functions Work Together?"

An integration test checks that the full API endpoint works end-to-end.

**Example:** Can you actually `POST /api/auth/login` and get a token?

```
Test: send a login request with username "testuser"
Expected: get back a 200 status with a JWT token
Result: ✓ PASS — the login endpoint works
```

**Why it helps:** Catches bugs that only appear when the middleware, route handler, and service all work together.

### 3. Hook Tests — "Does This Piece of State Logic Work?"

React hooks manage state (login status, file lists, tag lists). Hook tests check that state changes correctly.

**Example:** After calling `login()`, does `isAuthenticated` become `true`?

```
Test: render the useAuth hook, call login("user")
Expected: isAuthenticated goes from false → true
Result: ✓ PASS — login updates state correctly
```

**Why it helps:** You can refactor hook internals without breaking the state transitions.

### 4. Component Smoke Tests — "Does This UI Render Without Crashing?"

The simplest test: render the component and check it doesn't explode.

**Example:** Does `<StatusBar />` show up on screen?

```
Test: render <StatusBar />
Expected: it renders without throwing an error
Result: ✓ PASS — the component renders
```

**Why it helps:** Catches breaking changes from prop renames, missing dependencies, or API changes before a human notices.

---

## The 8 Phases (What's Tested)

The tests are organized into 8 phases, from most critical to least:

| Phase | What it Tests | Why it Matters |
|-------|---------------|----------------|
| **0** | Test infrastructure itself | Foundation — configs, helpers, mock tools |
| **1** | Security (path traversal, auth) | **Critical** — prevents file escapes and unauthorized access |
| **2** | Core services (files, tags, tools, LLM, reminders, locations) | **High** — the main business logic |
| **3** | Supporting services (lifecycle, config, templates) | **Medium** — LLM server management, provider catalog |
| **4** | Client hooks (useAuth, useTags, useSearch, etc.) | **High** — client state management |
| **5** | Feature modules (Editor, InfoPanel, Reminders, Timeline) | **Medium** — feature-specific UI logic |
| **6** | Component smoke tests (StatusBar, Header, etc.) | **Low** — regression safety net |
| **7** | TipTap extensions + utilities | **Low** — editor features, token counting |
| **8** | Coverage tracking + CI setup | **Quality gate** — measures how much code is covered |

---

## How to Use Them

### Before You Make Changes

```bash
npm test          # Run all tests — make sure they're green first
npm run test:server   # Server tests only
npm run test:client   # Client tests only
```

If tests are already red, fix those first. You need a clean baseline.

### While You Make Changes

```bash
npm run test:watch    # Auto-reruns tests when you save a file
```

This gives you instant feedback as you code. Red = stop and fix. Green = keep going.

### After You Make Changes

```bash
npm test              # Full suite — make sure nothing broke
npm run test:coverage # See what percentage of code is covered by tests
```

### When Adding a New Feature

1. Write the tests **before** or **alongside** the code
2. Place server tests in `server/tests/unit/services/` or `server/tests/integration/`
3. Place client tests in `client/src/hooks/` or `client/src/components/`
4. Run `npm test` to verify

---

## The "Mock" Concept (Simple Explanation)

A **mock** is a fake version of a dependency.

**Why use fakes?** Real testing would require:
- A real filesystem (slow, leaves files behind)
- A real LLM server (slow, costs money, might be offline)
- A real database (slow, shared state between tests)

Instead, we **fake** these dependencies so tests are:
- **Fast** — no real I/O
- **Reliable** — same result every time
- **Clean** — no leftover files or database entries

**Example:** Testing the LLM service without calling a real LLM server:

```
Real way: send request → wait for AI response → check answer (slow, unreliable)
Mock way: fake the HTTP call → return "test response" → check answer (fast, reliable)
```

---

## What the Numbers Mean

### Coverage

Coverage tells you **what percentage of your code is exercised by tests**:

| Metric | What it means | Current |
|--------|--------------|---------|
| Lines | 33% of code lines run during tests | 33% |
| Functions | 47% of functions are called by tests | 47% |

**This is a starting point, not a target.** The goal is to ratchet these up over time as more tests are added.

### Critical Paths = 100%

Some code is too important to leave untested:
- **Path traversal guards** — must never allow file escapes
- **Auth** — must never let unauthorized users in
- **File operations** — must not corrupt or lose data

These functions have comprehensive test coverage.

---

## Common Questions

**"Do I need to write tests for every change?"**
Not every change, but every **new feature** should have tests. Bug fixes should include a test that reproduces the bug (so it never comes back).

**"What if a test fails?"**
Either your code is broken, or the test is wrong. Check which one. Most of the time it's your code.

**"Can I delete a test?"**
Only if the feature it tests is removed. Never delete a passing test because it's "inconvenient."

**"How long should tests take?"**
Under 10 seconds for the full suite. If tests are slow, you won't run them. If you don't run them, they don't help.

---

## Quick Reference

```bash
# Run all tests
npm test

# Run only server tests
npm run test:server

# Run only client tests
npm run test:client

# Run in watch mode (auto-rerun on file changes)
npm run test:watch

# Run with coverage report
npm run test:coverage
```

---

## Files You Might Need

| File | What it is |
|------|-----------|
| `vitest.config.ts` (root) | Main test config |
| `server/vitest.config.ts` | Server test config |
| `client/vitest.config.ts` | Client test config |
| `server/tests/helpers/` | Server test helpers (auth, filesystem) |
| `client/tests/helpers/` | Client test helpers (TipTap mocks) |
| `PHASE_*.md` (this folder) | Detailed test case specs for each phase |

For detailed patterns, mock strategies, and gotchas, see the `worbi-tests` skill file.