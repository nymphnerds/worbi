# Phase 2: Core Services Tests

**Target Version:** v6.2.49
**Status:** ✅ Complete (2026-05-05)
**Priority:** High (correctness & data integrity)
**Dependencies:** Phase 0 (Test Infrastructure), Phase 1 (Security Tests)
**Supersedes:** Phase 3 (High-Priority Service Tests) from TEST_SUITE_SETUP.md

---

## 1. Problem Statement

The core business logic of WORBI lives in six server services. Without tests, any refactoring risks:
- **fileService** — Data loss (file/folder operations, search)
- **tagService** — Tag corruption (CRUD, file associations, relationships)
- **toolService** — Incorrect AI tool execution (8 tools, permission gating)
- **llmService** — Broken tool-calling loop, incorrect prompt construction
- **reminderService** — Reminders not firing, threading broken
- **locationService** — Location metadata corruption

This phase tests all six services with comprehensive unit tests and file/reminder integration tests.

---

## 2. Test Files Overview

| File | Service | Estimated | Actual |
|------|---------|-----------|--------|
| `server/tests/unit/services/fileService.test.ts` | fileService | ~40 | **63** |
| `server/tests/unit/services/tagService.test.ts` | tagService | ~25 | **32** |
| `server/tests/unit/services/toolService.test.ts` | toolService | ~35 | **31** |
| `server/tests/unit/services/llmService.test.ts` | llmService | ~20 | **21** |
| `server/tests/unit/services/reminderService.test.ts` | reminderService | ~20 | **35** |
| `server/tests/unit/services/locationService.test.ts` | locationService | ~15 | **24** |
| `server/tests/integration/files.test.ts` | files routes | ~15 | **23** |
| `server/tests/integration/reminders.test.ts` | reminder routes | ~10 | **17** |
| **Total** | | **~180 tests** | **246 tests** |

---

## 3. File Service Tests (Extended)

**File:** `server/tests/unit/services/fileService.test.ts` (append to path traversal tests from Phase 1)

### 3.1 Directory Listing
- `listDirectory()` lists files/folders with correct type field
- Returns empty array for empty directory
- Direct children only (not recursive)
- Files include size, folders exclude size
- Subdirectory listing when path provided
- Throws for non-existent path

### 3.2 File Read/Write
- `readFile()` returns correct content; throws on directory; throws on missing
- `writeFile()` creates with auto-parent-dir; overwrites; content matches

### 3.3 Folder Operations
- `createFolder()` creates; throws if exists; nested with recursive

### 3.4 Delete
- `deleteItem()` deletes file; deletes empty folder; deletes folder recursively; throws if not found

### 3.5 Rename / Copy / Move
- `renameItem()` renames file/folder; throws if source missing or dest exists
- `copyItem()` copies with "-copy" suffix; copies across dirs; throws on conflicts
- `moveItem()` moves; source gone; dest correct; throws on errors

### 3.6 Search
- `searchWorkspace()` matches filename; matches content; returns context; respects limit; skips binary; handles empty/no-match

### 3.7 Recents / Starred
- `saveUserRecents`/`loadUserRecents` persist and retrieve
- `saveUserStarred`/`loadUserStarred` persist and retrieve

---

## 4. Tag Service Tests

**File:** `server/tests/unit/services/tagService.test.ts`

### 4.1 Tag CRUD
- `getAllTags()` returns all / empty array
- `createTag()` with name+color / name+color+desc; throws on duplicate
- `updateTag()` name, color, description; throws if not found
- `deleteTag()` deletes; cascade deletes associations; throws if not found

### 4.2 File-Tag Associations
- `getFileTags()` returns tags / empty array
- `addTagsToFile()` single / multiple / idempotent
- `removeTagFromFile()` removes / no-op if not present

### 4.3 Queries
- `getFilesByTag()` returns files / empty array
- `getFileRelationships()` shared-tag relationships / empty
- `listDirectoryWithTags()` entries with tag annotations

---

## 5. Tool Service Tests

**File:** `server/tests/unit/services/toolService.test.ts` (append to path traversal tests from Phase 1)

### 5.1 Tool Execution (Mock axios for web_search)
- `web_search` returns formatted results
- `read_file` returns content / throws "not found" / throws traversal
- `list_directory` returns formatted listing
- `write_file` creates file
- `edit_file` replaces text / throws "not found"
- `create_folder` creates / throws if exists
- `delete_file` deletes / throws for critical files (root README.md) / allows subdirectory README.md / throws for directories
- `rename_file` renames / throws for directories
- Unknown tool throws "Unknown tool"

### 5.2 Permission Gating — `getToolDefinitions()`
- `{webSearch: true, fileAccessLevel: 'read'}` → web_search, read_file, list_directory
- `{webSearch: false, fileAccessLevel: 'readwrite', allowCreate: true, allowEdit: true}` → read+write+create+edit (no web_search, no delete/rename)
- `{webSearch: true, fileAccessLevel: 'full', allowDelete: true, allowRename: true}` → all 8 tools
- `{fileAccessLevel: 'none'}` → empty array (or web_search only if enabled)

---

## 6. LLM Service Tests

**File:** `server/tests/unit/services/llmService.test.ts`

**Mock:** All `axios` HTTP calls to LLM server (mock responses for chat, models, health)

### 6.1 Chat
- `sendChatMessage()` sends messages, returns assistant response
- Includes document content in system prompt
- Includes custom system prompt when provided
- Returns tool activity when tools used

### 6.2 Tool-Calling Loop
- Single tool call: LLM requests tool → tool returns → LLM gets results → final answer
- Multiple tools in sequence: read_file → web_search → final answer
- Tool call error: tool throws → error returned to LLM → final answer
- Max turns reached: after MAX_TOOL_TURNS iterations, returns limit message
- No tools enabled: zero tool definitions → no tools sent
- Tool activity tracking: correct status transitions (running → complete/error)

### 6.3 Other Functions
- `fetchModels()` returns list / throws on error
- `testConnection()` returns success / failure
- `getSystemInfo()` extracts model name, reports server status
- `sendCompletion()` sends completion request
- `generateDocument()` generates document content
- `transcribeImage()` transcribes image

---

## 7. Reminder Service Tests

**File:** `server/tests/unit/services/reminderService.test.ts`

### 7.1 CRUD
- `getAllReminders()` returns all reminders
- `createReminder()` creates with file, title, date-time
- `updateReminder()` updates fields
- `deleteReminder()` removes

### 7.2 Threading
- `addThreadNote()` adds note to reminder thread
- Thread notes persist and retrieve correctly

### 7.3 Firing
- `checkAndFireReminders()` fires overdue reminders
- Fired reminders marked correctly
- `advanceRecurringReminders()` advances next occurrence

### 7.4 File Association
- `getRemindersByFile()` returns reminders for a file
- Empty array for file with no reminders

---

## 8. Location Service Tests

**File:** `server/tests/unit/services/locationService.test.ts`

### 8.1 CRUD
- `getAllLocations()` returns all / empty
- `createLocation()` with name; throws on duplicate
- `updateLocation()` name, description; throws if not found
- `deleteLocation()` deletes; cascade deletes associations

### 8.2 File-Location Associations
- `getFileLocations()` returns locations / empty
- `addLocationsToFile()` adds; idempotent
- `removeLocationFromFile()` removes; no-op if absent

### 8.3 Queries
- `getFilesByLocation()` returns files / empty

---

## 9. Integration Tests

### 9.1 Files API

**File:** `server/tests/integration/files.test.ts`

- `GET /api/files/?path=` returns directory listing
- `GET /api/files/read?path=FILE` returns file content
- `POST /api/files/write` creates/overwrites file
- `POST /api/files/folder` creates folder
- `DELETE /api/files/?path=ITEM` deletes item
- `POST /api/files/rename` renames
- `POST /api/files/copy` copies
- `POST /api/files/move` moves
- `GET /api/files/search?q=QUERY` returns search results
- `POST /api/files/:path/tags` adds tags to file
- `DELETE /api/files/:path/tags/:tagId` removes tag

### 9.2 Reminders API

**File:** `server/tests/integration/reminders.test.ts`

- `GET /api/reminders` returns all reminders
- `POST /api/reminders` creates reminder
- `PUT /api/reminders/:id` updates reminder
- `DELETE /api/reminders/:id` deletes reminder
- `POST /api/reminders/:id/thread` adds thread note
- `GET /api/reminders?file=PATH` filters by file

---

## 10. Implementation Notes & Patterns

### 10.1 Mock Strategy Refinement
Several mocking patterns required iteration to discover the correct approach:

- **`vi.mocked()` for LLM service** — The `llmService` tests required 4+ iterations. `vi.spyOn(axios, 'get')` alone was insufficient because the service imports axios directly. The solution: `vi.mock()` the config module, then use `vi.mocked()` to type the mocked axios exports for proper TypeScript support.
- **Config mock pattern** — Mock `config.js` with default LLM settings before importing the service to ensure consistent test environment:
  ```js
  vi.mock('../../config', () => ({
    default: { llmBaseUrl: 'http://localhost:8080', llmModel: 'test-model', llmApiKey: 'test-key' }
  }))
  ```
- **"No baseUrl" fallthrough** — `transcribeImage` and `sendChatMessage` fall back to `config.baseUrl` when no URL is provided, so tests for missing config must expect connection errors (network failure) rather than "No LLM base URL" string errors.

### 10.2 Filesystem Isolation
- **`createTempWorkspace()`** helper from `fsHelper` creates isolated temp directories for file/tag/tool service tests, preventing contamination of real workspace data.
- **`os.homedir()` mock** — The `locationService` reads from `~/.wbu/` by default. Tests mock `os.homedir()` to point to a temp directory, avoiding any interaction with the real user's `~/.wbu` directory.

### 10.3 Database Format
- All services use **newline-separated JSON** in database files (not valid JSON arrays). Each line is a separate JSON object. Tests must write/read this format, not `JSON.stringify()` entire arrays.

### 10.4 Small-Change Delegation Pattern
- Create `.new` copy of test file first, test it independently, then `cp` to final name. This prevents partial file writes from breaking the test suite mid-development.

---

## 11. Mock Strategy

| Service | What to Mock | How |
|---------|-------------|-----|
| fileService | Filesystem (use temp dirs from fsHelper) | `createTempWorkspace()` |
| tagService | Database file path | Override data dir in test setup |
| toolService | axios (web_search HTTP) | `vi.spyOn(axios, 'get').mockResolvedValue(...)` |
| llmService | axios (all LLM HTTP) | `vi.spyOn(axios, ...).mockResolvedValue(...)` |
| reminderService | Database file path + Date.now() | Override data dir; mock `Date.now()` |
| locationService | Database file path | Override data dir in test setup |

---

## 12. Test Results Summary

```
 Test Files  11 passed (11)
      Tests  285 passed (285)
   Duration  ~900ms
```

Phase 2 contributed **246 tests** across 8 test files. Combined with Phase 1 (authService: 17, authMiddleware: 8, auth integration: 14), the full server test suite is **285 tests**.

| Test File | Tests | Status |
|-----------|-------|--------|
| fileService.test.ts | 63 | ✓ |
| tagService.test.ts | 32 | ✓ |
| toolService.test.ts | 31 | ✓ |
| llmService.test.ts | 21 | ✓ |
| reminderService.test.ts | 35 | ✓ |
| locationService.test.ts | 24 | ✓ |
| files.test.ts (integration) | 23 | ✓ |
| reminders.test.ts (integration) | 17 | ✓ |

---

## 13. Verification Checklist

- [x] All file service tests pass (63 tests)
- [x] All tag service tests pass (32 tests)
- [x] All tool service tests pass (31 tests)
- [x] All LLM service tests pass (21 tests)
- [x] All reminder service tests pass (35 tests)
- [x] All location service tests pass (24 tests)
- [x] All integration tests pass (40 tests)
- [x] No test data left in real server/data/ directory
- [x] Test suite completes in under 20 seconds (~900ms actual)

---

## 14. Next Phase

After all core service tests pass, proceed to **PHASE_3_LIFECYCLE_CONFIG_SERVICES.md**.