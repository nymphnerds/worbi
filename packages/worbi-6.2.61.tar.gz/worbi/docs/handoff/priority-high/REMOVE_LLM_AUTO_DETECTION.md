# Remove LLM Auto-Detection & Managed Server Lifecycle

**Created:** 2026-05-08
**Priority:** High
**Status:** Planned → Implementing

---

## Problem

The current LLM settings UI presents two connection modes: **Managed** (WORBI starts/stops the LLM server) and **External** (user-managed). The auto-detection system probes known local ports (8080, 8000, 11434, etc.) to detect running LLM servers. This causes issues:

1. **Port collisions** — `llama-server` commonly runs on 8000 (same as vLLM default), causing wrong detection
2. **Non-standard ports** — users running LLMs on custom ports are not detected
3. **VRAM management complexity** — auto-managing LLM start/stop across different servers is unreliable
4. **Confusing UX** — Managed vs External toggle confuses users about what WORBI controls

## Solution

Remove all auto-detection and managed server lifecycle. Treat **all** LLMs as external/user-controlled. The user manually enters their LLM URL, optional API key, selects a model, and tests the connection. Provider presets remain as convenient URL auto-fill helpers only.

---

## Files Involved

| # | File | Action |
|---|------|--------|
| 1 | `client/src/pages/Settings.tsx` | **Modify** — remove Managed/External toggle, remove server status panel |
| 2 | `server/src/routes/llm.js` | **Modify** — remove detection/lifecycle endpoints |
| 3 | `server/src/config.js` | **Modify** — remove managedLlmServers, simplify defaultUserSettings |
| 4 | `server/src/services/llmDetector.js` | **DELETE** |
| 5 | `server/src/services/llmLifecycle.js` | **DELETE** |
| 6 | `client/src/hooks/useLLM.ts` | **Modify** — simplify health check |
| 7 | `client/src/services/api.ts` | **Modify** — remove lifecycle API functions |

---

## Step-by-Step Implementation

### STEP 1: Delete `server/src/services/llmDetector.js`

**Action:** Delete the entire file.

This file handles port probing and auto-detection of local LLM servers. No longer needed.

### STEP 2: Delete `server/src/services/llmLifecycle.js`

**Action:** Delete the entire file.

This file handles starting/stopping LLM server binaries, health checks, GPU handoff coordination, and server detection. No longer needed.

### STEP 3: Modify `server/src/routes/llm.js`

**Remove imports (lines 6-8):**
```js
import { detectLocalProviders, clearCache } from '../services/llmDetector.js';
import * as llmLifecycle from '../services/llmLifecycle.js';
import * as imageGenLifecycle from '../services/imageGenLifecycle.js';
```

**Remove routes:**
- `GET /detect` (lines 17-30)
- `POST /detect/rescan` (lines 33-46)
- `GET /detect-servers` (lines 188-205)
- `GET /server/status` (lines 208-221)
- `POST /server/start` (lines 224-240)
- `POST /server/stop` (lines 243-256)
- `POST /gpu-handoff` (lines 293-369)
- Helper function `zImagePost` (lines 259-290) — only used by gpu-handoff

**Keep routes:**
- `GET /providers` — still needed for provider catalog (URL presets)
- `GET /models` — fetch models from user's configured URL
- `POST /complete` — creative writing completion
- `POST /generate-document` — document generation
- `POST /transcribe-image` — image transcription
- `POST /chat` — chat messages
- `GET /system-info` — deprecated but harmless, can keep or remove

### STEP 4: Modify `server/src/config.js`

**Remove `llmSettings` hardcoded block (lines 22-34):** No longer needed as a server-level default.

**Remove `lmsStartScript` (line 18):** Not used without managed lifecycle.

**Simplify `defaultUserSettings` (lines 39-77):**

**Before:**
```js
  llm: {
    mode: 'managed',         // 'managed' | 'external'
    folderPath: '',          // LLM installation folder
  },
  autoGpuHandoff: false,
  zImage: {
    baseUrl: '',
    mode: 'managed',
    folderPath: '',
  },
```

**After:**
```js
  zImage: {
    baseUrl: '',
  },
```

**Remove `managedLlmServers` object (lines 120-204):** Entire block defining 7 server types with search paths, ports, start/stop scripts.

**Update config export (lines 216-225):** Remove `managedLlmServers` and `lmsStartScript` from the exported `config` object.

### STEP 5: Modify `client/src/services/api.ts`

**Remove types (lines 1159-1187):**
```ts
export interface LlmServerStatus { ... }
export interface DetectedLlmServer { ... }
export interface GpuHandoffStage { ... }
export interface GpuHandoffResponse { ... }
```

**Remove functions (lines 1189-1244):**
- `getLlmServerStatus()`
- `detectLlmServers()`
- `startLlmServer()`
- `stopLlmServer()`
- `gpuHandoff()`

### STEP 6: Modify `client/src/hooks/useLLM.ts`

**Simplify `checkLlmHealth()` (lines 13-52):**

**Before:** Calls detect endpoint first, then falls back to models endpoint.

**After:** Only try fetching models from the configured URL:
```ts
async function checkLlmHealth(settings: LLMSettings): Promise<boolean> {
  try {
    if (!settings.baseUrl) return false;
    const token = localStorage.getItem('wbu_token');
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (token) headers['Authorization'] = `Bearer ${token}`;

    const modelsRes = await fetch(
      `/api/llm/models?baseUrl=${encodeURIComponent(settings.baseUrl)}&apiKey=${encodeURIComponent(settings.apiKey)}&serverType=${encodeURIComponent(settings.serverType)}`,
      { headers }
    );
    if (modelsRes.ok) {
      const modelsData = await modelsRes.json();
      return modelsData.models && modelsData.models.length > 0;
    }
    return false;
  } catch {
    return false;
  }
}
```

### STEP 7: Modify `client/src/pages/Settings.tsx`

This is the largest change. The LLM tab needs significant simplification.

**Remove state variables:**
- `llmMode` — managed/external toggle state
- `llmFolderPath` — LLM installation folder path
- `llmConfigSaved` — save confirmation state
- `llmServers` — detected server list
- `activeLlmServer` — currently active managed server

**Remove callback:**
- `saveLlmConfig()` — saves llm mode/folderPath to settings

**Remove helper function:**
- `providerToServerType()` — maps provider ID to server type string

**Remove UI sections:**
- **Connection Mode** toggle (Managed/External buttons and description text)
- **LLM Installation Folder** input + description + Save Configuration button
- **LlmServerStatusPanel** component (the entire managed server status panel at bottom)

**Simplify Connection section:**

**Current behavior:** URL field shown conditionally (only in External mode or Custom providers). API Key shown only for cloud/custom providers.

**New behavior:** 
- URL field **always visible** (pre-filled from provider selection, user can edit)
- API Key field shown for cloud providers + custom providers (not for local providers by default, but the provider catalog's `requiresApiKey` flag still controls visibility)
- Description text: "Configure your LLM connection below. Select a provider to auto-fill the URL, or enter a custom URL."

**New LLM Tab Layout (simplified):**

```
┌─ SETTINGS: LLM ──────────────────────────────┐
│                                               │
│ PROVIDER                                      │
│ [ Dropdown: llama.cpp | Ollama | ... ]       │
│ "Select a provider to auto-fill the URL       │
│  below, then configure your connection."      │
│                                               │
│ CONNECTION                                    │
│ Base URL: [ http://localhost:8080/v1     ]    │
│ "Enter the full URL to your LLM API endpoint" │
│                                               │
│ [Conditional] API Key: [_______________]      │
│                                               │
│ Test Connection  Save Settings                │
│                                               │
│ ────────────────────────────────────────────  │
│                                               │
│ MODEL                                         │
│ [ Dropdown: select model            ]  Load   │
│                                               │
│ ────────────────────────────────────────────  │
│                                               │
│ INFERENCE PARAMETERS                          │
│ Max Tokens, Context Window, Temperature, etc. │
│                                               │
│ ────────────────────────────────────────────  │
│                                               │
│ ADVANCED                                      │
│ System Prompt, Stop Sequences, Seed           │
│                                               │
└───────────────────────────────────────────────┘
```

**IMPORTANT:** When provider changes, auto-fill URL from provider catalog but do NOT change any "mode" — there is no mode anymore. The URL field is always editable.

### STEP 8: Check for remaining references

After making changes, search the entire codebase for references to:
- `llmDetector` — should be zero
- `llmLifecycle` — should be zero
- `managedLlmServers` — should be zero
- `detect-servers` — should be zero
- `gpu-handoff` — should be zero
- `getLlmServerStatus` — should be zero
- `startLlmServer` / `stopLlmServer` — should be zero
- `detectLlmServers` — should be zero
- `llm.mode` or `llm.folderPath` in settings — should be zero

---

## Settings Schema Changes

### Before
```json
{
  "providerId": "llamacpp",
  "serverType": "llama.cpp",
  "baseUrl": "http://localhost:8080/v1",
  "apiKey": "",
  "modelName": "",
  "llm": {
    "mode": "managed",
    "folderPath": ""
  },
  "zImage": {
    "baseUrl": "",
    "mode": "managed",
    "folderPath": ""
  },
  "autoGpuHandoff": false
}
```

### After
```json
{
  "providerId": "llamacpp",
  "serverType": "",
  "baseUrl": "http://localhost:8080/v1",
  "apiKey": "",
  "modelName": "",
  "zImage": {
    "baseUrl": ""
  }
}
```

**Migration:** Existing user settings files will have stale `llm`, `autoGpuHandoff`, and `zImage.mode/folderPath` fields. The simplified `defaultUserSettings` in `config.js` will NOT include these keys, so on next load, the spread merge `{...defaults, ...saved}` will keep the stale fields. This is harmless — they are simply ignored by the new UI. Optionally, a one-time cleanup can be added to strip them on save.

---

## Edge Cases

1. **User settings with old fields** — handled by spread merge; stale fields are ignored
2. **Orphaned localStorage keys** — `wbu_llm_mode`, `wbu_llm_folder` become harmless no-ops
3. **Z-Image without GPU handoff** — users on low VRAM must manually stop LLM before image gen; add a note in the Images tab
4. **Provider catalog still has `defaultPort`** — kept for URL auto-fill convenience, not used for detection
5. **`serverType` field** — kept in settings for backward compatibility (Ollama native API path), but no longer mapped from provider

---

## Verification Checklist

- [ ] `npx tsc --noEmit` passes with no errors
- [ ] Server starts without import errors (no references to deleted files)
- [ ] Settings LLM tab loads without errors
- [ ] Selecting a provider auto-fills the URL
- [ ] Test Connection works with a running LLM
- [ ] Models can be fetched from configured URL
- [ ] Chat works with configured LLM
- [ ] No console errors about missing imports
- [ ] No 404 errors for removed API endpoints

---

## What Stays the Same

- Provider catalog (`providerCatalog.js`) — still used as URL preset reference
- Model fetching from configured URL
- Test Connection button
- All inference parameters
- System prompt
- Tools tab, Editor tab, Appearance tab
- Z-Image image generation (without automatic GPU handoff)
- `imageGenLifecycle.js` — kept (Z-Image lifecycle management stays)