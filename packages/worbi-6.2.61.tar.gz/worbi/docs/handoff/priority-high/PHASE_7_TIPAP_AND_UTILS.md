# Phase 7: TipTap Extensions & Utility Tests

**Target Version:** v6.2.40
**Priority:** Low (pure functions, editor extensions)
**Dependencies:** Phase 0-6

## 1. Overview

Tests for TipTap custom extensions and utility functions. This phase also establishes the client-side test infrastructure (Vitest + Testing Library) since no client tests existed previously.

### Codebase Reality Check (5/7/2026)

The original Phase 7 spec referenced extensions and utilities that do not exist in the current codebase:
- **MarginNote** — Does not exist as a TipTap extension. Margin notes are implemented as `<!-- MARGIN_SPLIT -->` HTML comments in server-side `templateService.js`, not as a TipTap node/mark.
- **HeroImage** — Exists as a React component (`HeroImagePicker.tsx`), not as a TipTap extension.
- **Callout** — Does not exist anywhere in the codebase.
- **markdown.ts utils** — File does not exist.
- **theme.ts utils** — File does not exist.
- **proxyAuth** — No blob URL proxy endpoint exists on the server.

This document has been corrected to reflect the actual testable code.

## 2. Test Infrastructure Setup

**New files required:**

| File | Purpose |
|------|---------|
| `client/vitest.config.ts` | Vitest configuration (jsdom environment) |
| `client/test-setup.ts` | Testing Library + jest-dom setup |
| `client/package.json` | Add `vitest`, `@vitest/ui` devDeps + `"test"` script |

## 3. Test Files

| File | Module | Tests | Status |
|------|--------|-------|--------|
| `client/src/extensions/wikiLink.test.ts` | WikiLink extension + `parseWikiLinkText()` + `wikiLinkRegex` | ~5 | ✅ Implementable |
| `client/src/utils/storyFileDetector.test.ts` | Build/Template metadata detection | ~5 | ✅ Implementable |
| `client/src/utils/templateDetector.test.ts` | Template type detection from folder | ~5 | ✅ Implementable |
| `client/src/utils/tokenCounter.test.ts` | Token counting utilities | ~3 | ✅ Implementable |
| ~~`client/src/extensions/marginNote.test.ts`~~ | ~~MarginNote extension~~ | ~~~5~~ | ❌ SKIP — extension does not exist |
| ~~`client/src/extensions/heroImage.test.ts`~~ | ~~HeroImage extension~~ | ~~~3~~ | ❌ SKIP — not a TipTap extension |
| ~~`client/src/extensions/callout.test.ts`~~ | ~~Callout extension~~ | ~~~3~~ | ❌ SKIP — does not exist |
| ~~`client/src/utils/markdown.test.ts`~~ | ~~Markdown utils~~ | ~~~5~~ | ❌ SKIP — file does not exist |
| ~~`client/src/utils/theme.test.ts`~~ | ~~Theme utils~~ | ~~~3~~ | ❌ SKIP — file does not exist |
| ~~`server/tests/unit/services/proxyAuth.test.ts`~~ | ~~Blob URL proxy auth~~ | ~~~8~~ | ❌ SKIP — does not exist |
| **Original Total** | | **~32 tests** | |
| **Corrected Total** | | **~18 tests** | |

## 4. Key Tests

### WikiLink Extension (`wikiLink.test.ts`)
- `parseWikiLinkText("[[Name]]")` returns `{ targetName: "Name", displayText: "Name" }`
- `parseWikiLinkText("[[Name|Display]]")` returns `{ targetName: "Name", displayText: "Display" }`
- `parseWikiLinkText("no brackets")` returns `null`
- `parseWikiLinkText("")` returns `null`
- `wikiLinkRegex` matches multiple wiki-links in text

### StoryFileDetector (`storyFileDetector.test.ts`)
- Detects `<!-- Build: Yes -->` metadata comment
- Detects `<!-- Template: Character -->` metadata comment
- Returns correct template type from HTML content
- Handles missing metadata gracefully
- Extracts title from HTML `<h2>` tags

### TemplateDetector (`templateDetector.test.ts`)
- Detects Character template from `Characters/` folder path
- Detects Quest template from `Quests/` folder path
- Detects Location template from `Locations/` folder path
- Detects Timeline template from `Timeline/` folder path
- Returns `null` for unrecognized folders

### TokenCounter (`tokenCounter.test.ts`)
- Counts tokens for simple English text
- Handles empty string
- Handles long text accurately (within ~10% of expected)

## 5. Implementation Steps

1. **Set up Vitest infrastructure** — Add devDependencies, config file, test setup
2. **Create `wikiLink.test.ts`** — Test `parseWikiLinkText()` and `wikiLinkRegex` from `wiki-link.ts`
3. **Create `storyFileDetector.test.ts`** — Test build/template detection functions
4. **Create `templateDetector.test.ts`** — Test folder-based template type detection
5. **Create `tokenCounter.test.ts`** — Test token counting utilities
6. **Run full test suite** — Verify all tests pass

## 6. Verification
- [ ] Client Vitest infrastructure is configured
- [ ] `npm run test` works from the client directory
- [ ] All wikiLink tests pass
- [ ] All storyFileDetector tests pass
- [ ] All templateDetector tests pass
- [ ] All tokenCounter tests pass

## 7. Next Phase
- After Phase 7 is complete, proceed to **PHASE_8_COVERAGE_AND_CI.md**.