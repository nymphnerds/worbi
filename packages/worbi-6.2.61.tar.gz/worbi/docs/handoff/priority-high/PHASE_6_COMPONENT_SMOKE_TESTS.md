# Phase 6: Component Smoke Tests

**Target Version:** v6.2.40
**Priority:** Low (regression prevention)
**Dependencies:** Phase 0-5
**Status:** ✅ Complete (v6.2.40)

---

## 1. Overview

Minimal "it renders without crashing" tests for every UI component. Uses React Testing Library. Mock TipTap via Phase 0 helpers.

---

## 2. Existing Test Infrastructure

### Test Configuration
| File | Purpose |
|------|---------|
| `client/vitest.config.ts` | Vitest config: jsdom environment, `@` path alias, globals, 10s timeout |
| `client/tests/setup.ts` | Testing Library setup: jest-dom, matchMedia mock, confirm/prompt mock |
| `client/tests/helpers/mockTiptap.ts` | TipTap mock helpers: `mockTiptapReact()`, `mockUseEditor()` |

### Root package.json scripts
```
npm run test:client    # Run client tests only
npm run test           # Run all tests
npm run test:watch     # Watch mode
```

---

## 3. Test File Inventory

### Already Implemented (Pre-Existing)

| File | Component | Tests | Key Assertions |
|------|-----------|-------|----------------|
| `DocumentEditor.test.tsx` | DocumentEditor | 5 | Toolbar buttons (Bold/Italic/Underline), Save button onClick, InformationPanel renders |
| `InformationPanel.test.tsx` | InformationPanel | 5 | Hook calls (useFileTags, useFileLocations), tag names render, timeline metadata |
| `TagManager.test.tsx` | TagManager | Exists | Tags heading renders |
| `ReminderSidebar.test.tsx` | ReminderSidebar | Comprehensive | Header "Reminders", empty state, loading, error, CRUD, form validation |
| `TimelineView.test.tsx` | TimelineView | Comprehensive | Skeleton/loading, events render, era headers, collapse/expand |

### Newly Implemented (Batch 1-3)

| File | Tests | Status |
|------|-------|--------|
| `StatusBar.test.tsx` | 7 | ✅ Pass |
| `Welcome.test.tsx` | 7 | ✅ Pass |
| `ErrorBoundary.test.tsx` | 5 | ✅ Pass |
| `Header.test.tsx` | 8 | ✅ Pass |
| `SearchPanel.test.tsx` | 6 | ✅ Pass |
| `ActivityBar.test.tsx` | 6 | ✅ Pass |
| `ChatPanel.test.tsx` | 6 | ✅ Pass |
| `FileExplorer.test.tsx` | 1 | ✅ Pass |
| `TabBar.test.tsx` | 3 | ✅ Pass |
| `KeyboardShortcutSettings.test.tsx` | 1 | ✅ Pass |

**Total:** 23 test files, 153 tests, all passing.

---

## 4. Implementation Batches

### Batch 1 — Simple (No complex mocks)
- `StatusBar.test.tsx` — Pure rendering, no external deps
- `Welcome.test.tsx` — lucide-react mock only
- `ErrorBoundary.test.tsx` — Class component, pass-through + fallback

### Batch 2 — Medium (lucide-react mock)
- `Header.test.tsx` — lucide icons, dropdown menu
- `SearchPanel.test.tsx` — "SEARCH" heading + input
- `ActivityBar.test.tsx` — Inline SVGs + lucide icons

### Batch 3 — Complex (Multiple mocks)
- `ChatPanel.test.tsx` — NameGenerator mock, lucide mock
- `FileExplorer.test.tsx` — Many callbacks, star functionality
- `TabBar.test.tsx` — Tab rendering logic
- `KeyboardShortcutSettings.test.tsx` — Component analysis needed first

---

## 5. Test Pattern

```tsx
import { render, screen } from '@testing-library/react';
import { ComponentName } from './ComponentName';

describe('ComponentName', () => {
  it('renders without crashing', () => {
    render(<ComponentName {...minimalProps} />);
    expect(screen.getByText(/key-text/i)).toBeInTheDocument();
  });
});
```

### Mock Patterns

**lucide-react mock** (when icons needed as assertions):
```tsx
vi.mock('lucide-react', () => {
  const icons: Record<string, React.FC> = {};
  const names = ['Icon1', 'Icon2'];
  for (const n of names) {
    icons[n] = vi.fn((props: any) => <svg data-testid={n} {...props} />);
  }
  return icons;
});
```

**Hook mock**:
```tsx
vi.mock('../hooks/useSomeHook', () => ({
  useSomeHook: vi.fn().mockReturnValue({ data: [], loading: false }),
}));
```

---

## 6. Component Prop Reference

### StatusBar
```ts
interface StatusBarProps {
  currentPath: string | null;
  wordCount: number;
  llmConnected: boolean | null;
  error: string | null;
  aiOffline?: boolean;
}
```

### Welcome
```ts
interface WelcomeProps {
  recentFiles: ({ path: string; name: string; lastOpened: number })[];
  starredFiles: { path: string; name: string }[];
  onFileClick: (path: string) => void;
  onRemoveRecent: (path: string) => void;
  onToggleStar: (path: string) => void;
  onNewFile: () => void;
  onCreateFromTemplate?: () => void;
  onGenerateWithAI?: () => void;
  aiOffline?: boolean;
  onOpenHelp?: () => void;
}
```

### ErrorBoundary
```ts
interface Props {
  children: ReactNode;
  fallback?: ReactNode;
}
```

### SearchPanel
```ts
interface SearchPanelProps {
  width: number;
  query: string;
  onQueryChange: (q: string) => void;
  results: SearchResult[];
  loading: boolean;
  error: string | null;
  onFileOpen: (path: string) => void;
}
```

### Header
```ts
interface HeaderProps {
  onNewFile: () => void;
  onCreateFromTemplate: () => void;
  onImportDOCX: () => void;
  onLogout: () => void;
  username: string;
  showAISidebar: boolean;
  onToggleAISidebar?: () => void;
  aiOffline?: boolean;
  onOpenHelp?: () => void;
  onGenerateGameFile?: () => void;
}
```

### ActivityBar
```ts
type ActivityType = 'explorer' | 'search' | 'starred' | 'tags' | 'locations' | 'timeline' | 'graph' | 'images' | 'outline' | 'reminders';

interface ActivityBarProps {
  activeActivity: ActivityType;
  onSwitch: (activity: ActivityType) => void;
  onSettings?: () => void;
  onToggleAI?: () => void;
  showAISidebar?: boolean;
  aiOffline?: boolean;
  leftPanelHidden?: boolean;
  onTogglePanel?: () => void;
  hiddenIcons?: Set<HideableIcon>;
}
```

### ChatPanel
```ts
interface ChatPanelProps {
  history: ChatMessage[];
  loading: boolean;
  onSend: (message: string, documentContent: string) => Promise<ChatMessage | null>;
  onClear: () => void;
  documentContent: string;
  width: number;
  toolsEnabled: boolean;
  onToggleTools: () => void;
  aiOffline?: boolean;
  messagesTrimmed?: boolean;
  onDismissTrimNotification?: () => void;
}
```

### FileExplorer
```ts
interface FileExplorerProps {
  files: FileItem[];
  explorerPath: string;
  currentPath: string | null;
  loading: boolean;
  onFileSelect: (file: FileItem) => void;
  onDelete: (item: FileItem) => void;
  onRename: (item: FileItem, newName: string) => void;
  onCopy: (item: FileItem) => void;
  onMove: (item: FileItem) => void;
  onBack: () => void;
  onBackToRoot: () => void;
  onBackToSegment: (path: string) => void;
  onNewFolder: () => void;
  onUploadFiles: (files: FileList) => void;
  onCompile: () => void;
  width: number;
  starredFiles: StarredFile[];
  onToggleStar: (path: string) => void;
}
```

### TabBar
```ts
interface TabBarProps {
  tabs: Record<string, Tab>;
  activeTabId: string | null;
  onSwitch: (id: string) => void;
  onClose: (id: string) => void;
  onReorder?: (fromId: string, toId: string) => void;
}
```

---

## 7. Verification Checklist

- [x] All new test files created (10 new files)
- [x] `npm run test:client` passes (153 tests, 23 files, all green)
- [x] All components render without crashing
- [x] Key elements found in DOM
- [x] Phase 6 doc updated with final status

## 7a. Notes & Gotchas

- **TabBar**: Returns `null` when no tabs — test must assert empty container, not a specific element
- **TabBar**: `scrollIntoView` not available in jsdom — mock via `HTMLElement.prototype.scrollIntoView = vi.fn()`
- **FileExplorer**: Large component (655 lines) with many dependencies — minimal smoke test with full hook/icon mocks
- **ErrorBoundary**: `Boom` component must return `never` type to satisfy TypeScript
- **ActivityBar**: lucide-react imports `Image as ImageIcon` — mock must export `Image`, not `ImageIcon`

## 8. Next Phase

Proceed to **PHASE_7_TIPAP_AND_UTILS.md**.