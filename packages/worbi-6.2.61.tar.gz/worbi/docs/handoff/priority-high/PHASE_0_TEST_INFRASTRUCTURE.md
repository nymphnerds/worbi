# Phase 0: Test Infrastructure Setup

**Target Version:** v6.2.40
**Priority:** Critical (foundation for all subsequent phases)
**Dependencies:** None
**Supersedes:** Phase 1 (Infrastructure) from TEST_SUITE_SETUP.md

**Status:** ✅ COMPLETE — All infrastructure in place, verified with 57 passing tests (Phase 1)

---

## 1. Problem Statement

WORBI has zero automated test infrastructure. No test runner, no test dependencies, no test configuration, no test helpers. The server's `index.js` starts the HTTP server at module load time, making it impossible to import the Express app for testing without also starting a listener.

This phase creates the entire test foundation: installs dependencies, configures Vitest across the monorepo, creates test helpers, and refactors `index.js` for testability. After this phase, `npm test` runs with 0 tests and exits with code 0.

---

## 2. Testing Stack

| Layer | Tool | Rationale |
|-------|------|-----------|
| Test Runner | Vitest | Fast, native ESM support, same tool as client Vite |
| Server Unit Tests | Vitest (node env) | Native Node.js environment |
| Client Unit Tests | Vitest (jsdom env) | Browser-like DOM for React components |
| API Integration Tests | Vitest + Supertest | HTTP-level testing of Express routes |
| Client Component Tests | Vitest + React Testing Library | User-centric component API |
| Coverage | Vitest built-in (v8) | Built into Vitest, no extra config needed |
| Type Checking | TypeScript `--noEmit` | Already part of the build |

**Why NOT Jest:** The project uses ES modules (`"type": "module"` in server and client package.json). Jest's ESM support is experimental and painful. Vitest handles ESM natively and shares config with Vite.

---

## 3. Dependency Installation

### 3.1 Root `package.json` Changes

**File:** `package.json` (workspace root)

**Add to `devDependencies`:**
```json
"vitest": "^3.0.0"
```

**Add to `scripts`:**
```json
"test": "vitest run",
"test:watch": "vitest",
"test:coverage": "vitest run --coverage",
"test:server": "vitest run --project server",
"test:client": "vitest run --project client"
```

### 3.2 Server `package.json` Changes

**File:** `server/package.json`

**Add to `devDependencies`:**
```json
"supertest": "^7.0.0",
"@types/supertest": "^6.0.0"
```

### 3.3 Client `package.json` Changes

**File:** `client/package.json`

**Add to `devDependencies`:**
```json
"@testing-library/react": "^16.0.0",
"@testing-library/jest-dom": "^6.4.0",
"@testing-library/user-event": "^14.5.0",
"jsdom": "^24.0.0"
```

### 3.4 Coverage Provider (Root)

**File:** `package.json` (workspace root)

**Add to `devDependencies`:**
```json
"@vitest/coverage-v8": "^3.0.0"
```

---

## 4. Configuration Files

### 4.1 Root Vitest Config

**File:** `vitest.config.ts` (workspace root)

```ts
import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './client/src'),
    },
  },
  test: {
    workspace: ['server/vitest.config.ts', 'client/vitest.config.ts'],
    testTimeout: 10_000,
    coverage: {
      provider: 'v8',
      include: [
        'server/src/**/*.js',
        'client/src/**/*.{ts,tsx}',
      ],
      exclude: [
        '**/*.test.{ts,tsx,js}',
        '**/*.spec.{ts,tsx,js}',
        '**/tests/helpers/**',
        '**/tests/fixtures/**',
        '**/node_modules/**',
        'client/src/main.tsx',        // Entry point only
        'client/src/App.tsx',         // Orchestrator - tested via components
      ],
      thresholds: {
        lines: 0,
        branches: 0,
        functions: 0,
        statements: 0,
      },
    },
  },
});
```

**Notes:**
- Coverage thresholds start at 0% — will be ratcheted up in Phase 8
- `App.tsx` is excluded from coverage because it's a massive orchestrator (~1,376 lines); its logic is tested via the individual hooks and components it wires together
- `main.tsx` is excluded because it's just `ReactDOM.createRoot().render(<App />)`

### 4.2 Server Vitest Config

**File:** `server/vitest.config.ts`

```ts
import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    name: 'server',
    environment: 'node',
    include: ['src/**/*.test.ts', 'tests/**/*.test.ts', 'tests/**/*.test.js'],
    setupFiles: ['./tests/setup.ts'],
    globals: true,
    testTimeout: 10_000,
  },
});
```

### 4.3 Client Vitest Config

**File:** `client/vitest.config.ts`

```ts
import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  test: {
    name: 'client',
    environment: 'jsdom',
    include: ['src/**/*.test.tsx', 'src/**/*.test.ts'],
    setupFiles: ['./tests/setup.ts'],
    globals: true,
    testTimeout: 10_000,
  },
});
```

**Notes:**
- The `@/*` path alias is already configured in `client/tsconfig.json` and must be mirrored here
- React plugin is needed so Vitest can transform JSX in client test files

---

## 5. Test Setup Files

### 5.1 Server Test Setup

**File:** `server/tests/setup.ts`

```ts
import { vi } from 'vitest';

// Set test environment
process.env.NODE_ENV = 'test';

// Override config.port to 0 (random port) in tests to avoid port conflicts
// This is handled per-test by mocking, not globally

// Mock console methods to reduce test output noise (optional - comment out for debugging)
// vi.spyOn(console, 'log').mockImplementation(() => {});
// vi.spyOn(console, 'warn').mockImplementation(() => {});
```

### 5.2 Client Test Setup

**File:** `client/tests/setup.ts`

```ts
import '@testing-library/jest-dom';

// Mock window.matchMedia (used by some components for responsive behavior)
Object.defineProperty(window, 'matchMedia', {
  writable: true,
  value: (query: string) => ({
    matches: false,
    media: query,
    onchange: null,
    addListener: () => {},
    removeListener: () => {},
    addEventListener: () => {},
    removeEventListener: () => {},
    dispatchEvent: () => false,
  }),
});

// Mock window.confirm / window.prompt for dialog components
window.confirm = () => true;
window.prompt = () => null;

// Suppress React 19+ "startTransition" warnings in Testing Library
// (Not needed for React 18, but future-proof)
```

---

## 6. Server Refactoring for Testability

### 6.1 Problem

The current `server/src/index.js` calls `app.listen()` at module top level (line 63). This means importing the module starts the HTTP server, which:
1. Binds to a port (can cause conflicts when multiple tests import)
2. Makes it impossible to test routes without starting a server first

### 6.2 Solution

**File:** `server/src/index.js`

Two approaches were considered:

**Approach A:** Check if run as main module:

```js
const isMainModule = process.argv[1] && import.meta.url.startsWith('file://') && process.argv[1].endsWith('index.js');

if (isMainModule) {
  const PORT = config.port;
  const HOST = '0.0.0.0';
  app.listen(PORT, HOST, () => {
    console.log(`WBUI Server running on http://0.0.0.0:${PORT}`);
    console.log(`Users root: ${usersRoot}`);
  });
}
```

**Approach B (Selected):** Use a `NODE_ENV` check:

```js
// Start server only when not in test mode
if (process.env.NODE_ENV !== 'test') {
  const PORT = config.port;
  const HOST = '0.0.0.0';
  app.listen(PORT, HOST, () => {
    console.log(`WBUI Server running on http://0.0.0.0:${PORT}`);
    console.log(`Users root: ${usersRoot}`);
  });
}
```

**Implementation:** Approach B (`NODE_ENV` check) was used — it's simpler and the test setup already sets `NODE_ENV=test`.

---

## 7. Test Helpers

### 7.1 Express App Factory

**File:** `server/tests/helpers/testApp.ts`

**PLANNED (password-based auth):**
```ts
export async function getAuthedApp(username: string = 'testuser', password: string = 'testpass123') {
  await request(app).post('/api/auth/register').send({ username, password });
  const res = await request(app).post('/api/auth/login').send({ username, password });
  const token = res.body.token;
  const agent = request(app);
  return { agent, token };
}
```

**ACTUAL IMPLEMENTED (username-only passwordless auth):**
```ts
/**
 * Logs in (or creates) a test user via the username-only auth endpoint
 * and returns a supertest agent pre-authenticated with a valid JWT token.
 */
export async function getAuthedApp(username: string = 'testuser') {
  // Login or create user (WORBI uses passwordless username-only auth)
  const res = await request(app).post('/api/auth/login').send({ username });
  const token = res.body.token;
  const agent = request(app);
  return { agent, token };
}
```

**Note:** WORBI uses passwordless username-only auth (no passwords, no register endpoint). `POST /api/auth/login` creates the user if they don't exist. This is fundamentally different from the traditional register+login flow planned in the original doc.

### 7.2 Auth Helper

**File:** `server/tests/helpers/authHelper.ts`

```ts
import jwt from 'jsonwebtoken';
import config from '../../src/config.js';

/**
 * Generates a valid JWT token for the given username.
 * Used in unit tests to avoid calling the HTTP endpoint.
 */
export function generateTestToken(username: string): string {
  return jwt.sign({ username }, config.jwtSecret, { expiresIn: '7d' });
}

/**
 * Generates an expired JWT token for testing expired token rejection.
 */
export function generateExpiredToken(username: string): string {
  return jwt.sign({ username }, config.jwtSecret, { expiresIn: '0s' });
}

/**
 * Generates a token with a tampered payload (invalid signature).
 */
export function generateTamperedToken(username: string): string {
  return jwt.sign({ username }, 'wrong-secret', { expiresIn: '7d' });
}
```

### 7.3 Filesystem Test Helper

**File:** `server/tests/helpers/fsHelper.ts`

```ts
import fs from 'fs';
import path from 'path';
import os from 'os';

/**
 * Creates a temporary workspace directory structure for testing.
 * Returns the root path. Caller is responsible for cleanup.
 */
export function createTempWorkspace(): string {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'worbi-test-'));
  return root;
}

/**
 * Recursively deletes a directory.
 */
export function cleanupTempWorkspace(rootPath: string): void {
  if (fs.existsSync(rootPath)) {
    fs.rmSync(rootPath, { recursive: true, force: true });
  }
}

/**
 * Creates a file within a workspace with the given content.
 * Auto-creates parent directories.
 */
export function createTestFile(workspaceRoot: string, relativePath: string, content: string): void {
  const fullPath = path.join(workspaceRoot, relativePath);
  fs.mkdirSync(path.dirname(fullPath), { recursive: true });
  fs.writeFileSync(fullPath, content, 'utf-8');
}

/**
 * Creates a nested directory structure with sample files for testing.
 * Returns the workspace root.
 *
 * Example structure:
 *   root/
 *   ├── docs/
 *   │   ├── guide.html
 *   │   └── notes.html
 *   ├── lore/
 *   │   └── world.html
 *   └── README.html
 */
export function createSampleWorkspace(): string {
  const root = createTempWorkspace();

  createTestFile(root, 'README.html', '<h1>Project</h1>');
  createTestFile(root, 'docs/guide.html', '<h1>Guide</h1><p>Content here</p>');
  createTestFile(root, 'docs/notes.html', '<h1>Notes</h1><p>Some notes</p>');
  createTestFile(root, 'lore/world.html', '<h1>World</h1><p>World lore</p>');

  return root;
}
```

### 7.4 TipTap Editor Mock

**File:** `client/tests/helpers/mockTiptap.ts`

```ts
import { vi } from 'vitest';

/**
 * Mocks the @tiptap/react package for component tests.
 * Use with: vi.mock('@tiptap/react', () => mockTiptapReact())
 */
export function mockTiptapReact() {
  const mockEditor = {
    chain: () => ({
      focus: vi.fn().mockReturnThis(),
      insertContent: vi.fn().mockReturnThis(),
      run: vi.fn().mockReturnValue(true),
    }),
    focus: vi.fn(),
    setContent: vi.fn(),
    getHTML: vi.fn().mockReturnValue(''),
    getText: vi.fn().mockReturnValue(''),
    isActive: vi.fn().mockReturnValue(false),
    isFocused: vi.fn().mockReturnValue(false),
    commands: {
      focus: vi.fn().mockReturnValue(true),
      insertContent: vi.fn().mockReturnValue(true),
    },
    state: {
      doc: {},
      selection: {},
    },
    view: {
      dispatch: vi.fn(),
      props: {},
    },
    on: vi.fn(),
    off: vi.fn(),
    destroy: vi.fn(),
  };

  return {
    useEditor: vi.fn().mockReturnValue(mockEditor),
    EditorContent: vi.fn(({ editor }: { editor: any }) => null),
    BubbleMenu: vi.fn(() => null),
    FloatingMenu: vi.fn(() => null),
  };
}

/**
 * Mocks the @tiptap/react useEditor hook directly.
 * Use in individual tests when you need more control.
 */
export function mockUseEditor(customEditor?: any) {
  const defaultEditor = {
    chain: () => ({
      focus: vi.fn().mockReturnThis(),
      insertContent: vi.fn().mockReturnThis(),
      run: vi.fn().mockReturnValue(true),
    }),
    focus: vi.fn(),
    setContent: vi.fn(),
    getHTML: vi.fn().mockReturnValue(''),
    getText: vi.fn().mockReturnValue(''),
    isActive: vi.fn().mockReturnValue(false),
    commands: {
      focus: vi.fn().mockReturnValue(true),
      insertContent: vi.fn().mockReturnValue(true),
    },
    state: { doc: {}, selection: {} },
    view: { dispatch: vi.fn(), props: {} },
    on: vi.fn(),
    off: vi.fn(),
    destroy: vi.fn(),
  };

  vi.mocked(require('@tiptap/react').useEditor).mockReturnValue(customEditor || defaultEditor);
}
```

---

## 8. TypeScript Config Updates

### 8.1 Client `tsconfig.json`

**File:** `client/tsconfig.json`

**Change:** Add test files to `include`:

```json
{
  "include": ["src", "tests"]
}
```

### 8.2 Server TypeScript Config

The server uses plain JavaScript (`.js` files), not TypeScript. However, test files use `.ts` extensions for type safety with helpers. No tsconfig is needed on the server side since Vitest handles TypeScript compilation natively.

---

## 9. Files Created

| File | Purpose | Status |
|------|---------|--------|
| `vitest.config.ts` | Root Vitest workspace configuration | ✅ Created |
| `server/vitest.config.ts` | Server-specific test configuration (node env) | ✅ Created |
| `client/vitest.config.ts` | Client-specific test configuration (jsdom env) | ✅ Created |
| `server/tests/setup.ts` | Server test setup (env vars) | ✅ Created |
| `client/tests/setup.ts` | Client test setup (jest-dom, window mocks) | ✅ Created |
| `server/tests/helpers/testApp.ts` | Express app factory + supertest binding | ✅ Created (username-only auth) |
| `server/tests/helpers/authHelper.ts` | JWT token generation for tests | ✅ Created |
| `server/tests/helpers/fsHelper.ts` | Temporary workspace directory management | ✅ Created |
| `client/tests/helpers/mockTiptap.ts` | TipTap editor mocks for component tests | ✅ Created |

## 10. Files Modified

| File | Changes | Status |
|------|---------|--------|
| `package.json` (root) | Add vitest, @vitest/coverage-v8 dev deps; add test scripts | ✅ Done |
| `server/package.json` | Add supertest, @types/supertest dev deps | ✅ Done |
| `client/package.json` | Add @testing-library/react, @testing-library/jest-dom, @testing-library/user-event, jsdom dev deps | ✅ Done |
| `server/src/index.js` | Guard `app.listen()` with `NODE_ENV !== 'test'` check | ✅ Done |
| `client/tsconfig.json` | Add `tests` to `include` array | ✅ Done |

---

## 11. Implementation Order

1. **Install root dependencies** — `vitest`, `@vitest/coverage-v8` ✅
2. **Install server dependencies** — `supertest`, `@types/supertest` ✅
3. **Install client dependencies** — testing-library packages, `jsdom` ✅
4. **Create root `vitest.config.ts`** — workspace config with coverage settings ✅
5. **Create `server/vitest.config.ts`** — node environment config ✅
6. **Create `client/vitest.config.ts`** — jsdom environment config with `@/` alias ✅
7. **Create `server/tests/setup.ts`** — env var setup ✅
8. **Create `client/tests/setup.ts`** — jest-dom import, window mocks ✅
9. **Refactor `server/src/index.js`** — guard `app.listen()` with `NODE_ENV` check ✅
10. **Create `server/tests/helpers/testApp.ts`** — supertest factory ✅
11. **Create `server/tests/helpers/authHelper.ts`** — JWT helpers ✅
12. **Create `server/tests/helpers/fsHelper.ts`** — temp workspace helpers ✅
13. **Create `client/tests/helpers/mockTiptap.ts`** — TipTap mocks ✅
14. **Update `client/tsconfig.json`** — include test files ✅
15. **Run `npm test`** — verify it runs (57 tests, all passing) ✅

---

## 12. Verification Checklist

- [x] `npm install` completes without errors
- [x] `npm test` runs and exits with code 0 (57 tests passing)
- [x] `npm run test:server` runs without errors (57/57 passing, ~665ms)
- [x] `npm run test:client` runs without errors
- [x] `npm run test:coverage` generates a coverage report
- [x] `server/src/index.js` does NOT start the server when `NODE_ENV=test`
- [x] `server/src/index.js` still starts the server normally when `NODE_ENV` is not `test`
- [x] The `@/` path alias works in client tests (resolve to `client/src/`)
- [x] Supertest can import the Express app without starting a listener
- [x] `authHelper.generateTestToken()` produces a valid JWT that passes `authMiddleware`

---

## 13. Known Gotchas

### ESM in Server Tests
The server uses `"type": "module"` — all test files must use `.ts` extension (not `.js`) and import with full file extensions when importing server `.js` files:
```ts
import app from '../../src/index.js';  // .js extension required
import config from '../../src/config.js';
```

### Vitest Workspace Mode
The root `vitest.config.ts` uses workspace mode, delegating to server and client configs. Running `vitest` from the root runs both projects. Running with `--project server` or `--project client` filters to one.

### Jsdom vs Node Environment
Client tests run in `jsdom` (has `window`, `document`). Server tests run in `node` (no DOM). Do NOT mix them — a server test file must live under `server/tests/` and a client test under `client/src/` or `client/tests/`.

### TipTap Mock Scope
The TipTap mock must be applied at the module level using `vi.mock('@tiptap/react', ...)` BEFORE importing the component. This means it must be at the top of the test file, before any `import` statements that transitively import TipTap.

### Vite Plugin React in Root Config
The root `vitest.config.ts` needs the `@vitejs/plugin-react` plugin so it can transform JSX in client test files. This plugin is already a dev dependency of the client workspace, so it's available in the root `node_modules` via npm workspaces hoisting.

### Passwordless Auth (Discovered During Implementation)
WORBI uses username-only authentication (no passwords, no bcrypt, no register endpoint). `POST /api/auth/login` creates the user if they don't exist and returns a JWT. The `testApp.ts` helper was updated accordingly — `getAuthedApp(username)` takes only a username, not a password.

### verifyToken() Returns Object (Does NOT Throw)
`authService.verifyToken()` returns `{ valid: boolean, username?: string }` rather than throwing on invalid tokens. All middleware tests assert on the return value, not exceptions.

### path.join Behavior (NOT path.resolve)
`fileService.getSafePath()` uses `path.join(base, relPath)` which does NOT treat leading `/` as filesystem root. An input of `/etc/passwd` becomes a subdirectory inside the workspace. The traversal check catches `..` sequences which are the real security concern.

---

## 14. Next Phase

After this phase is complete and verified, proceed to **PHASE_1_SECURITY_TESTS.md** to write the critical security tests.

**Status:** Phase 1 is also ✅ COMPLETE (57/57 tests passing, ~665ms). See `PHASE_1_SECURITY_TESTS.md` for details.

---

## 15. Differences from Plan

| Planned | Actual | Reason |
|---------|--------|--------|
| `getAuthedApp(username, password)` with register+login | `getAuthedApp(username)` with login only | WORBI uses passwordless username-only auth |
| `POST /api/auth/register` endpoint | No register endpoint | Login auto-creates users |
| `Recommendation` for NODE_ENV approach | NODE_ENV approach confirmed working | Simpler and verified |
| Verification: 0 tests | Verification: 57 tests passing | Phase 1 tests written alongside |