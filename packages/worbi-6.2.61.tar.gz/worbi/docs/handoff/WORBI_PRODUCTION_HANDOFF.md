# WORBI Production Handoff — LLM Capabilities Reference

> **Purpose:** This document enables any LLM agent to understand what WORBI does, how it works from a user perspective, and how to assist users with it. No source code, build steps, or file-level architecture is included.

---

## 1. What WORBI Is

**WORBI** (WorldBuilder UI) by Nymphs is a **rich text document editor** designed for world-building — stories, quests, characters, lore, and campaign management. It also doubles as a business scheduling tool via work profiles.

- Runs **100% locally** on the user's machine — no cloud dependency
- Installed as a **NymphsCore addon** on Linux/WSL systems
- Self-hosted Express backend (port 8082) + Vite/React frontend
- **Dark theme only**, VS Code-style layout with resizable side panels
- Username-only login (no password — local-first trust model)

---

## 2. What WORBI Does — Feature Capabilities

### 2.1 Rich Text Editing
- WYSIWYG editor (TipTap/ProseMirror) with full formatting: headings (H1-H6), bold, italic, strikethrough, code, blockquotes, tables, bullet/numbered lists
- **Images:** drag-and-drop upload with drag-to-resize, hero image assignment
- **Multi-file tabs** with unsaved changes detection, auto-save, session persistence (restores open tabs on reload)
- **Inline spellcheck** with dictionary management (custom word lists)
- **WikiLinks** — `[[Name]]` syntax for cross-document links with autocomplete dropdown and backlink tracking
- **File+ toolbar button** for quick file creation from the editor

### 2.2 File Organization
- **File Explorer** tree with folders and files, drag-and-drop reordering
- Full CRUD: create, rename, delete, copy, move files and folders
- **Search** across all documents (full-text content search)
- **Recents** and **Starred** file lists per user
- **Inline rename** in explorer (click filename to edit)
- `.html` extension hidden from UI (all documents stored as HTML, displayed without extension)
- **Import:** DOCX files via drag-and-drop
- **Export:** PDF and DOCX export from any document

### 2.3 Tag System
- Color-coded tags assignable to files
- **Implicit relationships:** files sharing tags are automatically linked
- **Explicit relationships:** manually defined connections between files
- Tag management: create, rename, delete, duplicate detection
- Tag-based filtering in sidebar

### 2.4 Location Metadata
- Assign location names to files for spatial/geographic organization
- Location-to-file associations queryable
- Useful for world-building (map regions, geographic groupings)

### 2.5 Timeline View
- Chronological event browser organized by **eras**
- Events extracted from document metadata (date fields)
- AI-powered date suggestions for undated events
- Era management: create, rename, assign events
- Visual timeline panel for tracking story/campaign chronology

### 2.6 Relationship Graph
- **Visual force-directed graph** (Cytoscape.js) showing file connections
- **Seed-centric generation:** pick a file, discover what it connects to
- **Relationship types:** character connections, location connections, thematic, narrative, tag-based
- **AI-powered:** LLM analyzes document content to discover hidden relationships
- **Depth control:** 1-degree or 2-degree connections
- Era-based filtering

### 2.7 Reminders
- Timestamped reminders attached to specific files
- **Recurrence:** one-time, daily, weekly, monthly
- **Threading:** add notes to reminders over time
- **Status flow:** pending → fired → completed/converted
- Grouped by file for easy reference

### 2.8 Document Templates
Two profile types with distinct templates:

**Game Profile** (D&D campaign management):
- Character, Quest, Location, Item, Faction, Creature, Timeline
- Pre-structured fields for each type (name, description, stats, etc.)
- Default folders auto-created (Characters, Quests, Locations, etc.)

**Work Profile** (business scheduling):
- Customer, Job, Booking, Quote
- Default folders auto-created (Customers, Jobs, Bookings, Quotes)

Templates filter based on active profile — game users never see work templates and vice versa.

### 2.9 Story Bible Compiler
- Compile entire workspace into a single document
- **Options:** include/exclude by tags, sort alphabetically, include file dividers, generate table of contents
- Filters by Build metadata (files marked as build-included)
- Useful for generating campaign bibles, reference documents, or handouts

### 2.10 Game File Export
- Generate `.txt` files formatted for external game engines
- Detects template type (character, location, quest, etc.) and uses appropriate export template
- AI-powered: LLM structures content for game engine compatibility
- Exported files saved to `docs/GameReady/` in workspace

### 2.11 File Menu
- File menu button in header with: New Blank File, New from Template, Save, Save As, Close, Compile, Export

### 2.12 Keyboard Shortcuts
- Memory-based keyboard shortcut system that learns from user habits
- Keyboard shortcuts panel for viewing/learning shortcuts
- Quick file switcher via keyboard

### 2.13 Navigation
- Breadcrumb navigation in explorer
- Back/forward navigation between files
- Explorer path sync on file open

---

## 3. AI Capabilities — How LLM Integration Works

### 3.1 LLM Chat Panel
- **Context-aware chat:** the current document's content is sent as context with every message
- **System prompt** configurable per user (default: worldbuilding assistant)
- **Conversation history** maintained per session
- **Tool-calling:** LLM can invoke up to 8 tools (see 3.3)
- **Toggle on/off** via toolbar button

### 3.2 Ghost Text (Inline Autocomplete)
- **Trigger:** `Ctrl+Space` for manual invocation, or automatic as user types
- **Accept/Dismiss:** Tab to accept, Esc to dismiss
- Uses current document context for relevant suggestions
- **Ghost text button** in toolbar to toggle on/off
- Configurable: debounce delay, max tokens

### 3.3 AI Document Generation
Scaffold new documents from natural language prompts. Modes:
- **Character:** generate character sheets
- **Location:** generate location descriptions
- **Quest:** generate quest outlines
- **Timeline:** generate timeline entries
- **Freeform:** generate any content type

### 3.4 AI Image Transcription
- Send images to the LLM for description/analysis
- Uses vision-capable models
- Useful for converting scanned images, maps, or artwork to text

### 3.5 AI Tools (Permission-Gated)
The LLM can invoke **8 tools** during chat, all granularly permission-gated:

| Tool | Description | Permission Level |
|------|-------------|-----------------|
| `webSearch` | Search the internet via DuckDuckGo | Toggle on/off |
| `fileRead` | Read a workspace file | Read+ access |
| `fileCreate` | Create a new file | Create permission |
| `fileEdit` | Edit an existing file | Edit permission |
| `fileDelete` | Delete a file | Delete permission |
| `fileRename` | Rename a file | Rename permission |
| `fileSearch` | Search workspace files | Read+ access |
| `listFiles` | List files in a folder | Read+ access |

**File Access Levels:** `none` → `read` → `readwrite` → `full`
- Users control every permission in Settings → Tools tab
- Default: web search on, file access = read, create/edit/delete/rename = off

### 3.6 LLM Provider Support
WORBI supports **16+ LLM providers** via a provider catalog:

**Local (free, on-machine):**
- llama.cpp (via llama-server) — primary/default
- LM Studio
- Ollama
- vLLM
- TextGen WebUI
- LocalAI
- Jan

**Cloud (API key required):**
- OpenAI, Groq, OpenRouter, Anthropic, Google Gemini, Mistral, Together AI, DeepInfra, Perplexity, AWS Bedrock, Azure OpenAI, Cohere, Novita AI, FreeTrail, AI/FreeScale, Cloudflare Workers AI, Custom Local

Users select provider in Settings → LLM tab, then configure URL, API key, model name, temperature, max tokens, etc.

### 3.7 Managed LLM Server Lifecycle
WORBI can **auto-manage local LLM servers**:
- **Detect installed servers:** scan system for 7 server types (llama.cpp, LM Studio, Ollama, vLLM, TextGen, LocalAI, Jan)
- **Start/stop servers:** via lifecycle scripts
- **Status monitoring:** check if server is running, port, PID, loaded model
- **Managed vs External mode:** user chooses if WORBI manages the server or if the user manages it externally
- **Priority system:** server types ranked by priority for auto-detection

### 3.8 GPU Handoff
Solves the **single-GPU problem** (running both LLM + image generation on one GPU):
- When generating images, WORBI can **auto-stop the LLM server** → free VRAM → generate image → **restart LLM server**
- Toggle on/off in Settings
- Prevents VRAM OOM crashes on consumer hardware

---

## 4. Image Generation

Powered by **Z-Image-Turbo** (Nymphs2D2), a local AI image generation server.

### 4.1 Capabilities
- **Text-to-image:** generate images from text prompts
- **Image-to-image:** use an existing image as a starting point
- **Full controls:** prompt, negative prompt, width/height, steps, guidance scale, seed, strength (img2img)
- **Progress tracking** with visual progress bar
- **Image gallery** of generated images
- Images auto-saved to user's asset library

### 4.2 Configuration
- **Z-Image URL** configurable (default: localhost:8090)
- **Managed mode:** WORBI starts/stops Z-Image automatically
- **External mode:** user manages Z-Image separately
- **VRAM protection:** minimum free VRAM threshold (default 8192MB) before allowing generation
- **Folder path:** override default Z-Image installation path

### 4.3 Image Proxy
- Workspace-relative image URLs proxied through WORBI server
- Signed URLs for temporary access
- Batch signing for performance

---

## 5. Workspace Profiles

WORBI operates in two modes, selected at first login:

### 5.1 Game Profile
- **Purpose:** D&D campaign / story world management
- **Default folders:** Characters, Quests, Locations, Items, Factions, Creatures, Timeline, Lore, Notes
- **Templates:** 7 game-specific templates with pre-structured fields
- **Features emphasized:** Story Bible, Game Export, Timeline, Relationship Graph

### 5.2 Work Profile
- **Purpose:** Business scheduling and client management
- **Default folders:** Customers, Jobs, Bookings, Quotes
- **Templates:** 4 work-specific templates
- **Features emphasized:** Reminders, scheduling, client documentation

Profile selection affects: available templates, default folder structure, and workspace organization.

---

## 6. User Settings

Accessible via Settings panel (6 tabs):

### 6.1 LLM Tab
- Provider selection (dropdown from catalog)
- Custom URL, API key, model name
- Temperature, max tokens, top P, top K
- Frequency/presence penalty, stop sequences, seed
- System prompt
- Test connection button
- LLM server lifecycle controls (status, start/stop)

### 6.2 Tools Tab
- Web search toggle
- File access level (none/read/readwrite/full)
- Individual toggles: allow create, edit, delete, rename
- Max search results limit

### 6.3 Images Tab
- Z-Image server URL
- Managed vs external mode
- Z-Image folder path
- GPU handoff toggle
- VRAM threshold

### 6.4 Editor Tab
- Auto-save toggle and interval
- Spellcheck toggle
- Ghost text toggle
- Tab key behavior (indent vs autocomplete)
- Line width
- Font size

### 6.5 Appearance Tab
- **6 theme presets:** Default, System, Nymphs (green), Nord, Everforest, Toucan
- **Custom colors:** 18 CSS custom properties for backgrounds, surfaces, accents, text, borders
- **Color picker** (disabled for System theme)
- Font size controls (editor, sidebar)
- Icon visibility toggles (header)
- Sidebar icon labels

---

## 7. Authentication Model

- **Username-only login** — no password required (local-first trust model)
- **JWT tokens** with 7-day expiry, stored in localStorage
- **Per-user isolation:** each user gets a separate workspace directory, settings file, and asset library
- **Profile selection modal** appears for new users on first login (Game or Work)
- Session persists across page reloads

---

## 8. Data Storage (Conceptual)

From a user perspective:

- **Workspace:** a personal folder containing all documents, organized in subfolders
- **Documents:** stored as HTML files (rich text), displayed without the `.html` extension in the UI
- **Assets:** user-uploaded and AI-generated images stored in a personal asset library
- **Settings:** per-user configuration persisted as structured data
- **Recents/Starred:** per-user tracking of recently opened and starred files
- **Exports:** compiled story bibles and game-ready files saved in the workspace
- **Game exports:** `.txt` files generated for external game engines

---

## 9. How an LLM Can Help Users

When assisting a WORBI user, you can:

### Answer Feature Questions
- Explain any of the features listed above
- Walk users through how to use templates, tags, timeline, reminders, graph view
- Explain the difference between Game and Work profiles

### Help with LLM Configuration
- Guide users through selecting and configuring an LLM provider
- Explain the difference between local (free) and cloud providers
- Troubleshoot LLM connection issues (wrong URL, model not loaded, port conflicts)
- Explain tool permissions and what each does

### Help with Image Generation
- Guide Z-Image setup and configuration
- Explain managed vs external mode
- Troubleshoot VRAM issues, GPU handoff
- Explain image-to-image vs text-to-image

### Troubleshooting
- "LLM not connected" → check server is running, URL is correct, model is loaded
- "Image generation fails" → check Z-Image running, VRAM available, GPU handoff setting
- "File won't save" → check for unsaved changes dialog, auto-save settings
- "Can't see templates" → check workspace profile (game vs work)
- "WikiLink doesn't resolve" → file must exist with matching name in workspace

### Workspace Organization Advice
- Suggest folder structures for campaign management
- Recommend tag strategies for relationship tracking
- Explain how to use the Story Bible compiler
- Guide Game Export workflow

### Safety & Permissions
- Explain tool permission levels and recommend conservative defaults
- Warn about file write/delete permissions for the AI tools
- Explain that all data stays local on the user's machine

---

## 10. Quick Reference — Key Shortcuts & Access

| Action | How |
|--------|-----|
| New file | File menu → New Blank File, or File+ in editor toolbar |
| New from template | File menu → New from Template |
| Save | Auto-save, or File menu → Save |
| Export | File menu → Export (PDF/DOCX) |
| Ghost text | `Ctrl+Space` or toolbar button |
| LLM chat | Chat button in toolbar |
| Settings | Gear icon in header |
| File search | Search bar in File Explorer |
| Compile Story Bible | File menu → Compile |
| Game Export | Gamepad icon in header (game files only) |
| Toggle theme | Settings → Appearance → Theme preset |

---

## 11. Version

**Current version:** v6.2.51 (May 2026)

For detailed version history, see `CHANGELOG.md` and `update_record.md` in the project root.

---

*End of WORBI Production Handoff — LLM Capabilities Reference*