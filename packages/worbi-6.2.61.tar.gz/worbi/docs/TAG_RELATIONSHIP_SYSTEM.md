# Tag & Relationship System

## Overview

WBUI's Tag & Relationship system allows worldbuilders to tag documents (characters, locations, items) and discover relationships between them. Documents sharing tags are implicitly related, and users can also create explicit named relationships between documents.

**Core principle:** Tags are metadata stored on files, separate from file content. They survive content edits and enable automatic relationship discovery.

---

## Architecture

### Components

| Component | File | Purpose |
|-----------|------|---------|
| `tags.json` | `~/.wbu/tags.json` | Tag registry (name, color, description) |
| `fileService.js` | `server/src/services/fileService.js` | Extended to read/write `tags` and `relationships` metadata |
| `files.js` | `server/src/routes/files.js` | Tag API endpoints |
| `api.ts` | `client/src/services/api.ts` | Client API functions for tag operations |
| `useTags.ts` | `client/src/hooks/useTags.ts` | Tag state management hook |
| `TagManager.tsx` | `client/src/components/TagManager.tsx` | Tag panel in Activity Bar |
| `FileExplorer.tsx` | `client/src/components/FileExplorer.tsx` | Tag badges on filenames |
| `ActivityBar.tsx` | `client/src/components/ActivityBar.tsx` | Tags icon in sidebar |
| `Settings.tsx` | `client/src/pages/Settings.tsx` | Custom tag management |
| `globals.css` | `client/src/styles/globals.css` | Tag badge CSS styling |

### Default Tags

| Tag | Default Color | Description |
|-----|--------------|-------------|
| `MainChar` | `#f59e0b` (amber) | Main character documents |
| `MainChar2` | `#eab308` (yellow) | Secondary main character documents |
| `NPC` | `#6b7280` (gray) | Non-player character documents |
| `Friend` | `#22c55e` (green) | Ally/friend character documents |
| `Foe` | `#ef4444` (red) | Enemy/foe character documents |

---

## Phase 1: Tag Foundation (Current Implementation)

### Data Model

**Tag Registry** (`~/.wbu/tags.json`):
```json
{
  "tags": [
    { "id": "tag_001", "name": "MainChar", "color": "#f59e0b", "description": "Main character" },
    { "id": "tag_002", "name": "MainChar2", "color": "#eab308", "description": "Secondary main character" },
    { "id": "tag_003", "name": "NPC", "color": "#6b7280", "description": "Non-player character" },
    { "id": "tag_004", "name": "Friend", "color": "#22c55e", "description": "Ally or friend character" },
    { "id": "tag_005", "name": "Foe", "color": "#ef4444", "description": "Enemy or foe character" }
  ]
}
```

**File Metadata** (stored in existing file info JSON):
```json
{
  "name": "Character_Alice.html",
  "path": "Characters/Character_Alice.html",
  "type": "file",
  "tags": ["MainChar", "Friend"],
  "relationships": []
}
```

### Backend API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/tags` | List all registered tags |
| POST | `/api/tags` | Create a new custom tag |
| DELETE | `/api/tags/:id` | Delete a tag (removes from all files) |
| PATCH | `/api/tags/:id` | Update tag name/color/description |
| GET | `/api/files/by-tag/:tagName` | List all files with a specific tag |
| POST | `/api/files/:path/tags` | Add tag(s) to a file |
| DELETE | `/api/files/:path/tags/:tagName` | Remove tag from a file |
| GET | `/api/files/:path/tags` | Get tags on a specific file |

### Client API Functions

```typescript
getTags(): Promise<Tag[]>
createTag(name: string, color?: string, description?: string): Promise<Tag>
deleteTag(id: string): Promise<void>
updateTag(id: string, updates: Partial<Tag>): Promise<Tag>
getFilesByTag(tagName: string): Promise<FileItem[]>
addTagToFile(filePath: string, tags: string[]): Promise<void>
removeTagFromFile(filePath: string, tagName: string): Promise<void>
getTagsForFile(filePath: string): Promise<string[]>
```

### TagManager Panel

New Activity Bar section that shows:
1. **Tag filter list** - all tags with file count, click to filter explorer
2. **Active document tags** - badges showing current document's tags with add/remove controls
3. **Related documents** - files sharing tags with the active document

### File Explorer Integration

Small colored tag badges displayed after each filename:
```
Character_Alice.html [MainChar][Friend]
Character_Bob.html   [MainChar2]
Villain_Carol.html   [Foe][NPC]
```

### Settings - Tag Management

New "Tags" tab in Settings:
- List all tags with color swatches
- Add new tag (name input, color picker, description)
- Edit tag name/color/description
- Delete tag (with confirmation)

---

## Phase 2: Implicit Relationships

Documents sharing at least one tag are implicitly related.

```
GET /api/files/:path/relationships
```

Returns:
```json
{
  "file": "Characters/Character_Alice.html",
  "implicit": [
    {
      "target": "Characters/Character_Bob.html",
      "sharedTags": ["Friend"],
      "count": 1
    }
  ],
  "explicit": []
}
```

---

## Phase 3: Explicit Relationships (Future)

Users manually create named relationships:
- `related_to`, `references`, `child_of`, `parent_of`, `setting_for`, `foe_of`, `ally_of`
- Stored in file metadata alongside tags
- TagManager gains "Link to Document" section

---

## Phase 4: Relationship Graph Visualization (Future)

Canvas-based diagram:
- Documents as nodes (colored by primary tag)
- Relationships as edges (implicit=dashed, explicit=solid)
- Pan/zoom, click nodes to open documents
- Force-directed auto-layout

---

## Phase 5: Advanced Features (Future)

- Filter explorer by tag combinations
- Bulk tag operations
- Export relationship graph as image
- Relationship-aware search
- Relationship statistics in status bar

---

## File Locations

```
WBServer/
├── server/
│   └── src/
│       ├── services/
│       │   └── fileService.js          # Extended for tag metadata
│       └── routes/
│           └── files.js                # Tag endpoints added
├── client/
│   └── src/
│       ├── services/
│       │   └── api.ts                  # Tag API functions
│       ├── hooks/
│       │   ├── useTags.ts              # Tag state hook
│       │   └── useFiles.ts             # Extended for tag data
│       ├── components/
│       │   ├── TagManager.tsx           # Tag panel component
│       │   ├── FileExplorer.tsx         # Tag badges added
│       │   └── ActivityBar.tsx          # Tags icon added
│       ├── pages/
│       │   └── Settings.tsx             # Tag management tab
│       └── styles/
│           └── globals.css              # Tag badge CSS
├── docs/
│   └── TAG_RELATIONSHIP_SYSTEM.md       # This file
```

---

## Version History

| Version | What Changed |
|---------|-------------|
| v5.0 | Initial tag foundation. Default tags (MainChar, MainChar2, NPC, Friend, Foe). Tag CRUD API. TagManager panel. Tag badges in explorer. Settings tag management. |