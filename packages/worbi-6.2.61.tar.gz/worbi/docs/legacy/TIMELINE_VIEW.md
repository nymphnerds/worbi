# Handoff: Timeline View

**Target Version:** v5.5.0
**Priority:** Medium (world-building tooling, leverages existing tag system)
**Dependencies:**
- DATABASE_MIGRATION.md (useful for date-indexed queries, but can start with filesystem scan)
- CROSS_DOCUMENT_WIKILINKS.md (timeline events may reference each other)

---

## 1. Problem Statement

World-building involves tracking events across time. WORBI users create timeline entries as individual documents but have no way to visualize them chronologically. A Timeline View panel in the Activity Bar would display all timeline entries in order, allowing users to see the arc of their world's history at a glance.

---

## 2. Target Behavior

A new Activity Bar panel (clock icon, `Clock` from lucide-react) that shows a vertical chronological timeline:

```
┌─────────────────────────────────────┐
│  Timeline                           │
├─────────────────────────────────────┤
│  [Filter: All Eras      ▾]         │
│  [Filter: All Categories ▾]         │
│                                     │
│  ─── Third Age ───                 │
│                                     │
│  ● 3A 1247                         │
│  │ The Fall of the Goblin King      │
│  │ Historical · /World/Timeline/    │
│  │                                  │
│  ● 3A 1189                         │
│  │ The Great Migration              │
│  │ Historical · /World/Timeline/    │
│  │                                  │
│  ─── Second Age ───                │
│                                     │
│  ● 2A 892                          │
│  │ Founding of the Elven Council    │
│  │ Historical · /World/Timeline/    │
│  │                                  │
│  ● 2A 450                          │
│  │ The Dragon Wars Begin            │
│  │ War · /World/Timeline/           │
│  │                                  │
│  ○ 2A 300 (approx.)                │
│    First Human Settlements          │
│    Mythological                     │
│                                     │
│  ─── First Age ───                 │
│                                     │
│  ○ ~Creation                       │
│    The World is Formed              │
│    Mythological                     │
└─────────────────────────────────────┘
```

- Clicking an event opens the corresponding document in a new tab
- Era dividers collapse/expand
- Different event categories use different dot colors

---

## 3. How Timeline Events Are Identified

Timeline entries are `.html` documents that contain a specific metadata pattern. WORBI doesn't enforce a rigid schema — instead, it parses documents to extract timeline-relevant information.

### 3.1 Detection

A document is considered a "timeline entry" if it contains ALL of these markers:

1. A `Date/Period:` line in the format: `<p><strong>Date/Period:</strong> VALUE</p>`
2. An `Era:` line: `<p><strong>Era:</strong> VALUE</p>`
3. A `Category:` line: `<p><strong>Category:</strong> VALUE</p>`

OR the document is in the `/World/Timeline/` folder (auto-detected as a timeline entry even without the metadata markers).

### 3.2 Parsing

The server parses each timeline document to extract:

```json
{
  "name": "The Fall of the Goblin King",
  "path": "/World/Timeline/The Fall of the Goblin King.html",
  "date": "3A 1247",
  "era": "Third Age",
  "category": "Historical",
  "isApproximate": false
}
```

**Date format:** Freeform text (e.g., "3A 1247", "1452 BCE", "Year of the Red Moon", "~2000 years ago"). The server normalizes dates for sorting by extracting numeric components where possible, but falls back to alphabetical sorting for non-numeric dates.

**Sorting logic:**
1. Group by era (extracted from the `Era:` field or inferred from the folder structure)
2. Within each era, sort by date:
   - Try to extract a numeric year from the date string
   - If numeric: sort descending (most recent first) within the era
   - If non-numeric: sort alphabetically
3. Eras are sorted manually by a configurable era ordering list

**Era ordering configuration** (in server config or user settings):
```json
{
  "eraOrder": [
    "First Age",
    "Second Age",
    "Third Age",
    "Fourth Age",
    "Future",
    "Unknown"
  ]
}
```

Unknown eras appear at the bottom.

### 3.3 Category Colors

| Category | Color | Tailwind |
|----------|-------|----------|
| Historical | Blue | `bg-blue-400` |
| Personal | Green | `bg-green-400` |
| Mythological | Purple | `bg-purple-400` |
| War / Battle | Red | `bg-red-400` |
| Natural Disaster | Amber | `bg-amber-400` |
| Political | Cyan | `bg-cyan-400` |
| Cultural | Pink | `bg-pink-400` |
| Other / Unknown | Gray | `bg-gray-400` |

---

## 4. API Endpoint

`GET /api/files/timeline`

Response:
```json
{
  "eras": [
    {
      "name": "Third Age",
      "events": [
        {
          "name": "The Fall of the Goblin King",
          "path": "/World/Timeline/The Fall of the Goblin King.html",
          "date": "3A 1247",
          "dateSortable": 1247,
          "category": "Historical",
          "isApproximate": false,
          "snippet": "The Goblin King was overthrown..."
        }
      ]
    },
    {
      "name": "Second Age",
      "events": [...]
    }
  ]
}
```

**Server implementation:**
1. Scan workspace recursively (or query SQLite after DATABASE_MIGRATION)
2. Identify timeline entries by parsing HTML for `Date/Period:`, `Era:`, `Category:` patterns
3. Group by era, sort by date
4. Return structured JSON

**Client caching:** Cache the timeline data for the session. Refresh on file save/create/delete operations.

---

## 5. Activity Bar Integration

Add a new Activity Bar item: `Clock` icon (from lucide-react)

| Activity | Icon |
|----------|------|
| Explorer | `FolderOpen` |
| Search | `Search` |
| Starred | `Star` |
| Tags | `Tag` |
| **Timeline** | **`Clock`** (NEW) |
| (spacer) | |
| AI Sidebar | `Sparkles` |
| Settings | `Settings` |

The Activity Bar icon order becomes: Explorer → Search → Starred → Tags → Timeline → (spacer) → AI → Settings

---

## 6. UI Component

New component: `client/src/components/TimelineView.tsx`

**Layout:** A scrollable vertical list with era headers and event rows.

**Era headers:** Bold text with a horizontal line extending to the right. Collapsible (click to expand/collapse, default expanded).

**Event rows:**
- Colored dot (category-based)
- Date (left-aligned, monospace, muted color)
- Event name (bold, clickable → opens document)
- Category label (small badge)
- File path (gray, small text)

**Filters:**
- Era filter dropdown (multi-select checkboxes)
- Category filter dropdown (multi-select checkboxes)

**Empty state:** "No timeline entries found. Create a document in /World/Timeline/ or add Date/Period, Era, and Category fields to your documents."

**Loading state:** Skeleton placeholder — gray bars simulating event rows with pulsing animation.

**Error state:** If the server fails to parse timeline data: "Could not load timeline. [Retry]"

---

## 7. Integration with Other Features

- **Wiki Links:** Timeline events can link to each other via `[[...]]` (e.g., "Preceded by [[The Dragon Wars]]")
- **Template:** The Timeline Entry template from DOCUMENT_TEMPLATES.md pre-populates `Date/Period`, `Era`, and `Category` fields
- **Tags:** Timeline entries can be tagged like any other document — the tag system works independently
- **Version History:** Revisions track changes to timeline entries as standard documents

---

## 8. Files to Create

| File | Purpose |
|------|---------|
| `server/src/routes/timeline.js` | Timeline data endpoint |
| `client/src/components/TimelineView.tsx` | Timeline panel UI |

## 9. Files to Modify

| File | Changes |
|------|---------|
| `server/src/index.js` | Register `/api/files/timeline` route |
| `client/src/components/ActivityBar.tsx` | Add `Clock` icon for Timeline activity |
| `client/src/App.tsx` | Add `'timeline'` to ActivityType, render `<TimelineView>` in left panel |
| `client/src/services/api.ts` | Add `getTimeline()` function |
| `client/src/styles/globals.css` | Add timeline view styles |

---

## 10. Edge Cases

| Scenario | Handling |
|----------|----------|
| **No timeline entries** | Show empty state with helpful instructions |
| **Document with malformed date** | Include it but flag it as "Unparseable date" — sort alphabetically at the bottom of its era |
| **Same date, multiple events** | Sort alphabetically by name within the same date |
| **Very long era names** | Truncate with ellipsis in the header |
| **100+ timeline entries** | Virtualized scrolling using `react-window` or similar (or paginate server-side) |
| **Date format with negative years (BCE)** | Extract numeric value with sign, sort ascending (more negative = older) |
| **Document renamed/moved** | Timeline view refreshes — the entry's path updates |
| **Era not in era order list** | Append to the bottom of the timeline with "Other Eras" header |

---

## 11. Verification Checklist

- [ ] Timeline icon appears in the Activity Bar
- [ ] Clicking Timeline icon shows the Timeline View panel
- [ ] Timeline entries are grouped by era
- [ ] Events within an era are sorted by date (most recent first)
- [ ] Era headers are collapsible
- [ ] Clicking an event opens the document in a new tab
- [ ] Filters by era and category work
- [ ] Multiple filters can be combined
- [ ] Empty state shows when no timeline entries exist
- [ ] Documents in /World/Timeline/ are auto-detected
- [ ] Documents with Date/Period + Era + Category fields are detected anywhere in the workspace
- [ ] Timeline refreshes when documents are created/deleted
- [ ] Category dots use correct colors
- [ ] Approximate dates show "~" or "(approx.)" indicator
- [ ] Non-numeric dates are sorted alphabetically

---

## 12. Future Enhancements

- **Visual timeline graph:** A horizontal, scrollable timeline bar with event markers (D3.js or similar)
- **Date range filtering:** "Show events between 2A 500 and 3A 1000"
- **Relationship arrows:** Show connections between events (causes, consequences) as vertical lines
- **Calendar view:** Display events on a calendar-style grid for short-timespan campaigns
- **AI timeline generation:** "Generate a timeline of the Goblin Wars" using the LLM
- **Export timeline as image:** Render the timeline as a PNG for sharing