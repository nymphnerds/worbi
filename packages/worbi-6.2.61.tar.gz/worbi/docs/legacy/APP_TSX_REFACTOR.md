# Handoff: App.tsx Decomposition into Feature Slices

**Target Version:** v5.2.0  
**Priority:** Medium (improves maintainability, reduces bug surface)  
**Dependencies:** Should be done AFTER Blob URL Bridge Fix (the blob URL machinery is one of the biggest contributors to App.tsx bloat)

---

## 1. Problem Statement

`client/src/App.tsx` is 908 lines long and manages an excessive number of concerns:

| Concern | Approximate Lines | Description |
|---------|-------------------|-------------|
| Auth state | 30 | `useAuth`, login/logout flow |
| Layout management | 80 | Left/right panel widths, draggable resizers, AI sidebar toggle |
| Activity routing | 60 | ActivityBar state, switching between explorer/search/tags/starred |
| File operations | 150 | `useFiles` hook wiring, file CRUD, uploads, DOCX import/export |
| Blob URL management | 120 | `blobUrlMapRef`, `tabBlobUrlsRef`, conversion functions, cleanup effects |
| Image insertion | 40 | `imageToInsert`, `imageUrlToInsert` state + handlers |
| Undo/redo | 40 | `useFileSystemUndoRedo` wiring, refreshRef pattern |
| Recents & stars | 30 | `useRecents` hook wiring |
| Search | 20 | `useSearch` hook wiring |
| Tags | 25 | `tagsShowAddTag` state, tag sidebar handlers |
| Keyboard shortcuts | 50 | Global keyboard handler (Ctrl+S, Ctrl+Shift+S, etc.) |
| DOCX handling | 40 | Import/export DOCX functions, file input ref |
| Settings | 20 | Settings modal state, login/logout passthrough |
| Error handling | 10 | Global error state display |
| JSX rendering | ~200 | Nested conditional rendering of the entire layout |

**Consequences:**
- Adding a new feature requires touching this file, increasing merge conflict risk
- State variables are scattered and hard to trace
- The component re-renders entirely when any slice of state changes (though hooks mitigate this somewhat)
- Testing individual features in isolation is impossible
- The file defies summarization — a new developer cannot understand it quickly
- Several bugs (v4.2 stale closure, v4.11 crash) stemmed from complex state interactions within this file

---

## 2. Target Architecture

Extract each concern into a self-contained feature module: a custom hook plus, where appropriate, a layout wrapper component. App.tsx should become an **orchestrator** (~150 lines) that composes feature modules and renders the layout shell.

### 2.1 Proposed File Structure After Refactor

```
client/src/
├── App.tsx                          # ~150 lines — layout shell + feature composition
├── features/
│   ├── layout/
│   │   ├── useLayout.ts            # Panel widths, draggable resizers, AI sidebar
│   │   ├── LayoutContext.tsx        # React context for layout state
│   │   └── AppLayout.tsx           # Top-level layout component (grid of panels)
│   ├── files/
│   │   ├── useFileOperations.ts    # File CRUD, uploads, DOCX import/export
│   │   └── useImageInsertion.ts    # Image insertion state + handlers (after blob URL fix)
│   ├── editor/
│   │   ├── useTabManager.ts        # Tab open/close/switch, dirty state, content tracking
│   │   ├── useKeyboardShortcuts.ts # Global keyboard shortcut handler
│   │   └── useEditorSync.ts        # Editor content sync (currently intertwined with blob URLs)
│   ├── navigation/
│   │   ├── useActivityRouter.ts    # Activity switching, tag sidebar state
│   │   └── useSettings.ts          # Settings modal state
│   └── auth/
│       └── AuthProvider.tsx         # Auth context provider (wrap App)
├── hooks/                           # Keep existing hooks here
│   ├── useAuth.ts
│   ├── useFiles.ts
│   ├── useLLM.ts
│   ├── useRecents.ts
│   ├── useSearch.ts
│   ├── useTags.ts
│   └── useFileSystemUndoRedo.ts
└── components/                      # Keep existing components here
```

### 2.2 Orchestrator Pattern

The refactored `App.tsx` should look like this conceptually:

- Import feature hooks and layout components
- Call each feature hook at the top level
- The JSX renders `<AppLayout>` with child panels, passing only the props each panel needs
- No business logic in JSX — only conditional rendering and prop passing
- No raw `useState`/`useRef` calls except those belonging to the layout itself

---

## 3. Feature Slice Specifications

### 3.1 Layout Feature (`features/layout/`)

**`useLayout.ts` hook:**
- Manages: `leftWidth`, `rightWidth`, `searchWidth`, `showAISidebar`
- Exposes: current values, setter functions, `toggleAISidebar()`, drag handlers for each resizer
- Persists `showAISidebar` to `localStorage` (currently in App.tsx)
- Persists panel widths to `localStorage` so the user's layout is restored on reload
- The drag handlers accept `MouseEvent` and compute new widths with min/max constraints:
  - Left panel: 180px min, 500px max
  - Right panel (AI sidebar): 280px min, 600px max
  - Search panel: 200px min, 500px max

**`LayoutContext.tsx`:**
- React Context provider that wraps the app
- Provides layout state to deeply nested components that need it (e.g., `DocumentEditor` needs to know available width)
- Avoids prop drilling through `Header` → `DocumentEditor` → etc.

**`AppLayout.tsx`:**
- Pure presentational component
- Renders the CSS grid/flexbox structure: ActivityBar | LeftPanel | EditorArea | RightPanel(AI)
- Accepts children via slots: `leftPanel`, `mainContent`, `rightPanel`, `activityBar`
- Renders the draggable dividers between panels
- No business logic — just layout structure and resize handle rendering

### 3.2 File Operations Feature (`features/files/`)

**`useFileOperations.ts` hook:**
- Wraps and orchestrates the existing `useFiles` hook
- Manages DOCX import/export:
  - `handleExportDOCX()` — calls `useFiles` content + docx library
  - `handleImportDOCX()` — triggers file input, reads DOCX, opens as HTML
  - `importDocxInputRef` — ref to the hidden file input
  - `isDocxFile()` helper
- Manages file upload handling:
  - `handleFileUpload()` — handles drop/paste of files into the explorer
  - `handleDocxFileDetected()` — intercepts DOCX files during upload
- Manages `explorerPath` state for the FileExplorer breadcrumb navigation
- Exposes: all file operations, explorer path, DOCX handlers, upload handlers, file list state

**`useImageInsertion.ts` hook (post Blob URL Fix):**
- Manages: `imageToInsert`, `imageUrlToInsert` state
- After the blob URL fix, this becomes much simpler — just sets the image URL (now a signed proxy URL) for the editor to insert
- `handleImageClick(path)` — calls `POST /api/images/sign`, sets `imageToInsert`
- `handleImageInserted()` — clears `imageToInsert` after the editor consumes it
- `isImageFile()` helper

### 3.3 Editor Feature (`features/editor/`)

**`useTabManager.ts` hook:**
- Wraps tab state management currently inside `useFiles`:
  - `tabs`, `activeTabId`
  - `openFile()`, `closeTab()`, `closeOtherTabs()`, `closeAllTabs()`
  - Tab dirty state tracking
  - `openFileWithConversion()` (post blob URL fix: calls sign-batch, then opens)
- Computes `activeTab` from `tabs` and `activeTabId`
- Computes `dirty` from the active tab's dirty flag
- Manages `setContent()` for the active tab

**`useKeyboardShortcuts.ts` hook:**
- Registers a global `keydown` event listener on `window`
- Handles: `Ctrl+S` (save), `Ctrl+Shift+S` (save as), `Ctrl+B/I/U` (formatting passthrough to TipTap), `Ctrl+F` (find), `Ctrl+H` (find & replace), `Ctrl+Z` (undo file op), `Ctrl+Y` (redo file op), `Ctrl+N` (new file), `Escape` (close modals)
- Accepts callbacks for each action (e.g., `onSave`, `onFind`, `onUndo`)
- Skips shortcuts when a modal is open or when focus is in an input/textarea (unless the shortcut is specifically for that input, like Escape in Find & Replace)
- Cleanup: removes the event listener on unmount

**`useEditorSync.ts` hook (post Blob URL Fix):**
- Replaces the current content sync `useEffect` in App.tsx
- Distinguishes between user-initiated changes (typing) and external changes (file loads)
- Uses a ref-based flag (`isUserChangeRef`) pattern to skip sync on user typing
- Triggers content-to-editor sync when `activeTabId` or `content` changes externally
- This hook may become much simpler after the blob URL fix since the conversion step disappears

### 3.4 Navigation Feature (`features/navigation/`)

**`useActivityRouter.ts` hook:**
- Manages `activeActivity` state (explorer | search | starred | tags)
- Manages `tagsShowAddTag` state for the tag sidebar
- `handleOpenTagSidebar()` — switches to tags activity and opens the add-tag form
- Resets `tagsShowAddTag` when switching away from tags activity
- Exposes: current activity, setter, tag sidebar state, handlers

**`useSettings.ts` hook:**
- Manages `showSettings` modal state
- `openSettings()`, `closeSettings()`
- Simple toggle wrapper

### 3.5 Auth Feature (`features/auth/`)

**`AuthProvider.tsx`:**
- Context provider that wraps the entire App
- Uses the existing `useAuth` hook internally
- Provides `user`, `isAuthenticated`, `login()`, `logout()` via context
- If not authenticated, renders `<Login>` instead of children
- This removes auth conditionals from App.tsx entirely — App.tsx only renders when authenticated

---

## 4. Implementation Order

This refactor must be done incrementally to avoid a massive, unreviewable PR. Each step should be a separate commit/PR that leaves the app fully functional.

### Step 1: Extract Layout

1. Create `features/layout/useLayout.ts`
   - Move `leftWidth`, `rightWidth`, `searchWidth`, `showAISidebar` state
   - Move `toggleAISidebar()` function
   - Add `localStorage` persistence for widths (not just AI sidebar)
   - Create drag handler factory functions: `createHorizontalResizeHandler(setter, min, max)`
   - Export everything as a single hook return value

2. Create `features/layout/LayoutContext.tsx`
   - Simple context with layout state
   - Provider wraps children
   - Export `useLayoutContext()` consumer hook
   - Use this context in components that need to know available space (e.g., DocumentEditor for fitting toolbars)

3. Create `features/layout/AppLayout.tsx`
   - Extract the JSX grid structure from App.tsx
   - Accept children as props: `activityBar`, `leftPanel`, `mainContent`, `rightPanel`
   - Render resizer divs with `onMouseDown` handlers from `useLayout`
   - This component is purely presentational

4. Update App.tsx to use `useLayout` and render `<AppLayout>`

**Verification:** Layout resizing still works, AI sidebar toggle works, widths persist across reload.

### Step 2: Extract Auth

1. Create `features/auth/AuthProvider.tsx`
   - Import `useAuth` from `hooks/useAuth`
   - Call `useAuth()` inside the provider component
   - Create `AuthContext` with `{ user, isAuthenticated, login, logout }`
   - If `!isAuthenticated`, render `<Login onLogin={login} />`
   - Otherwise, render `{children}`

2. In `client/src/main.tsx`:
   - Wrap `<App />` with `<AuthProvider>`

3. In `App.tsx`: Remove auth conditionals — `App` is now only rendered when authenticated
   - Remove `useAuth` import
   - Remove `Login` import
   - Remove the `if (!isAuthenticated)` early return

**Verification:** Login/logout still works, protected routes still require auth.

### Step 3: Extract Navigation

1. Create `features/navigation/useActivityRouter.ts`
   - Move `activeActivity` state
   - Move `tagsShowAddTag` state
   - Move `handleOpenTagSidebar()` callback
   - Move the `useEffect` that resets tagsShowAddTag when activity changes
   - Export: `{ activeActivity, setActiveActivity, tagsShowAddTag, handleOpenTagSidebar }`

2. Create `features/navigation/useSettings.ts`
   - Move `showSettings` state
   - Export: `{ showSettings, openSettings, closeSettings }`

3. Update App.tsx to use both hooks.

**Verification:** Activity switching works, tag sidebar opens from + button, settings modal opens/closes.

### Step 4: Extract File Operations

1. Create `features/files/useFileOperations.ts`
   - Accept `username` (from auth context) as a parameter
   - Internally call `useFiles()` with the username
   - Move DOCX import/export functions from App.tsx
   - Move `explorerPath` state
   - Move `isDocxFile()` and `isImageFile()` helpers
   - Move upload handler logic
   - Export all file operations, explorer path, file list state, DOCX handlers

2. Create `features/files/useImageInsertion.ts` (if blob URL fix already done)
   - Move `imageToInsert`, `imageUrlToInsert` state
   - Move image click handler (updated for proxy URLs)
   - Move `onImageInserted` callback
   - Move `isImageFile()` helper

3. Update `useFileSystemUndoRedo` wiring:
   - The `refreshRef` pattern (where `loadFiles` is passed after initialization) should be internalized in `useFileOperations`
   - Remove the separate `useEffect` that wires `refreshRef.current = () => loadFiles(explorerPath)`

4. Update App.tsx to use `useFileOperations` and `useImageInsertion`.

**Verification:** All file operations work (create, delete, rename, copy, move), DOCX import/export works, image insertion works, undo/redo works.

### Step 5: Extract Editor

1. Create `features/editor/useTabManager.ts`
   - Move tab state management logic
   - Accept file operations from `useFileOperations` as parameters
   - Implement tab CRUD: open, close, closeOthers, closeAll
   - Compute `activeTab`, `dirty`, `content` for the active tab
   - Move `openFileWithConversion` (updated for proxy URLs)

2. Create `features/editor/useKeyboardShortcuts.ts`
   - Move the `useEffect` with the `keydown` listener
   - Accept callback props: `onSave`, `onFind`, `onFindReplace`, `onUndo`, `onRedo`, `onNewFile`
   - Handle `Ctrl+S`, `Ctrl+F`, `Ctrl+H`, `Ctrl+Z`, `Ctrl+Y`, `Ctrl+N`, `Escape`
   - Handle `Cmd+*` variants for Mac (check `event.metaKey`)
   - Prevent default browser behavior for handled shortcuts
   - Do NOT handle formatting shortcuts (Ctrl+B/I/U) — those are handled by TipTap internally

3. Create `features/editor/useEditorSync.ts` (simpler after blob URL fix)
   - Move the content sync `useEffect`
   - If still needed: `isUserChangeRef` pattern for cursor position preservation
   - Trigger sync when `activeTabId` or `content` changes externally

4. Update App.tsx to use these hooks.

**Verification:** All keyboard shortcuts work, tabs open/close/switch correctly, content saves and loads, cursor doesn't jump.

### Step 6: Final Cleanup

1. Review App.tsx — it should now be ~150 lines:
   - Import feature hooks
   - Call all hooks at the top
   - Compute derived values (e.g., which component to show in the left panel)
   - Render `<AppLayout>` with computed children
   - No business logic remains

2. Verify all imports — remove unused imports from App.tsx
3. Verify no circular dependencies between feature modules
4. Update `client/src/main.tsx` to include `AuthProvider`
5. Full manual test of every feature

---

## 5. Dependency Rules

To prevent circular dependencies, enforce these rules:

| Module | May Import From |
|--------|----------------|
| `features/layout/*` | React only (no other features) |
| `features/auth/*` | `hooks/useAuth`, React |
| `features/navigation/*` | React only |
| `features/files/*` | `hooks/useFiles`, `hooks/useFileSystemUndoRedo`, `services/api`, React |
| `features/editor/*` | `features/files/*` (for save/open callbacks), React |
| `App.tsx` | All features, all components |
| Components (`components/*`) | `features/layout/LayoutContext`, `hooks/*`, `services/api`, React |

**Key rule:** Features can depend on hooks and services, but NOT on other features (except `editor` → `files`). Components can depend on hooks and the layout context.

---

## 6. Shared State Patterns

### 6.1 When to Use Context vs. Props

| State | Method | Rationale |
|-------|--------|-----------|
| Layout (widths, sidebar visibility) | Context (`LayoutContext`) | Needed by deeply nested components (DocumentEditor, panels) |
| Auth (user, login, logout) | Context (`AuthContext`) | Needed everywhere for API calls |
| File operations | Props (from App.tsx) | Only needed by FileExplorer, Header, TabBar |
| Tab state | Props (from App.tsx) | Only needed by TabBar, DocumentEditor, Welcome |
| Activity routing | Props (from App.tsx) | Only needed by ActivityBar, panel switcher |
| Undo/redo | Props (from App.tsx) | Only needed by Header |
| Search | Props (from App.tsx) | Only needed by SearchPanel |

Don't over-use context — it makes component reuse harder and obscures data flow. Only use it for truly global concerns (auth, layout).

### 6.2 Callback Pattern for Cross-Feature Communication

When one feature needs to trigger an action in another, use callback props passed down from App.tsx:

```
App.tsx:
  const fileOps = useFileOperations(username);
  const tabManager = useTabManager(fileOps);
  const shortcuts = useKeyboardShortcuts({
    onSave: tabManager.saveActiveTab,
    onUndo: fileOps.undo,
    // ...
  });
```

App.tsx is the wiring layer — it knows about all features and connects them together. Features remain isolated.

---

## 7. React Performance Considerations

### 7.1 Memoize Callbacks

All callbacks passed to child components should be wrapped in `useCallback` to prevent unnecessary re-renders. This is already done in many places in App.tsx — preserve this pattern in the extracted hooks.

### 7.2 Memoize Derived Values

Computed values like `activeTab`, `dirty`, and `currentFileName` should use `useMemo` when they depend on multiple state variables.

### 7.3 Avoid State Colocation

If a child component is the only consumer of a piece of state, move that state into the child. For example:
- `showFindReplace` belongs in `DocumentEditor`, not in App.tsx (it's already there — keep it)
- `showSettings` could stay in App.tsx since the Settings button is in ActivityBar but the modal is at the App level

### 7.4 Context Value Stability

When creating context values, wrap them in `useMemo` to prevent re-renders of all consumers when only one value changes:

```
const layoutContextValue = useMemo(() => ({
  leftWidth, rightWidth, searchWidth, showAISidebar,
  toggleAISidebar, resizeLeftPanel, resizeRightPanel, resizeSearchPanel
}), [leftWidth, rightWidth, searchWidth, showAISidebar, toggleAISidebar, resizeLeftPanel, resizeRightPanel, resizeSearchPanel]);
```

---

## 8. Files to Create

| File | Purpose |
|------|---------|
| `client/src/features/layout/useLayout.ts` | Panel width management, drag handlers, AI sidebar toggle |
| `client/src/features/layout/LayoutContext.tsx` | React context for layout state |
| `client/src/features/layout/AppLayout.tsx` | Presentational layout grid component |
| `client/src/features/auth/AuthProvider.tsx` | Auth context provider with login gate |
| `client/src/features/navigation/useActivityRouter.ts` | Activity switching and tag sidebar state |
| `client/src/features/navigation/useSettings.ts` | Settings modal toggle |
| `client/src/features/files/useFileOperations.ts` | File CRUD orchestration, DOCX, uploads |
| `client/src/features/files/useImageInsertion.ts` | Image insertion state and handlers |
| `client/src/features/editor/useTabManager.ts` | Tab open/close/switch, dirty tracking |
| `client/src/features/editor/useKeyboardShortcuts.ts` | Global keyboard shortcut registration |
| `client/src/features/editor/useEditorSync.ts` | Editor content synchronization |

## 9. Files to Modify

| File | Changes |
|------|---------|
| `client/src/App.tsx` | Reduce from 908 to ~150 lines; import and compose feature hooks |
| `client/src/main.tsx` | Wrap `<App>` with `<AuthProvider>` |
| `client/src/components/Header.tsx` | Remove auth-related props (use `AuthContext`); may need layout context for responsive behavior |
| `client/src/components/ActivityBar.tsx` | May use `LayoutContext` if it needs to know panel states |

## 10. Files With No Changes Required

| File | Reason |
|------|--------|
| `client/src/hooks/useFiles.ts` | Used internally by `useFileOperations` — no API change |
| `client/src/hooks/useLLM.ts` | No change — already a standalone hook |
| `client/src/hooks/useRecents.ts` | No change — already a standalone hook |
| `client/src/hooks/useSearch.ts` | No change — already a standalone hook |
| `client/src/hooks/useTags.ts` | No change — already a standalone hook |
| `client/src/hooks/useFileSystemUndoRedo.ts` | Used internally by `useFileOperations` — no API change |
| `client/src/services/api.ts` | No change |
| All components in `components/` | Their props come from App.tsx regardless of where the state lives |
| `client/src/pages/Login.tsx` | Rendered by AuthProvider instead of App.tsx — same props |
| `client/src/pages/Settings.tsx` | Rendered by App.tsx with the same props |

---

## 11. Verification Checklist

- [ ] App compiles with no TypeScript errors
- [ ] App renders without React console errors
- [ ] Login screen appears when not authenticated
- [ ] Main UI appears after login
- [ ] Activity Bar switching works (Explorer ↔ Search ↔ Starred ↔ Tags)
- [ ] Left panel resizing works (draggable divider)
- [ ] AI sidebar toggle works and state persists across reload
- [ ] Creating, renaming, deleting files works
- [ ] Copy and move file operations work
- [ ] Opening a file loads content into the editor
- [ ] Saving a file persists content to disk
- [ ] Ctrl+S saves the current file
- [ ] Ctrl+F opens Find panel in the editor
- [ ] Ctrl+H opens Find & Replace panel in the editor
- [ ] Ctrl+Z/Ctrl+Y triggers file operation undo/redo
- [ ] Ctrl+N creates a new file
- [ ] Image insertion works (from file explorer and image explorer)
- [ ] DOCX import works (via Header Import button)
- [ ] DOCX export works (via editor toolbar button)
- [ ] File upload works (drag/drop and upload button)
- [ ] Tag sidebar opens from + button in editor toolbar
- [ ] Settings modal opens and closes
- [ ] No feature regressions: every existing feature functions identically to before the refactor
- [ ] App.tsx is under 200 lines
- [ ] No circular import warnings in the browser console or build output
- [ ] React DevTools shows a clean component tree without excessive nesting

## 12. Rollback Plan

1. Make each step (1–6) a separate git commit
2. Test thoroughly after each commit before proceeding to the next
3. If a step introduces a bug, revert that specific commit and fix it in isolation
4. The existing App.tsx serves as a reference — if the refactor goes badly, revert all commits and keep the monolithic version
5. Consider doing this work on a long-lived feature branch (`refactor/app-split`) merged only after all steps are verified