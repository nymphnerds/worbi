# Handoff: AI Writing Enhancements

**Target Version:** v5.5.0
**Priority:** High (leverages existing LLM infrastructure + local Z-Image backend)
**Dependencies:**
- LLM_PROVIDER_CONFIG_REDESIGN.md (chat endpoint should be stabilized first)
- Z-Image/Nymphs2D2 backend running locally (default port 8090, configurable)
- BLOB_URL_BRIDGE_FIX.md (generated images must be saved with correct URLs)

---

## 1. Overview

This handoff covers three AI-powered features plus integration with the local Nymphs2D2 (Z-Image) image generation backend:

| Feature | Description | Complexity |
|---------|-------------|------------|
| **1. Inline AI Writing Assistant** | Context-aware prose suggestions in the editor, Copilot-style | Medium |
| **2. AI Document Generation** | Generate structured documents from prompts using AI tools | Medium |
| **3. AI Name Generator** | Generate culture-specific character/location/item names | Small |
| **4. Z-Image Integration** | txt2img/img2img via local Nymphs2D2 FastAPI backend | Medium |

---

## 2. Feature 1: Inline AI Writing Assistant

### 2.1 Behavior

The user places the cursor at a point in the document and invokes the assistant (keyboard shortcut or toolbar button). The AI reads the surrounding context (previous ~500 words) and suggests the next paragraph. The suggestion appears as ghosted/dimmed text inline. The user presses Tab to accept or Escape to dismiss.

```
User writes:
  "The Goblin King surveyed his domain. The cavern stretched"

User presses Ctrl+Space (or clicks ✨ button)

Ghost text appears (dimmed, italic):
  "The Goblin King surveyed his domain. The cavern stretched
   endlessly into the darkness, punctuated only by the faint
   glow of bioluminescent fungi clinging to the stalactites
   overhead. His throne, carved from obsidian and inlaid with
   the bones of defeated rivals, sat atop a natural dais of
   volcanic rock."

User presses Tab → ghost text becomes real text
User presses Escape → ghost text disappears
```

### 2.2 Implementation

**Server endpoint:** `POST /api/llm/complete`

Request:
```json
{
  "context": "The Goblin King surveyed his domain. The cavern stretched",
  "documentTitle": "Goblin King.html",
  "documentContext": "... (optional: full document or surrounding paragraphs) ...",
  "maxTokens": 200
}
```

Response:
```json
{
  "completion": "endlessly into the darkness, punctuated only by the faint glow...",
  "model": "local-model-7b"
}
```

**System prompt for completions:**
```
You are a creative writing assistant embedded in WORBI, a world-building document editor.
Complete the user's text in their voice and style. Continue naturally from the cutoff point.
Match the tone, vocabulary, and pacing of the surrounding text.
Do NOT add dialogue markers, chapter headings, or structural elements unless the context clearly calls for them.
Output ONLY the continuation text — no explanations, no meta-commentary.
```

### 2.3 Client Implementation

- **Keyboard shortcut:** `Ctrl+Space` triggers completion at cursor position
- **Toolbar button:** A `Sparkles` icon next to the existing AI toggle
- **Ghost text rendering:** Use TipTap's `Decoration` system to render suggested text as a dimmed decoration after the cursor
- **Debounce:** The completion request should not fire more than once per 2 seconds
- **Loading state:** The toolbar button shows a pulsing animation while waiting for the response

### 2.4 TipTap Integration

The ghost text is implemented as a TipTap decoration:

```typescript
// In DocumentEditor.tsx, add a plugin:
import { Plugin, PluginKey } from 'prosemirror-state';
import { Decoration, DecorationSet } from 'prosemirror-view';

const ghostTextPluginKey = new PluginKey('ghostText');

const ghostTextPlugin = new Plugin({
  key: ghostTextPluginKey,
  state: {
    init() { return DecorationSet.empty; },
    apply(tr, set) { return set.map(tr.mapping, tr.doc); },
  },
  props: {
    decorations(state) {
      return this.getState(state);
    },
  },
});
```

When ghost text is active, create a `Decoration.widget` at the cursor position with dimmed, italic styling.

---

## 3. Feature 2: AI Document Generation

### 3.1 Behavior

A "Generate" button in the Welcome screen (and optionally in the File Explorer context menu) opens a modal:

```
┌─────────────────────────────────────┐
│  Generate Document with AI          │
├─────────────────────────────────────┤
│                                     │
│  Document Type:                     │
│  ┌─────────────────────────────┐   │
│  │ Character Sheet         ▾   │   │
│  └─────────────────────────────┘   │
│                                     │
│  Prompt:                            │
│  ┌─────────────────────────────┐   │
│  │ An ancient dragon who       │   │
│  │ secretly rules a merchant   │   │
│  │ guild in human form...      │   │
│  └─────────────────────────────┘   │
│                                     │
│  ─── Include in Prompt ───         │
│  ☑ World setting                   │
│  ☑ Current document context        │
│                                     │
│  [Cancel]      [Generate]          │
└─────────────────────────────────────┘
```

### 3.2 Document Type Templates

Each document type has a structured system prompt that guides the AI output:

**Character Sheet:**
```
You are generating a character sheet for a world-building project.
Output structured HTML with these sections:
<h2>Character Name</h2>
<p><strong>Role:</strong> ...</p>
<p><strong>Race/Species:</strong> ...</p>
<p><strong>Age:</strong> ...</p>
<h3>Physical Description</h3>
<p>...</p>
<h3>Personality</h3>
<p>...</p>
<h3>Background</h3>
<p>...</p>
<h3>Abilities & Skills</h3>
<p>...</p>
<h3>Motivations & Goals</h3>
<p>...</p>
<h3>Relationships</h3>
<p>...</p>
<h3>Notes</h3>
<p>...</p>

Fill in all sections with creative, detailed content based on the user's prompt.
Use the margin column (<!-- MARGIN_SPLIT -->) for supplementary notes.
```

**Location Description:**
```
You are generating a location description for a world-building project.
Output structured HTML with these sections:
<h2>Location Name</h2>
<p><strong>Type:</strong> (city, dungeon, forest, mountain, etc.)</p>
<p><strong>Region:</strong> ...</p>
<p><strong>Climate:</strong> ...</p>
<h3>Geography & Layout</h3>
<p>...</p>
<h3>Population & Culture</h3>
<p>...</p>
<h3>Points of Interest</h3>
<p>...</p>
<h3>History</h3>
<p>...</p>
<h3>Adventure Hooks</h3>
<p>...</p>

Fill in all sections with creative, detailed content based on the user's prompt.
```

**Quest Outline:**
```
You are generating a quest outline for a world-building project.
Output structured HTML with these sections:
<h2>Quest Name</h2>
<p><strong>Recommended Level:</strong> ...</p>
<p><strong>Quest Giver:</strong> ...</p>
<p><strong>Location:</strong> ...</p>
<h3>Hook</h3>
<p>How the party discovers the quest...</p>
<h3>Objectives</h3>
<ol><li>...</li><li>...</li></ol>
<h3>Key NPCs</h3>
<p>...</p>
<h3>Encounters</h3>
<p>...</p>
<h3>Rewards</h3>
<p>...</p>
<h3>Possible Complications</h3>
<p>...</p>

Fill in all sections with creative, detailed content based on the user's prompt.
```

**Timeline Entry:**
```
You are generating a timeline entry for a world-building project.
Output structured HTML with these sections:
<h2>Event Name</h2>
<p><strong>Date/Period:</strong> ...</p>
<p><strong>Category:</strong> (historical, personal, mythological, etc.)</p>
<h3>Description</h3>
<p>What happened...</p>
<h3>Key Figures</h3>
<p>...</p>
<h3>Consequences</h3>
<p>How this event shaped the world...</p>
<h3>Related Events</h3>
<p>...</p>
```

**Freeform:**
```
You are generating content for a world-building document.
Write creative, detailed prose based on the user's prompt.
Use HTML formatting with appropriate headings, paragraphs, and lists.
```

### 3.3 Implementation

**Client:**
- `client/src/components/GenerateDocumentModal.tsx` — modal with document type selector, prompt input, generate button
- Called from `Welcome.tsx` ("Generate with AI" button) and File Explorer context menu

**Server:**
- Uses existing `POST /api/llm/chat` endpoint with `toolPermissions` disabled (no tools needed for generation)
- The prompt is wrapped in the appropriate system prompt based on document type
- Response HTML is created as a new file in the user's workspace

**Flow:**
1. User opens modal, selects type, enters prompt
2. Client sends prompt + type to a new endpoint or wraps it in a chat message
3. Server constructs the full system prompt, sends to LLM
4. Response HTML is saved as a new file (e.g., `CharacterName.html`)
5. Client opens the new file in a tab

---

## 4. Feature 3: AI Name Generator

### 4.1 Behavior

A small tool accessible from the editor toolbar or Activity Bar:

```
┌─────────────────────────────────────┐
│  Name Generator                     │
├─────────────────────────────────────┤
│  Culture:                           │
│  ┌─────────────────────────────┐   │
│  │ Elvish                     │   │
│  │ Dwarvish                   │   │
│  │ Nordic / Viking            │   │
│  │ Roman / Latin              │   │
│  │ Japanese                   │   │
│  │ Arabic / Middle Eastern    │   │
│  │ Draconic                   │   │
│  │ Fey / Whimsical            │   │
│  │ Dark / Gothic              │   │
│  │ Custom...                  │   │
│  └─────────────────────────────┘   │
│                                     │
│  Type:  ○ Character  ○ Place       │
│          ○ Item      ○ Faction      │
│                                     │
│  Gender: ○ Any  ○ Male  ○ Female   │
│           ○ Neutral                 │
│                                     │
│  Count: [5] names to generate       │
│                                     │
│  ─── Generated Names ───           │
│  Aelindriel Moonshadow              │
│  Thalanil Starweaver                │
│  Caelum Nightbreeze                 │
│  Sylvara Dawnmist                   │
│  Elandor Silverleaf                 │
│                                     │
│  [Insert at Cursor]  [Generate]     │
└─────────────────────────────────────┘
```

### 4.2 Implementation

Uses the existing `POST /api/llm/chat` endpoint with a system prompt:

```
You are a name generator for a world-building tool. Generate {count} unique {culture} {type} names ({gender}).
Each name should include a first name and optionally a surname or epithet.
Output as a JSON array of strings. No explanations, no commentary.
Example: ["Aelindriel Moonshadow", "Thalanil Starweaver"]
```

- Minimal server-side code — just a well-crafted system prompt
- Client component: `client/src/components/NameGenerator.tsx`
- Results appear in a scrollable list with an "Insert at Cursor" button
- Also accessible from the AI chat panel as a tool (add to `toolService.js`)

---

## 5. Feature 4: Z-Image Integration (Local Image Generation)

### 5.1 The Nymphs2D2 Backend

The local image generation backend lives at `/home/nymph/Z-Image/` and provides:

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/health` | GET | Health check — `{ "status": "healthy", "worker_id": "abc123" }` |
| `/server_info` | GET | Runtime info — model ID, device, dtype, supported modes, nunchaku status |
| `/active_task` | GET | Current generation progress — status, stage, progress_percent |
| `/generate` | POST | Generate an image (txt2img or img2img) |

**Default config:**
- Model: `Tongyi-MAI/Z-Image-Turbo`
- Port: 8090
- Runtime: standard or nunchaku (quantized, ~19.8s at 1024×1024, ~1.3 GiB VRAM)
- Output: PNG + metadata JSON saved to `~/Nymphs2D2/outputs/`

### 5.2 WORBI Integration Architecture

```
┌──────────┐     ┌───────────────┐     ┌──────────────┐
│  WORBI   │────▶│ WORBI Server  │────▶│ Nymphs2D2    │
│  Client  │     │ (Express)     │     │ (FastAPI:8090)│
│          │     │               │     │              │
│ Generate │     │ POST /api/llm │     │ POST /generate│
│  Image   │     │ /generate-img │     │              │
│  modal   │     │               │     │ Z-Image-Turbo│
│          │     │◀──────────────│     │ generation   │
│          │     │  output_path  │     │              │
│          │     │               │     │              │
│          │     │ Copy to user  │     │              │
│          │     │ assets/images/│     │              │
│          │◀────│               │     │              │
│          │     │               │     │              │
│  Image   │     │               │     │              │
│  appears │     │               │     │              │
│  in Image│     │               │     │              │
│  Explorer│     │               │     │              │
└──────────┘     └───────────────┘     └──────────────┘
```

### 5.3 New WORBI Server Routes

**`POST /api/llm/generate-image`**

Request:
```json
{
  "mode": "txt2img",
  "prompt": "painted fantasy goblin adventurer, full body, neutral pose, dark cave background",
  "negative_prompt": "blurry, low quality, deformed",
  "width": 1024,
  "height": 1024,
  "steps": 9,
  "guidance_scale": 0.0,
  "seed": 12345
}
```

For img2img mode, add:
```json
{
  "mode": "img2img",
  "image_path": "/users/username/assets/images/sketch.png",
  "strength": 0.6
}
```

The server:
1. Validates the request
2. Checks if Nymphs2D2 is available by calling `GET /health`
3. For img2img, reads the init image from the user's assets and base64-encodes it
4. Forwards the request to Nymphs2D2 `POST /generate`
5. Polls `GET /active_task` (optional — or waits for the response)
6. Copies the generated image from Nymphs2D2's output dir to the user's `assets/images/` directory
7. Returns the image URL to the client

Response:
```json
{
  "status": "ok",
  "imageUrl": "/api/files/images/generated-20260501-143000-txt2img-goblin-a1b2c3.png",
  "imagePath": "assets/images/generated-20260501-143000-txt2img-goblin-a1b2c3.png",
  "metadata": {
    "model_id": "Tongyi-MAI/Z-Image-Turbo",
    "runtime": "nunchaku",
    "seed": 12345,
    "steps": 9,
    "width": 1024,
    "height": 1024
  }
}
```

**`GET /api/llm/image-generation-status`**

Proxies to Nymphs2D2 `GET /server_info`. Returns:
```json
{
  "available": true,
  "model_id": "Tongyi-MAI/Z-Image-Turbo",
  "runtime": "nunchaku",
  "device": "cuda",
  "dtype": "bfloat16",
  "supported_modes": ["txt2img"],
  "max_width": 1536,
  "max_height": 1536,
  "nunchaku": {
    "rank": 32,
    "precision": "auto"
  }
}
```

If Nymphs2D2 is not running: `{ "available": false }`

**`GET /api/llm/image-generation-progress`**

Proxies to Nymphs2D2 `GET /active_task`. Returns current generation progress for the UI progress bar.

### 5.4 Client: Generate Image Modal

New component: `client/src/components/GenerateImageModal.tsx`

```
┌─────────────────────────────────────┐
│  Generate Image                     │
├─────────────────────────────────────┤
│  Mode:  ● Text to Image             │
│          ○ Image to Image           │
│                                     │
│  Prompt:                            │
│  ┌─────────────────────────────┐   │
│  │ fantasy castle on a         │   │
│  │ floating island, clouds,    │   │
│  │ dramatic lighting           │   │
│  └─────────────────────────────┘   │
│                                     │
│  Negative Prompt:                   │
│  ┌─────────────────────────────┐   │
│  │ blurry, low quality         │   │
│  └─────────────────────────────┘   │
│                                     │
│  Size:  ○ 512²  ● 1024²  ○ 1536²  │
│  Steps: [━━━━━━○━━━━] 9            │
│  Seed:  [12345        ] 🎲          │
│                                     │
│  [Progress: ████████░░ 66%]        │  ← Shown during generation
│                                     │
│  [Cancel]            [Generate]     │
└─────────────────────────────────────┘
```

**img2img mode:** When selected, shows an additional "Init Image" field:
```
  Init Image:
  ┌─────────────────────────────┐
  │ [Image thumbnail]           │
  │ Click to select from assets │
  └─────────────────────────────┘
  Strength: [━━━━━━━━○━━] 0.60  │
```

Clicking the init image area opens the ImageExplorer to select an existing image.

### 5.5 Image Explorer Integration

- Add a "Generate" button to the ImageExplorer toolbar (Sparkles icon)
- Generated images appear automatically in the ImageExplorer after generation
- The user can then insert the generated image into a document via the existing image insertion flow
- Generated images can also be set as hero images via the HeroImagePicker

### 5.6 Progress Polling

During generation, the client polls `GET /api/llm/image-generation-progress` every 2 seconds:

```typescript
// In GenerateImageModal.tsx
const pollProgress = useCallback(async () => {
  const response = await getImageGenerationProgress();
  if (response.status === 'processing') {
    setProgress(response.progress_percent);
    setStage(response.stage);
    setTimeout(pollProgress, 2000);
  } else if (response.status === 'idle') {
    setProgress(100);
    // Generation complete
  } else if (response.status === 'error') {
    setError(response.detail);
  }
}, []);
```

### 5.7 Concurrency Control

Nymphs2D2 is single-worker (one generation at a time). WORBI enforces this:

**Server-side:**
- Before forwarding a generation request, check Nymphs2D2 `GET /active_task`
- If `status === 'processing'`, return `{ "error": "Image generation is already in progress. Please wait for the current generation to complete." }` with HTTP 409 Conflict

**Client-side:**
- Poll the status endpoint on modal open to detect if a generation is already in progress
- Show "A generation is already in progress" message with a progress bar if so

### 5.8 Z-Image Configuration

New WORBI server config env vars (in `.env` or `config.js`):

```
Z_IMAGE_BASE_URL=http://localhost:8090     # Nymphs2D2 server URL
Z_IMAGE_TIMEOUT_MS=120000                  # Max wait time for generation (2 min)
```

If `Z_IMAGE_BASE_URL` is not set, the image generation features are hidden (graceful degradation).

---

## 6. Settings Integration

Add a new "Image Generation" sub-tab to the Settings modal (LLM tab → Image Generation sub-tab):

```
┌─────────────────────────────────────┐
│  Settings                           │
│  [LLM] [Tools] [Editor] [Images]   │
├─────────────────────────────────────┤
│                                     │
│  Image Generation Server            │
│  ┌─────────────────────────────┐   │
│  │ http://localhost:8090       │   │
│  └─────────────────────────────┘   │
│  Status: ● Connected (Nunchaku)     │
│  Model: Tongyi-MAI/Z-Image-Turbo   │
│                                     │
│  Default Settings                   │
│  Size:     1024 × 1024             │
│  Steps:    9                        │
│  CFG:      0.0                      │
│                                     │
│  [Test Connection]  [Save]          │
└─────────────────────────────────────┘
```

---

## 7. Files to Create

| File | Purpose |
|------|---------|
| `server/src/routes/imageGeneration.js` | Proxy routes to Nymphs2D2 backend |
| `client/src/components/GenerateImageModal.tsx` | Image generation modal UI |
| `client/src/components/GenerateDocumentModal.tsx` | Document generation modal UI |
| `client/src/components/NameGenerator.tsx` | Name generator tool UI |
| `client/src/hooks/useImageGeneration.ts` | Image generation state, progress polling |

## 8. Files to Modify

| File | Changes |
|------|---------|
| `server/src/index.js` | Register `/api/llm/generate-image`, `/api/llm/image-generation-status`, `/api/llm/image-generation-progress` routes |
| `server/src/config.js` | Add `Z_IMAGE_BASE_URL` and `Z_IMAGE_TIMEOUT_MS` configuration |
| `server/src/routes/llm.js` | Add `/complete` endpoint for inline assistant |
| `client/src/components/DocumentEditor.tsx` | Add ghost text plugin, Ctrl+Space handler, Sparkles button |
| `client/src/components/ImageExplorer.tsx` | Add "Generate" button with Sparkles icon |
| `client/src/components/Welcome.tsx` | Add "Generate with AI" button |
| `client/src/pages/Settings.tsx` | Add Image Generation sub-tab |
| `client/src/services/api.ts` | Add all new API functions and types |
| `client/src/styles/globals.css` | Add ghost text, name generator, and generation modal styles |

---

## 9. Implementation Order

### Phase 1: Inline Writing Assistant

1. Add `POST /api/llm/complete` endpoint to `routes/llm.js`
2. Create ghost text TipTap plugin
3. Add Ctrl+Space handler and toolbar button in `DocumentEditor.tsx`
4. Style ghost text in `globals.css`

### Phase 2: Name Generator

1. Create `NameGenerator.tsx` component
2. Add name generator button to editor toolbar
3. Wire to existing `POST /api/llm/chat` with system prompt

### Phase 3: Document Generation

1. Create `GenerateDocumentModal.tsx` with document type selector
2. Create system prompts for each document type
3. Wire to existing LLM chat or new endpoint
4. Add "Generate with AI" button to Welcome screen and File Explorer

### Phase 4: Z-Image Integration

1. Create `server/src/routes/imageGeneration.js` with all proxy routes
2. Add Z-Image config to `server/src/config.js`
3. Create `useImageGeneration.ts` hook
4. Create `GenerateImageModal.tsx` with progress polling
5. Add "Generate" button to ImageExplorer
6. Add Image Generation settings sub-tab

---

## 10. Verification Checklist

**Inline Writing Assistant:**
- [ ] Ctrl+Space triggers completion at cursor position
- [ ] Ghost text appears with correct dimmed/italic styling
- [ ] Tab accepts the suggestion, Escape dismisses it
- [ ] Completion respects document context (genre, tone)
- [ ] Loading spinner shows while waiting for response
- [ ] Error handling: shows toast on API failure

**Name Generator:**
- [ ] Culture dropdown shows all cultures
- [ ] Type radio buttons filter name style
- [ ] Gender selection works
- [ ] Generated names appear in list
- [ ] "Insert at Cursor" inserts the selected name
- [ ] Custom culture option works with free-text input

**Document Generation:**
- [ ] Document type selector shows all types
- [ ] Prompt input works
- [ ] Generated document saves as new file in correct folder
- [ ] Generated document opens in new tab
- [ ] Each document type produces the correct structure
- [ ] Character sheet has all sections filled
- [ ] Location description has all sections filled

**Z-Image Integration:**
- [ ] Image generation modal opens from editor toolbar
- [ ] Image generation modal opens from ImageExplorer
- [ ] txt2img mode generates an image from a prompt
- [ ] img2img mode generates from an init image + prompt
- [ ] Progress bar updates during generation
- [ ] Generated image appears in ImageExplorer
- [ ] Generated image can be inserted into a document
- [ ] Generated image can be set as a hero image
- [ ] When Nymphs2D2 is not running, features show "unavailable" state
- [ ] Concurrent generation attempts receive 409 Conflict
- [ ] Settings tab shows connection status
- [ ] Negative prompt removes specified elements
- [ ] Seed reproduces identical output

---

## 11. Graceful Degradation

If the Z-Image backend or LLM provider is not available:
- The image generation buttons are hidden
- The inline assistant shows "AI unavailable" in the toolbar
- The name generator falls back to a local random-name generator (basic syllable-based, no LLM required)
- Document generation is hidden from Welcome screen and context menu

---

## 12. Future Enhancements

- **Fine-tuned writing style:** Let the user define a writing style profile (descriptive, concise, humorous, dark) for the inline assistant
- **Multi-image generation:** Generate a batch of images at once with different seeds
- **Image upscaling:** Post-process generated images via a separate upscaler
- **Style reference image:** Use an existing image as a style reference for img2img
- **AI image description:** Reverse — upload an image and have the AI describe it in prose for the document
- **Character portrait mode:** Template for generating character portraits with consistent style settings