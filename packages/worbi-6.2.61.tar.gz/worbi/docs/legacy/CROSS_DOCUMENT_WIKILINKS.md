# Handoff: Cross-Document WikiLinks (`[[bracket]]` Syntax)

**Target Version:** v5.3.0
**Priority:** High (transforms WORBI from isolated documents to a connected knowledge base)
**Dependencies:** None (independent of other handoff items)

---

## 1. Problem Statement

WORBI documents currently exist in isolation. A user writing about a character in one document must manually note which document contains that character's description. To cross-reference, they must:
1. Remember the file name
2. Open the File Explorer
3. Navigate to the folder
4. Double-click to open

This breaks the writing flow. World-building documents are inherently interconnected — characters reference locations, quests reference items, lore references historical events. WORBI needs a lightweight, Obsidian-style linking system.

---

## 2. Target Behavior

```
User types: "The [[Goblin King]] sat upon his [[Crystal Throne]] in [[The Underdark]]"

WORBI renders: underlined, clickable links in the editor

Clicking a link opens that document in a new tab (if it exists)
                  or creates it (if it doesn't exist yet)

Hovering a link shows a popover with:
  - Document name
  - File path
  - First ~100 characters of content
  - "Open" button
```

---

## 3. Architecture

### 3.1 WikiLink Syntax

- **Link format:** `[[Document Name]]` — matches Obsidian convention
- **Case-insensitive matching:** `[[goblin king]]` resolves to `Goblin King.html`
- **Optional display text:** `[[Crystal Throne|the ancient seat]]` renders as "the ancient seat" but links to "Crystal Throne"
- **Optional heading anchor:** `[[Goblin King#Early Life]]` links to a heading within the document (future enhancement)
- **Link resolution:** Resolves against all `.html` files in the user's workspace (recursive, but excluding `assets/`)

### 3.2 TipTap Extension

New file: `client/src/extensions/wiki-link.ts`

This is a custom TipTap extension that:
1. **Parses** `[[...]]` patterns as a custom inline node (`wikiLink`)
2. **Renders** them as styled links with underline and accent color
3. **Handles clicks** to open the linked document
4. **Shows a hover popover** with document preview
5. **Provides autocomplete** when the user types `[[`

**Extension structure:**
```typescript
import { Node } from '@tiptap/core';

export interface WikiLinkAttributes {
  targetName: string;      // The target document name (e.g., "Goblin King")
  displayText: string;     // What to display (e.g., "Goblin King" or "the king")
  exists: boolean;         // Whether the target file currently exists
  filePath: string | null; // Resolved file path (if exists)
}

export const WikiLink = Node.create({
  name: 'wikiLink',
  group: 'inline',
  inline: true,
  atom: true,

  addAttributes() {
    return {
      targetName: { default: '' },
      displayText: { default: '' },
      exists: { default: false },
      filePath: { default: null },
    };
  },

  parseHTML() {
    return [{ tag: 'span[data-wiki-link]' }];
  },

  renderHTML({ HTMLAttributes }) {
    const classes = HTMLAttributes.exists
      ? 'wiki-link wiki-link-exists'
      : 'wiki-link wiki-link-missing';
    return ['span', { ...HTMLAttributes, class: classes, 'data-wiki-link': '' }, HTMLAttributes.displayText];
  },
});
```

### 3.3 Link Resolution Service

New server route: `GET /api/files/resolve-wikilink?name=`

This endpoint:
1. Takes a document name (e.g., "Goblin King")
2. Normalizes it (lowercase, trim)
3. Searches the user's workspace recursively for `.html` files whose base name matches (case-insensitive)
4. Returns `{ exists: true, filePath: "/Quests/The Underdark/Goblin King.html" }` or `{ exists: false, suggestedPath: "/MainStory/Goblin King.html" }`

The `suggestedPath` for non-existent documents uses the current document's folder as the default location.

### 3.4 Autocomplete

When the user types `[[`, an autocomplete popover appears below the cursor:

```
┌─────────────────────────────┐
│  Search documents...        │  ← Filter input
├─────────────────────────────┤
│  Goblin King                │  ← Matching documents
│  /Quests/The Underdark/     │
│                             │
│  Goblin Tribes              │
│  /World/Lore/               │
│                             │
│  Goblin Warfare Tactics     │
│  /World/Lore/               │
│                             │
│  ─── Create "Goblin..." ─── │  ← Create new option
└─────────────────────────────┘
```

**Interaction:**
- As the user types after `[[`, the popover filters the list
- Arrow keys navigate, Enter selects
- Typing `]]` or pressing Escape closes the popover without selecting
- Selecting "Create..." inserts the full `[[Name]]` syntax with `exists: false` styling
- The autocomplete searches against all `.html` files in the workspace (cached per session)

### 3.5 Link Styling (globals.css)

```css
.wiki-link {
  text-decoration: underline;
  text-decoration-style: dotted;
  cursor: pointer;
  transition: color 0.15s;
}

.wiki-link-exists {
  color: #7dd3fc;  /* Light blue — document exists */
  text-decoration-color: #7dd3fc;
}

.wiki-link-exists:hover {
  color: #38bdf8;
  text-decoration-style: solid;
}

.wiki-link-missing {
  color: #f59e0b;  /* Amber — document doesn't exist yet */
  text-decoration-color: #f59e0b;
}

.wiki-link-missing:hover {
  color: #fbbf24;
  text-decoration-style: solid;
}

/* Popover */
.wiki-link-popover {
  background: #1e1e2e;
  border: 1px solid #3a3a4a;
  border-radius: 8px;
  padding: 12px;
  max-width: 320px;
  font-size: 13px;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.4);
  z-index: 1000;
}
```

### 3.6 Hover Popover

New component: `client/src/components/WikiLinkPopover.tsx`

Shows on mouse hover over a wiki link (with a 300ms delay to prevent flickering):

```
┌─────────────────────────────┐
│  Goblin King                │  ← Bold file name
│  /Quests/The Underdark/     │  ← Gray path
│                             │
│  The Goblin King rules      │  ← First 100 chars of content preview
│  over the sprawling         │
│  underground realm of...    │
│                             │
│  [Open Document]            │  ← Button
└─────────────────────────────┘
```

- Positioned with `position: absolute`, calculated from the link's bounding rect
- Closes on mouse leave (with a small delay for the user to reach the popover)
- For non-existent links, shows "Document not yet created. Click to create." with a "Create" button

---

## 4. Backlinks Panel

When viewing a document that is linked to from other documents, show backlinks in the Information Panel:

```
┌─────────────────────────────────┐
│  Backlinks (3)                  │  ← Section header
├─────────────────────────────────┤
│  "The Underdark.html"           │  ← Document linking to this one
│  "... the [[Goblin King]] ..."  │  ← Context snippet
│                                 │
│  "Quests/Rescue Mission.html"   │
│  "... defeat the [[Goblin ..."  │
│                                 │
│  "World/Lore/Goblins.html"      │
│  "... led by the [[Goblin ..."  │
└─────────────────────────────────┘
```

**Backlink computation:**
- Server endpoint: `GET /api/files/backlinks?path=`
- Searches all `.html` files in the workspace for `[[document name]]` references
- Returns: list of `{ filePath, snippet }` objects where `snippet` is ~50 characters around the link
- Uses FTS5 (after SQLite migration) or a brute-force grep of workspace files

---

## 5. API Endpoints

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| `GET` | `/api/files/resolve-wikilink?name=` | Yes | Resolve a document name to a file path |
| `GET` | `/api/files/wikilink-search?q=` | Yes | Search workspace files for autocomplete |
| `GET` | `/api/files/backlinks?path=` | Yes | Find all documents linking to a given document |

### 5.1 Resolve Endpoint Response

```json
{
  "exists": true,
  "filePath": "/Quests/The Underdark/Goblin King.html",
  "contentPreview": "The Goblin King rules over the sprawling underground realm..."
}
```

Or:
```json
{
  "exists": false,
  "suggestedPath": "/Quests/The Underdark/Goblin King.html"
}
```

### 5.2 Autocomplete Search Response

```json
{
  "results": [
    {
      "name": "Goblin King",
      "path": "/Quests/The Underdark/Goblin King.html",
      "folder": "/Quests/The Underdark/"
    },
    {
      "name": "Goblin Tribes",
      "path": "/World/Lore/Goblin Tribes.html",
      "folder": "/World/Lore/"
    }
  ]
}
```

### 5.3 Backlinks Response

```json
{
  "backlinks": [
    {
      "filePath": "/World/Lore/The Underdark.html",
      "snippet": "... the [[Goblin King]] rules with an iron fist ...",
      "lineNumber": 42
    }
  ]
}
```

---

## 6. Files to Create

| File | Purpose |
|------|---------|
| `client/src/extensions/wiki-link.ts` | Custom TipTap node extension for `[[...]]` syntax |
| `client/src/components/WikiLinkPopover.tsx` | Hover popover with document preview |
| `client/src/components/WikiLinkAutocomplete.tsx` | Autocomplete dropdown for `[[` typing |
| `server/src/routes/wikilinks.js` | Backend routes for link resolution, search, backlinks |

## 7. Files to Modify

| File | Changes |
|------|---------|
| `client/src/components/DocumentEditor.tsx` | Register `WikiLink` extension in both main and margin editor extension arrays; render `WikiLinkPopover` and `WikiLinkAutocomplete` |
| `client/src/components/InformationPanel.tsx` | Add "Backlinks" section below the Relationships section |
| `client/src/services/api.ts` | Add `resolveWikiLink()`, `searchWikiLinks()`, `getBacklinks()` functions |
| `client/src/styles/globals.css` | Add wiki link styles and popover styles |
| `server/src/index.js` | Register `/api/files/resolve-wikilink`, `/api/files/wikilink-search`, `/api/files/backlinks` routes |

---

## 8. Implementation Order

### Phase 1: Backend Link Resolution

1. Create `server/src/routes/wikilinks.js` with all three endpoints
2. Implement workspace file scanning (recursive `.html` file listing)
3. Implement backlink search (grep all workspace files for `[[name]]` patterns)
4. Register routes in `server/src/index.js`

### Phase 2: TipTap WikiLink Extension

1. Create `wiki-link.ts` extension with `renderHTML()`, `parseHTML()`, and attribute handling
2. Add wiki link CSS to `globals.css`
3. Register extension in `DocumentEditor.tsx` for both editors
4. Handle click events on wiki links → open file in new tab

### Phase 3: Autocomplete

1. Create `WikiLinkAutocomplete.tsx` component
2. Implement `onInput` listener that detects `[[` pattern in editor content
3. Wire to `searchWikiLinks()` API
4. Position popover below cursor, handle keyboard navigation

### Phase 4: Hover Popover and Backlinks

1. Create `WikiLinkPopover.tsx` component
2. Wire hover detection to `resolveWikiLink()` API (with 300ms debounce)
3. Add backlinks section to `InformationPanel.tsx`
4. Wire backlinks to `getBacklinks()` API

---

## 9. Edge Cases

| Scenario | Handling |
|----------|----------|
| **Circular links** | A links to B, B links to A — both render fine, backlinks show the mutual reference |
| **Deleted target document** | Existing links survive (they render as `wiki-link-missing` in amber). Editing the text removes the link node since `[[...]]` won't parse to a missing document without a `resolveWikiLink` call |
| **Renamed target document** | Links break (become amber "missing" links). Future: a rename operation could update all wiki links in the workspace (Phase 2 enhancement) |
| **Link in margin editor** | Works identically — the margin editor also has the `WikiLink` extension |
| **Link inside a code block** | Should NOT be parsed as a wiki link. The extension regex must exclude content within `<code>` or `<pre>` tags |
| **Very large workspace (1000+ files)** | Link resolution may be slow on first call. Cache the file list per session, refresh on file operations |
| **Special characters in document names** | URL-encode file names in links. Display the raw name in the editor |
| **Two files with same name in different folders** | `[[Goblin King]]` matches the first found. If ambiguous, show a disambiguation popover: "Multiple matches: /Quests/Goblin King.html, /World/Lore/Goblin King.html" |
| **Link to current document** | Renders as a self-link (bold, non-clickable, with a "You are here" tooltip) |
| **Pipe syntax with empty display text** | `[[Goblin King|]]` — same as `[[Goblin King]]`, renders the target name |
| **Nested brackets** | `[[[[recursive]] stuff]]` — only the inner `[[recursive]]` is parsed as a link; the outer brackets are literal text |

---

## 10. Verification Checklist

- [ ] Typing `[[Goblin King]]` in the editor renders as a styled wiki link
- [ ] Clicking an existing wiki link opens that document in a new tab
- [ ] Clicking a non-existent wiki link (amber) prompts to create the file
- [ ] Hovering over a wiki link shows the popover with content preview
- [ ] Adding `|display text` renders the custom display text
- [ ] Autocomplete appears when typing `[[` with at least 2 characters
- [ ] Arrow keys + Enter select from autocomplete
- [ ] Escape closes autocomplete without inserting
- [ ] Typing `]]` closes autocomplete and completes the link
- [ ] Wiki links inside code blocks are NOT parsed
- [ ] Backlinks panel shows documents linking to the current document
- [ ] Backlinks panel is empty when no documents link to the current one
- [ ] Renaming a document does not break existing wiki links (they become amber)
- [ ] Two files with the same name in different folders show a disambiguation popover
- [ ] Self-links render as non-clickable
- [ ] Wiki links survive save/load cycle (attributes serialized in HTML)

---

## 11. Future Enhancements

- **Heading anchors:** `[[Goblin King#Early Life]]` scrolls to the heading in the target document
- **Embed previews:** `![[Goblin King]]` embeds the full content of the linked document inline
- **Link graph visualization:** Supplementary to the Relationship Graph handoff — wiki links are explicit edges in the graph
- **Automatic link updates on rename:** Renaming a document updates all `[[...]]` references in the workspace
- **Unlinked mentions:** Show unlinked references to the current document name in the backlinks panel (mentions without `[[brackets]]`)
- **Link completion via AI:** The AI in the chat panel can suggest wiki links while reviewing your document