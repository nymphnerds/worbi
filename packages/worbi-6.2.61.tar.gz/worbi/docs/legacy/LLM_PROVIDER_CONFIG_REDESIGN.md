# Handoff: LLM Provider Configuration Redesign — Provider Selection, Auto-Detection, and Model Browsing

**Target Version:** v5.2.0
**Priority:** High (replaces hardcoded config with user-friendly provider setup)
**Dependencies:** `HARDCODED_CONFIG_CLEANUP.md` should be done first (the `env.js` module provides the foundation for the server-side auto-detection endpoints)

---

## 1. Problem Statement

The current LLM configuration system has multiple deficiencies:

| Issue | Current Behavior | Why It's a Problem |
|-------|-----------------|-------------------|
| No provider selection | Only supports a hardcoded local server at port 8000 | Can't use LM Studio, Ollama, cloud APIs, or any other provider |
| Model name is read-only | Field is `readOnly`, shows "Auto-detected from system" | User can't manually specify a model; auto-detection only works if the developer's `lms-start` script exists |
| No model dropdown | User must type model name manually (but field is read-only anyway) | Even if editable, user has to guess model names |
| No URL configuration in UI | LLM URL only configurable via `.env` or server config | Non-technical users can't change providers |
| No API key UI | API key only via `.env` | Can't use cloud providers that require API keys |
| Auto-detection deeply flawed | Server reads a non-existent `lms-start` script and pings port 8000 | Fails on every machine except the developer's |
| Polling every 10 seconds | `useLLM.ts` polls `fetchSystemInfo()` every 10s | Unnecessary network traffic; model name doesn't change that often |

The user needs a Settings UI where they can:
1. Select from a curated list of popular LLM providers (local + cloud)
2. See auto-detected local servers highlighted
3. Enter a custom URL if their provider isn't listed
4. Enter an API key for cloud providers
5. Browse and select from available models via a dropdown
6. Test the connection with one click
7. See clear connection status

---

## 2. Provider Catalog

### 2.1 Local Providers (auto-detectable)

These run on the user's machine. The server will probe their default ports to detect them.

| Provider | Default URL | Default Port | Requires API Key? | Notes |
|----------|------------|-------------|-------------------|-------|
| **LM Studio** | `http://localhost:1234/v1` | 1234 | No | Most popular local LLM desktop app. OpenAI-compatible API. |
| **Ollama** | `http://localhost:11434/v1` | 11434 | No | Popular open-source local LLM runner. OpenAI-compatible when `/v1` suffix. |
| **llama.cpp server** | `http://localhost:8080/v1` | 8080 | No | Underlying engine. Often used via CLI. OpenAI-compatible. |
| **TextGen WebUI** | `http://localhost:5000/v1` | 5000 | No | oobabooga's text-generation-webui. OpenAI-compatible with `--api` flag. |
| **LocalAI** | `http://localhost:8080/v1` | 8080 | No | Drop-in OpenAI replacement. Same port as llama.cpp — auto-detection should probe `/models` endpoint. |
| **Jan** | `http://localhost:1337/v1` | 1337 | No | Open-source desktop app. OpenAI-compatible API. |
| **vLLM** | `http://localhost:8000/v1` | 8000 | No | High-performance inference server. OpenAI-compatible. |
| **Custom Local** | User-specified | N/A | Optional | Free-text URL field for any OpenAI-compatible local server. |

### 2.2 Cloud Providers (require API key)

These are remote services. Some are OpenAI-compatible; others need special handling noted in the implementation.

| Provider | Default URL | Requires API Key? | Notes |
|----------|------------|-------------------|-------|
| **OpenAI** | `https://api.openai.com/v1` | Yes | Native format. Models: gpt-4o, gpt-4-turbo, gpt-3.5-turbo, etc. |
| **Groq** | `https://api.groq.com/openai/v1` | Yes | OpenAI-compatible. Ultra-fast inference. Free tier available. Models: llama-3.3-70b, mixtral-8x7b, etc. |
| **Together AI** | `https://api.together.xyz/v1` | Yes | OpenAI-compatible. Wide model selection. Models: 100+ open models. |
| **OpenRouter** | `https://openrouter.ai/api/v1` | Yes | OpenAI-compatible. Aggregator for 200+ models across providers. Pay-per-token. |
| **Mistral** | `https://api.mistral.ai/v1` | Yes | Native format (slightly different from OpenAI but compatible for chat completions). Models: mistral-large, mistral-small, codestral. |
| **DeepSeek** | `https://api.deepseek.com/v1` | Yes | OpenAI-compatible. Models: deepseek-chat, deepseek-reasoner. |
| **Anthropic** | `https://api.anthropic.com/v1` | Yes | **NOT OpenAI-compatible.** Uses different API format. If selected, show a note: "Anthropic uses a different API format. Consider using OpenRouter to access Claude models via the OpenAI-compatible endpoint." Do NOT block the provider — just show the warning and let the user proceed if they understand the limitation (their server may have an OpenAI-compatible proxy). |
| **xAI (Grok)** | `https://api.x.ai/v1` | Yes | OpenAI-compatible. Models: grok-beta. |
| **Custom Cloud** | User-specified | Yes | Free-text URL field for any OpenAI-compatible cloud API. |
| **Google AI Studio** | `https://generativelanguage.googleapis.com/v1beta` | Yes | **NOT OpenAI-compatible.** Same treatment as Anthropic — show warning, don't block. |

### 2.3 Provider Organization in the UI

Group providers into sections in the dropdown:

```
── Local Providers (auto-detected) ──
🟢 LM Studio                (detected)
   Ollama                   (not detected)
   llama.cpp server         
   TextGen WebUI
   LocalAI
   Jan
   vLLM
   Custom Local...

── Cloud Providers (API key required) ──
   OpenAI
   Groq (Free tier)
   Together AI
   OpenRouter
   Mistral
   DeepSeek
   Anthropic ⚠
   xAI (Grok)
   Google AI Studio ⚠
   Custom Cloud...
```

The green dot (🟢) and "(detected)" label appear next to local providers that responded to the auto-detection probe.

---

## 3. Auto-Detection System

### 3.1 Server-Side Detection Endpoint

Create a new API endpoint that probes common local LLM ports:

**`GET /api/llm/detect`** — AUTH REQUIRED

**Purpose:** Probe common local LLM server ports and report which ones respond.

**Implementation in `server/src/routes/llm.js`:**
1. Define an array of known local providers with their probe URLs:
   - Each entry has: `{ id, name, url, modelsEndpoint }`
   - `url` is the base URL to probe
   - `modelsEndpoint` is the specific path to call (usually `/models` or `/v1/models`)
2. Probe each provider concurrently (using `Promise.allSettled`):
   - Send a GET request to `{url}/models` (OpenAI-compatible models endpoint) with a 2-second timeout
   - If the response is 200 OK and returns a valid JSON body with a `data` array, mark the provider as `detected: true`
   - For Ollama: also try the native Ollama API at `http://localhost:11434/api/tags` (returns different JSON format) — parse both
   - If the request times out, is refused, or returns non-200, mark as `detected: false`
3. For detected providers, also return:
   - The list of available models (from the `/models` response) — so the frontend can populate a model dropdown
   - The actual detected URL (in case it's on a non-default port — probe a range: 1234, 11434, 8080, 5000, 1337, 8000, 4891)
4. Return the results as:
```json
{
  "detected": [
    {
      "id": "lmstudio",
      "name": "LM Studio",
      "url": "http://localhost:1234/v1",
      "detectedAt": "http://localhost:1234/v1",
      "models": ["llama-3.1-8b-instruct", "mistral-7b-v0.1"],
      "defaultModel": "llama-3.1-8b-instruct"
    },
    {
      "id": "ollama",
      "name": "Ollama",
      "url": "http://localhost:11434/v1",
      "detectedAt": "http://localhost:11434/v1",
      "models": ["llama3.1:8b", "codellama:7b", "mistral:7b"],
      "defaultModel": "llama3.1:8b"
    }
  ],
  "notDetected": [
    { "id": "textgen-webui", "name": "TextGen WebUI", "url": "http://localhost:5000/v1" },
    { "id": "jan", "name": "Jan", "url": "http://localhost:1337/v1" }
  ]
}
```

**Timeout and performance:** Use 2-second per-provider timeout, run probes concurrently, total endpoint response time under 3 seconds.

**Caching:** Cache the detection results on the server for 30 seconds (in-memory). Multiple rapid calls from the client shouldn't hammer local ports.

### 3.2 Frontend Auto-Detection Flow

1. When Settings modal opens to the LLM tab, call `GET /api/llm/detect`
2. While detection is running, show a skeleton/spinner row: "🔍 Detecting local LLM servers..."
3. When results arrive:
   - Populate the provider dropdown with detected providers highlighted
   - If exactly one provider is detected AND the user hasn't previously configured a different provider, auto-select it
   - If the current settings match a detected provider's URL, auto-select that provider and load its model list
4. After initial detection, add a "Re-scan" button that re-triggers detection
5. Remove the 10-second polling interval from `useLLM.ts` — replace with an explicit "Re-scan" button and a one-time scan on Settings open

---

## 4. Settings UI Redesign

### 4.1 LLM Tab Layout

Redesign the LLM Settings tab with these sections, in order:

```
┌────────────────────────────────────────────────────┐
│  LLM Configuration                                 │
│                                                    │
│  ── Provider ────────────────────────────────────  │
│  [Provider Dropdown           ▼]  [🔄 Re-scan]     │
│  🟢 LM Studio detected on port 1234                │
│                                                    │
│  ── Connection ──────────────────────────────────  │
│  URL:  [http://localhost:1234/v1          ]        │
│  API Key: [······························] [👁]    │
│                                                    │
│  ── Model ───────────────────────────────────────  │
│  [Model Dropdown               ▼]  [🔄 Refresh]    │
│  Status: 🟢 Server Online — llama-3.1-8b-instruct  │
│  [Test Connection]                                 │
│                                                    │
│  ── Inference Parameters ────────────────────────  │
│  Max Tokens: [4096]                                │
│  Temperature: [========|========] 0.7              │
│  Top P:       [===========|=====] 0.95             │
│  Top K:       [============|====] 50               │
│  Freq Penalty:[========|========] 0.0              │
│  Pres Penalty:[========|========] 0.0              │
│                                                    │
│  ── System Prompt ───────────────────────────────  │
│  [Multiline textarea                               │
│   You are a helpful AI assistant for a game        │
│   worldbuilder tool...                             │
│                                          ]         │
│                                                    │
│  [💾 Save Settings]                                │
└────────────────────────────────────────────────────┘
```

### 4.2 Provider Dropdown Behavior

**Dropdown structure:**
- Use an HTML `<select>` styled to match the WORBI dark theme, or a custom dropdown component
- Group `<optgroup>` elements for "Local Providers" and "Cloud Providers"
- Detected providers get a green indicator prefix: "🟢 LM Studio" 
- The currently selected provider is shown in the dropdown
- When the user changes the provider:
  1. Auto-fill the URL field with that provider's default URL
  2. If the provider requires an API key, auto-focus the API key field
  3. If the provider was detected, auto-populate the model dropdown from the detection results
  4. If the provider was not detected, show "Model list unavailable — start the server and click Refresh"
  5. If it's a cloud provider, show the API key field prominently and disable model loading until a key is entered

**Custom URL providers:**
- "Custom Local" and "Custom Cloud" are options at the bottom of each group
- When selected, the URL field becomes editable, and the user must manually enter a URL
- A "Detect" button appears next to the URL field to probe that specific URL

### 4.3 URL Field

- Pre-filled from the selected provider
- Editable for advanced users who need to change the port or path
- Validate on blur: ensure it starts with `http://` or `https://`
- If the user edits the URL, the provider dropdown changes to "Custom Local" or "Custom Cloud" automatically

### 4.4 API Key Field

- Type: `password` (masked, with a show/hide toggle button — the 👁 icon)
- Shown for cloud providers; hidden (or shown as optional) for local providers
- Placeholder: "Enter your API key" for cloud, "Optional — key or 'dummy' for local servers" for local
- If the user has a saved API key, show the first 4 and last 4 characters with asterisks in between when masked: `sk-a***b1c2`
- The API key is stored server-side in the user's settings (never in `localStorage`)

### 4.5 Model Dropdown

- Populated by calling `GET /api/llm/models` (the existing `fetchModels()` endpoint, but now it should accept a `baseUrl` and `apiKey` parameter to query the user's chosen provider)
- Show a loading spinner while fetching: "Loading models..."
- If models fail to load, show: "⚠ Could not load models. Check URL and API key."
- A "🔄 Refresh" button next to the dropdown re-fetches the model list
- The selected model is saved as part of the user settings
- If the model list is empty and the provider is detected, show: "Server is running but no models loaded. Load a model in {provider name}."

**Important:** The `fetchModels` function must be updated to accept dynamic `baseUrl` and `apiKey` parameters instead of reading them from the hardcoded config. This ties into the `HARDCODED_CONFIG_CLEANUP.md` document.

### 4.6 Connection Status Indicator

Replace the current single "Server Online/Offline" indicator with a richer status area:

- **Green dot + "Connected — {modelName}"** — server responded, models list loaded, connection test passed
- **Yellow dot + "Server reachable but no models"** — server responded to health check but `/models` returned empty
- **Red dot + "Connection failed"** — server did not respond; show the error message
- **Grey dot + "Not tested"** — no connection test performed yet
- **Spinner + "Testing..."** — connection test in progress

Show this status:
1. When the Settings modal opens (test automatically)
2. When the "Test Connection" button is clicked
3. When the provider, URL, or API key changes (debounced 1 second)

### 4.7 Inference Parameters

Keep the existing sliders for:
- Max Tokens (number input, 1–32768)
- Temperature (slider, 0–2, step 0.1)
- Top P (slider, 0–1, step 0.01)
- Top K (slider, 0–100, step 1)
- Frequency Penalty (slider, -2–2, step 0.1)
- Presence Penalty (slider, -2–2, step 0.1)

Add:
- Stop Sequences (optional text input, comma-separated) — tokens that stop generation
- Seed (optional number input, 0 = random)

### 4.8 System Prompt

Keep the existing textarea. No changes needed.

---

## 5. Data Model Changes

### 5.1 Extended LLM Settings

The `LLMSettings` type in `client/src/services/api.ts` must be extended:

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `providerId` | string | `''` | Provider ID from the catalog (e.g., `'lmstudio'`, `'openai'`, `'custom'`) |
| `baseUrl` | string | `'http://localhost:1234/v1'` | Full base URL for the LLM API |
| `apiKey` | string | `''` | API key (empty for local providers) |
| `modelName` | string | `''` | Selected model name |
| `maxTokens` | number | `4096` | Max tokens |
| `temperature` | number | `0.7` | Temperature |
| `topP` | number | `1.0` | Top P |
| `topK` | number | `50` | Top K |
| `frequencyPenalty` | number | `0.0` | Frequency penalty |
| `presencePenalty` | number | `0.0` | Presence penalty |
| `stopSequences` | string | `''` | Comma-separated stop sequences |
| `seed` | number | `0` | Seed (0 = random) |
| `systemPrompt` | string | `defaultSystemPrompt` | System prompt text |

The server-side `defaultUserSettings` in `config.js` must also include `providerId`, `baseUrl`, and `apiKey` fields.

### 5.2 New Types

Add to `client/src/services/api.ts`:

```typescript
interface LLMProvider {
  id: string;           // e.g., 'lmstudio', 'openai', 'custom'
  name: string;         // e.g., 'LM Studio', 'OpenAI'
  group: 'local' | 'cloud';
  defaultUrl: string;
  defaultPort: number | null;  // null for cloud providers
  requiresApiKey: boolean;
  openAiCompatible: boolean;   // true for most, false for Anthropic/Gemini
  warning?: string;            // Warning message if not OpenAI-compatible
}

interface LLMDetectionResult {
  detected: Array<{
    id: string;
    name: string;
    url: string;
    detectedAt: string;
    models: string[];
    defaultModel: string;
  }>;
  notDetected: Array<{
    id: string;
    name: string;
    url: string;
  }>;
}
```

### 5.3 Provider Catalog (Hardcoded)

Define the provider catalog as a constant in `client/src/services/providers.ts` (new file):

A static array of `LLMProvider` objects for all providers listed in Section 2. This catalog is the definitive list of supported providers. The auto-detection endpoint uses the same list (defined in `server/src/services/providerCatalog.js` — new file) to probe local ports.

**Keep client and server catalogs in sync** by maintaining the list in the server and exposing it via a `GET /api/llm/providers` endpoint, OR by maintaining identical copies in both places with a comment noting they must stay in sync. The endpoint approach is cleaner — the client fetches the provider list on first load.

---

## 6. API Endpoint Changes

### 6.1 New Endpoints

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| `GET` | `/api/llm/detect` | Yes | Probe common local LLM ports, return detection results with model lists |
| `GET` | `/api/llm/providers` | No | Return the static provider catalog (no auth needed) |

### 6.2 Modified Endpoints

| Method | Path | Change |
|--------|------|--------|
| `GET` | `/api/llm/models` | Accept optional `baseUrl` and `apiKey` query parameters. If not provided, use the user's saved settings. |
| `POST` | `/api/llm/test` | Accept optional `baseUrl` and `apiKey` in the request body. If not provided, use the user's saved settings. |
| `POST` | `/api/llm/chat` | Already accepts per-user settings — ensure it uses `baseUrl` and `apiKey` from settings. |
| `GET` | `/api/llm/system-info` | **DEPRECATE** or replace with `/api/llm/detect`. The old `system-info` endpoint will eventually be removed. |
| `GET` | `/api/settings` | Return extended settings including `providerId`, `baseUrl`, `apiKey`, `stopSequences`, `seed`. |
| `PUT` | `/api/settings` | Accept and save extended settings. |

### 6.3 Removed Endpoints

| Method | Path | Reason |
|--------|------|--------|
| `GET` | `/api/llm/system-info` | Replaced by `/api/llm/detect` and `/api/llm/providers`. Remove after deprecation period. |

---

## 7. Implementation Plan

### Phase 1: Server-Side Provider Catalog and Auto-Detection

1. Create `server/src/services/providerCatalog.js`:
   - Define the full provider list (same as client will use)
   - Export: `getLocalProviders()`, `getCloudProviders()`, `getAllProviders()`, `getProviderById(id)`

2. Create `server/src/services/llmDetector.js`:
   - `detectLocalProviders()`: Probe each local provider's `/models` endpoint concurrently with 2s timeouts
   - Parse and normalize model names from different providers (Ollama returns different format)
   - Cache results for 30 seconds
   - Return `{ detected: [...], notDetected: [...] }`

3. Create `GET /api/llm/detect` route:
   - Call `detectLocalProviders()`
   - Return detection results with model lists

4. Create `GET /api/llm/providers` route:
   - Return the full provider catalog

5. Modify `GET /api/llm/models` route:
   - Accept `?baseUrl=` and `?apiKey=` query parameters
   - If not provided, load from user's saved settings
   - Use the provided URL to fetch models instead of hardcoded config

6. Modify `POST /api/llm/test` route:
   - Accept `{ baseUrl, apiKey }` in the request body
   - If not provided, load from user's saved settings

7. Update `config.js` (or `env.js`) defaults:
   - Change default `baseUrl` to `http://localhost:1234/v1` (LM Studio default, more common than port 8000)
   - Add `providerId: ''` field
   - Add `apiKey: ''` field

### Phase 2: Client-Side Provider Selection UI

1. Create `client/src/services/providers.ts`:
   - Define the provider catalog (or fetch from `/api/llm/providers`)
   - Helper functions: `getProviderById()`, `getProvidersByGroup()`

2. Rewrite the LLM tab in `Settings.tsx`:
   - **Remove:** The read-only model name field with its polling indicator
   - **Remove:** The 10-second polling `useEffect` from `useLLM.ts`
   - **Add:** Provider dropdown with `<optgroup>` sections
   - **Add:** Auto-detection call on Settings open + "Re-scan" button
   - **Add:** URL field (editable, auto-fills from provider selection)
   - **Add:** API key field with show/hide toggle
   - **Add:** Model dropdown with "Refresh" button
   - **Add:** Rich connection status indicator
   - **Add:** "Test Connection" button
   - **Keep:** Inference parameter sliders (add stop sequences and seed)
   - **Keep:** System prompt textarea

3. Update `useLLM.ts`:
   - Remove the `fetchSystemInfo()` polling interval
   - Remove `llmServerOnline` state (replaced by richer status)
   - Add `providerId` to settings state
   - Add `baseUrl` and `apiKey` to settings state
   - Add `detectionResult` state for auto-detection results
   - Add `connectionStatus` state: `'untested' | 'testing' | 'connected' | 'reachable' | 'failed'`
   - Add `detectProviders()` function
   - Modify `loadModels()` to accept optional `baseUrl` and `apiKey`
   - Modify `testConn()` to pass `baseUrl` and `apiKey`
   - Modify `saveUserSettings()` to include all new fields

4. Update `api.ts`:
   - Add `LLMProvider` and `LLMDetectionResult` types
   - Add `detectLLMProviders()` API function
   - Add `fetchProviders()` API function
   - Modify `fetchModels()` to accept optional `baseUrl` and `apiKey`
   - Modify `testConnection()` to accept `baseUrl` and `apiKey`

### Phase 3: Polish and Edge Cases

1. **Provider URL validation:**
   - When the user manually edits the URL, validate it looks like a valid HTTP URL
   - Auto-detect trailing slashes and strip or add them consistently
   - Strip `/chat/completions` if the user accidentally pastes a full endpoint URL

2. **API key security:**
   - Never log the API key
   - Mask the API key in the UI (show first 4 + last 4 characters)
   - Transmit the API key only over HTTPS in production (note in the UI if using HTTP with a cloud provider)
   - Store API key server-side only (in user settings JSON)

3. **Model name normalization:**
   - Ollama models have names like `llama3.1:8b` — display them as-is
   - LM Studio/llama.cpp models have names like `llama-3.1-8b-instruct` — display as-is
   - Sort model names alphabetically in the dropdown

4. **Error handling:**
   - If auto-detection fails entirely (server down), show: "Could not scan for local LLM servers. Check that WORBI server is running."
   - If a provider is detected but models fail to load, show the model dropdown as disabled with the error message
   - If settings save fails, show an error toast

5. **Migration of existing settings:**
   - If a user has existing settings with a `modelName` but no `providerId`, infer the provider:
     - If `modelName` matches the old hardcoded `qwen3.6-27b`, default to "Custom Local" with URL `http://localhost:8000/v1`
     - Otherwise, default to "Custom Local" with the current default URL
   - Preserve existing `maxTokens`, `temperature`, `topP`, `topK`, etc. values

6. **Non-OpenAI-compatible providers:**
   - When the user selects Anthropic or Google AI Studio, show a persistent warning banner below the provider dropdown:
     "⚠ {Provider} uses a different API format that may not be fully compatible. For Claude models, consider using OpenRouter which provides OpenAI-compatible access. Proceed only if you have an OpenAI-compatible proxy configured."
   - Do NOT disable the provider — just show the warning
   - If the user clicks "Test Connection" and it fails, the error message should suggest checking the API format

### Phase 4: Cleanup

1. Remove `fetchSystemInfo()` from `client/src/services/api.ts`
2. Remove `getSystemInfo()` from `server/src/services/llmService.js` (or repurpose it if still needed)
3. Remove the `lmsStartScript` config reference (overlaps with HARDCODED_CONFIG_CLEANUP)
4. Remove the 10-second polling `useEffect` from `useLLM.ts`
5. Remove `llmServerOnline` state
6. Update `defaultSettings` in `useLLM.ts` to include new fields
7. Update `defaultUserSettings` in `config.js` to include new fields

---

## 8. Files to Create

| File | Purpose |
|------|---------|
| `server/src/services/providerCatalog.js` | Static provider list for server-side detection and API |
| `server/src/services/llmDetector.js` | Local port probing and model list fetching |
| `client/src/services/providers.ts` | Provider catalog and helper functions for the client |

## 9. Files to Modify

| File | Changes |
|------|---------|
| `server/src/routes/llm.js` | Add `GET /api/llm/detect`, `GET /api/llm/providers`; modify `GET /api/llm/models` and `POST /api/llm/test` to accept dynamic baseUrl/apiKey; deprecate `GET /api/llm/system-info` |
| `server/src/services/llmService.js` | Modify `fetchModels()`, `testConnection()`, `sendChatMessage()` to accept explicit `baseUrl` and `apiKey` instead of reading from config; remove or fix `getSystemInfo()` |
| `server/src/config.js` | Update `defaultUserSettings` with `providerId`, `baseUrl`, `apiKey` fields; update defaults |
| `client/src/services/api.ts` | Add `LLMProvider`, `LLMDetectionResult` types; add `detectLLMProviders()`, `fetchProviders()`, modify `fetchModels()`, `testConnection()`; deprecate `fetchSystemInfo()` |
| `client/src/hooks/useLLM.ts` | Add provider/detection state; remove polling; modify `loadModels()`, `testConn()`, `saveUserSettings()` |
| `client/src/pages/Settings.tsx` | Complete rewrite of LLM tab with provider dropdown, URL field, API key field, model dropdown, connection status, "Re-scan" and "Test Connection" buttons |
| `client/src/App.tsx` | Update `LLMSettings` type usage if needed |

## 10. Files to Eventually Remove (After Deprecation Period)

| File | Reason |
|------|--------|
| N/A | No files are deleted; only `fetchSystemInfo()` and `getSystemInfo()` functions are removed from existing files |

---

## 11. Verification Checklist

- [ ] Settings → LLM tab shows provider dropdown with all local and cloud providers
- [ ] Auto-detection finds running local LLM servers (test with LM Studio and Ollama)
- [ ] Detected providers are highlighted with 🟢 and "(detected)" in the dropdown
- [ ] Selecting a provider auto-fills the URL field
- [ ] Selecting a detected provider auto-populates the model dropdown
- [ ] "Re-scan" button re-runs auto-detection
- [ ] "Refresh" button re-fetches the model list
- [ ] "Test Connection" button tests the connection and shows clear status
- [ ] API key field is masked and has a show/hide toggle
- [ ] API key is saved and loaded correctly (persists across sessions)
- [ ] Cloud providers show the API key field prominently
- [ ] Non-OpenAI-compatible providers show a warning banner
- [ ] Custom URL providers allow manual URL entry
- [ ] Inference parameter sliders work and save correctly
- [ ] System prompt saves and loads correctly
- [ ] Chat functionality works with the selected provider/model
- [ ] Changing provider and saving updates the chat immediately (no restart needed)
- [ ] Existing settings are migrated: old users don't lose their configuration
- [ ] No 10-second polling occurs (check network tab)
- [ ] `fetchSystemInfo()` is no longer called
- [ ] The model field in the LLM tab is no longer read-only
- [ ] Works with Ollama (test: `ollama pull llama3.2:1b && ollama serve`)
- [ ] Works with LM Studio (test: download a model, start local server)
- [ ] Works with a cloud API key (test: Groq free tier or OpenRouter)
- [ ] Settings save button shows "Saved!" confirmation
- [ ] All new fields are included in the API settings save/load cycle

---

## 12. Backward Compatibility

- Users with existing settings (no `providerId`, no `baseUrl`, no `apiKey`) will be migrated:
  - If the server has `baseUrl` configured in `config.js` / `.env`, use that as the default
  - Provider defaults to a "Custom Local" entry with the existing URL
  - Model name and inference parameters are preserved
- The old `system-info` endpoint continues to work during a deprecation period (one version), returning a subset of the new `detect` endpoint's data