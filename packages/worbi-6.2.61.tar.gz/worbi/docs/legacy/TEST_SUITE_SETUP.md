# Handoff: Test Suite Setup and Coverage Targets

**Target Version:** v6.2.40 (updated from v5.2.0)
**Priority:** High (safety net for all future changes)
**Dependencies:** None (can and should be done first, before any other refactoring)
**Status:** DECOMPOSED — This document has been split into 9 actionable phase documents (Phase 0–8) with ~488 total tests. See the Master Phase Index below.

---

## Master Phase Index (Updated May 2026)

The implementation plan below has been decomposed into the following phase documents, to be executed in order:

| Phase | Document | Focus | Tests | Status |
|-------|----------|-------|-------|--------|
| Phase 0 | [PHASE_0_TEST_INFRASTRUCTURE.md](./PHASE_0_TEST_INFRASTRUCTURE.md) | Test infrastructure (Vitest config, helpers, mocks) | 0 (infra only) | ⬜ Not started |
| Phase 1 | [PHASE_1_SECURITY_TESTS.md](./PHASE_1_SECURITY_TESTS.md) | Security: path traversal + authentication | ~75 | ⬜ Not started |
| Phase 2 | [PHASE_2_CORE_SERVICES.md](./PHASE_2_CORE_SERVICES.md) | Core services: file, tag, tool, LLM, reminder, location | ~165 | ⬜ Not started |
| Phase 3 | [PHASE_3_LIFECYCLE_CONFIG_SERVICES.md](./PHASE_3_LIFECYCLE_CONFIG_SERVICES.md) | Supporting services: lifecycle, detector, provider, template | ~68 | ⬜ Not started |
| Phase 4 | [PHASE_4_CLIENT_HOOKS.md](./PHASE_4_CLIENT_HOOKS.md) | Client React hooks | ~86 | ⬜ Not started |
| Phase 5 | [PHASE_5_FEATURE_MODULES.md](./PHASE_5_FEATURE_MODULES.md) | Feature modules (LLM, reminders, tags, timeline) | ~46 | ⬜ Not started |
| Phase 6 | [PHASE_6_COMPONENT_SMOKE_TESTS.md](./PHASE_6_COMPONENT_SMOKE_TESTS.md) | UI component smoke tests | ~16 | ⬜ Not started |
| Phase 7 | [PHASE_7_TIPAP_AND_UTILS.md](./PHASE_7_TIPAP_AND_UTILS.md) | TipTap extensions & utilities | ~32 | ⬜ Not started |
| Phase 8 | [PHASE_8_COVERAGE_AND_CI.md](./PHASE_8_COVERAGE_AND_CI.md) | Coverage ratcheting & CI integration | — | ⬜ Not started |
| **Total** | | | **~488 tests** | |

**How to use:** Start with Phase 0. When all tests pass, move to Phase 1. Continue sequentially. Each phase document includes its own verification checklist.

---

## Key Differences from Original Plan

The phase documents refine the original TEST_SUITE_SETUP.md plan in the following ways:

1. **Version updated** from v5.2.0 → v6.2.40 (current WORBI version)
2. **Problem statement updated** with current stats (v6.2.39, 1526 changelog lines, 12,000+ lines of code)
3. **Server test helpers restructured** — testApp.ts split into testApp.ts (Express factory) and mockApp.ts (API function mocks) for use by both integration tests and server unit tests
4. **Expanded test coverage** — added location service tests, reminder service tests, template service tests, provider catalog tests, lifecycle tests
5. **Added integration test** for reminders API (was missing from original plan)
6. **Phase ordering refined** — Phase 1 includes auth integration tests; Phase 2 includes file+reminder integration tests; Phase 3 includes graph/timeline/image/settings integration tests
7. **Total test count** refined from "450+" to "~488 tests" based on actual service inventory

---

## 1. Problem Statement

WORBI has zero automated tests. No unit tests, no integration tests, no end-to-end tests. The project is at v5.1.9 with 696 lines of changelog and approximately 8,000+ lines of application code across 40+ files. Every change is verified manually.

**Consequences:**
- Refactoring (like the App.tsx decomposition or database migration) carries high risk of regression
- Bug fixes cannot prove they don't reintroduce old bugs
- No confidence that path traversal guards actually work
- LLM tool-calling loop (with 10-turn iteration) has no verification of its termination guarantees
- Tag CRUD operations have no proof of correctness
- File operations (copy, move, delete) with undo/redo have complex state transitions that are easy to break

**Testing priorities by risk:**
1. Path traversal guards (security — if broken, arbitrary file read/write)
2. Authentication (security — if broken, unauthorized access)
3. File operations with undo/redo (correctness — data loss risk)
4. Tag CRUD and relationships (data integrity)
5. LLM tool-calling loop (correctness — infinite loop or incorrect tool dispatch)
6. Search functionality (correctness)
7. UI component rendering (regression prevention)

---

## 2. Testing Stack

| Layer | Tool | Rationale |
|-------|------|-----------|
| Unit tests (server) | Vitest | Fast, native ESM support, Jest-compatible API, same tool as client |
| Unit tests (client) | Vitest + React Testing Library | Component testing with user-centric API |
| API integration tests | Vitest + Supertest | HTTP-level testing of Express routes |
| Database tests | Vitest + better-sqlite3 (in-memory) | Fast, isolated, no filesystem dependency |
| Coverage | Vitest built-in (c8/istanbul) | Built into Vitest, no extra config |
| Type checking | TypeScript `--noEmit` | Already part of the build, ensure it's in CI |

**Do NOT use Jest.** The project uses ES modules (`"type": "module"` in server) and Jest's ESM support is still experimental and painful. Vitest handles ESM natively.

---

## 3. Configuration Setup

### Step 1: Install Dependencies

In the root `package.json` (workspace root), add:

**Dev dependencies:**
- `vitest` — test runner
- `@vitest/coverage-v8` — code coverage provider
- `supertest` — HTTP assertion library for Express
- `@types/supertest` — TypeScript types for supertest

In `server/package.json`, no additional test dependencies needed (uses root vitest).

In `client/package.json`:
- `@testing-library/react` — React component testing
- `@testing-library/jest-dom` — DOM matchers (`.toBeInTheDocument()`, etc.)
- `@testing-library/user-event` — simulated user interactions
- `jsdom` — DOM environment for component tests

### Step 2: Root Vitest Config

Create `vitest.config.ts` at the workspace root (`/WORBI/vitest.config.ts`):

Specify:
- Use `defineConfig` from `vitest/config`
- Configure a workspace pattern: point to `server/vitest.config.ts` and `client/vitest.config.ts` for project-specific overrides
- Set global test timeout to 10 seconds
- Enable `coverage` with provider `v8`, include all `src/` directories in both server and client, exclude test files and `node_modules`
- Set coverage thresholds: 70% lines, 70% branches, 70% functions, 70% statements (aspirational — start with 0% and ratchet up)

### Step 3: Server Vitest Config

Create `server/vitest.config.ts`:

Specify:
- Environment: `node` (server-side code runs in Node.js)
- Include: `src/**/*.test.ts`, `tests/**/*.test.ts`
- Setup file: `server/tests/setup.ts` (global test setup)
- Globals: `true` so `describe`, `it`, `expect` are available without imports

### Step 4: Client Vitest Config

Create `client/vitest.config.ts`:

Specify:
- Environment: `jsdom` (browser-like DOM for React components)
- Include: `src/**/*.test.tsx`, `src/**/*.test.ts`
- Setup file: `client/tests/setup.ts` (imports `@testing-library/jest-dom`)
- Globals: `true`
- Alias: map `@/` to `client/src/` if the project uses path aliases (check `tsconfig.json`)

### Step 5: Test Setup Files

Create `server/tests/setup.ts`:
- No special setup needed for server tests beyond what Vitest provides
- Optionally: set environment variables for testing (`NODE_ENV=test`, `PORT=0` for random port)

Create `client/tests/setup.ts`:
- Import `@testing-library/jest-dom` to register custom matchers

### Step 6: NPM Scripts

Add to root `package.json`:
- `"test": "vitest run"` — run all tests once (CI mode)
- `"test:watch": "vitest"` — run tests in watch mode (development)
- `"test:coverage": "vitest run --coverage"` — run tests with coverage report
- `"test:server": "vitest run --project server"` — run only server tests
- `"test:client": "vitest run --project client"` — run only client tests

### Step 7: TypeScript Config

Ensure `server/tsconfig.json` includes test files (add `tests/**/*.ts` to `include`).
Ensure `client/tsconfig.json` includes test files (add `src/**/*.test.tsx` and `src/**/*.test.ts` to `include`).

---

## 4. Test Architecture

### 4.1 Server Test Structure

```
server/
├── tests/
│   ├── setup.ts                          # Global test setup
│   ├── helpers/
│   │   ├── testApp.ts                   # Create Express app instance for testing
│   │   ├── authHelper.ts               # Generate test tokens, create test users
│   │   └── fsHelper.ts                 # Create temporary workspace directories
│   └── unit/                            # Unit tests (no HTTP)
│   │   ├── services/
│   │   │   ├── authService.test.ts
│   │   │   ├── fileService.test.ts
│   │   │   ├── tagService.test.ts
│   │   │   ├── llmService.test.ts
│   │   │   ├── toolService.test.ts
│   │   │   └── proxyAuth.test.ts      # (after blob URL fix)
│   │   └── middleware/
│   │       └── authMiddleware.test.ts
│   └── integration/                     # HTTP-level tests
│       ├── auth.test.ts
│       ├── files.test.ts
│       ├── llm.test.ts
│       ├── settings.test.ts
│       └── images.test.ts              # (after blob URL fix)
```

### 4.2 Client Test Structure

```
client/
├── tests/
│   ├── setup.ts                          # Import jest-dom matchers
│   └── src/
│       ├── hooks/
│       │   ├── useAuth.test.ts
│       │   ├── useFiles.test.ts
│       │   ├── useLLM.test.ts
│       │   ├── useRecents.test.ts
│       │   ├── useSearch.test.ts
│       │   ├── useTags.test.ts
│       │   └── useFileSystemUndoRedo.test.ts
│       └── components/
│           ├── ActivityBar.test.tsx
│           ├── FileExplorer.test.tsx
│           ├── TabBar.test.tsx
│           ├── Header.test.tsx
│           ├── ChatPanel.test.tsx
│           ├── DocumentEditor.test.tsx
│           ├── TagManager.test.tsx
│           ├── InformationPanel.test.tsx
│           ├── SearchPanel.test.tsx
│           └── Welcome.test.tsx
```

---

## 5. Priority Test Cases

### 5.1 CRITICAL: Path Traversal Guards

These tests must pass before any other work proceeds.

**File: `server/tests/unit/services/fileService.test.ts`**

Test `getSafePath()`:
- Given username "testuser" and relative path "foo/bar.txt", returns absolute path within user's workspace root
- Given relative path "../../../etc/passwd", throws Error with message containing "path traversal"
- Given relative path "/etc/passwd", throws Error (absolute paths should not resolve outside workspace)
- Given relative path "foo/../../../etc/passwd", throws Error
- Given empty string, returns the workspace root path
- Given null/undefined, throws Error or returns workspace root (document current behavior, then decide)
- Given paths with symlinks (create a symlink in the test workspace pointing outside), throws Error or correctly resolves and then rejects

Test `getSafeImagePath()`:
- Same traversal tests as above, but against the assets root
- Given image name with path separators (e.g., "../foo.png"), throws Error

**File: `server/tests/unit/services/toolService.test.ts`**

Test `resolveSafePath()`:
- Given path "foo/bar.txt", resolves within WORKSPACE_ROOT
- Given path "../etc/passwd", throws Error with message "Path traversal not allowed"
- Given path starting with "..", throws Error
- Given path that resolves outside workspace root, throws Error with message "Access denied: path outside workspace"
- Given empty string, resolves to workspace root
- Given null/undefined, throws Error

### 5.2 HIGH: Authentication

**File: `server/tests/unit/services/authService.test.ts`**

- `authenticateUser()`: Correct password returns user object; wrong password throws; non-existent user throws
- `createUser()`: Creates user, password is bcrypt-hashed (verify hash format, not the actual hash); duplicate username throws
- `getUserWorkspaceDir()`: Returns correct path for a given username
- `getUserAssetsDir()`: Returns correct path for a given username

**File: `server/tests/unit/middleware/authMiddleware.test.ts`**

- Request with valid `Authorization: Bearer <token>` header calls `next()`
- Request with no Authorization header returns 401
- Request with `Authorization: Basic <...>` returns 401 (wrong scheme)
- Request with expired token returns 401
- Request with tampered token (invalid signature) returns 401
- Request with token for non-existent user returns 401

**File: `server/tests/integration/auth.test.ts`**

- `POST /api/auth/login` with valid credentials returns 200 + `{ token, user }`
- `POST /api/auth/login` with wrong password returns 401
- `POST /api/auth/register` creates user and returns token
- `POST /api/auth/register` with duplicate username returns 409
- Protected routes return 401 without token
- Protected routes return 200 with valid token

### 5.3 HIGH: File Operations

**File: `server/tests/unit/services/fileService.test.ts` (continued)**

- `listDirectory()`: Lists files and folders; returns correct type field; empty directory returns empty array; nested directories show only direct children; files have size field, folders don't
- `readFile()`: Reads file content correctly; throws on directory; throws on non-existent file
- `writeFile()`: Creates file in new directory (auto-creates parent dirs); overwrites existing file; content matches what was written
- `createFolder()`: Creates folder; throws if already exists; creates nested folders with recursive flag
- `deleteItem()`: Deletes file; deletes empty folder; deletes folder with contents (recursive); throws if not found
- `renameItem()`: Renames file; renames folder; throws if source doesn't exist; throws if destination exists
- `copyItem()`: Copies file to same directory with "-copy" suffix; copies to different directory; throws if source doesn't exist; throws if destination exists
- `moveItem()`: Moves file between directories; source file no longer exists after move; destination has correct content; throws if source doesn't exist; throws if destination exists

**File: `server/tests/unit/services/fileService.test.ts` — search**

- `searchWorkspace()`: Matches by filename; matches by content; returns context around match; respects limit parameter; skips binary files (test with a .png and a .zip in the workspace); handles empty workspace; handles workspace with no matching files

### 5.4 HIGH: File System Undo/Redo

**File: `client/tests/src/hooks/useFileSystemUndoRedo.test.ts`**

- After pushing a "create file" operation, undo removes the file
- After undo, redo recreates the file
- Multiple operations can be undone in reverse order
- Multiple operations can be redone in original order
- Push after undo clears redo stack
- Cannot undo when stack is empty
- Cannot redo when stack is empty
- Undo callback is called for each operation (simulate with mock functions)
- Redo callback is called for each operation

### 5.5 HIGH: Tag System

**File: `server/tests/unit/services/tagService.test.ts`**

- Create tag with name and color
- Create duplicate tag name throws
- Update tag name and color
- Delete tag (and verify cascade: file associations are removed)
- Add tag to file (creates file_tags entry)
- Remove tag from file (deletes file_tags entry)
- Add same tag to same file twice (should be idempotent or throw)
- Get files by tag returns correct file list
- Get tags for file returns correct tag list
- Get file relationships returns correct relationship data
- Tag with no files returns empty file list
- File with no tags returns empty tag list

**File: `server/tests/integration/files.test.ts` — tag endpoints**

- `GET /api/tags` returns all tags
- `POST /api/tags` creates a tag
- `PUT /api/tags/:id` updates a tag
- `DELETE /api/tags/:id` deletes a tag
- `GET /api/tags/:id/files` returns files with that tag
- `POST /api/files/:path/tags` adds tags to a file
- `DELETE /api/files/:path/tags/:tagId` removes a tag from a file

### 5.6 MEDIUM: LLM Service

**File: `server/tests/unit/services/llmService.test.ts`**

These tests should mock the `axios` HTTP calls to avoid requiring a real LLM server.

- `sendChatMessage()`: Sends messages and returns assistant response; includes document content in system prompt; includes custom system prompt when provided; returns tool activity when tools are used (mock a tool_call response); respects MAX_TOOL_TURNS limit (simulate 10+ tool calls, verify it stops and returns the limit message); handles LLM error responses gracefully (mock a 500 from the LLM server); passes permissions to tool definitions
- `fetchModels()`: Returns model list; throws on connection error
- `testConnection()`: Returns success when server responds; returns failure on error
- `getSystemInfo()`: Extracts model name from lms-start script; reports server status based on health check response

**File: `server/tests/unit/services/llmService.test.ts` — tool calling loop**

- Single tool call: LLM requests `web_search`, tool returns results, LLM gets results back, LLM returns final answer
- Multiple tool calls in sequence: LLM requests `read_file`, gets content, then requests `web_search` about that content, gets results, returns final answer
- Tool call error: tool throws, error is returned to LLM, LLM gets error context, LLM returns final answer
- Max turns reached: after exactly MAX_TOOL_TURNS iterations of tool calls, returns limit message
- No tools enabled: when permissions result in zero tool definitions, no tools are sent to the LLM
- Tool activity tracking: `toolActivity` array contains correct entries with status transitions (running → complete/error)

### 5.7 MEDIUM: Tool Service

**File: `server/tests/unit/services/toolService.test.ts`**

- `executeTool('web_search', { query: 'test' })`: Returns formatted search results (mock DuckDuckGo HTML response)
- `executeTool('read_file', { file_path: 'existing.txt' })`: Returns file contents
- `executeTool('read_file', { file_path: 'nonexistent.txt' })`: Throws "File not found"
- `executeTool('read_file', { file_path: '../secret.txt' })`: Throws path traversal error
- `executeTool('list_directory', { dir_path: '' })`: Returns formatted directory listing
- `executeTool('write_file', { file_path: 'new.txt', content: 'hello' })`: Creates file, returns success message
- `executeTool('edit_file', { file_path: 'test.txt', search_text: 'old', replace_text: 'new' })`: Replaces text, returns success
- `executeTool('edit_file', { file_path: 'test.txt', search_text: 'notfound', replace_text: 'new' })`: Throws "Text not found"
- `executeTool('create_folder', { folder_path: 'newdir' })`: Creates folder, returns success
- `executeTool('delete_file', { file_path: 'deletable.txt' })`: Deletes file, returns success
- `executeTool('delete_file', { file_path: 'README.md' })`: For root-level README.md, throws "Cannot delete critical project file"
- `executeTool('delete_file', { file_path: 'subdir/README.md' })`: For README.md in a subdirectory, succeeds (only root is protected)
- `executeTool('rename_file', { file_path: 'old.txt', new_name: 'new.txt' })`: Renames file, returns success
- `executeTool('unknown_tool', {})`: Throws "Unknown tool"
- `executeTool('delete_file', { file_path: 'a_directory' })`: Throws "Cannot delete directories"
- `executeTool('rename_file', { file_path: 'a_directory', new_name: 'b' })`: Throws "Cannot rename directories"
- `getToolDefinitions({ webSearch: true, fileAccessLevel: 'read' })`: Returns web_search, read_file, list_directory only
- `getToolDefinitions({ webSearch: false, fileAccessLevel: 'readwrite', allowCreate: true, allowEdit: true })`: Returns read, list, write, create_folder, edit_file only (no web_search, no delete/rename)
- `getToolDefinitions({ webSearch: true, fileAccessLevel: 'full', allowDelete: true, allowRename: true })`: Returns all 8 tools
- `getToolDefinitions({ fileAccessLevel: 'none' })`: Returns empty array (or web_search only if enabled)

### 5.8 MEDIUM: Client Hooks

**File: `client/tests/src/hooks/useAuth.test.ts`**

- Initial state: not authenticated, user is null
- `login(username, password)`: Calls API, sets user and token
- `logout()`: Clears user and token, removes from localStorage
- Token is stored in localStorage and loaded on mount
- Expired token: detects expiration, logs out

**File: `client/tests/src/hooks/useFiles.test.ts`**

- `loadFiles(path)`: Fetches and sets file list
- `openFile(path)`: Fetches content and opens tab
- `saveCurrentFile()`: Saves content, marks tab as clean
- `newFile(name)`: Creates file, refreshes list
- `newFolder(name)`: Creates folder, refreshes list
- `deleteSelected(path)`: Deletes file, refreshes list
- `renameSelected(oldPath, newName)`: Renames file, refreshes list
- `copySelected(sourcePath)`: Copies file, refreshes list
- `moveSelected(sourcePath, destFolder)`: Moves file, refreshes list
- `closeTab(tabId)`: Removes tab, activates another tab

**File: `client/tests/src/hooks/useRecents.test.ts`**

- `addRecentFile(path)`: Adds to recent list, most recent first
- Adding the same file again moves it to top (doesn't duplicate)
- Recent list is capped at a reasonable limit (e.g., 50)
- `toggleStar(path)`: Adds to starred if not starred, removes if starred
- Starred list persists in localStorage
- Recent list persists in localStorage

### 5.9 LOW: UI Component Smoke Tests

For each component, write a minimal "it renders without crashing" test:

**File: `client/tests/src/components/*.test.tsx`**

Each component test:
- Renders the component with minimal required props
- Asserts that some key element is in the document (e.g., a specific text, an icon, a data-testid)
- Does NOT test every interaction — those come later as the test suite matures

Component-specific smoke tests:
- `ActivityBar`: Renders explorer, search, starred, tags, settings icons
- `FileExplorer`: Renders "Explorer" heading, file list area
- `TabBar`: Renders tab list or empty state
- `Header`: Renders WORBI logo, save button (if file open)
- `ChatPanel`: Renders AI chat header
- `DocumentEditor`: Renders TipTap editor area
- `TagManager`: Renders tags heading
- `InformationPanel`: Renders hero image section, tags section
- `SearchPanel`: Renders search input
- `Welcome`: Renders welcome message, recent files section
- `StatusBar`: Renders status text
- `ErrorBoundary`: Renders children normally; renders fallback on error

---

## 6. Test Helpers and Utilities

### 6.1 Server Test App Factory

Create `server/tests/helpers/testApp.ts`:
- A function `createTestApp()` that imports the Express app from `server/src/index.js` WITHOUT starting the HTTP listener
- This requires refactoring `server/src/index.js` to export the `app` object separately from the `app.listen()` call
- The test helper imports `app`, applies supertest to it, and returns the supertest instance
- Also create a function `createTestAppWithUser(username)` that creates a test user, generates a valid JWT token, and returns both the supertest instance and the token for authenticated requests

### 6.2 Server Filesystem Test Helper

Create `server/tests/helpers/fsHelper.ts`:
- `createTempWorkspace()`: Creates a temporary directory structure with test files and folders, returns the root path
- `cleanupTempWorkspace(rootPath)`: Recursively deletes the temporary directory
- `createTestFile(workspaceRoot, relativePath, content)`: Creates a file within the temp workspace
- Use `beforeEach`/`afterEach` in test suites to set up and tear down temp workspaces
- Ensure temp directories are in the OS temp dir (`/tmp/worbi-tests-XXXXX`), not in the project directory

### 6.3 Mock API for Client Tests

For client hook tests, mock `services/api.ts`:
- Use `vi.mock('../../services/api')` (or the appropriate relative path)
- Each test can provide mock implementations for specific API functions
- Mock `fetch` for any direct fetch calls (like image blob URL fetching)

### 6.4 TipTap Editor Mock

Testing `DocumentEditor` requires mocking TipTap:
- Create a minimal mock in `client/tests/helpers/mockTiptap.ts`:
  - Mock `useEditor` to return an object with `chain()`, `focus()`, `setContent()`, `getHTML()`, `getText()`, `isActive()`, and event handlers as no-ops
  - Mock `<EditorContent>` to render a simple `<div>` with the content
- This allows smoke-testing the component without requiring the full ProseMirror DOM

---

## 7. Continuous Integration

If a CI pipeline is added in the future (GitHub Actions, etc.), add these steps:

1. `npm ci` — install dependencies
2. `npm run build` — verify the project builds
3. `npm run test` — run all tests
4. `npm run test:coverage` — run tests with coverage, fail if below threshold

For now, ensure `npm test` can be run locally and passes 100%.

---

## 8. Test Data Management

### 8.1 Server Test Data

- Use `server/tests/fixtures/` for static test data (e.g., sample HTML documents, sample `.wbi-meta.json`)
- Never use the actual `server/data/` directory in tests — always use temporary directories
- Set `NODE_ENV=test` so the server uses a test-specific data directory (override in config if needed)

### 8.2 Client Test Data

- Define mock API responses inline in tests or in `client/tests/fixtures/`
- Use realistic but minimal data (e.g., 2-3 files, 2-3 tags, not 50)
- Test edge cases with empty arrays, null values, and error responses

---

## 9. Coverage Targets

Start with 0% coverage requirement and ratchet up as tests are added:

| Milestone | Lines | Branches | Functions | When |
|-----------|-------|----------|-----------|------|
| Initial | 0% | 0% | 0% | Day 1 |
| After Phase 1 | 30% | 25% | 30% | After critical path tests written |
| After Phase 2 | 50% | 45% | 50% | After high-priority tests written |
| After Phase 3 | 70% | 65% | 70% | After all priority tests written |
| Target | 80% | 75% | 80% | Long-term goal |

**Critical paths must have 100% coverage:**
- `getSafePath()` and `resolveSafePath()` (path traversal)
- `authenticateUser()` and JWT verification
- `deleteItem()`, `renameItem()`, `copyItem()`, `moveItem()`
- `executeTool()` dispatch

---

## 10. Files to Create

| File | Purpose |
|------|---------|
| `vitest.config.ts` | Root Vitest workspace configuration |
| `server/vitest.config.ts` | Server-specific test configuration |
| `client/vitest.config.ts` | Client-specific test configuration |
| `server/tests/setup.ts` | Server test setup (env vars, etc.) |
| `client/tests/setup.ts` | Client test setup (jest-dom matchers) |
| `server/tests/helpers/testApp.ts` | Express app factory for integration tests |
| `server/tests/helpers/authHelper.ts` | Test user creation and token generation |
| `server/tests/helpers/fsHelper.ts` | Temporary workspace directory management |
| `client/tests/helpers/mockTiptap.ts` | TipTap editor mocks for component tests |
| `server/tests/unit/services/authService.test.ts` | Auth service tests |
| `server/tests/unit/services/fileService.test.ts` | File service tests (including path traversal) |
| `server/tests/unit/services/tagService.test.ts` | Tag service tests |
| `server/tests/unit/services/llmService.test.ts` | LLM service tests (mocked) |
| `server/tests/unit/services/toolService.test.ts` | Tool service tests |
| `server/tests/unit/middleware/authMiddleware.test.ts` | Auth middleware tests |
| `server/tests/integration/auth.test.ts` | Auth API integration tests |
| `server/tests/integration/files.test.ts` | Files API integration tests |
| `server/tests/integration/llm.test.ts` | LLM API integration tests (mocked) |
| `server/tests/integration/settings.test.ts` | Settings API integration tests |
| `client/tests/src/hooks/useAuth.test.ts` | Auth hook tests |
| `client/tests/src/hooks/useFiles.test.ts` | Files hook tests |
| `client/tests/src/hooks/useFileSystemUndoRedo.test.ts` | Undo/redo hook tests |
| `client/tests/src/hooks/useRecents.test.ts` | Recents hook tests |
| `client/tests/src/components/ActivityBar.test.tsx` | ActivityBar smoke test |
| `client/tests/src/components/FileExplorer.test.tsx` | FileExplorer smoke test |
| `client/tests/src/components/TabBar.test.tsx` | TabBar smoke test |
| `client/tests/src/components/Header.test.tsx` | Header smoke test |
| `client/tests/src/components/ChatPanel.test.tsx` | ChatPanel smoke test |
| `client/tests/src/components/DocumentEditor.test.tsx` | DocumentEditor smoke test |
| `client/tests/src/components/TagManager.test.tsx` | TagManager smoke test |
| `client/tests/src/components/InformationPanel.test.tsx` | InformationPanel smoke test |
| `client/tests/src/components/SearchPanel.test.tsx` | SearchPanel smoke test |
| `client/tests/src/components/Welcome.test.tsx` | Welcome smoke test |

## 11. Files to Modify

| File | Changes |
|------|---------|
| `package.json` (root) | Add vitest dev dependency, test scripts |
| `server/package.json` | Add supertest dev dependency |
| `client/package.json` | Add testing-library dev dependencies |
| `server/src/index.js` | Separate `app` creation from `app.listen()` for testability |
| `server/src/config.js` | Support `NODE_ENV=test` for test-specific data paths |

## 12. Implementation Order

### Phase 1: Infrastructure
1. Install test dependencies
2. Create vitest configs for root, server, client
3. Create test setup files
4. Create test helpers (testApp, authHelper, fsHelper, mockTiptap)
5. Refactor `server/src/index.js` to export `app` separately from listen
6. Verify `npm test` runs (even with 0 tests) without errors

### Phase 2: Critical Security Tests
1. Write path traversal tests for `fileService.js`
2. Write path traversal tests for `toolService.js`
3. Write auth middleware tests
4. Write auth service tests
5. Write auth integration tests
6. All critical tests must pass before proceeding

### Phase 3: High-Priority Service Tests
1. Write fileService tests (CRUD, search)
2. Write tagService tests
3. Write toolService tests (all tools, all permission levels)
4. Write llmService tests (mocked)
5. Write files integration tests
6. Write settings integration tests

### Phase 4: Client Tests
1. Write client hook tests (useAuth, useFiles, useFileSystemUndoRedo, useRecents)
2. Write component smoke tests

### Phase 5: Coverage and CI
1. Configure coverage thresholds
2. Add test scripts to package.json
3. Document testing in project README

---

## 13. Verification Checklist

- [ ] `npm test` runs all tests and exits with code 0
- [ ] `npm run test:server` runs only server tests
- [ ] `npm run test:client` runs only client tests
- [ ] `npm run test:coverage` generates a coverage report
- [ ] All path traversal tests pass (criteria: cannot read/write outside workspace)
- [ ] All auth tests pass (criteria: unauthorized requests are rejected)
- [ ] All file operation tests pass
- [ ] All tag operation tests pass
- [ ] All tool execution tests pass
- [ ] Client hook tests pass
- [ ] Component smoke tests pass
- [ ] No tests depend on external services (LLM server, network)
- [ ] No tests leave files in the project data directory
- [ ] Test suite completes in under 30 seconds (for unit + integration; E2E excluded)
- [ ] Tests can run in any order (no test interdependence)