# Handoff: Document Templates & Story Bible Compiler

**Target Version:** v5.4.0
**Priority:** Medium (lowers barrier to creating structured world-building content)
**Dependencies:** None (can be implemented independently)

---

## 1. Overview

This handoff covers two related features that help users create structured world-building content:

| Feature | Description |
|---------|-------------|
| **Document Templates** | Pre-built templates for character sheets, locations, quests, timelines, and items |
| **Story Bible Compiler** | One-click compilation of selected documents into a single organized reference |

---

## 2. Feature 1: Document Templates

### 2.1 Problem Statement

New WORBI users face a blank editor. They know they want to create a character or describe a location, but they don't know what sections to include or how to structure the content. Templates provide a scaffold — structured HTML with all the relevant headings and prompts — that users fill in.

### 2.2 Template Types

| Template | File Name Pattern | Default Folder |
|----------|-------------------|----------------|
| Character Sheet | `[Name] - Character.html` | `/Characters/` |
| Location Description | `[Name] - Location.html` | `/World/` |
| Quest Outline | `[Name] - Quest.html` | `/Quests/` |
| Timeline Entry | `[Name] - Event.html` | `/World/Timeline/` |
| Item / Artifact | `[Name] - Item.html` | `/World/Items/` |
| Faction / Organization | `[Name] - Faction.html` | `/World/Factions/` |
| Creature / Monster | `[Name] - Creature.html` | `/World/Creatures/` |
| Blank Document | `Untitled.html` | Current folder |

### 2.3 Template Content

**Character Sheet:**
```html
<h2>Character Name</h2>
<p><strong>Role:</strong> </p>
<p><strong>Race/Species:</strong> </p>
<p><strong>Age:</strong> </p>
<p><strong>Gender:</strong> </p>
<h3>Physical Description</h3>
<p></p>
<h3>Personality</h3>
<p></p>
<h3>Background</h3>
<p></p>
<h3>Abilities & Skills</h3>
<p></p>
<h3>Motivations & Goals</h3>
<p></p>
<h3>Relationships</h3>
<p></p>
<h3>Notes</h3>
<p></p>
<!-- MARGIN_SPLIT -->
<h3>Appearance Notes</h3>
<p><em>Use this margin column for visual descriptions, inspiration images, and casting ideas.</em></p>
```

**Location Description:**
```html
<h2>Location Name</h2>
<p><strong>Type:</strong> (city, dungeon, forest, mountain, temple, etc.)</p>
<p><strong>Region:</strong> </p>
<p><strong>Climate:</strong> </p>
<h3>Geography & Layout</h3>
<p></p>
<h3>Population & Culture</h3>
<p></p>
<h3>Points of Interest</h3>
<h4>1. </h4>
<p></p>
<h4>2. </h4>
<p></p>
<h3>History</h3>
<p></p>
<h3>Adventure Hooks</h3>
<p></p>
<!-- MARGIN_SPLIT -->
<h3>Visual References</h3>
<p><em>Add images of the location's atmosphere, architecture, and key landmarks.</em></p>
```

**Quest Outline:**
```html
<h2>Quest Name</h2>
<p><strong>Recommended Level:</strong> </p>
<p><strong>Quest Giver:</strong> </p>
<p><strong>Location:</strong> </p>
<h3>Hook</h3>
<p>How the party discovers the quest...</p>
<h3>Objectives</h3>
<ol>
  <li></li>
  <li></li>
  <li></li>
</ol>
<h3>Key NPCs</h3>
<h4>1. </h4>
<p></p>
<h4>2. </h4>
<p></p>
<h3>Encounters</h3>
<h4>Encounter 1</h4>
<p><strong>Type:</strong> (combat, social, puzzle, exploration)</p>
<p><strong>Difficulty:</strong> </p>
<p><strong>Description:</strong> </p>
<h3>Rewards</h3>
<ul>
  <li></li>
</ul>
<h3>Possible Complications</h3>
<p></p>
<!-- MARGIN_SPLIT -->
<h3>DM Notes</h3>
<p><em>Behind-the-scenes notes, secrets, and alternate outcomes.</em></p>
```

**Timeline Entry:**
```html
<h2>Event Name</h2>
<p><strong>Date/Period:</strong> </p>
<p><strong>Era:</strong> (First Age, Second Age, etc.)</p>
<p><strong>Category:</strong> (historical, personal, mythological, natural disaster, war)</p>
<h3>Description</h3>
<p></p>
<h3>Key Figures</h3>
<ul>
  <li></li>
</ul>
<h3>Causes</h3>
<p></p>
<h3>Consequences</h3>
<p></p>
<h3>Related Events</h3>
<p>Links to other timeline entries...</p>
<!-- MARGIN_SPLIT -->
<h3>Sources & Legends</h3>
<p><em>How is this event remembered? Are there conflicting accounts?</em></p>
```

**Item / Artifact:**
```html
<h2>Item Name</h2>
<p><strong>Type:</strong> (weapon, armor, wondrous item, artifact, consumable)</p>
<p><strong>Rarity:</strong> (common, uncommon, rare, very rare, legendary, artifact)</p>
<p><strong>Attunement:</strong> (yes/no/description)</p>
<h3>Physical Description</h3>
<p></p>
<h3>Properties & Effects</h3>
<p></p>
<h3>History & Origin</h3>
<p></p>
<h3>Current Location / Bearer</h3>
<p></p>
<h3>Plot Significance</h3>
<p></p>
<!-- MARGIN_SPLIT -->
<h3>Visual Concept</h3>
<p><em>Add sketches or generated images of the item.</em></p>
```

**Faction / Organization:**
```html
<h2>Faction Name</h2>
<p><strong>Type:</strong> (guild, cult, government, merchant company, thieves' guild, etc.)</p>
<p><strong>Alignment:</strong> </p>
<p><strong>Size/Influence:</strong> (local, regional, national, global)</p>
<h3>Overview</h3>
<p></p>
<h3>Goals & Agenda</h3>
<p></p>
<h3>Leadership</h3>
<h4>Leader Name</h4>
<p><strong>Title:</strong> </p>
<p><strong>Description:</strong> </p>
<h3>Notable Members</h3>
<ul><li></li></ul>
<h3>Structure & Hierarchy</h3>
<p></p>
<h3>Resources & Assets</h3>
<p></p>
<h3>Allies & Enemies</h3>
<p></p>
<h3>Campaign Role</h3>
<p></p>
<!-- MARGIN_SPLIT -->
<h3>Symbol & Heraldry</h3>
<p><em>Describe or add images of the faction's insignia, colors, and symbols.</em></p>
```

**Creature / Monster:**
```html
<h2>Creature Name</h2>
<p><strong>Type:</strong> (aberration, beast, dragon, fey, fiend, undead, etc.)</p>
<p><strong>CR / Challenge:</strong> </p>
<p><strong>Size:</strong> </p>
<p><strong>Alignment:</strong> </p>
<h3>Description</h3>
<p></p>
<h3>Behavior & Ecology</h3>
<p></p>
<h3>Habitat</h3>
<p></p>
<h3>Abilities</h3>
<p></p>
<h3>Combat Tactics</h3>
<p></p>
<h3>Lore & Legends</h3>
<p></p>
<h3>Adventure Hooks</h3>
<p></p>
<!-- MARGIN_SPLIT -->
<h3>Visual Reference</h3>
<p><em>Add images of the creature.</em></p>
```

### 2.4 UI: New from Template

**Entry points:**
1. Header "File" menu → "New from Template..."
2. Welcome screen: "New from Template" button
3. File Explorer context menu: "New from Template..."
4. Keyboard shortcut: `Ctrl+Shift+N`

**Modal:**
```
┌─────────────────────────────────────┐
│  New from Template                  │
├─────────────────────────────────────┤
│                                     │
│  ┌──────────┐  ┌──────────┐        │
│  │ 👤       │  │ 🏰       │        │
│  │Character │  │ Location  │        │
│  └──────────┘  └──────────┘        │
│                                     │
│  ┌──────────┐  ┌──────────┐        │
│  │ ⚔️       │  │ ⏳       │        │
│  │  Quest    │  │ Timeline  │        │
│  └──────────┘  └──────────┘        │
│                                     │
│  ┌──────────┐  ┌──────────┐        │
│  │ 🗡️       │  │ 🏛️       │        │
│  │  Item     │  │ Faction   │        │
│  └──────────┘  └──────────┘        │
│                                     │
│  ┌──────────┐  ┌──────────┐        │
│  │ 🐉       │  │ 📄       │        │
│  │ Creature  │  │  Blank    │        │
│  └──────────┘  └──────────┘        │
│                                     │
│  Folder: [/Characters/     ▾]      │
│                                     │
│  [Cancel]                           │
└─────────────────────────────────────┘
```

**Flow:**
1. User selects a template type
2. User optionally changes the target folder
3. A new file is created with the template content
4. The file opens in a new tab
5. The cursor is placed at the first editable position (e.g., after `<h2>`)

### 2.5 Implementation

**Server endpoint:** `POST /api/files/template`

Request:
```json
{
  "template": "character",
  "folder": "/Characters/",
  "name": "Goblin King"
}
```

Response:
```json
{
  "path": "/Characters/Goblin King - Character.html",
  "content": "<h2>Character Name</h2>..."
}
```

**Server implementation:**
- Template content is stored as `.html` files in `server/src/data/templates/`
- `server/src/services/templateService.js` loads templates from disk, replaces `[Name]` placeholders
- Creates the file in the specified folder via `fileService`

**Client:**
- `client/src/components/NewFromTemplateModal.tsx`
- Uses `lucide-react` icons: `User`, `Building2`, `Swords`, `Clock`, `Gem`, `Landmark`, `Dragon`, `FileText`

---

## 3. Feature 2: Story Bible Compiler

### 3.1 Problem Statement

Writers with many documents spread across folders want a single compiled reference — a "Story Bible" — that they can read through, share, or export. Currently they must manually copy-paste content or use the DOCX export one file at a time.

### 3.2 Behavior

The user selects documents in the File Explorer (checkboxes or Ctrl+click multi-select) or compiles everything in a folder. Clicking "Compile Story Bible" generates a single HTML file that concatenates all selected documents with clear section breaks.

**Compilation modal:**
```
┌─────────────────────────────────────┐
│  Compile Story Bible                │
├─────────────────────────────────────┤
│  Source:                            │
│  ○ Selected files (3 files)         │
│  ● Entire folder: /World/           │
│  ○ Entire workspace                 │
│                                     │
│  Order by:                          │
│  ● Folder structure                 │
│  ○ Alphabetical                     │
│  ○ Last modified                    │
│                                     │
│  Include:                           │
│  ☑ Table of Contents                │
│  ☑ Section dividers                 │
│  ☑ File paths as subtitles          │
│  ☐ Margin notes (exclude)           │
│                                     │
│  Output name:                       │
│  ┌─────────────────────────────┐   │
│  │ My World - Story Bible.html │   │
│  └─────────────────────────────┘   │
│                                     │
│  [Cancel]      [Compile]            │
└─────────────────────────────────────┘
```

### 3.3 Output Format

```html
<h1>Story Bible: My World</h1>
<p><em>Compiled on May 1, 2026. 12 documents from /World/</em></p>

<hr>

<h2>Characters</h2>

<div class="story-bible-document">
  <h3>Goblin King</h3>
  <p class="story-bible-path">/Characters/Goblin King.html</p>

  <h4>Character Name</h4>
  <p><strong>Role:</strong> Ruler of the Underdark</p>
  ...
</div>

<hr class="story-bible-section">

<div class="story-bible-document">
  <h3>Elara Moonshadow</h3>
  <p class="story-bible-path">/Characters/Elara Moonshadow.html</p>
  ...
</div>

<hr>

<h2>Quests</h2>

<div class="story-bible-document">
  <h3>Rescue the Goblin King</h3>
  ...
</div>
```

### 3.4 Implementation

**Server endpoint:** `POST /api/files/compile`

Request:
```json
{
  "files": ["/Characters/Goblin King.html", "/World/Underdark.html"],
  "title": "My World - Story Bible",
  "includeTableOfContents": true,
  "includeSectionDividers": true,
  "includeFilePaths": true,
  "excludeMarginNotes": false,
  "orderBy": "folder"  // "folder", "alphabetical", "modified"
}
```

Response:
```json
{
  "path": "/Story Bibles/My World - Story Bible.html",
  "content": "<h1>Story Bible: My World</h1>...",
  "documentCount": 12,
  "totalSize": 45820
}
```

**Server logic:**
1. Collect all specified HTML files
2. Strip `<!-- MARGIN_SPLIT -->` sections if `excludeMarginNotes` is true
3. Extract `<title>` or first `<h2>` from each document for the ToC
4. Generate ToC with anchor links
5. Concatenate with semantic HTML structure
6. Replace `[[wiki links]]` with plain text (they don't make sense in a compiled document)
7. Save to `/Story Bibles/` folder (created if needed)

**Client:**
- Multi-select in FileExplorer (Ctrl+click, Shift+click) to select multiple files
- "Compile Story Bible" button in the File Explorer toolbar
- `client/src/components/CompileStoryBibleModal.tsx`

---

## 4. Files to Create

| File | Purpose |
|------|---------|
| `server/src/data/templates/character.html` | Character sheet template |
| `server/src/data/templates/location.html` | Location description template |
| `server/src/data/templates/quest.html` | Quest outline template |
| `server/src/data/templates/timeline.html` | Timeline entry template |
| `server/src/data/templates/item.html` | Item/artifact template |
| `server/src/data/templates/faction.html` | Faction template |
| `server/src/data/templates/creature.html` | Creature template |
| `server/src/services/templateService.js` | Template loading and file creation |
| `server/src/routes/templates.js` | Template endpoints |
| `server/src/routes/compile.js` | Compile endpoint |
| `client/src/components/NewFromTemplateModal.tsx` | Template selection modal |
| `client/src/components/CompileStoryBibleModal.tsx` | Compilation options modal |

## 5. Files to Modify

| File | Changes |
|------|---------|
| `server/src/index.js` | Register `/api/files/template` and `/api/files/compile` routes |
| `client/src/components/Header.tsx` | Add "New from Template..." to File menu |
| `client/src/components/FileExplorer.tsx` | Add multi-select support, "Compile" toolbar button, "New from Template" context menu item |
| `client/src/components/Welcome.tsx` | Add "New from Template" button |
| `client/src/services/api.ts` | Add `createFromTemplate()`, `compileStoryBible()` functions |
| `client/src/styles/globals.css` | Add story bible output styles |

---

## 6. Edge Cases

| Scenario | Handling |
|----------|----------|
| **Template name contains special characters** | Sanitize: strip `/`, `\`, `:`, `*`, `?`, `"`, `<`, `>`, `|` |
| **Target folder doesn't exist** | Create the folder recursively before creating the file |
| **File with same name exists** | Append `-2`, `-3`, etc. (existing rename convention) |
| **Compile with zero files selected** | Show error: "Select at least one file or folder to compile." |
| **Compile file >50MB** | Warn: "The compiled story bible will be very large. Continue?" |
| **Margin notes excluded but no margin content** | Nothing to exclude — the `<!-- MARGIN_SPLIT -->` delimiter is simply removed |
| **Documents with different encodings** | All WORBI documents are UTF-8 — no encoding issue |
| **Image references in compiled doc** | Images keep their `src` attributes pointing to the server (requires auth). After BLOB_URL_BRIDGE_FIX, use signed proxy URLs |

---

## 7. Verification Checklist

**Templates:**
- [ ] New from Template modal opens from Header, Welcome screen, and File Explorer context menu
- [ ] All 7 template types are selectable
- [ ] Selecting a template creates a new file with the correct structured HTML
- [ ] File is created in the correct folder
- [ ] File opens in a new tab with cursor at the first editable position
- [ ] Template content includes the `<!-- MARGIN_SPLIT -->` delimiter
- [ ] Ctrl+Shift+N keyboard shortcut works

**Story Bible Compiler:**
- [ ] Multi-select works in File Explorer (Ctrl+click, Shift+click)
- [ ] "Compile Story Bible" button appears when files are selected
- [ ] Compilation modal shows correct options
- [ ] "Entire folder" option compiles all `.html` files in the selected folder
- [ ] "Entire workspace" option compiles all `.html` files
- [ ] Table of Contents is generated with correct anchor links
- [ ] Section dividers appear between folders
- [ ] File paths appear as subtitles (when enabled)
- [ ] Margin notes are excluded (when enabled)
- [ ] Compiled output is saved to `/Story Bibles/`
- [ ] ToC links are clickable within the output document
- [ ] Wiki links are converted to plain text
- [ ] Compilation works correctly with very large workspaces (100+ files)

---

## 8. Future Enhancements

- **Custom templates:** Users can save any document as a reusable template
- **Template variables:** `{{characterName}}`, `{{location}}` placeholders that prompt the user on creation
- **Export compiled bible as DOCX/PDF:** Builds on MARKDOWN_AND_EXPORT_FORMATS.md
- **Selective compilation:** Checkboxes per folder/section in the compilation modal
- **AI-Assisted Template Fill:** One-click "Fill with AI" that generates content for all template sections (uses AI_WRITING_ENHANCEMENTS.md)
- **Template marketplace:** Community-shared templates for specific RPG systems (D&D 5e, Pathfinder, etc.)