# Completed Today — 1 May 2026

**12 new handoff docs written + 21 docs organized into priority folders + Cline skill file created.**

## New Docs Created

1. **DOCUMENT_VERSION_HISTORY.md** — SQLite revision tracking, diff viewer, restore
2. **CROSS_DOCUMENT_WIKILINKS.md** — `[[bracket]]` links, autocomplete, backlinks
3. **AI_WRITING_ENHANCEMENTS.md** — Inline AI + doc generation + name generator + **Z-Image/Nymphs2D2 txt2img/img2img integration**
4. **DOCUMENT_TEMPLATES.md** — 7 templates + Story Bible Compiler
5. **FOCUS_MODE.md** — F11 toggle, collapse all panels + minimal chrome
6. **SESSION_PERSISTENCE.md** — localStorage tab/path/activity restore on startup
7. **MARKDOWN_AND_EXPORT_FORMATS.md** — WYSIWYG ↔ Markdown toggle, .md and .pdf export
8. **DOCUMENT_STATISTICS_PANEL.md** — Word/char counts, reading time
9. **TIMELINE_VIEW.md** — Chronological event viewer, era grouping
10. **RELATIONSHIP_GRAPH.md** — Cytoscape.js force graph of tag/wiki-link connections
11. **WORLD_MAP_INTEGRATION.md** — Uploadable map with clickable markers → linked docs

## Other

- **Cline skill file** — `.cline/skills/worbi.md` (project reference for Cline with API surface, component tree, conventions, and safety rules)
- **Cline rules added** — Rule #10: for changes affecting fewer than 5 lines, ask user if they'd prefer to hand-code. Rule #11: backends run in WSL container, frontends run as Windows apps — never assume same OS
- **AI_SIDEBAR_VISIBILITY_FIX.md** — High-priority handoff diagnosing sidebar appearing on fresh login (root cause analysis + 2-file fix)
- **Skills split into toggle-able files** — Original `worbi.md` (636 lines) split into 6 independent files (2 generic in Nymphs-Brain root, 4 WORBI-specific). Original replaced with lightweight index.
  - Generic: `nymphs-dark-ui.md`, `nymphs-safety.md` — reusable across all Nymphs projects
  - WORBI: `worbi-project.md`, `worbi-api.md`, `worbi-architecture.md`, `worbi-conventions.md`
- **csharp-caveats.md** — Generic .NET skill covering 8 sections: build tooling, language pitfalls (NRT, async, LINQ, records, disposal, pattern matching), ASP.NET Core (DI, minimal APIs, config, System.Text.Json), EF Core (change tracker, N+1, migrations), Linux/WSL specifics, performance (Span<T>, boxing, pooling), testing (xUnit, WebApplicationFactory), and .NET 6-10 target framework reference
- **unity-caveats.md** — Unity 6 (6000.x) skill covering 13 sections: version identity, editor settings (domain reload, asmdefs, git), C# scripting (lifecycle, null checks, coroutines, serialization, GetComponent, fixed vs frame update, ScriptableObject), URP + Render Graph migration, physics (interpolation, NonAlloc queries), UI (Canvas performance, layout groups, UI Toolkit), Input System, Addressables + asset pipeline, build pipeline (IL2CPP vs Mono, WebGL, mobile), profiling, editor scripting, netcode (NGO), and a 10-row bug reference table
- **cline-thinking.md** — Cognitive scaffold for local LLMs (Qwen3.6-27b profile): pre-action ritual (restate goal, identify files, check handoff docs, enumerate edge cases, scope constraint), execution discipline (match patterns, verify APIs, replace_in_file precision, component states, path safety), post-action verification (confirm tool result, run verification commands, compare to intent, enumerate what was not done), 8 known LLM failure modes (hallucinating APIs, blind retry, over-confidence, context drift, scope creep, tool misuse, silent failure, path confusion), Qwen-specific calibrations, Socratic self-questioning checklist, edge case enumeration template, verification tier system, and failure recovery protocol

## Organization

21 total docs moved into priority folders (post-audit corrections applied — 5 mis-filed docs re-categorized):
- `priority-high/` (8) — core infra + active bugs + safety-net tooling
- `priority-medium/` (8) — valuable features + refactoring, non-blocking
- `priority-low/` (6) — QoL, maintenance, large-scope features

**Post-audit moves:**
- `TEST_SUITE_SETUP.md` medium → **high** (doc declares High; foundational safety net)
- `APP_TSX_REFACTOR.md` high → **medium** (doc declares Medium; maintainability, not blocking)
- `DOCUMENTATION_IMPROVEMENTS.md` low → **medium** (doc declares Medium; onboarding value)
- `BINARY_DETECTION_UNIFICATION.md` medium → **low** (doc declares Low; latent issue, no known bugs)
- `RATE_LIMITING_AND_CACHING.md` medium → **low** (doc declares Low; defense-in-depth, not currently a problem)
