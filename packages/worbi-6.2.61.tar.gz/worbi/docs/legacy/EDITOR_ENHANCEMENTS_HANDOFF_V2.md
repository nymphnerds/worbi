# Editor Enhancements Handoff (Legacy - v2)

> **ARCHIVED:** This file documents the state of the editor up to v4.16.
> For the current state (v4.19), see `docs/EDITOR_ENHANCEMENTS_HANDOFF.md`.

---

## Current State (v4.16 - File System Undo/Redo)

**NOTE:** For the full version history from v2.7 through v4.15, see `docs/legacy/EDITOR_ENHANCEMENTS_HANDOFF.md`.

The editor now features **file system undo/redo** for destructive operations:
- **Undoable operations:** Create file, create folder, delete, rename, copy, move
- **UI:** Undo (⎌) and Redo (⏩) buttons in the Header toolbar, auto-disable when stack is empty
- **Architecture:** `useFileSystemUndoRedo` hook with separate undo/redo stacks, uses `useRef`-based `refreshRef` to avoid circular dependency with `useFiles`

### Undo/Redo Architecture

```
useFileSystemUndoRedo (no args)
  ├── refreshRef: useRef<(() => Promise<void>) | undefined>
  ├── undoStack: FsOperation[]
  ├── redoStack: FsOperation[]
  ├── push(op)   → add to undo stack, clear redo stack
  ├── undo()     → pop undo stack, execute op.undo(), push to redo stack, refresh
  ├── redo()     → pop redo stack, execute op.redo(), push to undo stack, refresh
  └── clear()    → reset both stacks
```

**Circular dependency solution:** `useFiles` needs `push` from `useFileSystemUndoRedo`, but the undo hook needs `loadFiles` from `useFiles` for refresh after undo/redo. Solved by using a mutable `refreshRef` that is wired in `App.tsx` via `useEffect` after both hooks initialize:

```typescript
// App.tsx
const fileUndoRedo = useFileSystemUndoRedo();
const { push: pushUndoOp, refreshRef, ... } = fileUndoRedo;
const { loadFiles, ... } = useFiles(pushUndoOp);

useEffect(() => {
  refreshRef.current = () => loadFiles(explorerPath);
}, [loadFiles, explorerPath, refreshRef]);
```

### Files Modified (v4.16)

| File | Change |
|------|--------|
| `client/src/hooks/useFileSystemUndoRedo.ts` | **NEW** — Undo/redo hook with undo/redo stacks, refreshRef pattern |
| `client/src/hooks/useFiles.ts` | Accept `pushUndo` callback; wrap destructive operations with undo entries |
| `client/src/components/Header.tsx` | Added `onUndo`/`onRedo`/`canUndo`/`canRedo` props; undo/redo toolbar buttons |
| `client/src/App.tsx` | Initialize undo hook; wire refreshRef; pass undo props to Header |

---

## Editor Layout (v4.0 - v4.15 inherited)

The editor features a **two-column layout** with a draggable split divider:
- **Main column (left, ~66%):** Full rich text editor with all formatting tools
- **Margin column (right, ~34%):** Secondary editor for notes, images, references
- **Draggable divider:** User can adjust the split from 30/70 to 80/20

Each column has its own TipTap editor instance with independent toolbars. Content is saved as a single HTML file with a `<!-- MARGIN_SPLIT -->` delimiter separating the two columns.

**Toolbar buttons (Main toolbar):** Bold, Italic, Underline, H1/H2/H3, Bullet List, Ordered List, Table, Insert Image URL, Create File (+), Save (Ctrl+S), Download HTML, Export PDF, Export DOCX
**Header buttons:** New File (+), Import DOCX, Undo, Redo, Logout

**Image features:** Custom `ImageResize` extension with drag-handle resizing, blob URL persistence, per-tab blob cleanup, external URL support.

---

## Key Hooks Overview

### useFileSystemUndoRedo
```typescript
const { canUndo, canRedo, undo, redo, push, clear, refreshRef } = useFileSystemUndoRedo();
```
- `push(op: FsOperation)` — Push a new operation to the undo stack (clears redo stack)
- `undo()` — Execute last undo, push to redo stack, call refresh
- `redo()` — Execute last redo, push to undo stack, call refresh
- `refreshRef.current` — Set this to a function that refreshes the file list after undo/redo

### useFiles(pushUndo)
```typescript
const { files, loadFiles, newFile, deleteSelected, renameSelected, copySelected, moveSelected, ... } = useFiles(pushUndo);
```
- `pushUndo` — Callback from undo hook to push file operations to the undo stack
- Each destructive operation creates a `FsOperation` with `undo()` and `redo()` functions

---

## Server Routes

| Route | Purpose | Auth |
|-------|---------|------|
| `GET /api/files?path=...` | List directory contents | Yes |
| `GET /api/files/content?path=...` | Read file content | Yes |
| `GET /api/files/workspace/*` | Serve any file from workspace | Yes |
| `GET /api/files/images/*` | Serve image from assets directory | Yes |
| `GET /api/files/search?q=...` | Full-text workspace search | Yes |
| `POST /api/files/create` | Create a new file | Yes |
| `POST /api/files/update` | Update file content | Yes |
| `POST /api/files/delete` | Delete a file or folder | Yes |
| `POST /api/files/rename` | Rename a file or folder | Yes |
| `POST /api/files/upload` | Upload image to assets | Yes |
| `POST /api/files/upload-file` | Upload any file to workspace | Yes |
| `POST /api/files/copy-file` | Copy a file within workspace | Yes |
| `POST /api/files/move-file` | Move a file within workspace | Yes |

---

## Future Enhancements

1. **Full file system undo with server-side state snapshots** — Current undo captures file content in memory; consider server-side snapshots for more robust recovery.
2. **Multi-file undo groups** — Batch multiple operations into a single undo step (e.g., "cut + paste" = one undo).
3. **Redo with conflict detection** — If a file was modified externally between undo and redo, detect and warn.
4. **Keyboard shortcuts for undo/redo** — Ctrl+Z / Ctrl+Y for file operations (distinct from editor undo).
5. **Proper file type system** — Add content type to files (text/html, markdown, etc.) so the editor can switch modes.
6. **Multi-handle resize** — Add corner handles and edge handles for image resizing.
7. **Blob URL map rebuild on reload** — Requires tab persistence first.
8. **PDF export with side-by-side layout** — Current PDF exports margin content after an `<hr>`.
9. **Find & Replace** — Full-text search across document content.
10. **Spell checker** — Built-in or dictionary-based spell checking.