# Handoff: Session Persistence

**Target Version:** v5.3.0
**Priority:** Medium (fixes daily friction, small implementation)
**Dependencies:** None

---

## 1. Problem Statement

When a user closes and reopens WORBI, their session state is lost:
- Open tabs are gone — they must re-navigate the file explorer and reopen documents
- The active folder in the File Explorer resets to root
- The left panel activity (Explorer/Search/Tags/Starred) resets to Explorer

Session persistence restores these on startup, making WORBI feel like a proper application rather than a stateless web page.

---

## 2. Target Behavior

On application startup (after login), WORBI restores:
1. Open tabs (file paths + active tab)
2. File Explorer breadcrumb path
3. Active Activity Bar panel

If any file in the saved tab list no longer exists, it's silently skipped.

---

## 3. Storage Schema

One `localStorage` key: `wbu-session`

```json
{
  "tabs": [
    "/Characters/Goblin King.html",
    "/Quests/Rescue Mission.html",
    "/World/The Underdark.html"
  ],
  "activeTabPath": "/Characters/Goblin King.html",
  "explorerPath": "/Characters/",
  "activeActivity": "explorer",
  "showAISidebar": true,
  "lastSaved": "2026-05-01T14:30:00.000Z"
}
```

**Storage size:** Typically under 1KB. No localStorage quota concerns.

---

## 4. Implementation

### 4.1 Save Hook

On every relevant state change, update `localStorage`:

```typescript
// In App.tsx (or extracted hooks after refactor)

// Save session whenever tabs change
useEffect(() => {
  const session = {
    tabs: tabs.map(t => t.path),
    activeTabPath: activeTab?.path,
    explorerPath,
    activeActivity,
    showAISidebar,
    lastSaved: new Date().toISOString(),
  };
  localStorage.setItem('wbu-session', JSON.stringify(session));
}, [tabs, activeTab, explorerPath, activeActivity, showAISidebar]);
```

### 4.2 Restore Hook

On successful login, restore the session:

```typescript
// In useAuth or App.tsx, after login:

useEffect(() => {
  if (isAuthenticated) {
    const saved = localStorage.getItem('wbu-session');
    if (saved) {
      try {
        const session = JSON.parse(saved);
        
        // Restore explorer path
        if (session.explorerPath) {
          loadFiles(session.explorerPath);
        }
        
        // Restore activity
        if (session.activeActivity) {
          setActiveActivity(session.activeActivity);
        }
        
        // Restore open tabs (openFile handles missing files gracefully)
        if (session.tabs && session.tabs.length > 0) {
          session.tabs.forEach((path: string) => {
            openFile(path, { silent: true }); // silent = don't make it active
          });
          // Activate the previously active tab
          if (session.activeTabPath) {
            activateTab(session.activeTabPath);
          }
        }
      } catch (e) {
        // Corrupted session data — ignore and start fresh
        localStorage.removeItem('wbu-session');
      }
    }
  }
}, [isAuthenticated]);
```

### 4.3 Cleanup on Logout

Clear the session on logout:

```typescript
// In logout handler:
localStorage.removeItem('wbu-session');
```

---

## 5. Files to Modify

| File | Changes |
|------|---------|
| `client/src/App.tsx` | Add session save/restore effects (or in extracted hooks after refactor) |

**If APP_TSX_REFACTOR is done, spread changes across:**
| `client/src/features/editor/useTabManager.ts` | Save/restore tab state |
| `client/src/features/files/useFileOperations.ts` | Restore explorer path |
| `client/src/features/navigation/useActivityRouter.ts` | Restore active activity |
| `client/src/features/layout/useLayout.ts` | Restore AI sidebar state |

---

## 6. Edge Cases

| Scenario | Handling |
|----------|----------|
| **Saved tab file no longer exists** | `openFile()` returns an error → catch it silently, skip that tab |
| **Corrupted session JSON** | `try/catch` around `JSON.parse()` — clear the corrupted key, start fresh |
| **Session from a different user** | Session is stored per-browser, not per-user. If multiple users share a browser, overwrite on login. Acceptable for a local-first tool |
| **Very old session (>30 days)** | Still restore — no harm in restoring old tabs |
| **All saved tabs are deleted** | Restore nothing; show Welcome screen |
| **Session during logout** | Clear session so next login starts fresh |
| **Session with 50+ tabs** | Restore all tabs but only activate the last active one. Remaining tabs load lazily (content fetched when activated) |
| **Race condition with file listing** | Wait for `loadFiles()` to complete before calling `openFile()` for each tab. Use `.then()` or `await` |

---

## 7. Verification Checklist

- [ ] Open 3 files, navigate to a subfolder, switch to Tags activity — close and reopen WORBI
- [ ] All 3 tabs are restored
- [ ] The previously active tab is focused
- [ ] File Explorer shows the same folder
- [ ] Tags activity is selected in the Activity Bar
- [ ] Delete a file that was open in a saved tab — reopen; the deleted tab is silently skipped
- [ ] Logout clears the session; next startup shows Welcome screen with no open tabs
- [ ] Corrupted localStorage data is handled gracefully (test by setting `wbu-session` to invalid JSON)
- [ ] Opening 50+ tabs and restarting doesn't freeze the UI

---

## 8. Future Enhancements

- **Tab scroll position:** Restore scroll position within each document
- **Editor cursor position:** Restore cursor position and selection (store `{from, to}` per tab)
- **Unsaved content recovery:** If the browser crashes with unsaved content, offer to restore from the last auto-save revision
- **Session export/import:** Export session as JSON for sharing or backup