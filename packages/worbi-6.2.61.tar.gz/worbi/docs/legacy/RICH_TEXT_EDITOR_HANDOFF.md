# Rich Text Editor - Image Rendering Handoff

## Current State (v4.4 - Blob URL Cleanup on Tab Close)

The editor now features a **two-column layout** with a draggable split divider:
- **Main column (left, ~66%):** Full rich text editor with all formatting tools
- **Margin column (right, ~34%):** Secondary editor for notes, images, references
- **Draggable divider:** User can adjust the split from 30/70 to 80/20

Each column has its own TipTap editor instance with independent toolbars. Content is saved as a single HTML file with a `<!-- MARGIN_SPLIT -->` delimiter separating the two columns. Legacy files (without the delimiter) load entirely into the main column.

**Image resizing works correctly (v3.0):** Each image is rendered inside a `<span class="image-wrapper">` with a drag handle in the bottom-right corner. Hovering over an image reveals the handle, which can be dragged left/right to resize the image width (height auto-adjusts).

**Image sizing fixed (v3.1):** Images render at natural size with `max-width: 600px` constraint instead of filling the entire viewport.

**Blob URL persistence fixed (v3.1):** On save, blob URLs in HTML content are replaced with real server URLs. On file load, server URLs are fetched with auth and converted back to blob URLs for rendering. Images now survive page reloads and file save/load cycles.

**Save stale closure fixed (v4.2):** Images no longer turn into broken placeholders on save. Converted content is passed directly to `saveCurrentFile()` bypassing React state closure issues.

**Load stale closure fixed (v4.2.10):** Images now render immediately when opening any file. The `openTab` function returns the exact tab ID, eliminating reliance on stale `activeTabId` from closure state.

---

## Version History

### v2.7 - The Original Bug

When clicking an image file in the explorer, `App.tsx` appended raw Markdown text `![name](path)` to the content string. TipTap has no Markdown parser, so the text appeared literally as text instead of a rendered image.

### v2.8 - Use TipTap setImage Command

Replaced the Markdown text append with TipTap's native `setImage()` command.

**Implementation:**
- Added `imageToInsert: { src: string; alt: string } | null` prop to `DocumentEditor.tsx`
- Added `onImageInserted: () => void` callback prop
- Added `useEffect` in `DocumentEditor` to watch `imageToInsert` and call `editor.commands.setImage()`
- `App.tsx` sets `imageToInsert` state with the image URL on confirm
- `DocumentEditor` clears the trigger via `onImageInserted()` after insertion

**Files modified:**
| File | Change |
|------|--------|
| `client/src/components/DocumentEditor.tsx` | Added `imageToInsert` prop + `onImageInserted` callback; useEffect to call `editor.commands.setImage()` |
| `client/src/App.tsx` | Removed Markdown append; added `imageToInsert` state; set proper image URL on confirm |

### v2.9 - Fix Auth on Image Requests

**Problem:** Images appeared as broken icons. The `<img>` tag was given a URL like `http://localhost:5173/api/files/workspace/Screenshot%20(6).png`, but the server returned 401 Unauthorized.

**Root Cause:** HTML `<img>` tags **cannot send custom HTTP headers**. The `/api/files/workspace/*` route requires authentication via `Authorization: Bearer <token>` header (enforced by `authMiddleware` on all `/api/files/*` routes). The browser's `<img>` element makes an unauthenticated request, so the server rejects it.

**Solution:** Fetch the image with auth headers first, convert to a Blob, create a `blob:` URL, then insert that into TipTap. Blob URLs are served by the browser itself, so no auth is needed for rendering.

**Implementation in `App.tsx` `handleFileSelect`:**
```typescript
// Fetch image with auth header, then convert to blob URL
const token = localStorage.getItem('wbu_token');
const response = await fetch(imageUrl, {
  headers: {
    'Authorization': token ? `Bearer ${token}` : '',
  },
});
const blob = await response.blob();
const blobUrl = URL.createObjectURL(blob);
setImageToInsert({ src: blobUrl, alt: file.name });
```

**Files modified:**
| File | Change |
|------|--------|
| `client/src/App.tsx` | Fetch image with auth header, convert to blob URL before inserting |

---

## Architecture

### Image Insertion Flow

```
User clicks image in FileExplorer
  -> handleFileSelect detects image extension
  -> confirm dialog shown
  -> fetch(/api/files/workspace/..., { Authorization: Bearer <token> })
  -> response.blob() -> URL.createObjectURL(blob)
  -> setImageToInsert({ src: blobUrl, alt: fileName })
  -> DocumentEditor useEffect detects imageToInsert
  -> editor.commands.setImage({ src, alt })
  -> onImageInserted() clears trigger
```

### Image URL Resolution

- Server serves workspace files at: `GET /api/files/workspace/*`
- Route defined in `server/src/routes/files.js` (line 198)
- Path resolution uses `fileService.getSafeWorkspaceFilePath()` with path traversal protection
- The Vite dev server proxies `/api` to `http://localhost:8082`
- **Images are NOT served directly from the API URL** - they are fetched with auth and converted to blob URLs

### Authentication

- Token stored in `localStorage` as `wbu_token`
- All `/api/files/*` routes protected by `authMiddleware` (requires `Authorization: Bearer <token>`)
- Server: `server/src/middleware/authMiddleware.js`
- Client: `client/src/hooks/useAuth.ts`

### Server Routes

| Route | Purpose | Auth |
|-------|---------|------|
| `GET /api/files?path=...` | List directory contents | Yes |
| `GET /api/files/content?path=...` | Read file content | Yes |
| `GET /api/files/workspace/*` | Serve any file from workspace | Yes |
| `GET /api/files/images/*` | Serve image from assets directory | Yes |
| `POST /api/files/upload` | Upload image to assets | Yes |
| `POST /api/files/upload-file` | Upload any file to workspace | Yes |

---

## Future Enhancements

1. **File type system:** Add content type to files (text/html, markdown, etc.) so the editor can switch modes
2. **Image management:** Dialog to browse and insert images from workspace
3. **Export to PDF/DOCX:** Use TipTap content for document export
4. **File extension on create:** Prompt user for file type when creating new file, default to `.doc`
5. **Persist resize dimensions:** Currently resize only changes inline `style` on the DOM. Save `data-width` attribute on the `<img>` so it persists across reloads.
6. **Multi-handle resize:** Add corner handles (bottom-right, bottom-left) and edge handles for vertical resize.
7. **Blob URL map rebuild on reload:** The `blobUrlMapRef` lives in component state and is lost on page reload. Consider rebuilding the map from saved content so re-saves work correctly even after reload.
8. **External image support:** Currently only converts server URLs (same origin). Consider supporting external image URLs (e.g., from paste operations).

---

## Implementation Checklists

### v2.8 Implementation Steps

- [x] v2.8.1: Add `imageToInsert` and `onImageInserted` props to DocumentEditor.tsx
- [x] v2.8.2: Add useEffect in DocumentEditor to watch `imageToInsert` and call `editor.commands.setImage()`
- [x] v2.8.3: Update App.tsx handleFileSelect to set `imageToInsert` state with proper URL
- [x] v2.8.4: Pass `imageToInsert` and `onImageInserted` to DocumentEditor in App.tsx
- [x] v2.8.5: Build verification
- [x] v2.8.6: Manual test - click image in explorer, verify it renders in editor

### v2.9 Implementation Steps

- [x] v2.9.1: Identify root cause - `<img>` tags can't send Authorization headers
- [x] v2.9.2: Update App.tsx to fetch image with auth header
- [x] v2.9.3: Convert response to blob URL
- [x] v2.9.4: Add error handling with user-friendly alerts
- [x] v2.9.5: Manual test - images now render correctly in editor

### v3.0 - Image Resizing

**Problem:** `@tiptap/extension-resize-image` does not exist as an npm package. TipTap does not ship a built-in resize plugin.

**Solution:** Custom extension (`ImageResize`) that extends the built-in `Image` extension with:
1. Custom `renderHTML()` that wraps each `<img>` in `<span class="image-wrapper">` with a resize handle (`<span class="resize-drag-handle">`)
2. ProseMirror plugin with `mousedown` handler on the drag handle for mouse-driven resizing

**DOM Structure:**
```html
<span class="image-wrapper resizable" contenteditable="false">
  <img src="blob:..." alt="..." />
  <span class="resize-drag-handle" contenteditable="false" draggable="false"></span>
</span>
```

**Files created/modified:**
| File | Change |
|------|--------|
| `client/src/extensions/resize-image.ts` | **NEW** - Custom `ImageResize` extension extending `Image` |
| `client/src/components/DocumentEditor.tsx` | Replaced `Image` + `ResizeImage` with `ImageResize` |
| `client/src/styles/globals.css` | Added `.image-wrapper`, `.resize-drag-handle` CSS |

### v3.0 Implementation Steps

- [x] v3.0.1: Attempt to install `@tiptap/extension-resize-image` (doesn't exist)
- [x] v3.0.2: Create custom `ImageResize` extension extending `Image`
- [x] v3.0.3: Implement `renderHTML()` with wrapper + drag handle
- [x] v3.0.4: Implement `mousedown` resize handler in ProseMirror plugin
- [x] v3.0.5: Update `DocumentEditor.tsx` to use `ImageResize`
- [x] v3.0.6: Add resize handle CSS to `globals.css`
- [x] v3.0.7: Manual test - insert image, hover to reveal handle, drag to resize
- [x] v3.0.8: Verify resized dimensions persist in saved HTML

---

### v3.1 - Blob URL Persistence & Image Sizing

**Problem 1 - Broken image links on reload:** Blob URLs (`blob:http://localhost:5173/...`) are ephemeral — they exist only for the lifetime of the browser tab that created them. When a file containing blob URLs was saved to disk and then reloaded, the images appeared broken because the blob URLs no longer existed.

**Problem 2 - Images too large:** High-resolution images rendered at their full native pixel dimensions, filling the entire editor viewport. Even `width: auto` was not enough — a `max-width` constraint was needed.

**Solution:** Two-directional URL conversion with a persistent mapping:

1. **Blob URL Map (`blobUrlMapRef`):** A `Map<string, string>` in `App.tsx` that tracks `blobUrl → serverUrl` for every image inserted. Updated in `handleFileSelect` when images are fetched with auth.

2. **Save conversion (`replaceBlobUrlsWithServerUrls`):** Before saving file content, all blob URLs in the HTML are replaced with their corresponding server URLs using the map. The saved file contains persistent server URLs like `http://localhost:5173/api/files/workspace/...` that survive page reloads.

3. **Load conversion (`convertServerUrlsToBlobUrls`):** After loading file content, server URLs in `<img>` tags are fetched with auth headers and converted to blob URLs for rendering. This ensures images display properly without requiring `<img>` tags to send auth headers.

**Files modified:**
| File | Change |
|------|--------|
| `client/src/App.tsx` | Added `blobUrlMapRef`, `replaceBlobUrlsWithServerUrls`, `convertServerUrlsToBlobUrls`, `handleSave`, `openFileWithConversion` |
| `client/src/styles/globals.css` | Changed `max-width` from `100%` to `600px` on `.tiptap img` and `.image-wrapper img` |

**Updated save flow:**
```
User saves file (Ctrl+S or Save button)
  -> handleSave() called
  -> replaceBlobUrlsWithServerUrls(tab.content) replaces blob URLs with server URLs
  -> saveCurrentFile(contentToSave) writes server URL content to disk (passed directly, no stale closure)
```

**Updated load flow:**
```
User clicks file in FileExplorer
  -> openFileWithConversion(path) called
  -> openFile(path) loads raw content, returns { content, id }
  -> convertServerUrlsToBlobUrls(fileContent) fetches images with auth
  -> updateTabContent(tabId, converted) using the returned tab ID (not stale closure state)
  -> Images render correctly
```

**Cleanup:** Blob URLs are revoked on component unmount via a `useEffect` cleanup function.

### v3.1 Implementation Steps

- [x] v3.1.1: Add `blobUrlMapRef` to track blob → server URL mappings
- [x] v3.1.2: Update `handleFileSelect` to populate the map on image insert
- [x] v3.1.3: Implement `replaceBlobUrlsWithServerUrls` for save conversion
- [x] v3.1.4: Implement `convertServerUrlsToBlobUrls` for load conversion
- [x] v3.1.5: Wrap save flow with `handleSave` that converts before saving
- [x] v3.1.6: Wrap open file flow with `openFileWithConversion` that converts after loading
- [x] v3.1.7: Fix image sizing - `max-width: 600px` on both `.tiptap img` rules
- [x] v3.1.8: Add blob URL cleanup on component unmount
- [x] v3.1.9: Manual test - insert image, save, reload, verify image displays
- [x] v3.1.10: Manual test - verify images render at reasonable size (not full-width)

---

### v4.0 - Two-Column Layout with Adjustable Margin

**Feature:** Split the editor into two independent editing columns with a draggable divider.

**Motivation:** Users want a main writing area on the left and a margin/notes area on the right for images, references, and quick notes — similar to a notebook margin or a two-pane document editor.

**Architecture:**
- Two independent `useEditor()` instances (`mainEditor` + `marginEditor`)
- Each editor has its own toolbar (rendered via shared `renderToolbar()` helper)
- Main toolbar at top shows full formatting controls + save button
- Per-column toolbars show compact formatting (bold/italic/underline/lists/table)
- Draggable divider between columns (width 6px, highlights on hover)
- Split range: 30%–80% for main column (prevents columns from collapsing)

**Content parsing:**
- Save format: `mainHTML <!-- MARGIN_SPLIT --> marginHTML`
- `parseContent()` splits on delimiter; legacy content goes to main only
- `combineContent()` joins with delimiter when margin has content

**Files modified:**
| File | Change |
|------|--------|
| `client/src/components/DocumentEditor.tsx` | Two `useEditor()` instances, draggable split, per-column toolbars, `parseContent`/`combineContent` helpers |
| `client/src/styles/globals.css` | Added `.editor-split-divider`, `.editor-margin-panel`, `.editor-main`, `.editor-margin-content` styles |

### v4.0 Implementation Steps

- [x] v4.0.1: Update DocumentEditor — two editors, draggable split, content parse/combine
- [x] v4.0.2: Fix TypeScript errors in DocumentEditor
- [x] v4.0.3: Add two-column CSS styles (divider, margin panel)
- [x] v4.0.4: Verify build compiles without errors
- [x] v4.0.5: Manual test — open file, verify two columns appear
- [x] v4.0.6: Manual test — drag split divider, verify columns resize
- [x] v4.0.7: Manual test — type in both columns, save, reload, verify content persists

---

### v4.1 - Image Insertion to Margin Editor

**Change:** Images clicked from the file explorer now insert into the **margin** (right) editor instead of the **main** (left) editor.

**Implementation:** Changed the image insertion `useEffect` in `DocumentEditor.tsx` to target `marginEditor` instead of `mainEditor`.

**Files modified:**
| File | Change |
|------|--------|
| `client/src/components/DocumentEditor.tsx` | Changed `mainEditor.commands.setImage()` to `marginEditor.commands.setImage()`; updated dependency array |

### v4.1 Implementation Steps

- [x] v4.1.1: Change image insertion useEffect to target `marginEditor`
- [x] v4.1.2: Update dependency array from `mainEditor` to `marginEditor`
- [x] v4.1.3: Manual test — click image in explorer, verify it appears in margin column

---

### v4.2 - Fix: Images Turn to Placeholders on Save

**Problem:** When saving a document with images, all images disappear and are replaced with broken placeholders. The saved file contains raw `blob:` URLs instead of persistent server URLs.

**Root Cause:** React stale closure in `handleSave`. The function calls `updateTabContent()` to update the tab with blob-to-server-URL-converted content, then immediately calls `saveCurrentFile()`. However, `saveCurrentFile()` (in `useFiles.ts`) captures the `tabs` state via `useCallback([activeTabId, tabs])` closure. Because `setTabs` from `updateTabContent()` hasn't flushed yet (React batches state updates), `saveCurrentFile()` reads the OLD tab content that still contains blob URLs. The server saves blob URLs to disk, which are meaningless when the file is reloaded.

**Solution (v4.2.1 - v4.2.2):** Pass the converted content directly to `saveCurrentFile()` instead of relying on the tab state:

1. **`useFiles.ts`** — Add optional `content` parameter to `saveActiveTab**:
```typescript
const saveActiveTab = useCallback(async (content?: string) => {
  // ...
  await updateFile(tab.path, content ?? tab.content);
  // ...
}, [activeTabId, tabs]);
```

2. **`App.tsx`** — Pass converted content directly:
```typescript
const handleSave = useCallback(async () => {
  const tab = activeTabId ? tabs[activeTabId] : null;
  if (!tab) return;
  const contentToSave = replaceBlobUrlsWithServerUrls(tab.content);
  await saveCurrentFile(contentToSave);  // bypass stale closure
}, [activeTabId, tabs, replaceBlobUrlsWithServerUrls, saveCurrentFile]);
```

### v4.2.5 - Fix: Sequential URL Conversion

**Problem:** `convertServerUrlsToBlobUrls` processed images in parallel using `Promise.all()`, but all callbacks mutated the same `result` string, causing race conditions where later replacements could overwrite earlier ones.

**Solution:** Process images sequentially in a `for...of` loop so each replacement operates on the updated `result` string.

### v4.2.6 - Fix: Return Content from openTab

**Problem:** `openFileWithConversion` used `await setTimeout(50)` to wait for tab state to update, then read `tabs[activeTabId].content` from state. This was fragile — the setTimeout delay was arbitrary and could fail under load or slow rendering.

**Solution:** Make `openTab` return the file content directly so the caller has it synchronously without relying on React state flush timing.

### v4.2.10 - Fix: Stale activeTabId in openFileWithConversion (THE FINAL FIX)

**Problem:** Even after v4.2.6 made `openTab` return content, `openFileWithConversion` still used `activeTabId` from the `useCallback` closure to call `updateTabContent(activeTabId, converted)`. This `activeTabId` was always the **previous** tab's ID, not the one just opened. Symptoms:
- Images did NOT render on first open of a file (had to switch away and back)
- Phantom yellow (dirty) dot appeared on OTHER tabs (because converted content was written to the wrong tab)
- Opening/closing/reopening files showed inconsistent behavior

**Root Cause:** `useCallback` captures `activeTabId` at the time the closure is created. Since `openTab` calls `setActiveTabId(id)` (async state update), the closure still holds the OLD value. Even `await setTimeout(0)` does not help — the closure variable was already captured before `openFile()` was called.

**Solution:** Have `openTab` return the tab ID along with the content, so `openFileWithConversion` uses the correct tab ID directly:

```typescript
// useFiles.ts - openTab now returns { content, id }
const openTab = useCallback(async (path: string): Promise<{ content: string; id: string } | null> => {
  const existingId = Object.values(tabs).find(t => t.path === path)?.id;
  if (existingId) {
    setActiveTabId(existingId);
    return { content: tabs[existingId]?.content || '', id: existingId };
  }
  // ... create new tab ...
  setActiveTabId(id);
  return { content: fileContent, id };
}, [tabs]);

// App.tsx - use returned tabId, not stale activeTabId
const openFileWithConversion = useCallback(async (path: string) => {
  const result = await openFile(path);
  if (!result) return;
  const { content: fileContent, id: tabId } = result;
  const converted = await convertServerUrlsToBlobUrls(fileContent);
  if (converted !== fileContent) {
    await new Promise(resolve => setTimeout(resolve, 0));
    updateTabContent(tabId, converted);  // use tabId from result, not activeTabId
  }
}, [openFile, convertServerUrlsToBlobUrls, updateTabContent]);
```

**Files modified:**
| File | Change |
|------|--------|
| `client/src/hooks/useFiles.ts` | `openTab` returns `{ content, id }` instead of just `string`; `saveActiveTab` has optional `content` param |
| `client/src/App.tsx` | `openFileWithConversion` uses returned `tabId`; `handleSave` passes converted content directly |

### v4.2 Implementation Steps (Complete)

- [x] v4.2.1: Add optional `content` parameter to `saveActiveTab` in `useFiles.ts`
- [x] v4.2.2: Update `handleSave` in `App.tsx` to pass converted content directly
- [x] v4.2.5: Fix `convertServerUrlsToBlobUrls` - sequential processing, no race conditions
- [x] v4.2.6a: Make `openTab` return file content
- [x] v4.2.6b: Update `openFileWithConversion` to use returned content (no setTimeout for content read)
- [x] v4.2.7: Fix TypeScript error - activeTabId null check for updateTabContent
- [x] v4.2.8: Verify TypeScript compiles cleanly
- [x] v4.2.9: Manual test — identified stale activeTabId bug in closure
- [x] v4.2.10: Fix — have openTab return tab ID so openFileWithConversion uses correct tab
- [x] v4.2.11: Verify build compiles cleanly
- [x] v4.2.12: Manual test — images render immediately on file open, no phantom dirty dots

---

### v4.3 - Fix: File Uploads Always Land in Root

**Problem:** Files uploaded via the explorer upload button always landed in the workspace root directory, regardless of which folder was selected in the explorer or which folder the user chose in the prompt dialog.

**Root Cause:** In `server/src/routes/files.js`, the `/upload-file` route read `req.body.folder || ''` on line 125 BEFORE calling `genericUpload.single('file')` as middleware. Since multer hadn't parsed the FormData yet, `req.body.folder` was always `undefined`, defaulting to `''` (root). The `/upload` route (images) was already correctly reading `folder` inside the callback, but `/upload-file` was missed during that earlier fix.

**Solution:** Moved `const folder = req.body.folder || ''` inside the multer callback where `req.body` is properly populated after parsing:

```javascript
// Before (broken):
router.post('/upload-file', (req, res) => {
  const folder = req.body.folder || '';  // Always undefined
  const handleUpload = genericUpload.single('file');
  handleUpload(req, res, (err) => {
    fileService.saveUploadedFile(username, ..., folder);  // Always root
  });
});

// After (fixed):
router.post('/upload-file', (req, res) => {
  const handleUpload = genericUpload.single('file');
  handleUpload(req, res, (err) => {
    const folder = req.body.folder || '';  // Now correctly populated
    fileService.saveUploadedFile(username, ..., folder);
  });
});
```

**Files modified:**
| File | Change |
|------|--------|
| `server/src/routes/files.js` | Moved `folder` read inside multer callback in `/upload-file` route (lines 122-145) |

### v4.3 Implementation Steps

- [x] v4.3.1: Identify root cause — `req.body.folder` read before multer parses FormData
- [x] v4.3.2: Move folder read inside multer callback
- [x] v4.3.3: Manual test — upload file while inside a folder, verify file lands in that folder
- [x] v4.3.4: Manual test — upload file at root with folder selection prompt, verify file lands in selected folder

---

### v4.4 - Fix: Blob URL Memory Leak — Cleanup on Tab Close

**Problem:** Blob URLs created for images (both from file loading via `convertServerUrlsToBlobUrls` and from image insertion via `handleFileSelect`) stayed in browser memory forever. They were only cleaned up when the entire App component unmounted (i.e., when the user logs out or closes the page). This means opening and closing many image-heavy files would leak blob URLs and their associated memory mappings in `blobUrlMapRef`.

**Root Cause:** The `blobUrlMapRef` tracks all blob URLs globally, but there was no way to know which blob URLs belonged to which tab. When a tab was closed, the blob URLs for that tab's images were never revoked.

**Solution:** Track blob URLs per tab using `tabBlobUrlsRef` (a `Map<string, string[]>` mapping tabId → blobUrl[]), and revoke them when the tab is closed.

**Implementation:**

1. **`tabBlobUrlsRef`** — New ref in `App.tsx` tracking which blob URLs belong to which tab:
```typescript
const tabBlobUrlsRef = useRef(new Map<string, string[]>());
```

2. **`cleanupTabBlobUrls(tabId)`** — Revokes all blob URLs for a given tab and removes them from both `blobUrlMapRef` and `tabBlobUrlsRef`:
```typescript
const cleanupTabBlobUrls = useCallback((tabId: string) => {
  const urls = tabBlobUrlsRef.current.get(tabId);
  if (urls) {
    urls.forEach(blobUrl => {
      blobUrlMapRef.current.delete(blobUrl);
      URL.revokeObjectURL(blobUrl);
    });
  }
  tabBlobUrlsRef.current.delete(tabId);
}, []);
```

3. **`convertServerUrlsToBlobUrls` tracks per-tab** — Accepts optional `tabId` parameter and stores created blob URLs under that tab's ID.

4. **`handleFileSelect` tracks per-tab** — Image blob URLs created for insertion are tracked under the active tab's ID.

5. **Tab close handlers wire up cleanup:**
   - `handleTabClose(id)` → `cleanupTabBlobUrls(id)` then `closeTab(id)`
   - `handleTabCloseOthers(id)` → clean up all tabs except the kept one
   - `handleTabCloseAll()` → clean up all blob URLs

**Files modified:**
| File | Change |
|------|--------|
| `client/src/App.tsx` | Added `tabBlobUrlsRef`, `cleanupTabBlobUrls`, per-tab tracking in `convertServerUrlsToBlobUrls` and `handleFileSelect`, wired cleanup into `handleTabClose`/`handleTabCloseOthers`/`handleTabCloseAll` |

### v4.4 Implementation Steps

- [x] v4.4.1: Add `tabBlobUrlsRef` to track blob URLs per tab
- [x] v4.4.2: Implement `cleanupTabBlobUrls(tabId)` function
- [x] v4.4.3: Update `convertServerUrlsToBlobUrls` to accept optional `tabId` parameter
- [x] v4.4.4: Update `handleFileSelect` to track blob URLs under active tab ID
- [x] v4.4.5: Wire `handleTabClose` to call cleanup before closing
- [x] v4.4.6: Wire `handleTabCloseOthers` to clean up all closed tabs
- [x] v4.4.7: Wire `handleTabCloseAll` to clean up all blob URLs
</task_progress>
