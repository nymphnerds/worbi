# Editor Enhancements Handoff

## Current State (v4.15 - External Image URL Support)

The editor now features a **two-column layout** with a draggable split divider:
- **Main column (left, ~66%):** Full rich text editor with all formatting tools
- **Margin column (right, ~34%):** Secondary editor for notes, images, references
- **Draggable divider:** User can adjust the split from 30/70 to 80/20

Each column has its own TipTap editor instance with independent toolbars. Content is saved as a single HTML file with a `<!-- MARGIN_SPLIT -->` delimiter separating the two columns. Legacy files (without the delimiter) load entirely into the main column.

**Toolbar buttons (Main toolbar):** Bold, Italic, Underline, H1/H2/H3, Bullet List, Ordered List, Table, Create File (+), Save (Ctrl+S), Download HTML, Export PDF, Export DOCX
**Header buttons:** New File (+), Import DOCX, Logout
**Explorer now populates on mount:** A `useEffect` in `App.tsx` calls `loadFiles('')` on component mount, so the file explorer immediately displays workspace folders (MainStory, Quests, Characters, World) after login.

---

## Previous: v4.12 - DOCX Export + Import

The editor now features a **two-column layout** with a draggable split divider:
- **Main column (left, ~66%):** Full rich text editor with all formatting tools
- **Margin column (right, ~34%):** Secondary editor for notes, images, references
- **Draggable divider:** User can adjust the split from 30/70 to 80/20

Each column has its own TipTap editor instance with independent toolbars. Content is saved as a single HTML file with a `<!-- MARGIN_SPLIT -->` delimiter separating the two columns. Legacy files (without the delimiter) load entirely into the main column.

**Toolbar buttons (Main toolbar):**
- Format: Bold, Italic, Underline, H1/H2/H3, Bullet List, Ordered List, Table
- File ops: Create File (+), Save (Ctrl+S), Download HTML, Export PDF, Export DOCX

**Header buttons:**
- New File (+), Import DOCX, Logout

**Image resizing works correctly (v3.0):** Each image is rendered inside a `<span class="image-wrapper">` with a drag handle in the bottom-right corner. Hovering over an image reveals the handle, which can be dragged left/right to resize the image width (height auto-adjusts).

**Image resize persistence fixed (v4.10/v4.11):** Resized image dimensions now survive tab switches and page reloads. Width is stored as a TipTap node attribute (updated via `doc.descendants()` + `setNodeMarkup()`), saved as `data-width` in HTML, and reloaded via `parseHTML`. Null-safe `renderHTML()` prevents crashes.

**Image sizing fixed (v3.1):** Images render at natural size with `max-width: 600px` constraint.

**Blob URL persistence fixed (v3.1):** On save, blob URLs in HTML content are replaced with real server URLs. On file load, server URLs are fetched with auth and converted back to blob URLs for rendering.

**Blob URL cleanup on tab close (v4.4):** Blob URLs are tracked per-tab and revoked when tabs are closed, preventing memory leaks.

**File Copy & Move (v4.5):** Full copy and move operations for files in the workspace.

**Auto .html extension (v4.6):** New files automatically get `.html` extension if no extension is provided.

**Download HTML (v4.7):** Fetches the current file from the server and triggers a browser download with the proper filename.

**Export PDF (v4.7):** Uses `html2pdf.js` to render the current editor content as a PDF. The `<!-- MARGIN_SPLIT -->` delimiter is replaced with a horizontal rule in the PDF output. A4 portrait format.

**Export DOCX (v4.12):** Uses `docx` library to convert HTML content to a `.docx` file. The 2-column layout is preserved as a table (70% main, 30% margin). HTML headings, bold, italic, and paragraphs are converted to proper DOCX elements.

**Import DOCX (v4.12):** "Import" button in Header opens file picker for `.docx` files. Uses `mammoth.js` to convert DOCX → HTML, then opens the result in the editor.

**DOCX upload detection (v4.12):** Dragging/dropping `.docx` files into the FileExplorer now auto-imports them as HTML (via mammoth) instead of uploading as binary.

---

## Version History

### v2.7 - The Original Bug

When clicking an image file in the explorer, `App.tsx` appended raw Markdown text `![name](path)` to the content string. TipTap has no Markdown parser, so the text appeared literally as text instead of a rendered image.

### v2.8 - Use TipTap setImage Command

Replaced the Markdown text append with TipTap's native `setImage()` command.

**Implementation:**
- Added `imageToInsert: { src: string; alt: string } | null` prop to `DocumentEditor.tsx`
- Added `onImageInserted: () => void` callback prop
- Added `useEffect` in `DocumentEditor` to watch `imageToInsert` and call `editor.commands.setImage()`
- `App.tsx` sets `imageToInsert` state with the image URL on confirm
- `DocumentEditor` clears the trigger via `onImageInserted()` after insertion

**Files modified:**
| File | Change |
|------|--------|
| `client/src/components/DocumentEditor.tsx` | Added `imageToInsert` prop + `onImageInserted` callback; useEffect to call `editor.commands.setImage()` |
| `client/src/App.tsx` | Removed Markdown append; added `imageToInsert` state; set proper image URL on confirm |

### v2.9 - Fix Auth on Image Requests

**Problem:** Images appeared as broken icons. The `<img>` tag was given a URL like `http://localhost:5173/api/files/workspace/Screenshot%20(6).png`, but the server returned 401 Unauthorized.

**Root Cause:** HTML `<img>` tags **cannot send custom HTTP headers**. The `/api/files/workspace/*` route requires authentication via `Authorization: Bearer <token>` header (enforced by `authMiddleware` on all `/api/files/*` routes). The browser's `<img>` element makes an unauthenticated request, so the server rejects it.

**Solution:** Fetch the image with auth headers first, convert to a Blob, create a `blob:` URL, then insert that into TipTap. Blob URLs are served by the browser itself, so no auth is needed for rendering.

**Implementation in `App.tsx` `handleFileSelect`:**
```typescript
const token = localStorage.getItem('wbu_token');
const response = await fetch(imageUrl, {
  headers: { 'Authorization': token ? `Bearer ${token}` : '' },
});
const blob = await response.blob();
const blobUrl = URL.createObjectURL(blob);
setImageToInsert({ src: blobUrl, alt: file.name });
```

### v3.0 - Custom Image Resize Extension

**Problem:** `@tiptap/extension-resize-image` does not exist as an npm package. TipTap does not ship a built-in resize plugin.

**Solution:** Custom extension (`ImageResize`) that extends the built-in `Image` extension with:
1. Custom `renderHTML()` that wraps each `<img>` in `<span class="image-wrapper">` with a resize handle
2. ProseMirror plugin with `mousedown` handler on the drag handle for mouse-driven resizing

**DOM Structure:**
```html
<span class="image-wrapper resizable" contenteditable="false">
  <img src="blob:..." alt="..." />
  <span class="resize-drag-handle" contenteditable="false" draggable="false"></span>
</span>
```

**Files created/modified:**
| File | Change |
|------|--------|
| `client/src/extensions/resize-image.ts` | **NEW** - Custom `ImageResize` extension extending `Image` |
| `client/src/components/DocumentEditor.tsx` | Replaced `Image` + `ResizeImage` with `ImageResize` |
| `client/src/styles/globals.css` | Added `.image-wrapper`, `.resize-drag-handle` CSS |

### v3.1 - Blob URL Persistence & Image Sizing

**Problem 1:** Blob URLs are ephemeral — they exist only for the lifetime of the browser tab. When a file containing blob URLs was saved to disk and then reloaded, the images appeared broken.

**Problem 2:** High-resolution images rendered at their full native pixel dimensions, filling the entire editor viewport.

**Solution:** Two-directional URL conversion with a persistent mapping:

1. **Blob URL Map (`blobUrlMapRef`):** A `Map<string, string>` in `App.tsx` tracking `blobUrl → serverUrl` for every image.
2. **Save conversion (`replaceBlobUrlsWithServerUrls`):** Before saving, all blob URLs are replaced with their server URL equivalents.
3. **Load conversion (`convertServerUrlsToBlobUrls`):** After loading, server URLs in `<img>` tags are fetched with auth and converted to blob URLs.

**Updated save flow:**
```
User saves file (Ctrl+S or Save button)
  -> handleSave() called
  -> replaceBlobUrlsWithServerUrls(tab.content) replaces blob URLs with server URLs
  -> saveCurrentFile(contentToSave) writes server URL content to disk
```

**Updated load flow:**
```
User clicks file in FileExplorer
  -> openFileWithConversion(path) called
  -> openFile(path) loads raw content, returns { content, id }
  -> convertServerUrlsToBlobUrls(fileContent) fetches images with auth
  -> updateTabContent(tabId, converted) using the returned tab ID
  -> Images render correctly
```

### v4.0 - Two-Column Layout with Adjustable Margin

**Feature:** Split the editor into two independent editing columns with a draggable divider.

**Architecture:**
- Two independent `useEditor()` instances (`mainEditor` + `marginEditor`)
- Each editor has its own toolbar (rendered via shared `renderToolbar()` helper)
- Draggable divider between columns (width 6px, highlights on hover)
- Split range: 30%–80% for main column

**Content parsing:**
- Save format: `mainHTML <!-- MARGIN_SPLIT --> marginHTML`
- `parseContent()` splits on delimiter; legacy content goes to main only
- `combineContent()` joins with delimiter when margin has content

**Files modified:**
| File | Change |
|------|--------|
| `client/src/components/DocumentEditor.tsx` | Two `useEditor()` instances, draggable split, per-column toolbars |
| `client/src/styles/globals.css` | Added `.editor-split-divider`, `.editor-margin-panel`, `.editor-main`, `.editor-margin-content` |

### v4.1 - Image Insertion to Margin Editor

Images clicked from the file explorer now insert into the **margin** (right) editor instead of the **main** (left) editor.

### v4.2 - Fix: Images Turn to Placeholders on Save

**Root Cause:** React stale closure in `handleSave` — `saveCurrentFile()` captured old tab content still containing blob URLs.

**Solution:** Pass converted content directly to `saveCurrentFile(content)` bypassing stale closure.

**v4.2.10 - Final Fix:** `openTab` now returns `{ content, id }` so `openFileWithConversion` uses the correct tab ID instead of the stale `activeTabId` from closure.

**Files modified:**
| File | Change |
|------|--------|
| `client/src/hooks/useFiles.ts` | `openTab` returns `{ content, id }`; `saveActiveTab` has optional `content` param |
| `client/src/App.tsx` | `openFileWithConversion` uses returned `tabId`; `handleSave` passes converted content |

### v4.3 - Fix: File Uploads Always Land in Root

**Root Cause:** `req.body.folder` read before multer parsed FormData, so it was always `undefined`.

**Solution:** Moved folder read inside the multer callback where `req.body` is populated.

### v4.4 - Blob URL Memory Leak Fix

Track blob URLs per-tab using `tabBlobUrlsRef` (a `Map<string, string[]>`) and revoke them on tab close/close others/close all.

### v4.5 - Copy & Move File Operations

Full file copy and move support:
- **Server:** `copyFile()` / `moveFile()` in `fileService.js`, `POST /copy-file` / `POST /move-file` routes in `files.js`
- **Client:** `copyFile()` / `moveFile()` in `api.ts`, `copySelected()` / `moveSelected()` in `useFiles` hook
- **UI:** Copy and Move buttons in FileExplorer context menu

### v4.6 - Auto-append .html Extension

When creating a new file, if the entered name has no file extension, `.html` is automatically appended. Files with an explicit extension (e.g., `notes.txt`) are preserved as-is.

### v4.7 - Download HTML & Export PDF

- **Download as HTML:** Fetches the current file from the server via auth API, creates a blob URL, triggers browser download with proper `.html` filename.
- **Export as PDF:** Uses `html2pdf.js` (html2canvas + jsPDF) to render the editor content as a PDF. The `<!-- MARGIN_SPLIT -->` delimiter is replaced with `<hr>` in the output. A4 portrait format. Buttons added to the Main toolbar.

### v4.8 - Attempt Persist Resize Dimensions (Flawed)

**Problem:** Image resize only changed inline `style` on the DOM, so the width was lost on re-render (tab switch, content update, reload).

**Approach:** Added `setAttribute('data-width', ...)` on the DOM element and attempted to dispatch a transaction. However, this approach did not properly integrate with TipTap's state model.

**Result:** Width was still lost on re-render. See v4.9/v4.10 for the correct approach.

### v4.9 - Rewrite with Width as TipTap Attribute (Broken)

**Approach:** Added `width` as a stored TipTap attribute via `addAttributes()`, custom `setImage` command with `width` option, and used `posAtDOM` + `setNodeAttribute()` in the resize handler.

**Why it failed (two bugs):**
1. `$from.node(1)` returned the paragraph node (depth 1), not the inline image (depth 2), so `type.name === 'image'` always failed
2. `$from.before(1)` targeted the wrong position for `setNodeAttribute`

**Result:** Resize worked visually but width still did not persist in state.

### v4.10 - Robust Tree Walk Approach (Working)

**Solution:** Replaced fragile DOM-to-state position mapping with a robust tree walk:
- `view.state.doc.descendants()` walks the entire ProseMirror tree
- Matches the image node by comparing `node.attrs.src` with the DOM image's `src` attribute
- `setNodeMarkup()` updates the width attribute reliably regardless of nesting depth

**Full data flow:**
1. Resize image → `stopResize` walks tree, finds matching image node by `src`, updates `width` via `setNodeMarkup`
2. Width stored in TipTap's internal ProseMirror state → survives tab switches
3. Save file → `renderHTML()` outputs `data-width="350"` in HTML → persists on disk
4. Load file → `parseHTML` reads `data-width` into node's `width` attribute → `renderHTML()` applies `style: width:350px`

**Files modified:**
| File | Change |
|------|--------|
| `client/src/extensions/resize-image.ts` | Rewrote `stopResize` with `doc.descendants()` + `setNodeMarkup()` |

### v4.11 - Fix: Runtime Crash on File Open

**Problem:** `renderHTML()` crashed with `Cannot read properties of undefined (reading 'width')` because `attributes` could be `undefined` during content load (when TipTap renders content from HTML before attributes are fully parsed).

**Solution:** Added null-safe access operators:
```typescript
const width = attributes?.width || HTMLAttributes?.['data-width'] || HTMLAttributes?.width;
```

**Files modified:**
| File | Change |
|------|--------|
| `client/src/extensions/resize-image.ts` | Null-safe `attributes?.width` in `renderHTML()` |

### v4.13 - Explorer Initial Load Fix

**Problem:** The FileExplorer showed "Empty folder" on initial page load, even though the workspace contained default folders (MainStory, Quests, Characters, World).

**Root Cause:** `loadFiles()` was never called when the `App` component mounted. It was only triggered by user navigation actions (back button, folder click, new folder, etc.), so the `files` state in the `useFiles` hook remained at its initial value: `useState<FileItem[]>([])` → empty array.

**Solution:** Added a `useEffect` in `App.tsx` that calls `loadFiles('')` on mount:
```typescript
useEffect(() => {
  loadFiles('');
}, []);
```

**Files modified:**
| File | Change |
|------|--------|
| `client/src/App.tsx` | Added mount-time `useEffect` to call `loadFiles('')` |

---

### v4.12 - DOCX Export + Import (Round-Trip Word Support)

**Feature:** Full DOCX round-trip — export editor content to `.docx` format, and import `.docx` files back into the editor as HTML.

**Export DOCX:**
- Dynamic import of `docx` library in `handleExportDOCX()` callback
- Parses 2-column content: splits on `<!-- MARGIN_SPLIT -->` delimiter
- Converts HTML to DOCX paragraphs using `DOMParser` for structure extraction
- Headings (H1/H2/H3), bold, italic, and paragraphs converted to proper DOCX elements
- 2-column layout preserved as a DOCX table (70% main cell, 30% margin cell)
- Table borders: vertical divider visible (`BorderStyle.SINGLE`, color `#CCCCCC`), all other borders hidden
- Downloads as `{fileName}.docx` using `Packer.toBlob()`

**Import DOCX via Header:**
- New "Import" button in Header (`FileInput` icon) triggers hidden `<input type="file" accept=".docx">`
- Uses `mammoth/mammoth.browser` to convert DOCX → HTML
- User prompted for target folder (defaults to current explorer path)
- Converted HTML saved as `.html` file in workspace, then opened in editor
- Conversion warnings logged to console

**DOCX upload detection:**
- In `handleUploadFiles()`, `.docx` files are detected via `isDocxFile()` helper
- Instead of uploading as binary, mammoth converts to HTML → saves as `.html` → opens in editor
- Non-DOCX files continue through the normal upload flow

**Files modified:**
| File | Change |
|------|--------|
| `client/src/App.tsx` | Added `isDocxFile()`, `handleExportDOCX()`, `handleImportDOCX()`, `handleDocxFileSelected()`, DOCX detection in upload flow, `importDocxInputRef` |
| `client/src/components/DocumentEditor.tsx` | Added `onExportDOCX` prop, DOCX export button with `FileSpreadsheet` icon |
| `client/src/components/Header.tsx` | Added `onImportDOCX` prop, "Import" button with `FileInput` icon |

---

## Architecture

### Image Insertion Flow

```
User clicks image in FileExplorer
  -> handleFileSelect detects image extension
  -> confirm dialog shown
  -> fetch(/api/files/workspace/..., { Authorization: Bearer <token> })
  -> response.blob() -> URL.createObjectURL(blob)
  -> setImageToInsert({ src: blobUrl, alt: fileName })
  -> DocumentEditor useEffect detects imageToInsert
  -> marginEditor.commands.setImage({ src, alt })  [v4.1: inserts into margin]
  -> onImageInserted() clears trigger
```

### Image Resize Flow (v4.10 - Working)

```
User drags resize handle
  -> mousedown: start resize (track startX, startWidth)
  -> mousemove: visually resize (DOM only, imageDOM.style.width)
  -> mouseup (stopResize):
      -> finalWidth = Math.round(newWidth)
      -> Walk ProseMirror tree: doc.descendants((node, pos) => {
           if (node.type.name === 'image' && node.attrs?.src === src) {
             foundPos = pos; foundNode = node;
           }
         })
      -> setNodeMarkup(foundPos, undefined, { ...attrs, width: String(finalWidth) })
      -> Width now in TipTap state → survives re-render, tab switch
```

### Server Routes

| Route | Purpose | Auth |
|-------|---------|------|
| `GET /api/files?path=...` | List directory contents | Yes |
| `GET /api/files/content?path=...` | Read file content | Yes |
| `GET /api/files/workspace/*` | Serve any file from workspace | Yes |
| `GET /api/files/images/*` | Serve image from assets directory | Yes |
| `POST /api/files/upload` | Upload image to assets | Yes |
| `POST /api/files/upload-file` | Upload any file to workspace | Yes |
| `POST /api/files/copy-file` | Copy a file within workspace | Yes (v4.5) |
| `POST /api/files/move-file` | Move a file within workspace | Yes (v4.5) |

### Authentication

- Token stored in `localStorage` as `wbu_token`
- All `/api/files/*` routes protected by `authMiddleware`
- Server: `server/src/middleware/authMiddleware.js`
- Client: `client/src/hooks/useAuth.ts`

---

## Future Enhancements

1. **Proper file type system** — Add content type to files (text/html, markdown, etc.) so the editor can switch modes
2. **Multi-handle resize** — Add corner handles (bottom-right, bottom-left) and edge handles for vertical resize.
3. **Blob URL map rebuild on reload** — Investigated in v4.14: `blobUrlMapRef` is lost on reload, but tabs are also not persisted (React state only, no localStorage). Rebuilding the map requires first implementing tab persistence. The existing `openFileWithConversion()` flow correctly rebuilds the map when the user reopens files after a refresh. A comment in `App.tsx` documents this decision.
4. **PDF export with margin column** — Currently the margin column content is appended after a `<hr>`. Consider side-by-side PDF layout.
5. **Undo/Redo across columns** — Each TipTap editor has independent undo/redo. Consider cross-column undo history.
6. **Find & Replace** — Full-text search across document content.
7. **Spell checker** — Built-in or dictionary-based spell checking.
8. **Persist resize height** — Currently only width is stored. Consider storing both dimensions.
9. **DOCX export with better styling** — Custom fonts, margins, page breaks, and cover pages.
10. **DOCX import with image extraction** — mammoth currently embeds images as base64 in HTML; consider extracting to server storage.

---

## Implementation Checklists

### v4.4 Implementation Steps

- [x] v4.4.1: Add `tabBlobUrlsRef` to track blob URLs per tab
- [x] v4.4.2: Implement `cleanupTabBlobUrls(tabId)` function
- [x] v4.4.3: Update `convertServerUrlsToBlobUrls` to accept optional `tabId` parameter
- [x] v4.4.4: Update `handleFileSelect` to track blob URLs under active tab ID
- [x] v4.4.5: Wire `handleTabClose` to call cleanup before closing
- [x] v4.4.6: Wire `handleTabCloseOthers` to clean up all closed tabs
- [x] v4.4.7: Wire `handleTabCloseAll` to clean up all blob URLs

### v4.5 Implementation Steps

- [x] v4.5.1: Add `copyFile` & `moveFile` to `fileService.js`
- [x] v4.5.2: Add `POST /copy-file` & `POST /move-file` routes in `files.js`
- [x] v4.5.3: Add `copyFile` & `moveFile` to `api.ts`
- [x] v4.5.4: Add `copySelected` & `moveSelected` to `useFiles` hook
- [x] v4.5.5: Export `copySelected` & `moveSelected` from useFiles
- [x] v4.5.6: Destructure in `App.tsx`
- [x] v4.5.7: Add `onCopy`/`onMove` props to FileExplorer
- [x] v4.5.8: Render Copy & Move buttons in FileExplorer UI

### v4.6 Implementation Steps

- [x] v4.6.1: Update `newFile()` in `useFiles.ts` to auto-append `.html` when no extension provided

### v4.7 Implementation Steps

- [x] v4.7.1: Install `html2pdf.js` via npm
- [x] v4.7.2: Add `onDownload` and `onExportPDF` props to DocumentEditor
- [x] v4.7.3: Render Download and Export PDF buttons in Main toolbar
- [x] v4.7.4: Implement `handleDownload` in App.tsx (fetch file, trigger download)
- [x] v4.7.5: Implement `handleExportPDF` in App.tsx (html2pdf.js with A4 format)
- [x] v4.7.6: Verify TypeScript compiles cleanly

### v4.10 Implementation Steps

- [x] v4.10.1: Diagnose v4.9 failure — `$from.node(1)` is paragraph, not image; `$from.before(1)` targets wrong position
- [x] v4.10.2: Rewrite `stopResize` with `doc.descendants()` tree walk + `src` matching
- [x] v4.10.3: Use `setNodeMarkup()` instead of `setNodeAttribute()` for reliable update
- [x] v4.10.4: Verify TypeScript compiles cleanly
- [x] v4.10.5: Manual test — resize image, switch tab, verify width persists

### v4.11 Implementation Steps

- [x] v4.11.1: Diagnose crash — `attributes` undefined in `renderHTML()` during content load
- [x] v4.11.2: Add null-safe access: `attributes?.width || HTMLAttributes?.['data-width'] || HTMLAttributes?.width`
- [x] v4.11.3: Manual test — open files with images, verify no crash

### v4.12 Implementation Steps

- [x] v4.12.1: Add `isDocxFile()` helper function in `App.tsx`
- [x] v4.12.2: Add `importDocxInputRef` for hidden DOCX file input
- [x] v4.12.3: Implement `handleExportDOCX()` with `docx` library (dynamic import, HTML→DOCX conversion)
- [x] v4.12.4: Implement `handleImportDOCX()` and `handleDocxFileSelected()` with mammoth.js
- [x] v4.12.5: Add DOCX detection in `handleUploadFiles()` — auto-convert `.docx` to HTML on upload
- [x] v4.12.6: Add `onExportDOCX` prop and button to DocumentEditor toolbar
- [x] v4.12.7: Add `onImportDOCX` prop and "Import" button to Header
- [x] v4.12.8: Add hidden `<input type="file" accept=".docx">` element
- [x] v4.12.9: Update CHANGELOG.md with v4.12 entry
- [x] v4.12.10: Verify TypeScript compiles cleanly
- [x] v4.12.11: Update handoff documentation

### v4.13 Implementation Steps

- [x] v4.13.1: Diagnose "Empty folder" — `loadFiles()` never called on mount
- [x] v4.13.2: Add `useEffect(() => { loadFiles('') }, [])` in `App.tsx`
- [x] v4.13.3: Verify explorer populates with default folders on login
- [x] v4.13.4: Update CHANGELOG.md with v4.13 entry
- [x] v4.13.5: Update handoff documentation

### v4.14 Investigation — Blob URL Map Rebuild on Reload

- [x] v4.14.1: Investigate `blobUrlMapRef` rebuild after page reload
- [x] v4.14.2: Discovered tabs are not persisted to localStorage (React state only)
- [x] v4.14.3: Confirmed `openFileWithConversion()` already handles rebuild correctly when files are reopened
- [x] v4.14.4: Added documentation comment in `App.tsx` explaining the decision
- [x] v4.14.5: Updated handoff documentation with finding
