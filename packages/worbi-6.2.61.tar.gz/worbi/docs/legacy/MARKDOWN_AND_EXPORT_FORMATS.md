# Handoff: Markdown View/Edit & Export Formats

**Target Version:** v5.4.0
**Priority:** Medium (expands WORBI's audience to Markdown-preferring writers)
**Dependencies:** None

---

## 1. Overview

This handoff covers three related features that expand WORBI's format support:

| Feature | Description |
|---------|-------------|
| **Markdown View/Edit Mode** | Toggle between WYSIWYG HTML and Markdown source in the editor |
| **Markdown Export** | Export documents as `.md` files |
| **PDF Export** | Export documents as `.pdf` files |

---

## 2. Feature 1: Markdown View/Edit Mode

### 2.1 Problem Statement

Some writers strongly prefer writing in Markdown. They're comfortable with `# headings`, `**bold**`, `- lists`, and find WYSIWYG editors distracting. WORBI's TipTap editor stores content as HTML internally, but can convert to/from Markdown for editing.

### 2.2 Behavior

A toggle button in the editor toolbar switches between two modes:

- **WYSIWYG Mode (default):** The TipTap rich text editor as it works today
- **Markdown Source Mode:** A plain text code editor showing the document as Markdown

When switching to Markdown mode:
1. The HTML content is converted to Markdown (using a library like Turndown)
2. The Markdown is displayed in a `<textarea>` (or CodeMirror for syntax highlighting)
3. The TipTap toolbar hides (Markdown commands are typed, not clicked)

When switching back to WYSIWYG mode:
1. The Markdown is converted back to HTML (using a library like marked or Showdown)
2. The TipTap editor reloads with the converted content
3. The toolbar reappears

### 2.3 Implementation

**Conversion libraries:**
- HTML → Markdown: [`turndown`](https://github.com/mixmark-io/turndown) (lightweight, configurable)
- Markdown → HTML: [`marked`](https://github.com/markedjs/marked) (fast, GFM-compatible)

```bash
cd client && npm install turndown marked
```

**Turndown configuration** (custom rules for WORBI-specific HTML):
```typescript
import TurndownService from 'turndown';

const turndownService = new TurndownService({
  headingStyle: 'atx',
  hr: '---',
  bulletListMarker: '-',
  codeBlockStyle: 'fenced',
  emDelimiter: '*',
});

// Custom rule: preserve wiki links <span data-wiki-link>
turndownService.addRule('wikiLink', {
  filter: (node) => node.getAttribute?.('data-wiki-link') !== null,
  replacement: (content, node) => {
    const target = node.getAttribute?.('data-target-name') || '';
    const display = node.getAttribute?.('data-display-text') || target;
    return display === target ? `[[${target}]]` : `[[${target}|${display}]]`;
  },
});

// Custom rule: handle images with resize attributes
turndownService.addRule('resizedImage', {
  filter: (node) => node.getAttribute?.('data-resized') !== null,
  replacement: (content, node) => {
    const src = node.getAttribute?.('src') || '';
    const width = node.getAttribute?.('data-width') || '';
    return `![image](${src}) <!-- width=${width} -->`;
  },
});
```

**Editor toggle:**
```typescript
// In DocumentEditor.tsx
const [isMarkdownMode, setIsMarkdownMode] = useState(false);

const toggleMarkdownMode = () => {
  if (isMarkdownMode) {
    // Convert markdown back to HTML
    const html = marked.parse(markdownContent);
    editor.commands.setContent(html);
    setIsMarkdownMode(false);
  } else {
    // Convert HTML to markdown
    const markdown = turndownService.turndown(editor.getHTML());
    setMarkdownContent(markdown);
    setIsMarkdownMode(true);
  }
};
```

**Markdown editor:** Use a `<textarea>` with monospace font and proper styling:
```css
.markdown-editor {
  width: 100%;
  height: 100%;
  background: #1a1a2e;
  color: #e0e0e0;
  font-family: 'JetBrains Mono', 'Fira Code', monospace;
  font-size: 14px;
  line-height: 1.6;
  padding: 24px;
  border: none;
  outline: none;
  resize: none;
  tab-size: 2;
}
```

### 2.4 Margin Editor in Markdown Mode

The margin editor also switches to Markdown mode. The `<!-- MARGIN_SPLIT -->` delimiter is preserved in the Markdown source:

```markdown
# Main Content Heading

Main body text here...

<!-- MARGIN_SPLIT -->

### Margin Notes

Supplementary content for the margin column.
```

When converting back, the server-side split logic (splitting on `<!-- MARGIN_SPLIT -->`) still works because Turndown preserves HTML comments.

### 2.5 Toolbar Button

Add a button to the editor toolbar:
- Icon: `FileCode` from lucide-react (or `Markdown` text badge)
- Tooltip: "Toggle Markdown Mode"
- Active state: highlighted when in Markdown mode
- Keyboard shortcut: `Ctrl+Shift+M`

---

## 3. Feature 2: Markdown Export

### 3.1 Behavior

"File → Export → Markdown (.md)" exports the current document as a `.md` file.

**Flow:**
1. Convert HTML content to Markdown using the same Turndown configuration
2. Download as `.md` file (using the browser's download mechanism)

### 3.2 Implementation

```typescript
// In DocumentEditor.tsx or useFileOperations.ts
const handleExportMarkdown = () => {
  const html = editor.getHTML();
  const markdown = turndownService.turndown(html);
  
  // Create blob and trigger download
  const blob = new Blob([markdown], { type: 'text/markdown' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = currentFileName.replace('.html', '.md');
  a.click();
  URL.revokeObjectURL(url);
};
```

- This is a **client-side only** operation — no server endpoint needed
- Images in the document: references become `![alt](path/to/image.png)` — these won't resolve outside WORBI without the server, but the paths are preserved for the user to fix up

---

## 4. Feature 3: PDF Export

### 4.1 Behavior

"File → Export → PDF (.pdf)" exports the current document as a PDF file.

### 4.2 Approach: Browser Print

Use the browser's built-in print-to-PDF functionality. This is the simplest approach and requires no additional dependencies.

```typescript
const handleExportPDF = () => {
  // Create a temporary iframe with styled content
  const iframe = document.createElement('iframe');
  iframe.style.display = 'none';
  document.body.appendChild(iframe);
  
  const doc = iframe.contentDocument!;
  doc.write(`
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body {
          font-family: 'Inter', -apple-system, sans-serif;
          font-size: 12pt;
          line-height: 1.6;
          color: #1a1a1a;
          max-width: 800px;
          margin: 40px auto;
          padding: 20px;
        }
        h1 { font-size: 24pt; margin-top: 0; }
        h2 { font-size: 18pt; }
        h3 { font-size: 14pt; }
        img { max-width: 100%; }
        .wiki-link { text-decoration: underline; color: #2563eb; }
        @media print {
          @page { margin: 1in; }
        }
      </style>
    </head>
    <body>
      <h1>${documentTitle}</h1>
      ${editor.getHTML()}
    </body>
    </html>
  `);
  
  // Trigger print
  iframe.contentWindow?.print();
  
  // Clean up after print dialog closes
  setTimeout(() => {
    document.body.removeChild(iframe);
  }, 1000);
};
```

**Alternative (future):** Use a library like `html2pdf.js` or `jsPDF` for programmatic PDF generation without the print dialog.

---

## 5. API Endpoints (None for Export)

Both Markdown and PDF exports are client-side only. No server endpoints are needed.

For a future server-side PDF export (headless Chrome/Puppeteer):
```
POST /api/files/export/pdf   →  { path: "/document.html" }  →  returns PDF blob
```

---

## 6. Files to Create

| File | Purpose |
|------|---------|
| `client/src/utils/markdownConverter.ts` | Shared Turndown + Marked configuration, conversion helpers |

## 7. Files to Modify

| File | Changes |
|------|---------|
| `client/src/components/DocumentEditor.tsx` | Add Markdown mode toggle, textarea rendering, toolbar button, Ctrl+Shift+M shortcut |
| `client/src/components/Header.tsx` | Add Markdown and PDF export options to File menu |
| `client/src/styles/globals.css` | Add `.markdown-editor` styling |

---

## 8. Edge Cases

| Scenario | Handling |
|----------|----------|
| **HTML elements not supported in Markdown** | Turndown strips unsupported elements with a warning. Tables, code blocks, lists, images, links all convert cleanly |
| **Images in Markdown export** | Paths are preserved but won't work outside WORBI. Acceptable — the user can replace them |
| **Very large documents** | Conversion is O(n) on content size. For documents >1MB, show a progress indicator during conversion |
| **Markdown with unsupported syntax** | Marked renders standard GFM faithfully. Non-standard extensions (footnotes, task lists) may not render |
| **Toggle during editing** | If the markdown content has been modified in the textarea, convert it back. If the TipTap content was modified (e.g., via toolbar), it takes precedence |
| **Wiki links in PDF** | Rendered as underlined text. No hyperlinks (PDF print preserves links from `<a>` tags, so wiki links wrapped in `<a>` work) |
| **Margin content in PDF** | Both main and margin content are included sequentially. The `<!-- MARGIN_SPLIT -->` is rendered as a horizontal rule in the PDF |

---

## 9. Verification Checklist

**Markdown View/Edit:**
- [ ] Toggle button switches between WYSIWYG and Markdown modes
- [ ] Markdown mode shows monospace textarea with correct content
- [ ] Switching back to WYSIWYG preserves formatting
- [ ] `Ctrl+Shift+M` toggles mode
- [ ] Bold/italic/headings convert correctly in both directions
- [ ] Lists (ordered and unordered) convert correctly
- [ ] Code blocks preserve indentation
- [ ] Wiki links convert to/from `[[...]]` syntax
- [ ] Images preserve their alt text and src
- [ ] Margin content (after `<!-- MARGIN_SPLIT -->`) is preserved
- [ ] Both editor columns (main + margin) switch to Markdown together

**Markdown Export:**
- [ ] Exported `.md` file is valid Markdown
- [ ] File downloads with correct name
- [ ] All formatting converts correctly
- [ ] Wiki links become `[[...]]` syntax in the .md file

**PDF Export:**
- [ ] Print dialog opens with styled content
- [ ] Document title appears as heading
- [ ] Images render in the PDF preview
- [ ] Page breaks work correctly for long documents
- [ ] Print-to-PDF produces a readable output

---

## 10. Dependencies to Add

```json
// client/package.json
{
  "turndown": "^7.1.0",
  "marked": "^12.0.0"
}
```

---

## 11. Future Enhancements

- **Split view:** Show WYSIWYG on the left and Markdown source on the right (like many Markdown editors)
- **Live preview:** Update the WYSIWYG view in real-time as you edit Markdown
- **Syntax highlighting:** Use CodeMirror 6 for the Markdown editor with syntax highlighting
- **Server-side PDF:** Use Puppeteer on the server for higher-quality PDF with proper page layout
- **Batch export:** Export all documents in a folder as a single PDF or Markdown file
- **DOCX improvements:** Enhance existing DOCX export with template-based styling