# Handoff: AI Sidebar Visibility Bug Fix

**Priority:** High (active bug, user-facing)
**Target Version:** v5.1.10 (patch)
**Complexity:** Trivial — 2 files, ~8 lines total

---

## 1. Problem Statement

The AI sidebar (ChatPanel) on the right side should be **hidden by default** when a user first logs in. Currently, it is **visible on first login** if the user toggled it on in a previous session, even after logging out and logging back in.

**Expected:** Fresh login → sidebar hidden
**Actual:** Fresh login → sidebar inherits stale preference from previous session

---

## 2. Root Cause

Three interacting issues:

### 2.1 `useState` initializer runs once on mount

In `App.tsx` lines 45-48:
```typescript
const [showAISidebar, setShowAISidebar] = useState(() => {
    const stored = localStorage.getItem('wbu-ai-sidebar');
    return stored !== null ? stored === 'true' : false;
});
```

This initializer runs **once** when App mounts (before the user logs in). If `wbu-ai-sidebar` is `'true'` from a previous session, `showAISidebar` initializes to `true`. It never re-runs after login.

### 2.2 `logout()` doesn't clear the sidebar key

In `useAuth.ts` lines 55-65, `logout()` removes `wbu_token` and `wbu_user` but does **not** remove `wbu-ai-sidebar`. So the stale `'true'` value persists in localStorage across logout/login cycles.

### 2.3 No auth transition handler

App.tsx has no `useEffect` that resets `showAISidebar` when `isAuthenticated` transitions from `false → true` (fresh login). Without this, even if localStorage is cleaned, React won't re-read it because the initializer is a one-shot.

---

## 3. Fix

### 3.1 File: `client/src/hooks/useAuth.ts`

**Line 56** — Inside `logout()`, add removal of `wbu-ai-sidebar`:

```typescript
// Current code (line 55-64):
const logout = useCallback(() => {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);

    setState({
      user: null,
      token: null,
      isAuthenticated: false,
      isLoading: false,
    });
  }, []);

// Fixed code — add line:
const logout = useCallback(() => {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
    localStorage.removeItem('wbu-ai-sidebar');   // ← ADD THIS LINE

    setState({
      user: null,
      token: null,
      isAuthenticated: false,
      isLoading: false,
    });
  }, []);
```

### 3.2 File: `client/src/App.tsx`

**After existing `useRef`s (~line 66)** — Add an auth transition handler:

```typescript
// Add after existing useRef declarations (around line 65-66, before useEffect at line 68):
const prevAuthRef = useRef(isAuthenticated);

// Reset AI sidebar visibility on fresh login (not on page refresh)
useEffect(() => {
    const wasUnauthenticated = !prevAuthRef.current;
    const isNowAuthenticated = isAuthenticated;
    if (wasUnauthenticated && isNowAuthenticated) {
        setShowAISidebar(false);
        localStorage.removeItem('wbu-ai-sidebar');
    }
    prevAuthRef.current = isAuthenticated;
}, [isAuthenticated]);
```

**Note:** The `useEffect` must be placed **after** the `showAISidebar` state declaration (line 48) and **before** the component unmount cleanup `useEffect` (line 68). A good spot is right after the `importDocxInputRef` / `blobUrlMapRef` declarations (~line 66).

---

## 4. Why This Works

| Scenario | What Happens | Sidebar? |
|----------|-------------|----------|
| **Fresh login** | `isAuthenticated: false→true` triggers `useEffect` → sets `showAISidebar(false)` + clears localStorage | Hidden ✓ |
| **Page refresh (already logged in)** | `isAuthenticated` stays `true` (no transition) → initializer reads localStorage → preserves user's preference | Preserved ✓ |
| **Logout → re-login** | `logout()` clears `wbu-ai-sidebar` → auth transition sets false | Hidden ✓ |
| **User toggles sidebar on** | `toggleAISidebar()` saves `'true'` to localStorage | Visible ✓ |
| **User toggles sidebar off** | `toggleAISidebar()` saves `'false'` to localStorage | Hidden ✓ |

---

## 5. Files to Modify

| File | Change | Lines |
|------|--------|-------|
| `client/src/hooks/useAuth.ts` | Add `localStorage.removeItem('wbu-ai-sidebar')` to `logout()` | +1 |
| `client/src/App.tsx` | Add `prevAuthRef` + `useEffect` for auth transition detection | +6 |

---

## 6. Verification Checklist

- [ ] Fresh login: AI sidebar is hidden
- [ ] Toggle sidebar on, then page refresh: sidebar stays on
- [ ] Toggle sidebar off, then page refresh: sidebar stays off
- [ ] Login, toggle on, logout, re-login: sidebar is hidden (fresh session)
- [ ] Existing localStorage `wbu-ai-sidebar=true` from before fix: cleared on next login