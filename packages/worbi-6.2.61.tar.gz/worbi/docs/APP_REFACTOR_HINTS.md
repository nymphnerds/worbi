# App.tsx Refactor Hints — Working With the New Feature Slice Architecture

**Version:** v6.1.0  
**Purpose:** Reference guide for LLMs and developers working with the decomposed App.tsx.  
**Target:** Replace 30 minutes of reading 7 files with 5 minutes of reading this one document.

---

## 1. What Happened

`App.tsx` was a 1538-line monolith managing ~13 distinct concerns. It was decomposed into **7 feature modules** across 4 domains plus a slimmed-down orchestrator (~595 lines, 61% reduction).

| Concern | Old Location | New Location |
|---------|-------------|--------------|
| Auth state + login gate | App.tsx `useAuth()` + `if (!isAuthenticated) return <Login>` | `features/auth/AuthProvider.tsx` |
| Layout (panel widths, drag) | App.tsx `useState` + inline `onMouseDown` | `features/layout/useLayout.ts` |
| Layout context sharing | Did not exist (prop-drilled) | `features/layout/LayoutContext.tsx` |
| Layout JSX grid | App.tsx return block | `features/layout/AppLayout.tsx` (presentational, unused but available) |
| Activity routing | App.tsx `activeActivity` + `handleActivitySwitch` + `tagsShowAddTag` | `features/navigation/useActivityRouter.ts` |
| Settings modal toggle | App.tsx `showSettings` + inline setter | `features/navigation/useSettings.ts` |
| File CRUD + undo/redo wiring | App.tsx `useFiles()` + `useFileSystemUndoRedo()` + `useEffect(refreshRef)` + DOCX upload handling | `features/files/useFileOperations.ts` |
| Image proxy conversion | App.tsx (still there — cross-cuts files + editor) | `App.tsx` inline functions |
| Keyboard shortcuts | App.tsx `useEffect(keydown)` | `App.tsx` inline (wires across feature boundaries) |
| DOCX import/export, PDF export | App.tsx callbacks | `App.tsx` inline |
| Modal/dialog state | App.tsx `useState` arrays | `App.tsx` inline |
| Batch selection | App.tsx `useState` + callbacks | `App.tsx` inline |

---

## 2. New Directory Structure

```
client/src/
├── App.tsx                           ~595 lines — orchestrator + cross-cutting concerns
├── main.tsx                           Wraps <App> with <AuthProvider>
├── features/
│   ├── layout/
│   │   ├── useLayout.ts              Panel widths, drag handlers, AI sidebar toggle
│   │   ├── LayoutContext.tsx          React context for layout state (useLayoutContext())
│   │   └── AppLayout.tsx              Presentational grid component (NOT wired in yet)
│   ├── auth/
│   │   └── AuthProvider.tsx           Auth context + login gate + useAuthContext()
│   ├── navigation/
│   │   ├── useActivityRouter.ts      Activity switching + tag sidebar state + ActivityType
│   │   └── useSettings.ts            Settings modal toggle
│   └── files/
│       └── useFileOperations.ts      File CRUD + undo/redo + explorer path + DOCX uploads
│           also exports: isImageFile(), isDocxFile()
├── hooks/                            Existing hooks (NO changes)
│   ├── useAuth.ts                    Used internally by AuthProvider only
│   ├── useFiles.ts                   Used internally by useFileOperations
│   ├── useFileSystemUndoRedo.ts      Used internally by useFileOperations
│   ├── useLLM.ts                     Still called directly in App.tsx
│   ├── useRecents.ts                 Still called directly in App.tsx
│   ├── useSearch.ts                  Still called directly in App.tsx
│   ├── useBookmarks.ts               Still called directly in App.tsx
│   ├── useSessionPersistence.ts      Still called directly in App.tsx
│   ├── useGraph.ts                   Still called directly in App.tsx
│   └── useTheme.ts                   applyThemeColours still called in App.tsx
├── components/                       NO changes to component signatures
├── pages/
│   ├── Login.tsx                     Rendered by AuthProvider instead of App.tsx
│   └── Settings.tsx                  Still rendered by App.tsx
└── services/
    └── api.ts                        NO changes
```

---

## 3. The Orchestrator Pattern

`App.tsx` now works as a **composition layer**:

1. Import feature hooks
2. Call each hook at the top level (React rules-of-hooks)
3. Destructure return values
4. Wire callbacks between hooks (e.g., `useActivityRouter` needs `toggleLeftPanel` from `useLayout`)
5. Compute derived values (`dirty`, `canRestore`, `wordCount`)
6. Render JSX passing destructured values as props to children

```tsx
// Pattern in App.tsx:
export default function App() {
  // Step 1: Auth (must be first — provides user identity)
  const { user, isAuthenticated, login, logout } = useAuthContext();

  // Step 2: Layout
  const layout = useLayout();
  const { leftWidth, rightWidth, showAISidebar, toggleAISidebar, toggleLeftPanel,
          leftPanelHidden, setLeftPanelHidden, setLeftWidth, setRightWidth, ... } = layout;

  // Step 3: Navigation (depends on layout's toggleLeftPanel)
  const nav = useActivityRouter(toggleLeftPanel, setLeftPanelHidden);
  const { activeActivity, setActiveActivity, tagsShowAddTag, handleActivitySwitch,
          handleOpenTagSidebar } = nav;
  const { showSettings, setShowSettings } = useSettings();

  // Step 4: File Operations (depends on showFolderPicker dialog)
  const fileOps = useFileOperations(showFolderPicker);
  const { files, tabs, activeTabId, explorerPath, canUndo, canRedo,
          undoFs, redoFs, handleNewFile, handleDelete, ... } = fileOps;

  // Step 5: Other hooks called directly
  const { chatHistory, aiOffline, sendMessage, ... } = useLLM();
  const { recentFiles, starredFiles, ... } = useRecents(recentsRefreshKey);
  const { query: searchQuery, ... } = useSearch();

  // Step 6: Wire cross-cutting callbacks
  const handleSave = useCallback(async () => {
    const tab = tabs[activeTabId];
    if (!tab) return;
    await saveCurrentFile(convertProxyUrlsToServerUrls(tab.content));
  }, [activeTabId, tabs, ...]);

  // Step 7: Render
  return <div>...</div>;
}
```

**Key rule:** Features are called in dependency order. `useActivityRouter` needs `toggleLeftPanel` from `useLayout`. `useFileOperations` needs `showFolderPicker` from the dialog state in App.tsx.

---

## 4. Feature Module Reference

### 4.1 `features/layout/useLayout.ts`

```ts
function useLayout(): {
  leftWidth: number;
  setLeftWidth: React.Dispatch<React.SetStateAction<number>>;
  rightWidth: number;
  setRightWidth: React.Dispatch<React.SetStateAction<number>>;
  searchWidth: number;
  setSearchWidth: React.Dispatch<React.SetStateAction<number>>;
  leftPanelHidden: boolean;
  setLeftPanelHidden: React.Dispatch<React.SetStateAction<boolean>>;
  showAISidebar: boolean;
  setShowAISidebar: (value: boolean | ((prev: boolean) => boolean)) => void;
  toggleAISidebar: () => void;
  toggleLeftPanel: () => void;
  resizeLeftPanel: (e: React.MouseEvent) => void;
  resizeRightPanel: (e: React.MouseEvent) => void;
  resizeSearchPanel: (e: React.MouseEvent) => void;
}
```

**Internal state:**
- `leftWidth` — persisted to `localStorage('wbu-left-width')`, default 250, min 180, max 500
- `rightWidth` — persisted to `localStorage('wbu-right-width')`, default 350, min 280, max 600
- `searchWidth` — persisted to `localStorage('wbu-search-width')`, default 250, min 200, max 500
- `leftPanelHidden` — persisted to `localStorage('wbu-left-panel-hidden')`
- `showAISidebar` — persisted to `localStorage('wbu-ai-sidebar')`

**Depends on:** React only. No other features.

**Note:** `resizeLeftPanel`, `resizeRightPanel`, `resizeSearchPanel` are factory-built from `createHorizontalResizeHandler` which returns a mouse event handler that uses `document.addEventListener` for mousemove/mouseup and persists final width on mouseup.

---

### 4.2 `features/layout/LayoutContext.tsx`

```ts
// Provider:
function LayoutProvider({ children, value }: { children: ReactNode; value: LayoutContextValue }): JSX.Element

// Consumer:
function useLayoutContext(): LayoutContextValue

interface LayoutContextValue {
  leftWidth: number;
  rightWidth: number;
  searchWidth: number;
  leftPanelHidden: boolean;
  showAISidebar: boolean;
  toggleAISidebar: () => void;
  toggleLeftPanel: () => void;
  resizeLeftPanel: (e: React.MouseEvent) => void;
  resizeRightPanel: (e: React.MouseEvent) => void;
  resizeSearchPanel: (e: React.MouseEvent) => void;
}
```

**Usage:** Any component that needs layout dimensions can call `useLayoutContext()`. The provider wraps children and memoizes the value object to prevent unnecessary re-renders.

**Currently NOT wired in App.tsx.** Available for deeply nested components that would otherwise receive layout props via prop drilling.

---

### 4.3 `features/layout/AppLayout.tsx`

Pure presentational component (currently NOT used in the JSX — App.tsx still renders layout directly). Available for future use if layout structure extraction is desired.

```ts
interface AppLayoutProps {
  header: ReactNode;
  overlayContent?: ReactNode;
  leftPanel: ReactNode | null;
  activityBar: ReactNode;
  collapsedToggle: ReactNode | null;
  leftPanelVisible: boolean;
  onLeftResizerMouseDown: (e: React.MouseEvent) => void;
  mainContent: ReactNode;
  rightPanel: ReactNode | null;
  rightPanelVisible: boolean;
  onRightResizerMouseDown: (e: React.MouseEvent) => void;
  statusBar: ReactNode;
  modalContent?: ReactNode;
}
```

---

### 4.4 `features/auth/AuthProvider.tsx`

```ts
// Provider (wraps app in main.tsx):
function AuthProvider({ children }: { children: ReactNode }): JSX.Element

// Consumer:
function useAuthContext(): {
  user: { username: string } | null;
  isAuthenticated: boolean;
  login: (username: string) => Promise<{ username: string } | null>;
  logout: () => void;
}
```

**Behavior:** If `!isAuthenticated`, renders `<Login onLogin={login} />` instead of children. Otherwise renders children wrapped in `AuthContext.Provider`.

**Internal:** Calls `useAuth()` from `hooks/useAuth.ts` (which manages localStorage token hydration and API calls).

**Crucial:** `App` is now ONLY rendered when authenticated. Any code in `App.tsx` can safely assume `isAuthenticated === true`.

**Wiring in main.tsx:**
```tsx
<AuthProvider>
  <App />
</AuthProvider>
```

---

### 4.5 `features/navigation/useActivityRouter.ts`

```ts
function useActivityRouter(
  toggleLeftPanel: () => void,
  setLeftPanelHidden: (hidden: boolean | ((prev: boolean) => boolean)) => void
): {
  activeActivity: ActivityType;
  setActiveActivity: React.Dispatch<React.SetStateAction<ActivityType>>;
  tagsShowAddTag: boolean;
  handleActivitySwitch: (activity: ActivityType) => void;
  handleOpenTagSidebar: () => void;
}

type ActivityType = 'explorer' | 'search' | 'starred' | 'tags' | 'timeline' | 'locations' | 'graph' | 'images' | 'outline';
```

**Behavior:**
- `handleActivitySwitch(activity)`: If `activity === activeActivity`, toggles left panel. Otherwise switches activity and unhides the panel.
- `handleOpenTagSidebar()`: Sets activity to 'tags' and `tagsShowAddTag` to true.
- `useEffect` resets `tagsShowAddTag` to false when switching away from tags activity.
- Exports `ActivityType` as a type for use elsewhere.

---

### 4.6 `features/navigation/useSettings.ts`

```ts
function useSettings(): {
  showSettings: boolean;
  openSettings: () => void;
  closeSettings: () => void;
  setShowSettings: React.Dispatch<React.SetStateAction<boolean>>;
}
```

Simple wrapper. Exposes `setShowSettings` for the ActivityBar's toggle pattern (`setShowSettings(prev => !prev)`).

---

### 4.7 `features/files/useFileOperations.ts`

```ts
function useFileOperations(
  showFolderPicker: (defaultFolder?: string) => Promise<string>
): {
  // State
  files: FileItem[];
  currentPath: string | null;
  content: string;
  loading: boolean;
  error: string | null;
  setContent: React.Dispatch<React.SetStateAction<string>>;
  tabs: Record<string, Tab>;
  activeTabId: string | null;
  explorerPath: string;
  setExplorerPath: React.Dispatch<React.SetStateAction<string>>;

  // Core file operations
  loadFiles: (path: string) => Promise<void>;
  openFile: (path: string) => Promise<{ content: string; id: string } | null>;
  openTab: (path: string) => Promise<boolean>;
  saveCurrentFile: (content?: string) => Promise<void>;
  restoreToOriginal: () => void;
  newFile: (folder: string, name: string) => Promise<string | null>;
  newFolder: (parentPath: string, name: string) => Promise<void>;

  // CRUD wrappers
  deleteSelected: (path: string, parentPath: string) => void;
  renameSelected: (path: string, newName: string, parentPath: string) => void;
  copySelected: (path: string, parentPath: string) => void;
  moveSelected: (path: string, parentPath: string) => void;
  uploadImageFile: (file: File) => Promise<void>;
  uploadFileToFolder: (file: File, folder: string) => Promise<void>;

  // Tab operations
  closeTab: (id: string) => void;
  switchTab: (id: string) => void;
  updateTabContent: (id: string, content: string) => void;
  closeOtherTabs: (id: string) => void;
  closeAllTabs: () => void;

  // Batch operations
  batchDelete: (paths: string[], currentFolder: string) => void;
  batchCopy: (paths: string[], destFolder: string, currentFolder: string) => void;
  batchMove: (paths: string[], destFolder: string, currentFolder: string) => void;

  // Undo/redo
  canUndo: boolean;
  canRedo: boolean;
  undoFs: () => void;
  redoFs: () => void;

  // Convenience handlers with confirmation dialogs
  handleNewFile: (name: string) => void;
  handleDelete: (item: FileItem) => void;
  handleRename: (item: FileItem, newName: string) => void;
  handleCopy: (item: FileItem) => void;
  handleMove: (item: FileItem) => void;
  handleBack: () => void;
  handleBackToRoot: () => void;
  handleBackToSegment: (path: string) => void;
  handleNewFolder: () => void;
  handleUploadFiles: (fileList: FileList) => Promise<void>;
}
```

**Also exports:** `isImageFile(name: string): boolean`, `isDocxFile(name: string): boolean`

**Internal wiring:** Calls `useFiles(pushUndoOp, showFolderPicker)` and `useFileSystemUndoRedo()`. The `useEffect` that wires `refreshRef.current = () => loadFiles(explorerPath)` is internal — you don't need to wire it in App.tsx.

**Important:** `handleDelete`, `handleRename`, `handleCopy`, `handleMove` are convenience wrappers that compute `parentPath` from the item. The raw `deleteSelected`, `renameSelected`, etc. expect you to pass `parentPath` explicitly.

**handleUploadFiles** handles DOCX-to-HTML conversion internally using mammoth.js.

---

## 5. Data Flow Diagram

```
main.tsx
  └─ AuthProvider (useAuthContext available anywhere below)
       └─ App.tsx (orchestrator)
            ├── useLayout()          ─→ leftWidth, rightWidth, toggleAISidebar, ...
            │                              │
            ├── useActivityRouter()  ─→ activeActivity, handleActivitySwitch (uses toggleLeftPanel↑)
            ├── useSettings()        ─→ showSettings
            ├── useFileOperations()  ─→ files, tabs, content, handleNewFile, handleDelete, ...
            │                              │
            ├── useLLM()             ─→ chatHistory, aiOffline, sendMessage, ...
            ├── useRecents()         ─→ recentFiles, starredFiles, toggleStar, ...
            ├── useSearch()          ─→ searchQuery, searchResults, ...
            ├── useBookmarks()       ─→ getBookmarks, parseHeadings, ...
            ├── useGraph()           ─→ graphModalData, graph.generate(), ...
            ├── useSessionPersistence()
            │
            ├── [dialog state inline]─→ showConfirm, showPrompt, showFolderPicker
            ├── [image proxy inline] ─→ convertServerUrlsToProxyUrls, convertProxyUrlsToServerUrls
            ├── [export inline]      ─→ handleDownload, handleExportPDF, handleExportDOCX
            ├── [keyboard inline]    ─→ Ctrl+S, Ctrl+Shift+N, F1
            │
            └── JSX renders:
                 ├── Header          (user, logout, toggleAISidebar, aiOffline)
                 ├── ActivityBar     (activeActivity, handleActivitySwitch, toggleAISidebar)
                 ├── FileExplorer    (files, explorerPath, handleFileSelect, handleDelete, ...)
                 ├── TabBar          (tabs, activeTabId, handleTabSwitch, handleTabClose)
                 ├── DocumentEditor  (content, currentPath, handleSave, handleRestore, ...)
                 ├── ChatPanel       (chatHistory, sendMessage, rightWidth, ...)
                 ├── StatusBar       (currentPath, wordCount, llmConnected)
                 └── Modals          (ConfirmDialog, PromptDialog, FolderPickerDialog, ...)
```

**Rule:** Data flows DOWN from hooks through App.tsx to component props. No component calls hooks directly except App.tsx (exception: AuthProvider internally calls useAuth, useFileOperations internally calls useFiles/useFileSystemUndoRedo).

---

## 6. Where Every Old App.tsx Section Moved

| Old App.tsx Section | Lines | New Location |
|---------------------|-------|-------------|
| `useAuth()` call + `!isAuthenticated` gate | ~30 | `features/auth/AuthProvider.tsx` |
| `isImageFile()` / `isDocxFile()` helpers | ~10 | `features/files/useFileOperations.ts` (re-exported) |
| `ActivityType` type alias | ~2 | `features/navigation/useActivityRouter.ts` |
| Layout state: `leftWidth`, `rightWidth`, `searchWidth`, `leftPanelHidden`, `showAISidebar` | ~15 | `features/layout/useLayout.ts` |
| `toggleAISidebar()`, `toggleLeftPanel()` | ~15 | `features/layout/useLayout.ts` |
| Resizer `onMouseDown` handlers (inline in JSX) | ~20 | `features/layout/useLayout.ts` (`resizeLeftPanel`, `resizeRightPanel`, `resizeSearchPanel`) |
| `handleActivitySwitch()` | ~8 | `features/navigation/useActivityRouter.ts` |
| `setTagsShowAddTag` + reset effect | ~8 | `features/navigation/useActivityRouter.ts` |
| `showSettings` + toggle | ~3 | `features/navigation/useSettings.ts` |
| `useFiles()` call | ~20 | `features/files/useFileOperations.ts` |
| `useFileSystemUndoRedo()` call | ~5 | `features/files/useFileOperations.ts` |
| `useEffect(refreshRef)` wiring | ~4 | `features/files/useFileOperations.ts` |
| `handleNewFile()`, `handleDelete()`, `handleRename()`, `handleCopy()`, `handleMove()` | ~30 | `features/files/useFileOperations.ts` |
| `handleBack()`, `handleBackToRoot()`, `handleBackToSegment()` | ~15 | `features/files/useFileOperations.ts` |
| `handleNewFolder()`, `handleUploadFiles()` | ~50 | `features/files/useFileOperations.ts` |
| `explorerPath` state | ~1 | `features/files/useFileOperations.ts` |
| Batch selection: `handleToggleSelectionMode`, `handleToggleSelect`, `handleSelectAll`, `handleClearSelection`, `handleBatchDelete`, `handleBatchCopy`, `handleBatchMove` | ~55 | `App.tsx` (still there — lightweight) |
| Image proxy: `extractImagePaths`, `extractWorkspaceImagePaths`, `convertServerUrlsToProxyUrls`, `convertProxyUrlsToServerUrls` | ~75 | `App.tsx` (still there — cross-cuts files + editor) |
| `handleSave`, `handleRestore`, `openFileWithConversion`, `trackRecent` | ~35 | `App.tsx` (still there — wires files + image proxy) |
| `handleFileSelect` (image insertion logic) | ~25 | `App.tsx` (still there — uses confirm dialog) |
| `handleCreateFileFromEditor` | ~25 | `App.tsx` (still there) |
| `handleTabClose`, `handleTabSwitch`, `handleTabCloseOthers`, `handleTabCloseAll`, `handleConfirmDirtyClose` | ~25 | `App.tsx` (still there) |
| DOCX import: `handleImportDOCX`, `handleDocxFileSelected`, `importDocxInputRef` | ~35 | `App.tsx` (still there) |
| Export: `handleDownload`, `handleExportPDF`, `handleExportDOCX`, `handleInsertImageUrl` | ~120 | `App.tsx` (still there) |
| Keyboard shortcuts `useEffect(keydown)` | ~15 | `App.tsx` (still there) |
| `beforeunload` `useEffect` | ~12 | `App.tsx` (still there) |
| Session restore: `handleSessionRestore`, `useSessionPersistence()` | ~25 | `App.tsx` (still there) |
| Auth transition `useEffect(prevAuthRef)` | ~12 | `App.tsx` (still there) |
| Theme init `useEffect` | ~10 | `App.tsx` (still there) |
| Dialog state: confirm, prompt, folderPicker + `showConfirm`, `showPrompt`, `showFolderPicker` | ~55 | `App.tsx` (still there) |
| Modal state: template, compile, generate, help, graph | ~15 | `App.tsx` (still there) |
| Completions: `dirty`, `canRestore`, `wordCount` | ~5 | `App.tsx` (still there) |
| JSX rendering (the entire layout) | ~500 | `App.tsx` (still there) |

---

## 7. What Stayed in App.tsx and Why

These concerns remain in the orchestrator because they **wire across multiple feature boundaries** and extracting them would create circular dependencies or excessive prop drilling:

| Concern | Why It Stayed |
|---------|--------------|
| Image proxy conversion (`convertServerUrlsToProxyUrls`, `convertProxyUrlsToServerUrls`) | Needs file content from `useFileOperations`, image APIs from `services/api`, and feeds into `handleSave` / `openFileWithConversion`. Cross-cuts files + editor. |
| `handleSave` / `handleRestore` / `openFileWithConversion` | Wires tabs from `useFileOperations` with proxy conversion functions. Tightly couples save and image proxy. |
| Keyboard shortcuts | Fires `handleSave` (which uses file ops + proxy), `setShowTemplateModal`, `setShowHelp`. Crosses 3 feature boundaries. |
| DOCX import/export, PDF export | Uses file ops, tabs, proxy conversion, explorer path. Each uses 3-4 features. |
| Dialog state + `showConfirm` / `showPrompt` / `showFolderPicker` | Used by file operations, image insertion, batch operations, dirty close. Shared infrastructure used by everything. |
| `handleFileSelect` | Image insertion path uses confirm dialog. File open path uses proxy conversion. Cross-cuts dialogs + files + images. |
| `handleCreateFileFromEditor` | Uses `newFile` from file ops, `openFileWithConversion`, `loadFiles`, `explorerPath`, `files`. Cross-cuts file ops + proxy. |
| Session restore | Needs `setActiveActivity` from navigation, `loadFiles`/`openTab` from file ops. Cross-cuts nav + files. |
| Auth transition + theme init + initial load `useEffects` | App-level bootstrap — must run once, at the top. |
| Batch selection callbacks | These are thin wrappers around `batchDelete`/`batchCopy`/`batchMove` + dialog state. ~30 lines, not worth extracting. |
| `beforeunload` effect | Reads `tabs` from file ops. Single-purpose effect, fits in orchestrator. |

---

## 8. How to Add a New Feature

### Pattern: Create a Feature Hook

```ts
// client/src/features/myFeature/useMyFeature.ts
import { useState, useCallback } from 'react';

export function useMyFeature(someDependency: () => void) {
  const [myState, setMyState] = useState<string>('');

  const doSomething = useCallback(() => {
    someDependency();
    setMyState('done');
  }, [someDependency]);

  return { myState, setMyState, doSomething };
}
```

### Pattern: Wire It into App.tsx

```tsx
// In App.tsx imports:
import { useMyFeature } from './features/myFeature/useMyFeature';

// In the App function body (after existing hooks):
const myFeature = useMyFeature(someCallbackFromAnotherHook);
const { myState, doSomething } = myFeature;

// In JSX, pass to children:
<SomeComponent myState={myState} onAction={doSomething} />
```

### Pattern: Create a Context (only for truly global state)

```tsx
// client/src/features/myFeature/MyContext.tsx
import { createContext, useContext } from 'react';

const MyContext = createContext<MyType | null>(null);

export function MyProvider({ children, value }: { children: ReactNode; value: MyType }) {
  return <MyContext.Provider value={value}>{children}</MyContext.Provider>;
}

export function useMyContext(): MyType {
  const ctx = useContext(MyContext);
  if (!ctx) throw new Error('useMyContext must be used within MyProvider');
  return ctx;
}
```

---

## 9. Dependency Rules

| Module | May Import From |
|--------|----------------|
| `features/layout/*` | React only |
| `features/auth/*` | `hooks/useAuth`, `pages/Login`, React |
| `features/navigation/*` | React only |
| `features/files/*` | `hooks/useFiles`, `hooks/useFileSystemUndoRedo`, `services/api` (types), React |
| `App.tsx` | ALL features, ALL hooks, ALL components |
| Components (`components/*`) | `features/layout/LayoutContext` (optional), `hooks/*`, `services/api`, React |
| Hooks (`hooks/*`) | `services/api`, React (never import from `features/*`) |
| `services/api.ts` | Nothing except `fetch` |

**Key rule:** Features can depend on hooks and services, but NOT on other features. Hooks never depend on features. Components can depend on hooks and the layout context. App.tsx is the only file that imports from all domains.

**Circular dependency prevention:** If a feature needs something from another feature, it must be lifted up to App.tsx and passed down as a parameter. Example: `useActivityRouter` needs `toggleLeftPanel` from `useLayout` — App.tsx passes it as a parameter.

---

## 10. Gotchas & Pitfalls

### `useFileOperations` manages undo/redo internally

Do NOT call `useFileSystemUndoRedo()` in App.tsx. It's already called inside `useFileOperations`. The `canUndo`, `canRedo`, `undoFs`, `redoFs` values are returned in the hook's output.

### `showFolderPicker` is a dependency injection

`useFileOperations(showFolderPicker)` receives the folder picker dialog function from App.tsx. This is because the dialog state lives in App.tsx. If you move dialog state, update this parameter.

### `toggleAISidebar` and `showAISidebar` from `useLayout`

The auth transition effect in App.tsx calls `setShowAISidebar(false)` directly (not `toggleAISidebar`). This is intentional — on fresh login, we force sidebar closed without toggling.

### `handleActivitySwitch` replaces old inline logic

The old `handleActivitySwitch` in App.tsx has been removed. The version in `useActivityRouter` has the same behavior: same-activity click toggles panel, different-activity click switches and unhides.

### `tagsShowAddTag` is read-only from App.tsx

App.tsx destructures `tagsShowAddTag` from `useActivityRouter` but the setter is internal to the hook. The reset-on-activity-change effect is also internal. App.tsx only uses the current value to pass to `<TagManager defaultShowAddTag={tagsShowAddTag}>`.

### `LayoutContext` / `AppLayout` are NOT wired

Both exist and compile but are not used in the current App.tsx JSX. App.tsx still renders the layout grid directly. They're available for future use if we want to push layout structure out of App.tsx.

### localStorage keys

New persistence keys added by `useLayout`:
- `wbu-left-width` (was previously unpersisted)
- `wbu-right-width` (was previously unpersisted)
- `wbu-search-width` (was previously unpersisted)

Existing keys preserved:
- `wbu-ai-sidebar` (managed by `useLayout`)
- `wbu-left-panel-hidden` (managed by `useLayout` + `useActivityRouter`)
- `wbu_token`, `wbu_theme_settings` (managed in App.tsx / useAuth)

### Callback stability

All callbacks returned from feature hooks use `useCallback` with appropriate dependency arrays. App.tsx must NOT re-wrap these in additional `useCallback` layers — use them directly to avoid stale closures.

### `useFileOperations` re-exports helpers

```ts
import { useFileOperations, isImageFile, isDocxFile } from './features/files/useFileOperations';
```

These were previously defined as plain functions at the top of App.tsx. They're now exported from the file operations module.

---

## 11. Quick Reference: Common Change Scenarios

### "Add a new button to the Header"

1. Add the onClick prop to `HeaderProps` in `Header.tsx`
2. Implement the handler in `App.tsx` (or in the relevant feature hook)
3. Pass the handler from App.tsx to `<Header>`

### "Add a new Activity Bar panel"

1. Add the panel name to the `ActivityType` union in `useActivityRouter.ts`
2. Add the icon in `ActivityBar.tsx` in the existing icons list
3. Add the conditional rendering in App.tsx JSX (inside the `activeActivity === '...'` chain)
4. Create the panel component in `components/`

### "Add a new file operation feature"

1. Add the API call in `services/api.ts`
2. Add the operation to `hooks/useFiles.ts` if it's a core file mutation
3. Create a convenience handler in `features/files/useFileOperations.ts` if it needs undo/redo wiring
4. Export the handler from `useFileOperations`
5. Destructure in App.tsx and pass to the relevant component

### "Fix a bug in image saving"

1. Look at `convertProxyUrlsToServerUrls` in `App.tsx` — this runs before every save
2. Check `handleSave` in `App.tsx` — it calls `saveCurrentFile` from `useFileOperations`
3. Follow the flow: editor onChange → tab content → handleSave → proxy conversion → saveCurrentFile → API call

---

*Document version: 1.0 — matches WORBI v6.1.0 refactor state*