# App.tsx Refactor — Detailed Execution Plan

**Version:** v6.1.0+  
**Date:** 2026-05-04  
**Status:** Ready for execution  
**Target:** Wire 10 existing feature modules + create 2 new modules into App.tsx  
**Realistic Line Reduction:** ~330 lines extracted (App.tsx: 1,578 → ~1,248 lines)  
**Pessimistic Estimate:** ~250-400 lines (depending on what cross-cutting concerns stay inline)

---

## 1. Current State Inventory

### 1.1 App.tsx Concerns (1,578 lines)

App.tsx currently manages ~17 distinct concerns inline. The following table maps each concern to its approximate line range and whether a feature module already exists for it:

| Concern | Approx. Lines | Extracted Module Exists? | Module Path |
|---------|--------------|------------------------|-------------|
| Auth state + login gate | L56, L34, L27 | ✅ Yes (wired in main.tsx) | `features/auth/AuthProvider.tsx` |
| `isImageFile` / `isDocxFile` helpers | L41-50 | ✅ Yes (duplicated) | `features/files/useFileOperations.ts` |
| `ActivityType` type alias | L52 | ✅ Yes (duplicated) | `features/navigation/useActivityRouter.ts` |
| Layout state (widths, hidden, sidebar) | L57-70 | ✅ Yes | `features/layout/useLayout.ts` |
| `toggleAISidebar` / `toggleLeftPanel` | L172-185 | ✅ Yes | `features/layout/useLayout.ts` |
| Activity routing + `handleActivitySwitch` | L59, L187-195 | ✅ Yes | `features/navigation/useActivityRouter.ts` |
| `tagsShowAddTag` + reset effect | L66, L354-358 | ✅ Yes | `features/navigation/useActivityRouter.ts` |
| `showSettings` toggle | L65 | ✅ Yes | `features/navigation/useSettings.ts` |
| Sidebar icon visibility (`hiddenIcons`) | L78-103 | ❌ Partial (not in useLayout) | — |
| Batch selection state + handlers | L105-106, L993-1052 | ✅ Yes | `features/files/useBatchSelection.ts` |
| Graph state (`graphModalData`, `useGraph`) | L109-110, L1207-1231 | ❌ No | — |
| File CRUD + undo/redo wiring | L212-251 | ✅ Yes | `features/files/useFileOperations.ts` |
| File operation callbacks | L550-688 | ✅ Yes | `features/files/useFileOperations.ts` |
| Tab management (close, switch, dirty) | L691-726 | ❌ No | — |
| Image proxy conversion | L365-486 | ✅ Yes | `features/editor/useImageConversion.ts` |
| `handleSave` / `handleRestore` | L488-515 | Cross-cutting (stays) | — |
| `handleFileSelect` | L517-548 | Cross-cutting (stays) | — |
| Keyboard shortcuts | L945-964 | ✅ Yes | `features/keyboard/useKeyboardShortcuts.ts` |
| `beforeunload` warning | L967-982 | ✅ Yes | `features/editor/useUnsavedWarning.ts` |
| Computed values (dirty, canRestore) | L985-990 | ❌ No | — |
| Session restore | L306-351 | Cross-cutting (stays) | — |
| Auth transition + theme init | L270-298 | App-level (stays) | — |
| Dialog state (confirm, prompt, folderPicker) | L113-170 | Shared infra (stays) | — |
| DOCX import/export, PDF export | L776-930 | Cross-cutting (stays) | — |
| Export functions (download, PDF, DOCX) | L730-930 | Cross-cutting (stays) | — |

### 1.2 Feature Modules That Exist (11 Files)

| File | Lines | Status |
|------|-------|--------|
| `features/layout/useLayout.ts` | ~160 | Compiled, NOT wired in App.tsx |
| `features/layout/LayoutContext.tsx` | 53 | Compiled, NOT wired |
| `features/layout/AppLayout.tsx` | 99 | Compiled, NOT wired |
| `features/auth/AuthProvider.tsx` | 34 | Wired in main.tsx, App.tsx still uses `useAuth()` directly |
| `features/navigation/useActivityRouter.ts` | 43 | Compiled, NOT wired |
| `features/navigation/useSettings.ts` | 10 | Compiled, NOT wired |
| `features/files/useFileOperations.ts` | 220 | Compiled, NOT wired |
| `features/files/useBatchSelection.ts` | 82 | Compiled, NOT wired |
| `features/editor/useImageConversion.ts` | 121 | Compiled, NOT wired |
| `features/editor/useUnsavedWarning.ts` | 27 | Compiled, NOT wired |
| `features/keyboard/useKeyboardShortcuts.ts` | 29 | Compiled, NOT wired |

### 1.3 What STAYS in App.tsx (Cross-Cutting Concerns)

These concerns wire across 3+ feature boundaries and extracting them would create circular dependencies:

| Concern | Reason |
|---------|--------|
| Image proxy conversion callbacks (`handleSave`, `handleRestore`, `openFileWithConversion`) | Wires tabs from file ops + proxy conversion functions |
| Dialog infrastructure (confirm, prompt, folderPicker) | Shared by file ops, batch selection, dirty close |
| `handleFileSelect` | Cross-cuts dialogs + files + image insertion |
| `handleCreateFileFromEditor` | Cross-cuts file ops + proxy conversion + loadFiles |
| DOCX import/export, PDF export, download | Each uses 3-4 features |
| `handleInsertImageUrl` | Uses fetch + blob URLs |
| Activity panel rendering switch | Orchestrator's job to compose panels |
| Modal rendering (template, compile, generate, graph, help) | App-level composition |
| Session restore | Cross-cuts nav + files |
| Auth transition + theme init + initial load | App-level bootstrap |
| `handleHandleTranscription` (image generator) | Cross-cuts createFile + updateFile + proxy |
| `handleTabCloseOthers`, `handleTabCloseAll`, `handleConfirmDirtyClose` | Uses showConfirm dialog |

---

## 2. Recommended Execution Order

**Order:** Step 1 → Step 3 → Step 2 → Step 5 → Step 4 → Step 6

**Rationale:** Smallest and safest steps first to build confidence. The biggest and riskiest change (file operations) is second-to-last so any issues are isolated. The new module creation (Step 6) is last since it has no dependencies on prior steps.

---

## 3. Step-by-Step Execution Plan

### Step 1: Wire Auth Context into App.tsx

**Estimated lines saved:** ~10  
**Risk:** Low — AuthProvider is already wired in main.tsx  
**Estimated time:** 5 minutes

#### 1A: Update App.tsx imports

1. Remove the `import useAuth from './hooks/useAuth';` line.
2. Remove the `import Login from './pages/Login';` line.
3. Add `import { useAuthContext } from './features/auth/AuthProvider';`.

#### 1B: Replace auth hook call

1. Find the line that calls `useAuth()` at the top of the App function.
2. Replace it with `useAuthContext()`.
3. Destructure the same values: `user`, `isAuthenticated`, `login`, `logout`.

#### 1C: Remove the login gate from JSX

1. Locate the JSX block that renders `<Login>` when `!isAuthenticated`.
2. Remove this conditional render entirely — App.tsx is only rendered when authenticated because AuthProvider gates it.

#### 1D: Verify the auth transition effect still works

1. Confirm the `useEffect` that resets AI sidebar on fresh login (around line 270) still compiles. It references `isAuthenticated` and `setShowAISidebar`, both of which are still available.
2. This effect stays inline since it crosses feature boundaries (auth → layout → LLM).

#### Verification Checklist

- [ ] App compiles with no TypeScript errors
- [ ] Login screen appears when not authenticated (rendered by AuthProvider)
- [ ] Main UI appears after login
- [ ] Auth transition effect resets AI sidebar on fresh login
- [ ] LLM health check re-runs on login
- [ ] No console errors related to auth context

---

### Step 3: Wire Navigation (Activity Router + Settings)

**Estimated lines saved:** ~20  
**Risk:** Low — self-contained state  
**Estimated time:** 10 minutes

#### 3A: Add imports

1. Add `import { useActivityRouter, type ActivityType } from './features/navigation/useActivityRouter';`
2. Add `import { useSettings } from './features/navigation/useSettings';`
3. Remove the inline `type ActivityType = ...` definition (now imported from the module).

#### 3B: Replace activity state

1. Remove the `useState` call for `activeActivity`.
2. Remove the `useState` call for `tagsShowAddTag`.
3. Remove the `useState` call for `showSettings`.
4. Remove the `handleActivitySwitch` callback definition.
5. Remove the `useEffect` that resets `tagsShowAddTag` when activity changes.
6. Add the hook calls:
   - `const nav = useActivityRouter(toggleLeftPanel, setLeftPanelHidden);` — Note: at this point, `toggleLeftPanel` and `setLeftPanelHidden` are still inline (not yet wired from useLayout). This is fine — they'll be replaced in Step 2.
   - Destructure: `activeActivity`, `setActiveActivity`, `tagsShowAddTag`, `handleActivitySwitch`, `handleOpenTagSidebar`.
   - `const { showSettings, setShowSettings } = useSettings();`

#### 3C: Update JSX references

1. Ensure `handleActivitySwitch` is still passed to ActivityBar with the same prop name.
2. Ensure `tagsShowAddTag` is still passed to TagManager with the same prop name.
3. Ensure `showSettings` is still used for the Settings modal render.
4. Ensure `setActiveActivity` is used in session restore (stays inline).

#### Verification Checklist

- [ ] App compiles with no TypeScript errors
- [ ] All 10 activity types work (explorer, search, starred, tags, timeline, locations, graph, images, outline, reminders)
- [ ] Same-activity click toggles left panel
- [ ] Different-activity click switches and unhides panel
- [ ] Tag sidebar opens from + button in editor toolbar
- [ ] Settings modal opens and closes
- [ ] Session restore still sets activity correctly

---

### Step 2: Wire Layout

**Estimated lines saved:** ~80  
**Risk:** Medium — layout state is pervasive  
**Estimated time:** 20 minutes

#### 2A: Extend `features/layout/useLayout.ts`

Before wiring, the existing `useLayout.ts` must be extended to include concerns currently in App.tsx:

1. Add the `HideableIcon` type alias (union of all ActivityType values + 'ai').
2. Add `visibilityRefreshKey` state (number, initial 0).
3. Add a `useEffect` that listens for `storage` and `wbu-sidebar-visibility-change` events, incrementing `visibilityRefreshKey` on each event.
4. Add `hiddenIcons` as a `useMemo` that reads `localStorage('wbu_sidebar_visibility')`, parses the JSON, and builds a Set of hidden icon keys. Depend on `visibilityRefreshKey`.
5. Export `hiddenIcons` and `visibilityRefreshKey` from the hook's return value.
6. Import `ActivityType` from the navigation module (or define the type inline to avoid circular deps — prefer inline definition of `HideableIcon` in useLayout.ts).

#### 2B: Add imports to App.tsx

1. Add `import { useLayout } from './features/layout/useLayout';`.

#### 2C: Replace inline layout state

1. Remove the `useState` calls for: `leftWidth`, `rightWidth`, `searchWidth`, `leftPanelHidden`, `showAISidebar`.
2. Remove the `useState` call for `visibilityRefreshKey`.
3. Remove the `useEffect` for the storage listener (sidebar icon visibility).
4. Remove the `useMemo` for `hiddenIcons`.
5. Remove the `toggleAISidebar` callback definition.
6. Remove the `toggleLeftPanel` callback definition.
7. Add: `const layout = useLayout();`
8. Destructure all needed values from `layout`:
   - `leftWidth`, `setLeftWidth`, `rightWidth`, `setRightWidth`, `searchWidth`, `setSearchWidth`
   - `leftPanelHidden`, `setLeftPanelHidden`
   - `showAISidebar`, `setShowAISidebar`
   - `toggleAISidebar`, `toggleLeftPanel`
   - `resizeLeftPanel`, `resizeRightPanel`, `resizeSearchPanel`
   - `hiddenIcons`, `visibilityRefreshKey`

#### 2D: Update the activity router call

1. Update the `useActivityRouter(toggleLeftPanel, setLeftPanelHidden)` call — these values now come from `layout`.

#### 2E: Replace inline resizer handlers in JSX

1. Find the left panel resizer div in the JSX (the `<div>` with `onMouseDown` for left panel resizing).
2. Replace the inline `onMouseDown` handler with `resizeLeftPanel`.
3. Find the right panel resizer div (the `<div>` with `onMouseDown` for right panel resizing).
4. Replace the inline `onMouseDown` handler with `resizeRightPanel`.
5. If there's a search panel resizer, replace it with `resizeSearchPanel`.

#### 2F: Update JSX references

1. Ensure `hiddenIcons` is still passed to ActivityBar (or wherever sidebar icon visibility is used).
2. Ensure `leftWidth`, `rightWidth`, `searchWidth` are still used for panel width styling.
3. Ensure `leftPanelHidden` and `showAISidebar` are still used for conditional rendering.

#### Verification Checklist

- [ ] App compiles with no TypeScript errors
- [ ] Left panel resizing works (draggable divider)
- [ ] Right panel (AI sidebar) resizing works
- [ ] AI sidebar toggle works and state persists across reload
- [ ] Left panel hide/show works (state persists)
- [ ] Sidebar icon visibility works (icons hide/show via context menu)
- [ ] Panel widths persist across page reload
- [ ] Activity router still receives correct toggleLeftPanel/setLeftPanelHidden

---

### Step 5: Wire Editor Modules (Image Conversion, Unsaved Warning, Keyboard Shortcuts)

**Estimated lines saved:** ~70  
**Risk:** Low — each module is self-contained  
**Estimated time:** 15 minutes

#### 5A: Wire `useImageConversion` (~30 lines saved)

1. Add `import { useImageConversion } from './features/editor/useImageConversion';`.
2. Remove the `IMAGE_EXTENSIONS` constant at the top of App.tsx (now internal to the module).
3. Remove the `isImageFile()` helper function (re-exported from useFileOperations in Step 4).
4. Remove the `isDocxFile()` helper function (re-exported from useFileOperations in Step 4).
5. Remove the `extractImagePaths()` function.
6. Remove the `extractWorkspaceImagePaths()` function.
7. Remove the `convertServerUrlsToProxyUrls` callback.
8. Remove the `convertProxyUrlsToServerUrls` callback.
9. Add: `const { convertServerUrlsToProxyUrls, convertProxyUrlsToServerUrls } = useImageConversion();`
10. Verify all call sites still work:
    - `handleSave` uses `convertProxyUrlsToServerUrls` — still inline, no change needed.
    - `openFileWithConversion` uses `convertServerUrlsToProxyUrls` — still inline, no change needed.

#### 5B: Wire `useUnsavedWarning` (~15 lines saved)

1. Add `import { useUnsavedWarning } from './features/editor/useUnsavedWarning';`.
2. Remove the `useEffect` that registers the `beforeunload` listener.
3. Add: `useUnsavedWarning(tabs);` — Note: `tabs` is still inline at this point (from useFiles). This is fine — it'll come from fileOps in Step 4.

#### 5C: Wire `useKeyboardShortcuts` (~20 lines saved)

1. Add `import { useKeyboardShortcuts } from './features/keyboard/useKeyboardShortcuts';`.
2. Remove the `useEffect` that registers the `keydown` listener (Ctrl+S, Ctrl+Shift+N, F1).
3. Add: `useKeyboardShortcuts(handleSave, setShowTemplateModal, setShowHelp);`
4. Verify `handleSave` is still defined inline (it is — it crosses feature boundaries).
5. Verify `setShowTemplateModal` and `setShowHelp` are still available (they are — modal state stays inline).

#### Verification Checklist

- [ ] App compiles with no TypeScript errors
- [ ] Image display in editor works (proxy URLs sign correctly)
- [ ] Image URLs save correctly (proxy → server conversion)
- [ ] Workspace-relative image paths work
- [ ] `beforeunload` warning appears with unsaved changes
- [ ] Ctrl+S saves the current file
- [ ] Ctrl+Shift+N opens the new-from-template modal
- [ ] F1 toggles the help panel
- [ ] No console errors related to image conversion

---

### Step 4: Wire File Operations + Batch Selection

**Estimated lines saved:** ~100  
**Risk:** High — file ops touch every component  
**Estimated time:** 30 minutes

#### 4A: Add imports

1. Add `import { useFileOperations, isImageFile, isDocxFile } from './features/files/useFileOperations';`.
2. Add `import { useBatchSelection } from './features/files/useBatchSelection';`.
3. Remove `import { useFiles } from './hooks/useFiles';`.
4. Remove `import { useFileSystemUndoRedo } from './hooks/useFileSystemUndoRedo';`.

#### 4B: Replace file operations wiring

1. Remove the `useFileSystemUndoRedo()` call.
2. Remove the destructuring of `canUndo`, `canRedo`, `undoFs`, `redoFs`, `pushUndoOp`, `refreshRef`.
3. Remove the `useFiles(pushUndoOp, showFolderPicker)` call.
4. Remove the destructuring of all useFiles values (files, currentPath, content, loading, error, setContent, tabs, activeTabId, loadFiles, openFile, openTab, saveCurrentFile, restoreToOriginal, newFile, newFolder, deleteSelected, renameSelected, copySelected, moveSelected, uploadImageFile, uploadFileToFolder, closeTab, switchTab, updateTabContent, closeOtherTabs, closeAllTabs, batchDelete, batchCopy, batchMove).
5. Remove the `useEffect` that wires `refreshRef.current = () => loadFiles(explorerPath)`.
6. Remove the `explorerPath` state declaration.
7. Add: `const fileOps = useFileOperations(showFolderPicker);`
8. Destructure all needed values from `fileOps` (same values as above, plus `explorerPath`, `setExplorerPath`, `handleNewFile`, `handleDelete`, `handleRename`, `handleCopy`, `handleMove`, `handleBack`, `handleBackToRoot`, `handleBackToSegment`, `handleNewFolder`, `handleUploadFiles`, `createFileWithContent`).

#### 4C: Remove inline callbacks

1. Remove the `handleNewFile` callback definition.
2. Remove the `handleDelete` callback definition.
3. Remove the `handleRename` callback definition.
4. Remove the `handleCopy` callback definition.
5. Remove the `handleMove` callback definition.
6. Remove the `handleBack` callback definition.
7. Remove the `handleBackToRoot` callback definition.
8. Remove the `handleBackToSegment` callback definition.
9. Remove the `handleNewFolder` callback definition.
10. Remove the `handleUploadFiles` callback definition.

#### 4D: Wire batch selection

1. Remove the `selectionMode` state declaration.
2. Remove the `selectedPaths` state declaration.
3. Remove the inline batch selection handlers (`handleToggleSelectionMode`, `handleToggleSelect`, `handleSelectAll`, `handleClearSelection`, `handleBatchDelete`, `handleBatchCopy`, `handleBatchMove`).
4. Add: `const batch = useBatchSelection(fileOps.explorerPath, fileOps.batchDelete, fileOps.batchCopy, fileOps.batchMove, showConfirm, showFolderPicker);`
5. Destructure: `selectionMode`, `setSelectionMode`, `selectedPaths`, `setSelectedPaths`, `handleToggleSelectionMode`, `handleToggleSelect`, `handleSelectAll`, `handleClearSelection`, `handleBatchDelete`, `handleBatchCopy`, `handleBatchMove`.

#### 4E: Update all JSX references

1. Replace all references to `files` with `fileOps.files` (or use destructured values).
2. Replace all references to `tabs` with `fileOps.tabs`.
3. Replace all references to `activeTabId` with `fileOps.activeTabId`.
4. Replace all references to `content` with `fileOps.content`.
5. Replace all references to `explorerPath` with `fileOps.explorerPath`.
6. Replace all references to `canUndo`, `canRedo`, `undoFs`, `redoFs` with values from `fileOps`.
7. Replace all references to `handleNewFile`, `handleDelete`, etc. with values from `fileOps`.
8. Replace all references to batch selection values with values from `batch`.

#### 4F: Update cross-cutting callbacks

These callbacks stay inline but reference file ops values — verify they still compile:

1. `handleSave` — references `tabs`, `activeTabId`, `saveCurrentFile`.
2. `handleRestore` — references `tabs`, `activeTabId`, `restoreToOriginal`.
3. `openFileWithConversion` — references `openFile`, `convertServerUrlsToProxyUrls`.
4. `handleFileSelect` — references `openTab`, `showConfirm`, `isImageFile`.
5. `handleCreateFileFromEditor` — references `newFile`, `openFileWithConversion`, `loadFiles`, `explorerPath`, `files`.
6. `handleSessionRestore` — references `setActiveActivity`, `setExplorerPath`, `loadFiles`, `openTab`.
7. `handleHandleTranscription` — references `createFileWithContent`, `updateFile`.
8. Tab handlers (`handleTabClose`, `handleTabSwitch`, etc.) — reference `tabs`, `closeTab`, `switchTab`.

#### 4G: Update `useUnsavedWarning` reference

1. Update the `useUnsavedWarning(tabs)` call to use `fileOps.tabs` (or the destructured `tabs`).

#### 4H: Remove duplicate helper functions

1. If `isImageFile` and `isDocxFile` are still defined inline, remove them — they're now imported from `useFileOperations`.

#### Verification Checklist

- [ ] App compiles with no TypeScript errors
- [ ] Creating files works (new file button)
- [ ] Deleting files/folders works (with confirm dialog)
- [ ] Renaming files works
- [ ] Copy and move file operations work
- [ ] Opening a file loads content into the editor
- [ ] Saving a file persists content to disk (Ctrl+S + toolbar)
- [ ] File upload works (drag/drop and upload button)
- [ ] DOCX upload (via file upload) works
- [ ] Batch selection works (select all, batch delete, batch copy, batch move)
- [ ] Explorer navigation works (back, back to root, back to segment)
- [ ] Undo/redo file operations work
- [ ] Image insertion works (click image in explorer → confirm → insert)
- [ ] Tab operations work (close, switch, close others, close all)
- [ ] Dirty tab close shows 3-button confirmation
- [ ] No console errors related to file operations

---

### Step 6: Create New Modules (Graph Manager + Tab Manager)

**Estimated lines saved:** ~50  
**Risk:** Medium — new code  
**Estimated time:** 20 minutes

#### 6A: Create `features/graph/useGraphManager.ts`

1. Create a new file at `client/src/features/graph/useGraphManager.ts`.
2. Import `useGraph` from `hooks/useGraph`.
3. Import types `GraphNode` and `GraphEdge` from `services/api`.
4. Create the `useGraphManager` function that accepts `username: string | undefined`.
5. Internally call `useGraph(username)` to get graph operations.
6. Manage `graphModalData` state locally.
7. Implement `handleGraphGenerate(seedPath, relTypes, useAI, depth)` — calls the internal graph hook's generate method, stores result in graphModalData.
8. Implement `handleGraphViewCached()` — loads cached graph data into graphModalData.
9. Implement `handleGraphClear()` — clears graph cache and sets graphModalData to null.
10. Return: `graphModalData`, `setGraphModalData`, `handleGraphGenerate`, `handleGraphViewCached`, `handleGraphClear`, `loading`, `error`, `hasCache`.

#### 6B: Wire `useGraphManager` into App.tsx

1. Add `import { useGraphManager } from './features/graph/useGraphManager';`.
2. Remove `import { useGraph } from './hooks/useGraph';`.
3. Remove the `graphModalData` state declaration.
4. Remove the `graph = useGraph(user?.username)` call.
5. Add: `const graphManager = useGraphManager(user?.username);`
6. Destructure: `graphModalData`, `setGraphModalData`, `handleGraphGenerate`, `handleGraphViewCached`, `handleGraphClear`, `graphLoading`, `graphError`, `graphHasCache`.
7. Remove the inline `handleGraphGenerate`, `handleGraphViewCached`, `handleGraphClear` callback definitions.
8. Update all JSX references to use the new variable names.
9. Ensure `GraphModal` is still rendered with the correct props (graphModalData, onClose, etc.).
10. Ensure `RelationshipGraphSidebar` is still wired correctly.

#### 6C: Create `features/editor/useTabManager.ts`

1. Create a new file at `client/src/features/editor/useTabManager.ts`.
2. Define a `TabInfo` type (or accept the Tab type from api).
3. Create the `useTabManager` function that accepts:
   - `tabs: Record<string, Tab>`
   - `activeTabId: string | null`
   - `content: string`
   - `closeTab: (id: string) => void`
   - `switchTab: (id: string) => void`
   - `closeOtherTabs: (id: string) => void`
   - `closeAllTabs: () => void`
4. Implement `handleTabClose(id)` — checks dirty state, if dirty calls a confirm callback, else closes.
   - NOTE: Since dirty close requires `showConfirm` (dialog state in App.tsx), the hook should accept `onDirtyClose: (tabId: string, tabName: string) => void` as a parameter. App.tsx passes `handleConfirmDirtyClose` inline.
5. Implement `handleTabSwitch(id)` — calls switchTab.
6. Implement `handleTabCloseOthers(id)` — calls closeOtherTabs.
7. Implement `handleTabCloseAll()` — calls closeAllTabs.
8. Compute `dirty` from the active tab's dirty flag (useMemo).
9. Compute `canRestore` from the active tab's originalContent vs content (useMemo).
10. Compute `wordCount` from the active content (useMemo).
11. Compute `currentFileName` from the active tab's path (useMemo).
12. Return: `handleTabClose`, `handleTabSwitch`, `handleTabCloseOthers`, `handleTabCloseAll`, `dirty`, `canRestore`, `wordCount`, `currentFileName`.

#### 6D: Wire `useTabManager` into App.tsx

1. Add `import { useTabManager } from './features/editor/useTabManager';`.
2. Remove the inline `handleTabClose`, `handleTabSwitch`, `handleTabCloseOthers`, `handleTabCloseAll` callback definitions.
3. Remove the computed `dirty`, `canRestore`, `wordCount`, `currentFileName` values.
4. Add: `const tabManager = useTabManager({ tabs, activeTabId, content: fileOps.content, closeTab, switchTab, closeOtherTabs, closeAllTabs, onDirtyClose: handleConfirmDirtyClose });`
5. Destructure: `handleTabClose`, `handleTabSwitch`, `handleTabCloseOthers`, `handleTabCloseAll`, `dirty`, `canRestore`, `wordCount`, `currentFileName`.
6. Keep `handleConfirmDirtyClose` inline (it uses `showConfirm` dialog).
7. Update all JSX references to use the new values.

#### 6E: Update computed value references

1. Verify `dirty` is still used for the save button / toolbar state.
2. Verify `canRestore` is still used for the restore button.
3. Verify `wordCount` is still passed to StatusBar.
4. Verify `currentFileName` is still used in the editor title / StatusBar.

#### Verification Checklist

- [ ] App compiles with no TypeScript errors
- [ ] Graph generation works from RelationshipGraphSidebar
- [ ] Graph modal opens and displays nodes/edges
- [ ] View cached graph works
- [ ] Clear graph cache works
- [ ] Node click in graph modal opens the file
- [ ] Tab close/switch/close others/close all work
- [ ] Dirty tab close shows 3-button confirmation
- [ ] Word count displays correctly in StatusBar
- [ ] Current file name displays correctly
- [ ] Save/restore button states reflect dirty/canRestore correctly

---

## 4. Final Cleanup (After All Steps)

### 4A: Remove Unused Imports

1. Scan App.tsx for imports no longer used and remove them:
   - `useAuth` (replaced by `useAuthContext`)
   - `useFiles` (moved to useFileOperations)
   - `useFileSystemUndoRedo` (moved to useFileOperations)
   - `useGraph` (moved to useGraphManager)
   - `Login` (rendered by AuthProvider)
   - `type GraphNode, GraphEdge` (if only used by useGraphManager, remove from App.tsx)

### 4B: Remove Duplicate Type Definitions

1. Remove the inline `ActivityType` type (imported from useActivityRouter).
2. Remove the inline `isImageFile` function (imported from useFileOperations).
3. Remove the inline `isDocxFile` function (imported from useFileOperations).
4. Remove the inline `IMAGE_EXTENSIONS` constant (internal to useImageConversion).

### 4C: Verify Feature Module Exports

1. Ensure `useActivityRouter.ts` exports `ActivityType` as a type.
2. Ensure `useFileOperations.ts` exports `isImageFile` and `isDocxFile` as named exports.
3. Ensure `useLayout.ts` exports `hiddenIcons` and `visibilityRefreshKey` in the return value.

### 4D: Check for Circular Dependencies

1. Verify no feature module imports from another feature module (except useTabManager → useFileOperations types).
2. Check browser console and build output for circular dependency warnings.

### 4E: App.tsx Line Count

1. Count the lines in App.tsx after all steps.
2. Target: Under 1,300 lines (realistic) — under 1,000 if JSX extraction into AppLayout is also done.

---

## 5. Rollback Plan

1. **Each step is a separate git commit** on a feature branch (`refactor/app-split-wire`).
2. **Test thoroughly after each commit** before proceeding to the next step.
3. **If a step introduces a bug**, revert that specific commit (`git revert <commit-hash>`) and fix it in isolation.
4. **The current App.tsx (1,578 lines) is the baseline** — if the refactor goes badly, revert all commits.
5. **Feature modules are additive** — they can exist without being wired, so partial progress is safe. If Step 4 (file ops) introduces a critical bug, you can revert it and Steps 1, 3, 2, 5 remain intact.

---

## 6. Final Verification Checklist (Complete)

### Functional Tests (after all steps)
- [ ] App compiles with no TypeScript errors
- [ ] App renders without React console errors
- [ ] Login screen appears when not authenticated
- [ ] Main UI appears after login

### Layout (Step 2)
- [ ] Left panel resizing works (draggable divider)
- [ ] Right panel (AI sidebar) resizing works
- [ ] AI sidebar toggle works and state persists across reload
- [ ] Left panel hide/show works (state persists)
- [ ] Sidebar icon visibility works (icons hide/show via context menu)
- [ ] Panel widths persist across page reload

### Auth (Step 1)
- [ ] Login/logout still works
- [ ] Protected routes still require auth
- [ ] Auth transition resets AI sidebar on fresh login

### Navigation (Step 3)
- [ ] Activity switching works for ALL 10 types (explorer, search, starred, tags, timeline, locations, graph, images, outline, reminders)
- [ ] Same-activity click toggles left panel
- [ ] Different-activity click switches and unhides panel
- [ ] Tag sidebar opens from + button in editor toolbar
- [ ] Settings modal opens and closes

### File Operations (Step 4)
- [ ] Creating files works (new file button)
- [ ] Deleting files/folders works (with confirm dialog)
- [ ] Renaming files works
- [ ] Copy and move file operations work
- [ ] Opening a file loads content into the editor
- [ ] Saving a file persists content to disk (Ctrl+S + toolbar)
- [ ] File upload works (drag/drop and upload button)
- [ ] DOCX upload (via file upload) works
- [ ] Batch selection works (select all, batch delete, batch copy, batch move)
- [ ] Explorer navigation works (back, back to root, back to segment)
- [ ] Undo/redo file operations work
- [ ] Image insertion works (click image in explorer → confirm → insert)

### Editor (Step 5)
- [ ] All keyboard shortcuts work (Ctrl+S, Ctrl+Shift+N, F1)
- [ ] `beforeunload` warning appears with unsaved changes
- [ ] Image proxy URLs convert correctly on save (proxy → server) and load (server → proxy)
- [ ] Workspace-relative image paths work correctly

### Graph (Step 6)
- [ ] Graph generation works from RelationshipGraphSidebar
- [ ] Graph modal opens and displays nodes/edges
- [ ] View cached graph works
- [ ] Clear graph cache works
- [ ] Node click in graph modal opens the file

### Tab Manager (Step 6)
- [ ] Tabs open/close/switch correctly
- [ ] Dirty tab close shows 3-button confirmation
- [ ] Tab close others / close all work
- [ ] Word count displays correctly
- [ ] Current file name displays correctly

### Cross-Cutting
- [ ] DOCX export preserves 2-column layout as table
- [ ] PDF export works
- [ ] Download file works
- [ ] Session restore works (tabs, activity, explorer path restored on reload)
- [ ] Welcome screen shows recent/starred files
- [ ] New from template modal works
- [ ] Compile Story Bible modal works
- [ ] Generate with AI modal works
- [ ] Help Panel opens/closes with F1
- [ ] Image Generator panel works (generate, select, insert)
- [ ] Image Generator transcription creates file correctly
- [ ] Bookmark/Outline sidebar works
- [ ] Location Manager works
- [ ] Timeline View works
- [ ] Search panel works

### Code Quality
- [ ] App.tsx is under 1,300 lines (realistic target)
- [ ] No circular import warnings
- [ ] No unused imports in App.tsx
- [ ] All feature hooks use `useCallback` with correct dependency arrays
- [ ] React DevTools shows clean component tree
- [ ] No feature regressions: every existing feature functions identically to before the refactor

---

## 7. Summary of Changes by File

### Files Modified

| File | Changes |
|------|---------|
| `client/src/App.tsx` | Replace inline logic with feature hook calls; remove duplicate functions; update imports |
| `client/src/features/layout/useLayout.ts` | Add `hiddenIcons`, `visibilityRefreshKey`, storage listener, `HideableIcon` type |

### Files Created

| File | Purpose |
|------|---------|
| `client/src/features/graph/useGraphManager.ts` | Graph modal state + generate/view/clear callbacks |
| `client/src/features/editor/useTabManager.ts` | Tab CRUD handlers + computed values (dirty, wordCount, etc.) |

### Files NOT Changed

| File | Reason |
|------|--------|
| `client/src/main.tsx` | AuthProvider already wired |
| `client/src/features/auth/AuthProvider.tsx` | Already complete |
| `client/src/features/navigation/useActivityRouter.ts` | Already complete |
| `client/src/features/navigation/useSettings.ts` | Already complete |
| `client/src/features/files/useFileOperations.ts` | Already complete |
| `client/src/features/files/useBatchSelection.ts` | Already complete |
| `client/src/features/editor/useImageConversion.ts` | Already complete |
| `client/src/features/editor/useUnsavedWarning.ts` | Already complete |
| `client/src/features/keyboard/useKeyboardShortcuts.ts` | Already complete |
| `client/src/features/layout/LayoutContext.tsx` | Available but not wired in (future use) |
| `client/src/features/layout/AppLayout.tsx` | Available but not wired in (future use) |
| All hooks in `hooks/` | Used internally by feature modules |
| All components in `components/` | Props come from App.tsx regardless of state location |

---

*Document version: 1.0 — matches WORBI App.tsx at 1,578 lines (2026-05-04)*  
*Supersedes: APP_TSX_REFACTOR.md, APP_REFACTOR_HINTS.md for current codebase state*  
*Companion to: APP_REFACTOR_TASK.md (gap analysis and target architecture)*