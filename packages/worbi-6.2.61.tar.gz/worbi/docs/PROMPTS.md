# WORBI Agent Prompts

Master prompt for AI agents (Cline/Qwen3.6-27b) working on the WORBI project.

---

## WORKING ON WORBI PROJECT — Agent Instructions

### 1. Project Context

- **Project:** WORBI by Nymphs (WorldBuilder UI) — rich text document editor for world-building
- **Location:** `/home/nymph/Nymphs-Brain/WORBI`
- **Tech:** React + TypeScript + Vite + Tailwind (client), Node.js + Express (server)
- **Structure:** npm workspaces monorepo with `server/` and `client/` directories
- **UI:** Dark theme only, `lucide-react` icons only

---

### 2. Skill Loading Protocol

On **EVERY task**, load skills in this order:

1. **ALWAYS:** `cline-thinking` (reasoning guardrails) + `worbi-project` (context) + `worbi-conventions` (rules)
2. **THEN load based on task type:**
   - Backend work → `worbi-api` + `worbi-architecture`
   - Frontend/UI work → `worbi-architecture` + `worbi-ui`
   - App.tsx changes → `worbi-app-refactor` + `worbi-architecture`
   - New features → `worbi-conventions` + `worbi-architecture`
   - Tests → `worbi-tests`
   - Safety check → `nymphs-safety`
   - ≤5 line changes → `small-change-delegation`

---

### 3. Workflow: Before Making Changes

- [ ] Restate the goal in your own words
- [ ] Identify all files involved — **READ them first**, don't assume contents
- [ ] Check for handoff docs in `docs/handoff/` that specify the feature
- [ ] Check for relevant MCP skills and load them
- [ ] Enumerate at least 3 edge cases that could go wrong
- [ ] Determine the smallest change that solves the problem

---

### 4. Workflow: During Changes

- [ ] Make changes in **small batches** — one file at a time
- [ ] When editing large files: make a `.new` copy first, edit the copy, verify it's correct, then overwrite the original
- [ ] Match existing code style (indentation, quotes, import order, naming)
- [ ] Verify every API/function you reference **actually exists** (read the file, don't hallucinate)
- [ ] Use `replace_in_file` for targeted edits, `write_to_file` only for new files or major rewrites
- [ ] Use `context7` (MCP) and `web-forager` (MCP) to look up correct syntax when unsure
- [ ] Monitor context window usage — be aware of remaining tokens with large files

---

### 5. Workflow: After Changes

- [ ] Verify the tool result — read the final file content (auto-formatting may have changed it)
- [ ] Run verification: `npx tsc --noEmit` for TS, `node -c` for JS
- [ ] Compare result to the original request — did you do everything asked, nothing extra?
- [ ] State what was **NOT** done (known gaps)

---

### 6. Server Management

- Start/stop/restart WORBI: use scripts in `/home/nymph/Nymphs-Brain/bin/`
  - `wbu-start`, `wbu-stop` (or equivalent restart script)
- **Restart the app** after code changes before testing

---

### 7. Logging Policy

- **Do NOT `cat` log files** without asking the user first — the user will either permit it or paste the output
- If you need to check logs, ask the user and they will provide the relevant output

---

### 8. Changelog & Documentation (After User Testing)

**Only after the user has thoroughly tested the changes:**

1. Ask if the user is ready to update logs
2. If yes, update `CHANGELOG.md` (format: `## vX.Y.Z — Title (date)` with bullets + `### Files Changed`)
3. Add detailed info to `update_record.md`
4. If `update_record.md` exceeds **1000 lines**: backup it with version numbers in filename, start fresh
5. Update relevant WORBI skills with new information
6. Add tests to `client/tests` and `server/tests` for new additions if they require testing
7. **Do NOT push to GitHub**

---

### 9. Critical Anti-Patterns (DO NOT DO)

- **NEVER** push to GitHub without explicit user instruction
- **NEVER** hallucinate APIs — read the file to confirm the function/method exists
- **NEVER** assume file contents — read first, write second
- **NEVER** chain commands with `&&` (causes crashes)
- **NEVER** introduce new dependencies without updating `package.json`
- **NEVER** add light mode or theme switching
- **NEVER** add icon libraries other than `lucide-react`
- **NEVER** use inline `<style>` tags or CSS modules — use `globals.css`
- **NEVER** silently retry a failed command more than 2 times — diagnose instead

---

### 10. Qwen-Specific Calibration

- **Be direct:** state plan in 1-2 sentences, then act (no verbose preamble)
- **Read files before writing** — don't guess contents
- **Break large tasks** into sequential tool uses — don't try to solve everything at once
- **Use task_progress checklists** for multi-step work
- **Re-read skill files** if context drifts after many messages

---

## How to Use This Prompt

### When to Send It

**Only in your FIRST message of a new Cline session.** Cline retains the prompt context for the entire conversation, so you do NOT need to resend it on follow-up messages.

**Re-send it only when:**
- Starting a brand new Cline chat (previous session ended/closed)
- Switching to a completely different task

**Do NOT resend on:**
- Follow-up messages in the same conversation
- Asking Cline questions about what it's working on
- Requesting small tweaks to what's already in progress

### Step-by-Step

1. Copy everything from "## WORKING ON WORBI PROJECT" through section 10
2. Append your specific task:

```
---

### CURRENT TASK: <Your Feature Name>

<Paste your specific task description here — what you want built, fixed, or changed.
Be specific about the problem, desired behavior, and any files already involved.>
```

3. Paste the **entire thing** as your **first message** to Cline
4. After that, just talk normally — Cline remembers the instructions

### Example

```
### CURRENT TASK: Fix WikiLink broken on mobile

When tapping [[Character Name]] on mobile Safari, the link does nothing.
Desktop works fine. The issue is in WikiLinkPopover.tsx — the onTouchStart
handler doesn't call the same navigation function as onClick.
```

**That's it.** Sections 1-10 are the same every time. Only the "CURRENT TASK" section changes per session.

---

## GitHub Push Prompt (Optional Add-On)

**When to use:** Append this section to your main prompt when you want Cline to commit and push changes to GitHub after completing work.

---

### GITHUB PUSH INSTRUCTIONS

**Copy everything below and append it after your CURRENT TASK section:**

```
---

### GITHUB PUSH AUTHORIZATION

You are AUTHORIZED to commit and push changes to GitHub without asking for confirmation.

**Repository:** `github.com/rauty79/WORBI` (remote: `origin`)
**Branch:** `master` (NOT main)
**Project Path:** `Nymphs-Brain/WORBI/`

#### Before Pushing — Mandatory Checklist
- [ ] Load `worbi-github` skill
- [ ] Run `git status` — verify what will be staged
- [ ] Run `git add -A`
- [ ] Run `git status` again — verify `server/src/data/users.json` is NOT staged
- [ ] If `users.json` IS staged, run `git reset HEAD server/src/data/users.json`
- [ ] Verify no files from `server/data/` are accidentally staged
- [ ] Commit message follows format: `vX.Y.Z: Short Summary` with bullet points per change
- [ ] Use `requires_approval: false` on all git execute_command calls
- [ ] After each git command, verify result (`git status` after add, `git log -1` after commit)

#### Push Workflow
1. `cd Nymphs-Brain/WORBI`
2. `git status` — check current state
3. `git add -A` — stage all changes
4. `git status` — verify `users.json` NOT staged (unstage it if present)
5. `git commit -m "vX.Y.Z: Summary"` — commit with version
6. `git log -1` — verify commit
7. `git push origin master` — push
8. `git status` — confirm "up to date with 'origin/master'"

#### Critical Rules
- `users.json` contains local credentials — must NEVER be committed
- `.gitignore` does NOT unstage already-tracked files — use `git reset HEAD`
- Command output may be incomplete — always verify with follow-up command
- Use `requires_approval: false` on git commands (approval UI may not render in Cline)
```

---

## Prompt Usage Guide

### Why This Structure Works

| Section | Purpose |
|---------|---------|
| 1. Project Context | Grounds the agent in the correct project and tech stack |
| 2. Skill Loading | Ensures relevant skills are loaded in the correct order |
| 3-5. Workflow | Provides explicit Before/During/After checkpoints |
| 6. Server Management | Centralizes knowledge about dev server scripts |
| 7. Logging Policy | Prevents unsafe log file operations |
| 8. Documentation | Defines the post-testing documentation workflow |
| 9. Anti-Patterns | Explicit "never do" list prevents common failures |
| 10. Qwen Calibration | Compensates for known LLM tendencies |
| Current Task | Your specific feature/bug — appended at the bottom each session |
| GitHub Push | Optional add-on — append when you want auto-commit/push |

### Quick Reference

| Do | Don't |
|----|-------|
| Load `cline-thinking` + `worbi-project` + `worbi-conventions` first | Skip skill loading |
| Read files before editing | Assume file contents |
| Small batch changes, one file at a time | Monolithic multi-file edits |
| `.new` copy for large files | Edit large files directly |
| Verify with `npx tsc --noEmit` / `node -c` | Skip verification |
| Ask before `cat`-ting logs | Cat logs without permission |
| Update changelog after user testing | Update changelog before testing |
| Use `wbu-start` / `wbu-stop` scripts | Manually start/stop the server |

---

*Prompt version: 1.1 — added GitHub Push Prompt — matches WORBI v6.2.40+*
