# AI Tools Integration (MCP-Style Function Calling)

> **Version:** v5.1.9
> **Date:** 2026-04-30

## Overview

WORBI's LLM chat supports an MCP-style tool calling system that allows the AI assistant to perform actions beyond text generation. When tools are enabled, the LLM can search the web, read and write workspace files, and more — all governed by a granular permission system.

## Architecture

```
┌─────────────┐     ┌──────────────┐     ┌──────────────────┐
│  ChatPanel  │────▶│  /api/chat   │────▶│  llmService.js   │
│  (Client)   │     │  (Express)   │     │  + toolService   │
└─────────────┘     └──────────────┘     └──────────────────┘
       │                                          │
       │                                          ▼
       │                                 ┌──────────────────┐
       │                                 │ Built-in Tools   │
       │                                 │ (8 tools)        │
       │                                 └──────────────────┘
       │                                          │
       │                    ┌─────────────────────┤
       ▼                    ▼                     ▼
  Status Cards      Tool Activity            Permission Check
  (✅/❌)            Feedback                 (client config)
```

## Tool Calling Flow

1. **User sends a message** with tools enabled (⚡ toggle ON)
2. **Client sends** `POST /api/chat` with `messages[]`, `settings`, and optional `permissions`
3. **Server calls LLM** with system prompt including tool definitions
4. **LLM responds** with either:
   - **Text response** — returned directly to client
   - **Tool call** — JSON block in format `{"name":"tool_name","arguments":{...}}`
5. **Server executes tool** via `toolService.executeTool()` with permission validation
6. **Result fed back** as `tool_result` message to LLM
7. **Steps 4-6 repeat** up to **10 iterations** per user message
8. **Final response** returned to client with `toolActivity[]` array

### Message Format (Tool Calls)

When the LLM wants to use a tool, it responds with a JSON block:

```json
{
  "name": "web_search",
  "arguments": {
    "query": "dragon anatomy medieval folklore"
  }
}
```

The server detects this format, executes the tool, and appends the result as a new assistant message prefixed with `tool_result:`.

### System Prompt

When tools are enabled, the system prompt is augmented with:

```
You have access to the following tools:

1. web_search: Search the internet. Args: {"query": "search terms"}
2. read_file: Read a file. Args: {"path": "folder/file.html"}
3. list_files: List files in a directory. Args: {"path": "folder/"}
...

To use a tool, respond with ONLY a JSON block:
{"name": "tool_name", "arguments": {"arg1": "value1"}}

Tool permissions: web_search=true, file_access=readwrite
```

## Built-in Tools

### 🔍 Web Search

| Property | Value |
|----------|-------|
| **Name** | `web_search` |
| **Description** | Search the internet for information |
| **Permission** | `webSearch: true` |
| **Arguments** | `{ query: string, maxResults?: number }` |
| **Returns** | Formatted list of search results with titles, URLs, and snippets |

### 📄 Read File

| Property | Value |
|----------|-------|
| **Name** | `read_file` |
| **Description** | Read contents of a workspace file |
| **Permission** | `fileAccessLevel: "read" \| "readwrite" \| "full"` |
| **Arguments** | `{ path: string }` |
| **Returns** | File contents (truncated to 10,000 chars) |

### 📁 List Files

| Property | Value |
|----------|-------|
| **Name** | `list_files` |
| **Description** | List files and folders in a workspace directory |
| **Permission** | `fileAccessLevel: "read" \| "readwrite" \| "full"` |
| **Arguments** | `{ path?: string }` (empty string = root) |
| **Returns** | Directory listing with type (file/folder) and paths |

### 📝 Create File

| Property | Value |
|----------|-------|
| **Name** | `create_file` |
| **Description** | Create a new file in the workspace |
| **Permission** | `fileAccessLevel: "readwrite" \| "full"` + `allowCreate: true` |
| **Arguments** | `{ path: string, content: string }` |
| **Returns** | Success/failure message |

### ✏️ Edit File

| Property | Value |
|----------|-------|
| **Name** | `edit_file` |
| **Description** | Apply search/replace edit to an existing file |
| **Permission** | `fileAccessLevel: "readwrite" \| "full"` + `allowEdit: true` |
| **Arguments** | `{ path: string, search: string, replace: string }` |
| **Returns** | Success/failure message with match count |

### 🗑️ Delete File

| Property | Value |
|----------|-------|
| **Name** | `delete_file` |
| **Description** | Delete a file from the workspace |
| **Permission** | `fileAccessLevel: "full"` + `allowDelete: true` |
| **Arguments** | `{ path: string }` |
| **Returns** | Success/failure message |

### 🔄 Rename File

| Property | Value |
|----------|-------|
| **Name** | `rename_file` |
| **Description** | Rename a file or folder in the workspace |
| **Permission** | `fileAccessLevel: "full"` + `allowRename: true` |
| **Arguments** | `{ path: string, newName: string }` |
| **Returns** | Success/failure message |

### 🔎 Search Files

| Property | Value |
|----------|-------|
| **Name** | `search_files` |
| **Description** | Search for text across workspace files |
| **Permission** | `fileAccessLevel: "read" \| "readwrite" \| "full"` |
| **Arguments** | `{ query: string, path?: string }` |
| **Returns** | Matching lines with file paths |

## Permission System

### File Access Levels

| Level | Can Read | Can Create | Can Edit | Can Delete | Can Rename |
|-------|----------|------------|----------|------------|------------|
| `none` | ❌ | ❌ | ❌ | ❌ | ❌ |
| `read` | ✅ | ❌ | ❌ | ❌ | ❌ |
| `readwrite` | ✅ | ✅* | ✅* | ❌ | ❌ |
| `full` | ✅ | ✅* | ✅* | ✅* | ✅* |

\* Requires the corresponding granular permission toggle enabled.

### Granular Permissions

When `fileAccessLevel` is `readwrite` or `full`, individual toggles further restrict:

- `allowCreate` — Allow file creation
- `allowEdit` — Allow file modification (readwrite+)
- `allowDelete` — Allow file deletion (full only)
- `allowRename` — Allow file/folder renaming (full only)

### Configuration

Permissions are configured via **Settings → Tools** tab in the UI and persisted server-side per-user in the user settings JSON file:

```json
{
  "toolPermissions": {
    "webSearch": true,
    "fileAccessLevel": "readwrite",
    "allowCreate": true,
    "allowEdit": true,
    "allowDelete": false,
    "allowRename": true,
    "maxSearchResults": 5
  }
}
```

### Permission Validation

Before executing any tool, `toolService.executeTool()` validates:

1. **Tool is available** (exists in tool registry)
2. **Permissions allow the tool** (webSearch toggle, fileAccessLevel, granular flags)
3. **Arguments are valid** (required fields present, paths exist)

If any check fails, the tool returns an error message that is fed back to the LLM.

## Client-Side Components

### ChatPanel Tool Toggle

The ⚡ (Sparkles) icon in the chat panel header toggles all tools on/off:

- **ON** (amber glow) — AI can use tools, placeholder shows "Tools active — AI can search the web and access files"
- **OFF** (dimmed) — Standard chat mode, placeholder shows "Ask me anything about your world..."

### Tool Status Messages

Tool activities are displayed as styled cards in the chat:

- **[🔍 Web Search]** — Amber card with ✅ Done or ❌ Error status
- **[📄 Read File]** — Blue card
- **[📁 List Files]** — Blue card
- **[📝 Create File]** — Green card
- **[✏️ Edit File]** — Purple card
- **[🗑️ Delete File]** — Red card
- **[🔄 Rename File]** — Yellow card
- **[🔎 Search Files]** — Blue card

### Loading State

When tools are active and the LLM is processing:
- Loading text changes to **"⚡ Thinking & acting..."**
- Tool status cards appear in real-time as tools execute

### Settings → Tools Tab

Full permission management UI:

1. **Info banner** — Explains what tools do
2. **Web Search toggle** — On/off switch
3. **File Access Level** — Dropdown (none/read/readwrite/full)
4. **Granular Permissions** — Individual toggles (shown based on access level)
5. **Max Search Results** — Slider (1–20)
6. **Save Permissions** — Button to persist changes

## Server-Side Implementation

### toolService.js

```javascript
module.exports = {
  // Execute a tool with permission validation
  executeTool(name, arguments, permissions, workspacePath),

  // Internal tool implementations
  _webSearch(query, maxResults),
  _readFile(path, workspacePath),
  _listFiles(path, workspacePath),
  _createFile(path, content, workspacePath),
  _editFile(path, search, replace, workspacePath),
  _deleteFile(path, workspacePath),
  _renameFile(path, newName, workspacePath),
  _searchFiles(query, path, workspacePath),
};
```

### llmService.js — Tool Calling Loop

```javascript
async function chatWithLLM(messages, settings, systemPrompt, permissions) {
  const toolActivity = [];
  const maxIterations = 10;
  const toolMessages = [...messages];

  for (let i = 0; i < maxIterations; i++) {
    // Call LLM
    const response = await fetch(LM_URL, { /* ... */ });
    const text = await response.text();

    // Check for tool call
    const toolCall = parseToolCall(text);
    if (!toolCall) break; // Normal text response

    // Execute tool
    const result = await toolService.executeTool(
      toolCall.name, toolCall.arguments, permissions, WORKSPACE_PATH
    );

    // Track activity
    toolActivity.push({ name: toolCall.name, result, status: result.error ? 'error' : 'done' });

    // Feed result back to LLM
    toolMessages.push({ role: 'assistant', content: text });
    toolMessages.push({ role: 'tool', content: `tool_result: ${result.output}` });
  }

  return { content: finalText, toolActivity };
}
```

## Security Considerations

1. **Workspace boundary** — All file operations are restricted to the configured workspace directory. Path traversal attacks are prevented by validating resolved paths.
2. **Permission gating** — Every tool call is validated against the user's configured permissions.
3. **Delete confirmation** — The `delete_file` tool requires explicit `allowDelete: true` permission, which is off by default.
4. **Content truncation** — File reads are truncated to 10,000 characters to prevent memory issues.
5. **No network access** — Only the web search tool has outbound network access; all other tools are local-only.

## Future Enhancements

- **Custom tool definitions** — Allow users to define their own tools
- **MCP server integration** — Connect to external MCP servers for additional capabilities
- **Tool rate limiting** — Limit number of tool calls per time window
- **Audit log** — Log all tool executions for transparency
- **Image generation** — AI-powered image creation tools
- **Database queries** — Read/write to structured data stores
- **API integrations** — Connect to external APIs (weather, maps, etc.)