# Information Panel System

The Information Panel is a structured details panel that sits above the information (right-column) editor, providing file metadata, tag management, relationship tracking, image galleries, and notes in a clean multi-section layout.

## Overview

The `InformationPanel` component renders above the information TipTap editor when a file is open. It is divided into four sections:

1. **Hero Image** — A visual header image for the file
2. **File Tags** — Active tags assigned to the current file displayed as interactive banners
3. **Relationships** — Reserved area for future tag-relationship display
4. **Images & Notes** — Tabbed interface for gallery images and plain-text notes

## Architecture

### Component: `InformationPanel.tsx`

Located at `client/src/components/InformationPanel.tsx`.

**Props:**
- `currentPath: string | null` — The currently open file path

**Internal State:**
- `heroUrl` — The hero image URL loaded from localStorage for the current file
- `galleryImages` — Array of `GalleryImage` objects for the current file
- `notes` — Array of `Note` objects for the current file
- `activeTab` — Currently active tab (`'images'` | `'notes'`)
- `showPicker` — Whether the HeroImagePicker modal is open
- `showExplorer` — Whether the ImageExplorer modal is open
- `viewerImage` — Currently viewed image in the ImageViewer modal
- Uses `useFileTags(currentPath)` hook for tag data
- Uses `useTags()` hook for the global tag registry (color lookups)

### Integration: `DocumentEditor.tsx`

The `InformationPanel` is rendered conditionally when `currentPath` is truthy, between the information toolbar and the information `<EditorContent>`:

```tsx
{currentPath && <InformationPanel currentPath={currentPath} />}
<div className="flex-1 overflow-auto editor-info-content min-h-0">
  <EditorContent editor={marginEditor} />
</div>
```

## Section 1: Hero Image

### Functionality
- Click the placeholder area to open the **HeroImagePicker** modal (replaces `prompt()` from v4.33)
- Click an existing hero image to change it via the modal
- Hover over the hero image to reveal a semi-transparent overlay with a ✕ remove button
- If the image URL fails to load (`onError`), it falls back to the placeholder

### HeroImagePicker Modal (`HeroImagePicker.tsx`)
The hero image is selected via a modal file browser (`HeroImagePicker` component) instead of a URL prompt:
- **Thumbnail grid** — Displays image files (`.png`, `.jpg`, `.jpeg`, `.gif`, `.webp`, `.svg`, `.bmp`) as a 3-column grid with aspect-ratio-square thumbnail previews
- **Folder navigation** — Folders shown as clickable cards; breadcrumbs bar at top for path navigation; Back button for parent directory
- **Auth-aware thumbnails** — Because HTML `<img>` tags cannot send custom HTTP headers (required for JWT auth on `/api/files/workspace/*` routes), thumbnails are fetched with auth headers via `fetch()`, converted to blob URLs via `URL.createObjectURL()`, and displayed using those blob URLs. Blob URLs are cleaned up via `URL.revokeObjectURL()` on component unmount and when navigating between folders.
- **Selection** — Click any image to select it (highlighted with purple ring + checkmark), then click "Select" to confirm

### Persistence
- Hero images are stored in `localStorage` under the key `wbu_hero_images`
- Value is a JSON object mapping file paths to workspace file paths (not API URLs):
  ```json
  { "World/planets/Marathon.html": "Assets/hero.png" }
  ```
- **Blob URL bridge for display** (v5.3.1) — Because HTML `<img>` tags cannot send JWT auth headers, the hero image is fetched with auth headers, converted to a blob URL via `URL.createObjectURL()`, and displayed using that blob URL. The blob URL is tracked in `heroBlobRef` and revoked on file switch, hero removal, and component unmount to prevent memory leaks.
- **localStorage migration** (v5.3.1) — Old entries storing full API URLs (`/api/files/workspace/...`) are automatically migrated to file path format on first read.
- Images are loaded via `useEffect` when `currentPath` changes

### Helper Functions
- `getHeroImages()` — Reads and parses the localStorage entry
- `setHeroImage(filePath, url)` — Sets/updates a hero image for a file path
- `removeHeroImage(filePath)` — Deletes the hero image for a file path

## Section 2: File Tags (Active Banners)

### Functionality
- Fetches tags assigned to the current file via `useFileTags(currentPath)`
- Displays each tag as an interactive banner with the tag's assigned color
- Each banner has a ✕ button to remove that tag from the file
- Shows "No tags assigned" when the file has no tags

### Banner Styling
Tags in the information panel use the `.tag-banner-interactive` CSS class:
- Black background (`#111111`)
- Bold yellow text (`#fbbf24`)
- Glowy purple border (`#a855f7`)
- Purple box-shadow glow effect
- `data-tag-color` attribute set to the tag's color for future customization

## Section 3: Relationships (Placeholder)

Currently displays a "Coming soon..." placeholder. This section is reserved for future implementation of tag-based document relationships, as outlined in `TAG_RELATIONSHIP_SYSTEM.md`.

## Section 4: Images & Notes (Tabbed)

A tabbed interface below Sections 1-3, providing two sub-sections: **Images** (gallery) and **Notes** (plain text).

### Tab Bar
- Two tabs: "Images" and "Notes"
- Active tab indicated with `border-primary` underline and `text-primary` color
- Each tab shows a badge counter (e.g., `3`) when items exist
- Icons: `ImageIcon` for Images, `StickyNote` for Notes

### Images Tab — Gallery

A per-file gallery of additional images from the workspace:

- **Empty state** — Centered message with "Add Images" button opening ImageExplorer modal
- **Thumbnail grid** — 2-column grid of square aspect-ratio thumbnails
- **Image sources** — Thumbnails use the **blob URL bridge pattern** (v5.3.1): each image is fetched with auth headers, converted to a blob URL, and tracked in `galleryBlobRef` (`Map<string, string>` keyed by image ID). After async blob fetch, `setGalleryImages(prev => [...prev])` triggers re-render so `<img>` picks up the blob URL. Blob URLs are revoked on file switch, image removal, and component unmount.
- **Name label** — File name displayed at the bottom of each thumbnail in a dark translucent bar
- **Click to view** — Clicking a thumbnail opens the full-screen `ImageViewer` modal with pan & zoom
- **Add button** — Opens the `ImageExplorer` modal for browsing workspace and adding images

### Notes Tab — Plain Text Notes

A per-file collection of plain text note cards:

- **Empty state** — Centered message with "Add Note" button
- **Note cards** — Each note is a card with:
  - **Header bar** — Title input field (inline editable) + trash button on the right
  - **Content area** — Resizable textarea for plain text content (minimum 60px height)
- **Add button** — Creates a new blank note card with empty title and content
- **Auto-save** — All note changes (title/content edits, adds, removes) are immediately persisted to localStorage

### ImageExplorer Modal (`ImageExplorer.tsx`)

A file browser modal for adding images to the gallery:

- **Thumbnail grid** — 3-4 column grid showing image files as square thumbnails
- **Folder navigation** — Same pattern as HeroImagePicker (breadcrumbs, back button, root button)
- **Auth-aware thumbnails** — Fetches images with auth headers, converts to blob URLs for display
- **Already-added indicator** — Images already in the gallery show a checkmark overlay and are disabled
- **Multi-select** — Modal stays open after adding an image, allowing multiple additions
- **"Done" button** — Closes the modal when finished

### ImageViewer Modal (`ImageViewer.tsx`)

A full-screen modal for viewing images with pan and zoom:

- **Zoom controls** — Floating toolbar (top-right) with zoom in/out buttons, percentage indicator, reset button, and close button
- **Mouse wheel zoom** — Scroll up/down to zoom in/out (10%–1000% range, 15% increments)
- **Pan** — When zoomed >100%, click and drag to pan the image (cursor changes to grab/grabbing)
- **Keyboard** — Escape key closes the viewer
- **File name** — Displayed in a translucent bar at the bottom center
- **Smooth transitions** — Transform transitions are disabled during drag, re-enabled on release

### Persistence

Gallery images and notes are stored in localStorage:

- **Gallery**: key `wbu_file_images`, format `Record<string, GalleryImage[]>`
  ```json
  {
    "World/planets/Marathon.html": [
      { "id": "img_1234_abc", "path": "Assets/marathon.jpg", "name": "marathon.jpg" }
    ]
  }
  ```
- **Notes**: key `wbu_file_notes`, format `Record<string, Note[]>`
  ```json
  {
    "World/planets/Marathon.html": [
      { "id": "note_1234_abc", "title": "Ideas", "content": "Add crater descriptions..." }
    ]
  }
  ```

### Helper Functions

**Gallery:**
- `getGalleryImages()` — Reads localStorage entry
- `setGalleryImages(filePath, images)` — Updates gallery for a file
- `addGalleryImage(filePath, image)` — Appends an image (deduplicates by path)
- `removeGalleryImage(filePath, imageId)` — Removes an image by ID

**Notes:**
- `getNotes()` — Reads localStorage entry
- `setNotes(filePath, notes)` — Updates notes for a file
- `addNote(filePath)` — Creates a new blank note and appends it
- `updateNote(filePath, noteId, updates)` — Partially updates a note's title or content
- `removeNote(filePath, noteId)` — Removes a note by ID

## CSS Classes

### `.tag-banner` (Editor-inserted tags)
Tags inserted into the information editor via the TagInsertControl toolbar. Renders as inline block with black bg, yellow text, purple glow border.

### `.tag-banner-interactive` (InformationPanel tags)
Same visual style as `.tag-banner` but with `inline-flex` display and a remove button. Used for the active file tag banners in Section 2.

### `.tag-remove-btn`
Small ✕ button on tag banners. Default opacity 0.5, transitions to 1 on hover. Color changes to red (`#f87171`) on hover.

### `.toolbar-tag-banner` (Compact toolbar preview)
Smaller, compact version of the tag banner shown in the main editor toolbar when a tag is selected in the TagInsertControl dropdown. Same black/yellow/purple color scheme.

### `.info-note-card` (v5.3.0)
Note card container with subtle background. Shows a purple glow box-shadow on `:focus-within`.

### `.gallery-thumbnail` (v5.3.0)
Gallery thumbnail with smooth hover scale (1.02x) and purple glow border on hover.

### `.info-panel-tab` (v5.3.0)
Tab bar button with smooth color/border transitions.

## TagInsertControl Toolbar Integration

The `TagInsertControl` component in the main editor toolbar includes:
- Tag dropdown for selecting a tag
- **Preview banner** — When a tag is selected, a compact `.toolbar-tag-banner` appears next to the dropdown showing the selected tag's name in the tag banner style
- **Plus (+) button** — Inserts the selected tag as a `.tag-banner` into the information editor at the cursor position

## Data Storage

| Key | Location | Format |
|-----|----------|--------|
| `wbu_hero_images` | `localStorage` | `Record<string, string>` — file path → workspace file path (v5.3.1 migrated from API URLs) |
| `wbu_file_images` | `localStorage` | `Record<string, GalleryImage[]>` — file path → gallery image array |
| `wbu_file_notes` | `localStorage` | `Record<string, Note[]>` — file path → notes array |
| Tag registry | Server (`WBU_DATA/tags.json`) | Array of tag objects with id, name, color, description |
| File-tag associations | Server (`WBU_DATA/.wbi-meta.json`) | File path → array of tag names |

## Known Issues & Design Decisions

### Thumbnail Auth Pattern
The thumbnail display in HeroImagePicker and ImageExplorer uses a **blob URL bridge pattern** identical to the main editor's image auth fix (v2.9):
1. Fetch image from `/api/files/workspace/<path>` with `Authorization: Bearer <token>` header
2. Convert response to Blob, create `blob:` URL via `URL.createObjectURL()`
3. Use blob URL in `<img src="...">` for rendering
4. Revoke blob URLs on cleanup to prevent memory leaks

This pattern is required because all `/api/files/*` routes enforce JWT authentication, and HTML `<img>` tags cannot attach custom headers.

### ImageViewer blob URL cleanup
The ImageViewer receives blob URLs created on-demand when a gallery thumbnail is clicked. Blob URL cleanup happens naturally when the viewer closes (component unmounts and the reference is lost). For production hardening, explicit `URL.revokeObjectURL()` on viewer close could be added.

### localStorage for gallery and notes
Gallery images and notes are stored in localStorage for simplicity and fast local access. This means:
- Data is per-browser/per-device (not synced across devices)
- No server-side API needed for these features
- Large galleries may approach localStorage size limits (~5-10MB per origin)
- Future enhancement: migrate to server-side storage with sync

## Future Enhancements

- Hero image file upload (not just selection from workspace)
- Relationship section implementation (tag-based document linking)
- Hero image drag-and-drop from file explorer
- Drag-and-drop images into the gallery
- Server-side sync for gallery images and notes
- Image annotations / cropping in the ImageViewer
- Note markdown support
- Note pinning / reordering
+++++++ REPLACE