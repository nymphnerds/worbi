# Editor Enhancements Handoff

## Current State (v4.19 - Recent Files, Favorites, Welcome Screen)

**NOTE:** For the previous version history (up to v4.16), see `docs/legacy/EDITOR_ENHANCEMENTS_HANDOFF_V2.md`.

WBUI now features a full **workspace experience** with a welcome screen, recent files tracking, and a favorites/starred system:

### Welcome Screen
- When no file tab is open, the editor area displays a landing page instead of empty space
- Shows "WBUI" branding with Sparkles icon and "WorldBuilder UI — Your creative workspace" subtitle
- **New File** button for quick file creation (opens the same flow as the editor's "+ File" button)
- **Recent files list** (up to 10) with relative timestamps ("2 hours ago", "3 days ago", "Just now")
- **Starred/Favorites section** with instant file access
- Remove individual items from recents or favorites with hover-revealed X button

### Recent Files Tracking
- Every opened file is automatically tracked via `trackRecent(path)` in `openFileWithConversion()`
- Persisted across browser sessions via `localStorage` key `wbu_recent_files`
- Limited to 10 entries; newest first; duplicates are moved to top
- Relative time formatting: seconds → "Just now", minutes → "N mins ago", hours → "N hours ago", days → "N days ago"

### Starred Files (Favorites)
- Hover any file row in the FileExplorer → star icon appears → click to toggle favorite
- Starred files appear in a **collapsible "Favorites" section** at the top of the FileExplorer, regardless of current folder path
- Star icon: yellow filled = favorited, gray outline = not favorited
- Remove from favorites by hovering and clicking X in the Favorites section
- Persisted via `localStorage` key `wbu_starred_files`

### Recent UI Polish (v4.18 inherited)
- Full-screen layout (`height: 100vh` on body and #root)
- Improved text contrast throughout (explorer, breadcrumb, AI chat, header toolbar)
- `--muted-foreground` brightened from 60% to 72%
- Draggable split divider restored between editor columns

---

## Architecture Overview

### Hooks

#### useRecents
```typescript
const {
  recentFiles,       // RecentFile[] — { path, name, lastOpened: timestamp }
  starredFiles,      // StarredFile[] — { path, name }
  addRecentFile,     // (path: string) => void
  toggleStar,        // (path: string) => void
  isStarred,         // (path: string) => boolean
  removeRecent,      // (path: string) => void
  removeStar,        // (path: string) => void
  clearRecents,      // () => void
} = useRecents();
```
- No arguments required; reads/writes to `localStorage` automatically
- Persists on every state change via `useEffect`

#### useFileSystemUndoRedo
```typescript
const { canUndo, canRedo, undo, redo, push, clear, refreshRef } = useFileSystemUndoRedo();
```
- Undo/redo for file system operations (create, delete, rename, copy, move)
- Uses `refreshRef` to avoid circular dependency with `useFiles`

#### useSearch
```typescript
const { query, setQuery, results, loading, error } = useSearch();
```
- Debounced (300ms) full-text workspace search
- Results show file path + matching line; click to open file

#### useFiles(pushUndo)
```typescript
const { files, loadFiles, openFile, saveCurrentFile, newFile, newFolder, ... } = useFiles(pushUndo);
```
- Core file management: tabs, file list, content, CRUD operations
- Accepts `pushUndo` callback for undo/redo integration

#### useLLM
```typescript
const { chatHistory, loading, llmConnected, sendMessage, clearChat } = useLLM();
```
- AI chat integration with LLM backend
- Sends `chat` POST requests to `/api/llm`

---

## UI Layout

```
┌────────────────────────────────────────────────────────────────────┐
│  Header: [New File] [Import] [Undo] [Redo] [Logout]               │
├──┬──────┬──┬──────────────────────────────┬──┬────────┬──┬───────┤
│A │Explr │▮│        Center Panel          │▮│ AI Chat │A│ Search│
│c │      │▮│  ┌──────────┬───────────────┐ │▮│        │c│       │
│t │ File │▮│  │ Tab Bar  │               │ │▮│ History│t│ Input │
│i │List  │▮│  └──────────┘               │ │▮│        │i│ Results│
│v │Starred│▮│     Document Editor         │ │▮│ Input  │v│       │
│i │      │▮│                             │ │▮│        │v│       │
│t │      │▮│                             │ │▮│        │ │       │
│y │      │▮│                             │ │▮│        │y│       │
└──┴──────┴▮│                             │ ┴▮│        │ ┴───────┘
           └─ Resizer ────────────────────┘  Resizer
├────────────────────────────────────────────────────────────────────┤
│  StatusBar: [path] [word count] [LLM status] [error]              │
└────────────────────────────────────────────────────────────────────┘
```

- **ActivityBar** (48px): Explorer ↔ Search toggle
- **Left Panel**: FileExplorer (with Favorites section) or SearchPanel
- **Center Panel**: TabBar + DocumentEditor (two-column with draggable split) or Welcome screen
- **Right Panel**: AI Chat panel

---

## Key Components

| Component | Purpose |
|-----------|---------|
| `Welcome.tsx` | Landing screen when no tab is open (recent files, favorites, new file) |
| `FileExplorer.tsx` | File/folder tree with Favorites section, star toggle on file rows |
| `DocumentEditor.tsx` | Two-column TipTap editor with independent toolbars |
| `TabBar.tsx` | File tabs with close, close others, close all |
| `ChatPanel.tsx` | AI chat with LLM backend, document context awareness |
| `Header.tsx` | Toolbar: New File, Import DOCX, Undo, Redo, Logout |
| `ActivityBar.tsx` | Thin icon bar: Explorer, Search |
| `SearchPanel.tsx` | Workspace full-text search with debounced input |
| `StatusBar.tsx` | Footer: current path, word count, LLM status, errors |

---

## Server Routes

| Route | Purpose | Auth |
|-------|---------|------|
| `GET /api/files?path=...` | List directory contents | Yes |
| `GET /api/files/content?path=...` | Read file content | Yes |
| `GET /api/files/workspace/*` | Serve any file from workspace | Yes |
| `GET /api/files/images/*` | Serve image from assets directory | Yes |
| `GET /api/files/search?q=...` | Full-text workspace search | Yes |
| `POST /api/files/create` | Create a new file | Yes |
| `POST /api/files/update` | Update file content | Yes |
| `POST /api/files/delete` | Delete a file or folder | Yes |
| `POST /api/files/rename` | Rename a file or folder | Yes |
| `POST /api/files/upload` | Upload image to assets | Yes |
| `POST /api/files/upload-file` | Upload any file to workspace | Yes |
| `POST /api/files/copy-file` | Copy a file within workspace | Yes |
| `POST /api/files/move-file` | Move a file within workspace | Yes |
| `POST /api/llm` | Send chat message to LLM | Yes |
| `POST /api/auth/login` | User login | No |

---

## Future Enhancements

1. **Tab persistence** — Save/restore open tabs across reloads (required for blob URL map rebuild).
2. **Full file system undo with server-side state snapshots** — More robust recovery.
3. **Multi-file undo groups** — Batch operations into single undo step.
4. **Keyboard shortcuts for file undo/redo** — Ctrl+Z / Ctrl+Y distinct from editor.
5. **Proper file type system** — Content type per file for editor mode switching.
6. **Multi-handle image resize** — Corner + edge handles.
7. **PDF export with side-by-side layout** — Current PDF is single-column.
8. **Find & Replace** — In-document search and replace.
9. **Spell checker** — Built-in or dictionary-based.
10. **Clear recents button** — One-click "Clear all recent files" on the Welcome screen.