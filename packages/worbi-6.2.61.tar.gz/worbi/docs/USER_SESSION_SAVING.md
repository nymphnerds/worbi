# USER_SESSION_SAVING.md — Cross-User Recents/Starred Leak Fix

**Date:** 2026-05-03
**Version:** v6.0.41
**Category:** Bugfix — Data Isolation
**Files Changed:** `client/src/hooks/useRecents.ts`, `CHANGELOG.md`

---

## Problem

After migrating starred and recent files from browser `localStorage` to server-side persistence (v6.0.40), users reported that another user's starred and recent files were appearing in their own welcome screen. For example, "shaz" could see "rauty"'s starred files, and vice versa.

## Root Cause

The server-side architecture was **correct** — each user's workspace is isolated in `data/users/<username>/workspace/` with per-user `.wbu_recents.json` and `.wbu_starred.json` files. The auth middleware correctly extracts the username from the JWT token and attaches it to `req.user.username`, and the file service resolves all paths relative to the user's workspace directory.

The bug was a **client-side race condition** in the `useDebouncedSave` hook inside `useRecents.ts`.

### Sequence of Events

1. User "rauty" opens a file → `addRecentFile(path)` fires → updates React state → triggers the debounced save effect
2. The debounced save schedules a `setTimeout(fn, 500)` to call `saveUserRecents()` via the API
3. User "rauty" logs out before the 500ms timer fires
4. User "shaz" logs in → a new JWT token is written to `localStorage('wbu_token')`
5. The pending 500ms timer fires → calls `saveUserRecents(rautyData)` → `authFetch()` reads `shaz`'s JWT token from localStorage → the server sees `req.user.username = 'shaz'` → **rauty's recents are written to shaz's `.wbu_recents.json`**

### Why This Happened

The `useDebouncedSave` hook (pre-v6.0.41):

```js
function useDebouncedSave() {
  const timerRef = useRef(null);
  const debouncedSave = useCallback((data, saveFn) => {
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(async () => {
      try {
        await saveFn(data);
      } catch {
        // silently fail
      }
    }, 500);
  }, []);
  return debouncedSave;
}
```

There was **no cleanup on unmount**. When the `App` component unmounted (user logs out), the pending `setTimeout` continued to exist in the JavaScript event loop. When it eventually fired, the closure still held the old user's data, but `authFetch` read the new user's token from `localStorage`.

Additionally, when the `refreshKey` changed (triggered by login), stale data was still in React state for one render cycle — and the debounced save effects could fire with that stale data before the new fetch completed.

## Fix (Two-Part Defense)

### Part 1: Debounce Cleanup on Unmount

Added a `mountedRef` and a `useEffect` cleanup to `useDebouncedSave`:

```js
function useDebouncedSave() {
  const timerRef = useRef(null);
  const mountedRef = useRef(true);  // NEW

  useEffect(() => {                 // NEW
    return () => {                  // NEW
      mountedRef.current = false;   // NEW
      if (timerRef.current) {       // NEW
        clearTimeout(timerRef.current);  // NEW
      }
    };
  }, []);

  const debouncedSave = useCallback((data, saveFn) => {
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(async () => {
      if (!mountedRef.current) return;  // NEW: bail if unmounted
      try {
        await saveFn(data);
      } catch {
        // silently fail
      }
    }, 500);
  }, []);
  return debouncedSave;
}
```

**How this prevents the leak:**
- On unmount, `mountedRef.current` is set to `false`
- The `setTimeout` is immediately cleared via `clearTimeout`
- Even if the timer had already been moved to the callback queue (race condition), the `if (!mountedRef.current) return;` guard prevents the save from executing
- The stale closure can never reach the server

### Part 2: State Reset on Login

Added immediate state clearing when `refreshKey` changes:

```js
// Pre-v6.0.41 — useEffect for refreshKey:
useEffect(() => {
  let mounted = true;
  (async () => {
    const [recents, starred] = await Promise.all([...]);
    if (mounted) {
      setRecentFiles(recents);
      setStarredFiles(starred);
      setLoading(false);
    }
  })();
  return () => { mounted = false; };
}, [refreshKey]);

// v6.0.41 — useEffect for refreshKey:
useEffect(() => {
  let mounted = true;
  // Immediately clear stale data and re-enter loading
  setRecentFiles([]);     // NEW
  setStarredFiles([]);    // NEW
  setLoading(true);       // NEW
  (async () => {
    const [recents, starred] = await Promise.all([...]);
    if (mounted) {
      setRecentFiles(recents);
      setStarredFiles(starred);
      setLoading(false);
    }
  })();
  return () => { mounted = false; };
}, [refreshKey]);
```

**How this prevents the leak:**
- When `refreshKey` increments (login event), state is immediately cleared before the fetch begins
- `loading` is set to `true`, which gates the debounced save effects (`if (!loading)` guards on lines 105 and 123)
- Even if a save effect somehow fires during the transition, it saves empty arrays — which is a no-op cleanup write
- Once the new user's data loads from the server, `loading` becomes `false` and saves proceed normally

## Architecture Check: Server-Side

The server-side code was confirmed correct during investigation:

| Layer | File | Correct? | Notes |
|-------|------|----------|-------|
| Auth Middleware | `server/src/middleware/authMiddleware.js` | ✅ | Extracts `username` from JWT, attaches to `req.user.username` |
| Routes | `server/src/routes/files.js` L756-814 | ✅ | Passes `req.user.username` to fileService functions |
| Workspace Resolution | `server/src/services/authService.js` L129-131 | ✅ | `getUserWorkspaceDir(username)` → `data/users/<username>/workspace` |
| File Service | `server/src/services/fileService.js` L469-498 | ✅ | `saveUserRecents(username, data)` and `loadUserRecents(username)` use `writeFile`/`readFile` with per-user `getSafePath` |
| Path Safety | `server/src/services/fileService.js` L36-44 | ✅ | `getSafePath(username, relPath)` enforces workspace directory containment, prevents path traversal |

Each user's `.wbu_recents.json` and `.wbu_starred.json` are stored in completely separate directories:
- `data/users/rauty/workspace/.wbu_recents.json`
- `data/users/shaz/workspace/.wbu_recents.json`

## Why Prior Fixes Failed

| Version | Approach | Why It Failed |
|---------|----------|---------------|
| v6.0.36 | localStorage keys scoped to username | Same browser means same localStorage; logout didn't clear keys |
| v6.0.37 | Key version bump (`_v2_`) | Migration code copied old user's data to new user's scoped key |
| v6.0.38 | Re-fetch on username change | React state initialized from localStorage before auth loaded, so old data was already in state |
| v6.0.40 | Server-side persistence | Correct architecture, but client-side race condition undid the isolation |

## Testing

To verify the fix:

1. Log in as user A, star some files, open some files (creates recents)
2. Confirm the starred/recents appear in the welcome screen
3. Log out
4. Log in as user B
5. Confirm user B's welcome screen shows ONLY user B's starred/recents (NOT user A's)
6. Repeat the cycle rapidly (within 500ms) to stress-test the debounce cleanup
7. Verify server-side files are isolated:
   ```bash
   cat data/users/userA/workspace/.wbu_recents.json
   cat data/users/userB/workspace/.wbu_recents.json
   # Should show only their respective files
   ```

## Edge Cases Considered

- **Rapid logout/login within 500ms**: The debounce timer is cancelled on unmount via `clearTimeout`, and the `mountedRef` guard catches any timer that slips through
- **Multiple rapid logins without browser refresh**: `refreshKey` increments each time, clearing state and setting `loading = true`, gating saves
- **Stale data already written to wrong user's file**: Will self-correct as each user interacts with their own starred/recents, overwriting with correct data
- **Browser crash while debounce is pending**: No effect — the save was never committed to the server, so no data is lost or leaked