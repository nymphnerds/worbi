# WORBI

## [v6.2.58] — Fix Cross-User Sidebar Icon Visibility Leakage (2026-05-08)

- **Fixed sidebar icon visibility persisting across user logins** — When logging in as one user, changing sidebar icon settings, logging out, and logging in as another user, the second user saw the first user's icon visibility settings instead of their own. The `useLayout.ts` hook was not re-reading per-user localStorage when the user changed, because the `storage` event only fires in other browser tabs, not the current tab. Added explicit `useEffect` on `user?.username` to force a re-read of localStorage on user change.
- **Removed global fallback localStorage key** — Both `useLayout.ts` and `Settings.tsx` fell back to a shared global `wbu_sidebar_visibility` key when `user` was null during login/logout transitions, causing cross-user data contamination. Removed global fallback; now returns conservative defaults (all icons hidden) when no user is available.
- **Fixed Settings.tsx dependency stability** — Changed `user` object reference in `useEffect`/`useCallback` dependencies to `user?.username` string for reliable re-computation on login/logout, since object references may not change but the username string will.
- **Added write guards** — `Settings.tsx` now guards localStorage writes with `if (!user?.username) return;` to prevent writes during transitional states where user is null.
- **Fixed new user sidebar icon visibility** — When logging in as a brand new user, all sidebar icons were visible regardless of the default server settings because `useLayout.ts` initialized visibility from hardcoded localStorage defaults (all `false`/hidden) but the `visibilityRefreshKey` timestamp was stale. New users now get their visibility initialized from the server's user settings on first load, ensuring the activity bar icons match the Settings window toggles immediately after login.

### Files Changed
- `client/src/features/layout/useLayout.ts` — Added `useEffect` to refresh `visibilityRefreshKey` on `user?.username` change, removed global `wbu_sidebar_visibility` fallback, added `user?.username` to `useMemo` deps
- `client/src/pages/Settings.tsx` — Changed deps from `user` object to `user?.username` string, removed global fallback key, added early-return guard in `handleToggleVisibility`
- `.agents/skills/worbi-conventions/SKILL.md` — Added Section 9: Per-User localStorage Isolation rules (patterns, anti-patterns, code template)

## [v6.2.57] — Fix LLM Settings Provider Display Race Condition (2026-05-08)

- **Fixed LLM provider showing wrong value on Settings open** — The Settings panel's initial sync effect was firing on the first render with empty default values from `useLLM()` hook, marking `initialSyncDone = true` before real settings arrived from the server. This caused the provider dropdown to display "LM Studio" (first option) instead of the saved provider (e.g., "llama.cpp") because the select had an empty value. Added `&& settings.baseUrl` guard so the sync only runs when settings contain actual data.

### Files Changed
- `client/src/pages/Settings.tsx` — Added `settings.baseUrl` guard to initial sync useEffect

## [v6.2.56] — Fix LLM/Z-Image Settings Save (2026-05-08)

- **Fixed LLM settings not saving** — Server route `POST /settings/save` expected `req.body.settings` but client was sending nested payload. Aligned client/server to use `req.body` directly so LLM provider, URL, model, max tokens, context window, and temperature now persist correctly.
- **Fixed Z-Image settings not saving** — Same payload mismatch affected Image/Z-Image settings panel. All Image, Video, Audio, and Z-Image sub-settings now save and persist across server restarts.
- **Removed broken LLM auto-detection** — Removed `llmDetector.js` and `llmLifecycle.js` services that attempted automatic provider detection on connection and were causing settings refresh failures when the server was connected. Replaced with explicit provider selection in the LLM Settings panel.
- **Aligned all version numbers** — `package.json`, `nymph.json`, and archive all set to 6.2.56.

### Files Changed
- `package.json` — Version to 6.2.56
- `client/src/pages/Settings.tsx` — Fixed save payload structure for all settings tabs
- `client/src/services/api.ts` — Updated settings save API call
- `client/src/hooks/useLLM.ts` — Removed auto-detection logic, simplified connection flow
- `server/src/routes/settings.js` — Fixed to read `req.body` directly instead of `req.body.settings`
- `server/src/routes/llm.js` — Simplified, removed auto-detection endpoints
- `server/src/config.js` — Removed auto-detection defaults
- `server/src/services/llmDetector.js` — Deleted
- `server/src/services/llmLifecycle.js` — Deleted

## [v6.2.53] — Simplify Images Settings Panel (2026-05-08)

- **Simplified Images Settings panel** — Removed Provider selector (always Black Forest Labs), Model dropdown (always `flux-1-schnell`), Image Format slider, and Quality slider. Remaining controls: Max Images (1-8) and Refresh button only.
- **Hardcoded Stable Diffusion config** — `imageGeneration` settings now always use `provider: 'black-forest-labs'`, `model: 'flux-1-schnell'`, `format: 'jpeg'`, `quality: 80`. Users can only adjust Max Images.
- **Deployed to production** — Rebuilt dist, copied to `/home/nymph/worbi/dist/`, server restarted (PID 50588 on port 8082).

### Files Changed
- `client/src/pages/Settings.tsx` — Removed Image Provider, Model, Format, Quality controls. Added Max Images selector and Refresh button.
- `server/src/routes/llm.js` — Removed `imageProvider`, `imageModel`, `imageFormat`, `imageQuality` from `updateSettings()` and `updateLLMSettings()`.

---

- **Removed Managed/External LLM connection mode** — The Connection Mode toggle buttons ("Managed (WORBI controls)" and "External (User-managed)") have been removed from the LLM Settings tab. All LLM connections are now assumed to be external and user-managed. WORBI no longer attempts to start/stop the LLM server.
- **Removed LLM Installation Folder field** — The `~/llama.cpp (default)` input field and its "Path to your LLM server installation" help text have been removed, as WORBI no longer manages the LLM binary.
- **Removed LLM Server Management panel** — The entire "LLM Server (Managed)" section including "Detect Servers", "Start", "Stop", and "Refresh" buttons have been removed. Users manage their LLM server lifecycle externally.
- **Removed `POST /api/llm/detect` endpoint** — The server-side LLM detection endpoint that probed local ports is no longer available.
- **Simplified LLM Settings UI** — The Settings LLM tab now only shows: Provider selector, URL, API Key (for cloud providers), Model dropdown, Max Tokens, Temperature, Top P, Connection status, and Save button.

### Files Changed
- `client/src/pages/Settings.tsx` — Removed Connection Mode toggle, LLM Installation Folder, Server Management panel
- `client/src/hooks/useLLM.ts` — Removed server lifecycle management code
- `client/src/services/api.ts` — Removed LLM detect endpoint type
- `server/src/routes/llm.js` — Removed detect endpoint
- `server/src/config.js` — Cleaned up managed server config references

---

## [v6.2.51] — Fix Production Deploy: Profile Selector, Bin Scripts, Dist Symlink (2026-05-07)

- **Rebuilt production package with AuthProvider fix** — v6.2.50 package did not include the compiled fix. Rebuilt from source to ensure `dist/` contains corrected `AuthProvider.tsx` with `localStorage.getItem('wbu_profile')` check.
- **Fixed production bin script paths** — `worbi-start` was running `node src/index.js` from `$HOME/worbi` instead of `$HOME/worbi/server`. Updated to `cd "$INSTALL_DIR/server"` and fixed node_modules check path.
- **Fixed "Cannot GET /" error** — Server's `index.js` resolves dist at `server/dist` (relative to `server/src/`), but the installer placed dist at `~/worbi/dist`. Created symlink `server/dist -> /home/nymph/worbi/dist` so the server finds the frontend.
- **Installer now includes dist/ and symlink** — Updated `installer_from_package.sh` to: (1) copy `dist/` from the archive, (2) create `server/dist` symlink automatically after install.

### Files Changed
- `client/src/features/auth/AuthProvider.tsx` — Fix already in place from v6.2.50
- `bin/worbi-start` — Fixed working directory to `$INSTALL_DIR/server` and node_modules path
- `worbi-installer/scripts/installer_from_package.sh` — Added `dist/` copy and `server/dist` symlink creation
- `worbi-installer/scripts/install_worbi.sh` — Resolved merge conflict, kept dynamic nymph.json archive path
- `worbi-installer/nymph.json` — Updated to `packages/worbi-6.2.51.tar.gz`

---

## [v6.2.50] — Fix Profile Selector Loop on Refresh (2026-05-07)

- **Fixed profile selector modal appearing on every page refresh** — The `isNewUser` flag was persisted in `localStorage('wbu_user')` and restored on every refresh, but `clearNewUserFlag()` only cleared React state, not localStorage. Added check for `wbu_profile` localStorage key in both state initialization and useEffect sync in `AuthProvider.tsx` so the modal skips for users who already selected a profile.

### Files Changed
- `client/src/features/auth/AuthProvider.tsx` — Added `localStorage.getItem('wbu_profile')` check to useState init and useEffect sync

---

## [v6.2.49] — Phase 2 Core Services Tests Complete: 285 Tests Passing (2026-05-05)

- **Phase 2 core service tests implemented** — Created 6 new test files covering all core server services: fileService (63 tests), tagService (32 tests), toolService (31 tests), llmService (21 tests), reminderService (35 tests), locationService (24 tests). Also created 2 integration test files: files API (23 tests) and reminders API (17 tests). Full server test suite: 285 tests across 11 files, all passing.
- **Test infrastructure verified** — All tests use Vitest with proper mocking strategies: `vi.mock()` for module mocks, `vi.spyOn()` for axios, `vi.mocked()` for typed mocked exports. Filesystem tests use `createTempWorkspace()` helper. Location tests use temp workspace with `os.homedir()` mock to isolate from real `~/.wbu` directory.

### Files Changed
- `server/tests/unit/services/fileService.test.ts` — 63 tests (CRUD, scanning, metadata, search, compression, recents, starred)
- `server/tests/unit/services/tagService.test.ts` — 32 tests (CRUD, file tagging, color validation, duplicate detection)
- `server/tests/unit/services/toolService.test.ts` — 31 tests (tool registry, discovery, profiles, validation)
- `server/tests/unit/services/llmService.test.ts` — 21 tests (transcribeImage, sendChatMessage, config mocking, connection errors)
- `server/tests/unit/services/reminderService.test.ts` — 35 tests (CRUD, threading, firing, recurrence, file association, conversion)
- `server/tests/unit/services/locationService.test.ts` — 24 tests (CRUD, file-location associations, queries, temp workspace isolation)
- `server/tests/integration/files.test.ts` — 23 tests (API routes: list, create, read, update, delete, rename, search, profile, recents, starred)
- `server/tests/integration/reminders.test.ts` — 17 tests (API routes: create, list, grouped, update, thread, delete, check, convert)

---

## [v6.2.48] — Test Suite Master Plan Decomposed into 9 Phase Docs (2026-05-05)

- **TEST_SUITE_SETUP.md decomposed into 9 actionable phase documents** — The original monolithic test suite plan has been split into PHASE_0 through PHASE_8, covering test infrastructure, security tests, core services, lifecycle/config services, client hooks, feature modules, component smoke tests, TipTap extensions, and coverage/CI integration. Total planned test count: ~488 tests across all phases.
- **Phase docs includeWORBI-specific details** — Each phase document references actual WORBI service names, route patterns, hook names, and component names discovered by analyzing the codebase. Mock strategies are tailored to WORBI's actual architecture (e.g., axios mocking for LLM server, child_process.spawn mocking for lifecycle services).

### Files Changed
- `docs/handoff/priority-high/TEST_SUITE_SETUP.md` — Added Master Phase Index table, version update, key differences section
- `docs/handoff/priority-high/PHASE_0_TEST_INFRASTRUCTURE.md` — Created (test infrastructure setup)
- `docs/handoff/priority-high/PHASE_1_SECURITY_TESTS.md` — Created (path traversal + auth tests)
- `docs/handoff/priority-high/PHASE_2_CORE_SERVICES.md` — Created (file, tag, tool, LLM, reminder, location)
- `docs/handoff/priority-high/PHASE_3_LIFECYCLE_CONFIG_SERVICES.md` — Created (lifecycle, detector, provider, template)
- `docs/handoff/priority-high/PHASE_4_CLIENT_HOOKS.md` — Created (React hook tests)
- `docs/handoff/priority-high/PHASE_5_FEATURE_MODULES.md` — Created (feature module tests)
- `docs/handoff/priority-high/PHASE_6_COMPONENT_SMOKE_TESTS.md` — Created (UI component smoke tests)
- `docs/handoff/priority-high/PHASE_7_TIPAP_AND_UTILS.md` — Created (TipTap extensions & utilities)
- `docs/handoff/priority-high/PHASE_8_COVERAGE_AND_CI.md` — Created (coverage ratcheting & CI)

---

## [v6.2.47] — System Theme + Settings Hardcoded Color Fix (2026-05-05)

- **"System" theme preset added, replacing "Rose"** — The Rose theme has been replaced with a System theme that automatically detects and uses the user's OS-level dark theme via CSS `@media (prefers-color-scheme: dark)`. The system theme uses CSS-only variables (no hardcoded hex values), displays with a 💻 emoji, and has no light mode override. Color pickers are automatically disabled when System theme is active to prevent conflicts with OS-level colors.
- **Settings panel no longer ignores theme colors** — All hardcoded hex colors in Settings.tsx (including inline `#1e1e2e` backgrounds, `#888` muted text, `#3a3a4a` toggle rails, and `#282838` panel backgrounds) have been replaced with CSS custom properties (`var(--bg-hex)`, `var(--card-hex)`, `var(--muted-fg-hex)`, `var(--border-hex)`) so the Settings panel respects the active theme across all 6 tabs (LLM, Tools, Images, Editor, Appearance) and all sub-components (LlmServerStatusPanel, ImageGenStatusPanel, MinimumVramInput, ZImageConfigPanel).

### Files Changed
- `client/src/hooks/useTheme.ts` — Replaced Rose preset with System preset using CSS-only colors, added `prefers-color-scheme: dark` detection
- `client/src/components/ThemePicker.tsx` — Added `disabled` prop to `ColourPickerRow`, all color pickers disabled when `preset === 'system'`
- `client/src/pages/Settings.tsx` — Replaced all hardcoded hex colors with CSS custom properties across all tabs and sub-components

---

## [v6.2.46] — Dracula Replaced with Nymphs Green Theme (2026-05-05)

- **"Dracula" theme preset replaced with "Nymphs" green theme** — The Dracula theme preset has been renamed to "Nymphs" with a green-based color palette. The new theme uses deep green-gray backgrounds (`#1e2e1e`), vibrant green primary accent (`#66bb6a`), and green-tinted muted text (`#6a8a6a`). Dark mode only, displayed with a 🌿 emoji in the theme picker.

### Files Changed
- `client/src/hooks/useTheme.ts` — Renamed `DRACULA` constant to `NYMPHS` with green color palette, updated preset entry from `{ id: 'dracula', ... }` to `{ id: 'nymphs', name: 'Nymphs', emoji: '🌿' }`

---

## [v6.2.45] — Template Profile Filtering Fix (2026-05-05)

- **"Create from Template" now filters by workspace profile** — The server route handler for `/api/files/templates` was ignoring the `profile` query parameter, causing all templates (both game and work) to be returned regardless of the active profile. Fixed by passing `req.query.profile` to `templateService.getAvailableTemplates()`, so game profile users only see game templates (Character, Location, Quest, etc.) and work profile users only see work templates (Customer, Job, Booking, Quote).

### Files Changed
- `server/src/routes/files.js` — Pass `req.query.profile` to `getAvailableTemplates()` in GET `/templates` route handler

---

## [v6.2.44] — Login Page WORBI Branding Update (2026-05-05)

- **Login page now displays proper WORBI branding** — Updated the login page title from "WorldBuilder" to "WORBI" using the Orbitron font to match the main app header. Added "by Nymphs" subtitle with baseline alignment. Changed tagline to "WorldBuilder UI". Updated footer version from "WBUI v2.0" to "WORBI v6.2.43".

### Files Changed
- `client/src/pages/Login.tsx` — Replaced title with "WORBI" (Orbitron font), added "by Nymphs" subtitle with baseline alignment, updated tagline to "WorldBuilder UI", updated footer version

---

## [v6.2.43] — wbu-stop Script Fix: Proper Process Tree Cleanup (2026-05-05)

- **wbu-stop now properly kills child processes and releases ports** — The previous script only killed the parent `npm` process, leaving child Node.js processes orphaned on ports 8082 and 5173. The updated script kills child processes before the parent, includes a port-based fallback using `lsof`/`fuser`, and stops the backend before the frontend to prevent connection errors during shutdown.

### Files Changed
- `Nymphs-Brain/bin/wbu-stop` — Added child process killing via `pgrep -P`, added `kill_port()` fallback function, reversed stop order (backend first)

---

## [v6.2.42] — Profile Selector Modal Wired into Auth Flow (2026-05-05)

- **New users now see Game/Work profile selection on first login** — The ProfileSelectorModal component existed but was not wired into the auth flow. New users (detected by null profile field) are now flagged via localStorage, and the modal appears automatically on app startup, allowing them to choose between Game (D&D campaign management) or Work (business scheduling) folder templates before entering the app.

### Files Changed
- `client/src/services/api.ts` — Added `isNewUser?: boolean` to User interface
- `client/src/hooks/useAuth.ts` — After login, detect new users (null profile), save `isNewUser` flag to localStorage, expose `handleProfileSelect` callback. Added `loginAsNewUser()` helper for testing.
- `client/src/features/auth/AuthProvider.tsx` — Added `isNewUser` to context, computed from localStorage on load, auto-resets after modal shown
- `client/src/App.tsx` — Imported ProfileSelectorModal, destructured `isNewUser`/`handleProfileSelect` from useAuth, rendered modal conditionally

---

## [v6.2.41] — WORBI Agent Skills Comprehensive Update (2026-05-05)

- **All 7 WORBI agent skills updated to v6.2.40** — Complete rewrite of worbi-project, worbi-api, worbi-architecture, worbi-app-refactor, worbi-conventions, worbi-github, and worbi index to reflect current project state. Added 15+ missing components, 5 new API endpoint tables (Reminders, Timeline, Graph, Images, Image Generation), 16 hooks inventory, 12 backend services, 6 data flow patterns, and feature module wiring status.
- **New worbi-ui design system skill** — Created comprehensive UI reference covering CSS custom properties (18 variables), color palette with Tailwind mappings, 11 component patterns with CSS + Tailwind equivalents, 5 custom animations, typography scale, icon library guide, z-index layers, spacing scale, and 10 rules for new components.
- **nymphs-dark-ui deprecated for WORBI** — Updated to redirect to worbi-ui for all WORBI projects while maintaining legacy reference for non-WORBI Nymphs projects.
- **update_record.md archived** — Previous 984-line file backed up to update_record_v6.2.archives.md; fresh file started for v6.2.41+.

### Files Changed
- `.agents/skills/worbi-project/SKILL.md` — Full rewrite
- `.agents/skills/worbi-api/SKILL.md` — Full rewrite
- `.agents/skills/worbi-architecture/SKILL.md` — Full rewrite
- `.agents/skills/worbi-app-refactor/SKILL.md` — Full rewrite
- `.agents/skills/worbi/SKILL.md` — Full rewrite
- `.agents/skills/worbi-conventions/SKILL.md` — Added 3 patterns
- `.agents/skills/worbi-github/SKILL.md` — Updated example
- `.agents/skills/worbi-ui/SKILL.md` — NEW (~500 lines)
- `.agents/skills/nymphs-dark-ui/SKILL.md` — Deprecated for WORBI
- `update_record.md` — Archived + new entry
- `update_record_v6.2.archives.md` — Backup created

---

## [v6.2.40] — Editor Toolbar File+ Dropdown Menu (2026-05-04)

- **Editor toolbar File+ button now uses themed dropdown** — Clicking the File+ icon in the editor toolbar opens a dropdown menu with "New Blank File" and "New from Template..." options, matching the File menu in the header. Eliminates the native `prompt()` dialog that previously appeared.
- **Editor toolbar file creation uses themed dialogs** — `handleCreateFileFromEditor` now uses `showFolderPicker()` and `showPrompt()` (the themed `PromptDialog` and `FolderPickerDialog`) instead of native `prompt()` calls for folder selection and file naming.

### Files Changed
- `client/src/App.tsx` — Replaced native `prompt()` calls in `handleCreateFileFromEditor` with `showFolderPicker()` + `showPrompt()`. Wired `onCreateFromTemplate` prop to DocumentEditor.
- `client/src/components/DocumentEditor.tsx` — Added dropdown menu to File+ button with "New Blank File" and "New from Template..." options. Added `onCreateFromTemplate` prop. Added outside-click dismissal for dropdown.

---

## [v6.2.39] — Strip .html Extension from Tab Bar and Editor Title Bar (2026-05-04)

- **.html extension now hidden from tabs and editor title bar** — File tabs previously showed the full filename with `.html` extension (e.g., `foldertest.html`). Tabs and the editor title bar now display clean names without the extension (e.g., `foldertest`), consistent with the File Explorer which already stripped the extension. File paths on disk remain unchanged — only the display names are affected.

### Files Changed
- `client/src/hooks/useFiles.ts` — Updated `getFileName()` to strip `.html` extension using `.replace(/\.html$/i, '')`, so tab names are clean.
- `client/src/components/DocumentEditor.tsx` — Updated `fileName` variable to strip `.html` extension for the editor title bar display.

---

## [v6.2.38] — Filename Heading in Info Panel Hero Section (2026-05-04)

- **Uppercase filename heading added above hero image in Information Panel** — The hero image section in the Info Panel now displays the current file's name (with `.html` extension stripped) as a bold uppercase heading above the hero image. This provides immediate visual context for which document the panel metadata belongs to, especially useful when browsing files quickly. The heading uses `text-xs font-bold uppercase tracking-wider` styling consistent with the panel's dark theme aesthetic.

### Files Changed
- `client/src/components/InformationPanel.tsx` — Added filename heading element in the hero section that extracts the basename from `currentPath`, strips `.html`, and displays it in uppercase.

---

## [v6.2.37] — Navigate Explorer to Folder when Creating File from Template (2026-05-04)

- **File Explorer now navigates to the new file's folder after creating from template** — When creating a file via "New from Template" (e.g., a Character in the `Characters` folder), the file opened in the editor but the File Explorer remained at its previous location (often root), making it hard to see the newly created file among its siblings. Fixed by updating `handleTemplateSuccess` in `App.tsx` to extract the parent folder from the created file's path and call `setExplorerPath(folder)` + `loadFiles(folder)` before opening the file, matching the same pattern already used in `handleNewFile`.

### Files Changed
- `client/src/App.tsx` — Updated `handleTemplateSuccess` to extract the folder from the file path and navigate the explorer to it before opening the file.

---

## [v6.2.36] — Restore Game Export Button in Header (2026-05-04)

- **"Game Export" button restored in Header toolbar** — The Game Export feature (Gamepad2 icon) was present in `Header.tsx` but invisible because `App.tsx` was not passing the `onGenerateGameFile` prop. The entire game file export system (GameExportModal, templateDetector, gameGeneratorPrompts) was fully implemented but disconnected. Reconnected by: (1) importing `GameExportModal` in App.tsx, (2) adding `showGameExportModal` state, (3) passing `onGenerateGameFile={() => setShowGameExportModal(true)}` to Header, and (4) rendering the modal conditionally with the current file's path, content, and aiOffline status.

### Files Changed
- `client/src/App.tsx` — Added import for `GameExportModal`, added `showGameExportModal` state, wired `onGenerateGameFile` prop to Header, rendered `GameExportModal` with `currentPath`, `content`, `onClose`, `onFileCreated`, and `aiOffline` props.

---

## [v6.2.35] — Fix "Cancel" Button in Unsaved Changes Dialog (2026-05-04)

- **"Cancel" button in unsaved changes dialog now correctly dismisses without closing the tab** — When closing a tab with unsaved changes, the "Cancel" button was inadvertently closing the tab instead of just dismissing the dialog. Root cause: the "Don't Save" callback was stored in React state via `setState`, and during the state update triggered by `setConfirmOpen(true)`, React's state batching caused the callback expression to be evaluated during the render cycle (inside `useState`'s internal `updateReducer`), not as a button click. Fixed by switching the dirty-tab callbacks to `useRef` instead of state, so they are stable across renders and only invoked when the user explicitly clicks a button. Also cleaned up debug logging added during diagnosis.

### Files Changed
- `client/src/App.tsx` — Changed `handleConfirmDirtyClose` to store callbacks in `confirmCallbackRef` / `confirmSecondaryCallbackRef` refs instead of state. Updated `ConfirmDialog`'s `onConfirm`/`onSecondary`/`onCancel` handlers to capture refs into locals before clearing. Removed debug `console.log` statements from `handleTabClose` and `handleConfirmDirtyClose`.

---

## [v6.2.34] — Fix "New Blank File" Opens File and Syncs Explorer (2026-05-04)

- **"New Blank File" now opens the file and syncs explorer** — After creating a blank file via File > New Blank File, the newly created file is now automatically opened in the editor (previously it was created but not opened). The file explorer also navigates to and displays the selected folder (previously the explorer got stuck with a mismatched path state after the folder picker closed, making navigation impossible until a refresh).

### Files Changed
- `client/src/App.tsx` — `handleNewFile` now awaits `newFile()`, syncs `explorerPath` via `setExplorerPath()` + `loadFiles()`, and opens the new file via `openFileWithConversion()`.

---

## [v6.2.33] — Fix Resizable Panel Bars (2026-05-04)

- **Left and right panel resizers now work correctly** — The resize handler was querying DOM elements to determine the initial panel width at drag start, but the DOM traversal returned wrong values (the entire flex container width for the left panel, and the center panel width for the right panel). This caused the left panel resizer to appear stuck (width clamped to max) and the right panel resizer to move in the opposite direction. Replaced the fragile DOM-based width detection with direct React state values passed via getter functions, and added a `reverse` parameter so the right panel drag direction matches user expectation (drag right = grow, drag left = shrink).

### Files Changed
- `client/src/features/layout/useLayout.ts` — Rewrote `createHorizontalResizeHandler` (renamed from `createResizeHandler`) to accept a `getInitialWidth()` function and `persistKey`/`reverse` params instead of querying DOM. Updated `resizeLeftPanel`, `resizeRightPanel`, and `resizeSearchPanel` callers.

---

## [v6.2.32] — Restore Proper UI for "New Blank File" (2026-05-04)

- **"New Blank File" now uses themed dialogs** — Replaced the native browser `prompt()` dialog with the proper themed `FolderPickerDialog` → `PromptDialog` flow. When at root, the folder picker appears first (preventing files in root). When inside a folder, the prompt dialog appears directly for the file name. Also fixed the `FolderPickerDialog` cancel handler so the promise resolves on cancel instead of hanging.

### Files Changed
- `client/src/App.tsx` — `handleNewFile` now uses async `showFolderPicker()` → `showPrompt()` → `newFile()` flow. Fixed FolderPickerDialog cancel to resolve promise.

---

## [v6.2.31] — Fix "New Blank File" Button (2026-05-04)

- **"New Blank File" button now works** — Fixed a signature mismatch between Header.tsx and App.tsx: the Header's `onNewFile` callback was defined as `() => void` (no arguments) but App.tsx's `handleNewFile` required a `(name: string)` parameter, resulting in `undefined` being passed to `newFile()` and silently failing. Replaced with proper themed dialog flow (v6.2.32).

### Files Changed
- `client/src/App.tsx` — Updated `handleNewFile` (superseded by v6.2.32)

---

## [v6.2.30] — Dropdown Folder Picker in New from Template Dialog (2026-05-04)

- **Folder text field replaced with dropdown picker** — The "New from Template" dialog now uses a dropdown folder picker instead of a typed text field. The dropdown lists all existing workspace folders with visual checkmarks for the selected folder.
- **Auto-match folder to template** — When a template is selected, the dropdown auto-selects the closest matching existing folder (e.g., "Location" template → pre-selects "Locations" folder if it exists).
- **Create new folder inline** — If no appropriate folder exists, the dropdown includes a "Create New Folder..." option that lets the user type a new folder name. When a template has a default folder name that doesn't exist yet, it pre-fills the new folder name field.
- **Visual indicator for new folders** — When a non-existing folder is selected (pending creation), a "new" badge appears next to the folder name in the dropdown trigger.

### Files Changed
- `client/src/components/NewFromTemplateModal.tsx` — Replaced folder text input with dropdown picker, added folder loading, auto-match logic, and inline new-folder creation

---

## [v6.2.29] — Fix "Don't Save" Button in Unsaved Changes Dialog (2026-05-04)

- **"Don't Save" button now works correctly** — Fixed a stale closure bug in the ConfirmDialog's `onSecondary` handler where the callback was cleared (`setConfirmSecondaryCallback(null)`) before being invoked, causing the "Don't Save" button to do nothing. The callback is now captured in a local variable before state updates, ensuring it executes correctly.

### Files Changed
- `client/src/App.tsx` — Capture `confirmSecondaryCallback` before clearing in `onSecondary` handler

---

## [v6.2.28] — Explorer Navigates to Folder on Template Create (2026-05-04)

- **File Explorer navigates to target folder after template creation** — When creating a file from a template, the Explorer now automatically navigates to the parent folder where the new file was created, making the new file immediately visible in the file tree.

---

## [v6.2.27] — Quest Template Default Folder Renamed to Quests (2026-05-04)

- **Quest template default folder `QuestArcs` → `Quests`** — The "New from Template" dialog now defaults to the `Quests` folder for Quest templates, matching the user workspace folder structure.

---

## [v6.2.26] — All Template Files Now .html (2026-05-04)

- **Game templates now create `.html` files** — All 7 game templates (Character, Quest, Location, Item, Faction, Creature, Timeline) now generate `.html` files instead of `.txt`. The entire app uses `.html` as the standard file format.
- **File Explorer hides `.html` extension** — Files are stored as `.html` on disk but displayed without the extension in the Explorer tree, matching the current "no-extension" UX.
- **Inline rename preserves `.html`** — When renaming a file via inline rename, if the user omits an extension, `.html` is auto-appended.
- **App.tsx simplified** — Removed all `.txt`-specific conversion logic (plain-text-to-HTML wrapping on open, HTML-to-plain-text on save, buildMetadata restoration). All content is now stored and loaded as HTML natively.
- **storyFileDetector HTML comment metadata** — Build/Template metadata now uses HTML comment format (`<!-- Build: Yes -->`) instead of plain text. Legacy plain-text format is still parsed for backward compatibility during migration.
- **Template service unified** — Server-side `templateService.js` no longer distinguishes between game (.txt) and work (.html) templates; all templates produce `.html` with `<h2>`/`<p>` structure.

## [v6.2.25] — Hidden Build/Template Metadata in Editor (2026-05-04)

- **Hidden metadata in .txt editor** — Opening `.txt` files now extracts `Build:` and `Template:` lines into per-tab metadata so they are invisible in the TipTap editor. The metadata is restored automatically on save, preserving the original file content on disk.
- **Tab buildMetadata field** — Added optional `buildMetadata?: string[]` to the `Tab` interface and `setTabBuildMetadata` function to the file operations chain.
- **Removed obsolete CSS** — Deleted `.story-metadata-hidden` class from `_editor.css` (no longer needed since metadata is stripped from editor content).

## [v6.2.24] — Plain Text Template Newline Preservation (2026-05-04)

- **Bugfix: Template newlines collapsed in editor** — Opening newly created `.txt` files from templates now converts plain text newlines to HTML `<br/>` tags before loading into TipTap, preserving the proper line-by-line field layout instead of rendering everything on one line.

## [v6.2.23] — Story Build Inclusion Metadata + Template Fix (2026-05-04)

- **Story Build inclusion system** — Game template files now include `Build: Yes` and `Template: <type>` metadata headers for story build filtering.
- **storyFileDetector utility** — New `client/src/utils/storyFileDetector.ts` with metadata parsing, auto-detection of template candidates, and mark/unmark helpers.
- **Server templates updated** — All 7 game templates (Character, Quest, Location, Item, Faction, Creature, Timeline) now include `Build: Yes` + `Template: <type>` headers.
- **Auto-detect candidates** — Files in template folders with `[Section]` structure but missing `Build: Yes` can be detected and offered for inclusion review.
- **Bugfix: Template file not found error** — Game templates (Character, Quest, etc.) now load from inline content in `templateService.js` instead of external `.txt` files, fixing path resolution issues. Templates are now completely self-contained.

## [v6.2.22] — New Blank File Folder Selection (2026-05-04)

- **New Blank File requires folder selection** — Clicking "New Blank File" now prompts for a folder first when the explorer is at the workspace root, preventing files from being created in the root. When already inside a folder, the file is created directly in the current folder.
- **FolderPickerDialog enhancements** — Added `disableRoot` prop to hide the root option and `confirmLabel` prop for dynamic button text.

## [v6.2.21] — Game Engine Template Format (2026-05-04)

- **Game templates now create `.txt` files** — All 7 game templates (Character, Quest, Location, Item, Faction, Creature, Timeline) now generate plain-text `.txt` files compatible with the game engine instead of HTML.
- **Info bar metadata headers** — Every game template includes structured `Key: Value` metadata headers (Name, Role, Type, etc.) for the Information Panel.
- **Bracketed section structure** — Templates use `[Section Name]` format matching `GameStoryTemplates` examples for game engine compatibility.
- **Default folder alignment** — Character/Creature→`NPCs/`, Quest→`QuestArcs/`, Timeline→`MainStory/`, Location→`Locations/`, Item→`Items/`, Faction→`Factions/` to match TemplateDetector.
- **Work templates unchanged** — Customer, Job, Booking, Quote remain `.html` files for the Work profile only.
- **Profile-based visibility** — Game templates hidden in Work mode, Work templates hidden in Game mode (already working via `getAvailableTemplates(profile)`).

## [v6.2.x] — App.tsx Refactor, Graph Polish & Game File Generator (2026-05-04)

- **App.tsx decomposition** — Extracted keyboard shortcuts, unsaved-warning, image conversion, dialog JSX, and graph manager into dedicated feature hooks and components. App.tsx reduced from ~1,578 lines to ~1,286 lines.
- **Graph Manager extraction** — `useGraphManager` hook consolidates graph state (`graphModalData`), `useGraph` wiring, and all graph callbacks (`handleGenerate`, `handleViewCached`, `handleClear`, `handleOpenGraph`, `handleCloseModal`) into `features/graph/useGraphManager.ts`.
- **Relationship Graph filters** — Collapsible filter panel with search, edge type toggles, tag toggles, minimum strength slider, and reset button.
- **Multi-select relationship types** — All 5 types selectable by default with toggle dropdown and clear button.
- **Implicit AI mode** — Removed explicit AI toggle; AI mode activates automatically when no instant toggles are active.
- **Instant toggle switches** — Tag-Based, Era-Based, Location-Based as toggle switches in Analysis Mode section.
- **Era & Location relationship types** — New metadata-based connection types for timeline eras and shared locations.
- **Cumulative graph** — Graph now accumulates across sessions with deduplication and localStorage persistence.
- **Seed-based graph rewrite** — Complete redesign from multi-filter global graph to single-seed focused graph.
- **Graph bug fixes** — Mini graph preview cache isolation, username prop wiring, route mount fix.
- **UI polish** — Independent sidebar background colors, per-icon visibility settings, sidebar theme unification.
- **Reminders sidebar fix** — Added missing render branch for `reminders` activity in App.tsx so clicking the Reminders button shows ReminderSidebar instead of falling through to SearchPanel.
- **Game File Generator** — One-click conversion of Story Template documents into GameReady game engine files via LLM. Template type auto-detected from folder path (NPCs, QuestArcs, MainStory, Locations, Items, Factions). Multi-step modal: detect → confirm → generate → review → save. LOOKUP tag support for NoticeBoard templates.

## [v6.1.x] — Reminders, Inline Rename & Profiles (2026-05-03)

- **Reminder system** — Full reminder sidebar with file attachment, recurrence, toast notifications, threading, and auto-polling.
- **Inline rename** — Double-click to rename files/folders directly in the Explorer with auto-confirm on blur.
- **Native rename dialog** — Replaced `window.prompt()` with styled `PromptDialog` for rename operations.
- **Graph cache isolation** — Per-user graph cache keys preventing cross-user data leakage.
- **Workspace profiles** — Game and Work templates with profile selector modal and profile-aware template filtering.
- **Custom modal for new file** — Replaced browser `prompt()` with themed `PromptDialog` for blank file creation.
- **Dotfile hiding** — Fixed dotfile visibility in Explorer, renamed `wbu_timeline_metadata.json` to hidden dotfile.
- **Location filter in graph** — Added location filtering to Relationship Graph sidebar.
- **App.tsx decomposition** — Major refactor from 1,538-line monolith into feature hooks (layout, auth, navigation, files).

## [v6.0.x] — Core Features (2026-05-02 to 2026-05-03)

- **Recents/Starred server-side persistence** — Moved from localStorage to server-side dotfiles with per-user isolation.
- **Location metadata system** — Full CRUD for file locations with autocomplete and dedicated Locations panel.
- **Collapsible left sidebar** — Active icon click hides panel with unfold button restore.
- **LLM settings redesign** — Provider-based conditional UI, connection mode per provider, multi-server detection.
- **Managed LLM server** — Start/stop local llama.cpp with GPU handoff orchestration.
- **Portable Z-Image config** — Managed vs External mode with custom installation folder.
- **Context window management** — Auto-trim chat history, configurable context size presets.
- **Batch file operations** — Multi-select with batch copy/move/delete and floating action bar.
- **Folder Picker dialog** — Visual folder tree picker replacing text input for move operations.
- **Mini graph preview** — Interactive graph visualization in Information Panel right sidebar.
- **Graph features** — Era filtering, JSON parsing resilience (5-strategy fallback), label rendering fixes, timeline metadata.
- **Interactive Relationship Graph** — Force-directed Cytoscape.js visualization with 5 graph types and 5 relationship types.
- **WikiLinks** — Obsidian-style `[[Document Name]]` cross-document linking with autocomplete, hover popover, and backlinks.
- **File restore** — One-click restore to last opened version with snapshot preservation.
- **Outline/Bookmark sidebar** — Heading detection, quick navigation, manual bookmarks with Ctrl+Shift+M.
- **Image to Text** — Document transcription using LLM vision capabilities.
- **Z-Image integration** — AI image generation with VRAM protection, server lifecycle management, AI offline detection.
- **Timeline View** — Chronological view grouped by era with filters and settings modal.
- **AI Writing Assistant** — Ghost text completions, name generator, document generation from prompts.
- **Document Templates** — 7 pre-built templates plus Blank Document with New from Template modal.
- **Story Bible Compiler** — Compile files into single HTML reference with table of contents.
- **Session persistence** — Tabs, folders, and active panel survive page reload.
- **LLM Provider Config** — 16 curated providers with model browser and per-user settings.
- **Theme & Colour Settings** — 6 presets, light/dark toggle, 13 customizable colors with live preview.
- **Custom dialogs** — Styled ConfirmDialog and PromptDialog replacing native browser popups.
- **Unsaved changes warning** — Browser leave confirmation with dirty tab detection.
- **Keyboard shortcuts settings** — 7 rebindable hotkeys with conflict detection and custom badges.
- **Emoji picker** — 8 categories with ~800 emojis, search, and category tabs.

## [v5.x] — AI & Editor Enhancements (2026-04-30 to 2026-05-02)

- **AI Tools Engine** — 8 built-in tools with granular permission system.
- **Tag management** — Create, edit, filter files by tag with color-coded badges.
- **Two-column editor** — Main + margin columns with draggable split and independent TipTap instances.
- **Hero image support** — Per-document hero images persisted in localStorage.
- **Find & Replace** — In-editor search with highlights and case-sensitive toggle.
- **Spellcheck** — Visual underlines with suggestion tooltips.
- **DOCX import/export** — Export as .docx, import via mammoth.js.
- **PDF export** — Render editor content to PDF via html2pdf.js.
- **Image resize** — Custom resize extension with dimension persistence.
- **AI Sidebar toggle** — Show/hide AI panel with session persistence.

## [v4.x] — Core UI & File Management (2026-04-29 to 2026-04-30)

- **WORBI rebrand** — Orbitron font, visual identity, trademark-style logo.
- **Activity Bar** — Thin icon bar for Explorer, Search, Tags views.
- **Full-text workspace search** — Debounced search across all text files.
- **File system undo/redo** — Undo/redo for create, delete, rename, copy, move.
- **Welcome screen** — Recent files, starred favorites, New File button.
- **Copy & move operations** — Full file copy/move across workspace.
- **Blob URL system** — Authenticated image display via blob URL conversion.

## [v3.x] — Image & Editor Foundation (2026-04-29)

- Custom image resize extension with hover drag handle.
- Authenticated image rendering via blob URL system.
- Two-column editor layout with content delimiter.

## [v2.x] — Early Development (2026-04-29)

- Core file CRUD operations with TipTap rich text editor.
- Basic toolbar with formatting controls.
- Initial image insertion support.

---

*WORBI by Nymphs — World Builder UI*