
## v6.2.58 — Fix Cross-User Sidebar Icon Visibility Leakage (2026-05-08)

**Goal:** Fix sidebar icon visibility settings leaking between users during login/logout transitions. When User A logged in, set their preferred visible icons, logged out, and User B logged in, User B saw User A's icon visibility instead of their own saved settings.

**Problem:** WORBI stores sidebar icon visibility per-user in `wbu_${user.username}_sidebar_visibility` localStorage. However, during login/logout transitions, `user` becomes null briefly. Both `useLayout.ts` and `Settings.tsx` fell back to a shared global key `wbu_sidebar_visibility` when `user` was null, causing all users to read/write the same global key during transitions. Additionally, `useLayout.ts` did not re-read localStorage when the user changed, because the `storage` event only fires in other browser tabs, not the current tab.

**Root Cause:** Two bugs combined:
1. **Global fallback key** — When `user` was null (during login/logout), code fell back to `wbu_sidebar_visibility` instead of returning defaults. This caused cross-user data contamination.
2. **Missing user-change trigger** — `useLayout.ts` used a `visibilityRefreshKey` state to trigger re-reads of localStorage, but the `useEffect` that increments it only listened for `storage` and `wbu-sidebar-visibility-change` events. The `storage` event only fires in **other browser tabs**, not the current tab. No effect listened for `user` changes, so the key never updated on login/logout.

### Changes Made

#### client/src/features/layout/useLayout.ts
1. Added `useEffect(() => { setVisibilityRefreshKey(k => k + 1); }, [user?.username]);` to force re-read when user changes
2. Removed global fallback: `const prefix = user ? `wbu_${user.username}_sidebar_visibility` : 'wbu_sidebar_visibility';` → now returns all-hidden default when `!user?.username`
3. Added `user?.username` to `useMemo` dependency array for `hiddenIcons`

**Before:**
```typescript
const prefix = user ? `wbu_${user.username}_sidebar_visibility` : 'wbu_sidebar_visibility';

const hiddenIcons = useMemo((): Set<HideableIcon> => {
  void visibilityRefreshKey;
  const raw = localStorage.getItem(prefix);
  // ... parse and return
}, [visibilityRefreshKey, prefix]);
```

**After:**
```typescript
// Force re-read when user changes (storage event only fires in other tabs)
useEffect(() => {
  setVisibilityRefreshKey(k => k + 1);
}, [user?.username]);

const hiddenIcons = useMemo((): Set<HideableIcon> => {
  void visibilityRefreshKey;
  if (!user?.username) return new Set<HideableIcon>(['tags', 'locations', 'timeline', 'outline', 'graph', 'images', 'reminders', 'ai']);
  try {
    const raw = localStorage.getItem(`wbu_${user.username}_sidebar_visibility`);
    // ... parse and return
  } catch { /* ignore */ }
  return new Set<HideableIcon>(['tags', 'locations', 'timeline', 'outline', 'graph', 'images', 'reminders', 'ai']);
}, [visibilityRefreshKey, user?.username]);
```

#### client/src/pages/Settings.tsx
1. Changed dependency from `user` object to `user?.username` string in `useEffect`/`useCallback` for reliable re-computation
2. Removed global fallback key (same pattern as useLayout.ts)
3. Added `if (!user?.username) return;` guard in `handleToggleVisibility` to prevent writes during transitional states

### Lessons Learned — Documented in Skills
Added Section 9 "Per-User localStorage Isolation (CRITICAL)" to `worbi-conventions` skill covering:
- Always use `wbu_${user.username}_<feature>` keys, never fall back to global
- Use `user?.username` string in deps, not `user` object reference
- Add explicit `useEffect` on `user?.username` — `storage` event won't fire in same tab
- Guard writes with `if (!user?.username) return;`
- Null user = conservative defaults, never guess or inherit

### Packaging & Deployment Lessons (v6.2.58)
- **NEVER `mv ~/worbi` during package testing** — Moving the entire install directory breaks user data. The installer has built-in preservation logic but only works when the old `~/worbi` still exists. Test installs in isolated directories or restore immediately.
- **Archive must exclude server/dist** — The `server/dist/` directory from a previous build was leaking into the archive (different hash than new build). Remove it from staging before building the tar.gz.
- **Production bin scripts must use `~/worbi` paths** — `worbi-start`, `worbi-stop`, `worbi-status` scripts reference `$INSTALL_DIR="$HOME/worbi"` — ensure paths match the actual install location.
- **Verify bundle hash after install** — Compare JS hash served by server (`curl | grep index-`) to hash in `~/worbi/dist/index.html` to confirm correct bundle is served.
- **Package size target** — Final archive: 2.4MB (no node_modules, no user data, no server/dist).

### Files Changed
- `client/src/features/layout/useLayout.ts` — Added user-change useEffect, removed global fallback, added username to useMemo deps
- `client/src/pages/Settings.tsx` — Changed deps from user object to username string, removed global fallback, added write guard
- `.agents/skills/worbi-conventions/SKILL.md` — Added Section 9: Per-User localStorage Isolation rules
- `.agents/skills/worbi-package/SKILL.md` — Updated with packaging deployment lessons
- `worbi-installer/nymph.json` — Updated to 6.2.58
- `CHANGELOG.md` — Added v6.2.58 entry
- `update_record.md` — This entry

---

## v6.2.57 — Fix LLM Settings Provider Display Race Condition (2026-05-08)

**Goal:** Fix the LLM provider dropdown in Settings showing "LM Studio" instead of the user's saved provider (e.g., "llama.cpp") when the Settings panel opens.

**Problem:** The `Settings` component uses a `useLLM()` hook that initializes with empty default settings (`providerId: ''`, `baseUrl: ''`, etc.). On first render, the initial sync `useEffect` fires with these empty defaults, copies them to the form state, and sets `initialSyncDone.current = true`. When the real settings arrive asynchronously from the server a moment later, the effect is skipped because the flag is already true. The provider `<select>` with `value=""` displays the first `<option>` in the list ("LM Studio") instead of the saved provider.

**Root Cause:** Race condition between component mount (empty defaults) and async settings load (real data). The `initialSyncDone` flag was too eager — it consumed the first render regardless of whether settings had actual data.

### Changes Made

#### client/src/pages/Settings.tsx
- Added `&& settings.baseUrl` guard to the initial sync useEffect condition
- Effect now only fires when `settings.baseUrl` is truthy (non-empty), ensuring real settings from the server trigger the sync instead of empty defaults
- Added explanatory comment about the guard to prevent future regressions

**Before:**
```tsx
useEffect(() => {
  if (!initialSyncDone.current) {
    setFormProviderId(settings.providerId);
    ...
    initialSyncDone.current = true;
  }
}, [...]);
```

**After:**
```tsx
useEffect(() => {
  if (!initialSyncDone.current && settings.baseUrl) {
    setFormProviderId(settings.providerId);
    ...
    initialSyncDone.current = true;
  }
}, [...]);
```

### Files Changed
- `client/src/pages/Settings.tsx` — Added `settings.baseUrl` guard to initial sync useEffect

---

## v6.2.52 — Remove LLM Auto-Detection: External-Only Configuration (2026-05-08)

**Goal:** Remove all LLM auto-detection and server management functionality from WORBI, simplifying the LLM configuration to external-only connections managed by the user.

**Problem:** The LLM Settings UI included complex managed server functionality (Connection Mode toggle, LLM Installation Folder field, server Start/Stop/Refresh buttons, port detection endpoint) that caused recurring issues: connection errors ("ECONNREFUSED"), invalid JSON responses ("Unexpected token '<'"), and user confusion about managed vs external modes. The managed server lifecycle was unreliable and not aligned with how users actually run their LLM servers.

### Changes Made

#### 1. Client — Settings.tsx
- Removed Connection Mode section (Managed/External toggle buttons)
- Removed LLM Installation Folder input field
- Removed "Save Configuration" button for installation folder
- Removed entire "LLM Server (Managed)" panel including:
  - "Detect Servers" button
  - Server status indicator (Stopped/Running)
  - "Start llama.cpp" button
  - "Stop Server" button
  - "Refresh" button
- Removed all related state variables and callback handlers
- Simplified to clean configuration: Provider, URL, API Key, Model, Max Tokens, Temperature, Top P, Connection status, Save button

#### 2. Client — useLLM.ts
- Removed server lifecycle management functions (start/stop/detect)
- Removed dependency on llmLifecycle service references
- Simplified to only manage LLM connection configuration and chat

#### 3. Client — api.ts
- Removed `POST /api/llm/detect` endpoint type definition

#### 4. Server — llm.js
- Removed `POST /api/llm/detect` route handler that probed local ports for LLM servers

#### 5. Server — config.js
- Cleaned up managed server configuration references

### Files Changed
- `client/src/pages/Settings.tsx` — Removed Connection Mode toggle, LLM Installation Folder, Server Management panel
- `client/src/hooks/useLLM.ts` — Removed server lifecycle management code
- `client/src/services/api.ts` — Removed LLM detect endpoint type
- `server/src/routes/llm.js` — Removed detect endpoint
- `server/src/config.js` — Cleaned up managed server config references
- `CHANGELOG.md` — Added v6.2.52 entry
- `update_record.md` — This entry
- `.agents/skills/worbi-api/SKILL.md` — Removed detect endpoint from LLM table
- `.agents/skills/worbi-architecture/SKILL.md` — Removed lifecycle/detector services

### Production Deployment Note
Discovered that server serves static files from `server/dist/` (relative to `server/src/`), not `client/dist/`. After building with `npm run build` in client directory, must copy `client/dist/assets/` and `client/dist/index.html` to `server/dist/` for the server to serve the updated frontend.

---

## v6.2.49 — Phase 2 Core Services Tests Complete: 285 Tests Passing (2026-05-05)

**Goal:** Implement all Phase 2 core service tests for WORBI server, covering file, tag, tool, LLM, reminder, and location services, plus integration tests for files and reminders API routes.

**Problem:** Phase 2 specified ~145 core service tests across 6 service files plus 2 integration test files. After Phase 0 (test infrastructure) and Phase 1 (security tests) were completed, the core service layer had zero test coverage. This left the backend services unverified and made refactoring risky.

### Changes Made

#### 1. Created 6 Unit Test Files (206 tests)

**fileService.test.ts** — 63 tests
- Full CRUD: createFile, createFolder, read content, update, delete
- Scanning: scan for files/folders, dotfile filtering, recursive traversal
- Metadata: read/write metadata files, .wbu_metadata.json format
- Search: full-text search across workspace files
- Compression: zip/unzip operations
- Recents/Starred: per-user recents and starred file lists
- Path safety: workspace root resolution, path validation

**tagService.test.ts** — 32 tests
- Tag CRUD: create, get all, update, delete tags
- File tagging: get tags for file, add/remove tags, tag database operations
- Color validation: hex color format, default color assignment
- Duplicate detection: case-insensitive name uniqueness
- Tag files: .tag and .color file format in .wbu/tags/

**toolService.test.ts** — 31 tests
- Tool registry: getAvailableTools, getToolByName
- Discovery: scan for custom tools in .wbu/tools/ directory
- Profiles: profile-aware tool filtering (game vs work)
- Validation: tool manifest structure, required fields
- Game engine constraints: tool permissions per profile

**llmService.test.ts** — 21 tests
- transcribeImage: image-to-text via LLM vision API
- sendChatMessage: chat completion via LLM API
- Config mocking: LLM base URL, API key, model name
- Connection error handling: fallback behavior when LLM unavailable
- Mock pattern: vi.mocked() for axios, vi.mock() for config

**reminderService.test.ts** — 35 tests
- Reminder CRUD: create, get all, get by ID, update, delete
- Threading: addReply to reminder threads
- Firing: markAsFired for due reminders, recurrence handling
- File association: associate reminders with workspace files
- Conversion: convertReminder text replacement
- Recurrence: daily/weekly/monthly recurrence patterns
- Database: newline-separated JSON format in reminders.db

**locationService.test.ts** — 24 tests
- Location CRUD: create, get all, update, delete locations
- File-location associations: get, add, remove, set locations for files
- Queries: getFilesByLocation across workspace
- Default locations: auto-init with standard locations
- Temp workspace isolation: os.homedir() mock to avoid real ~/.wbu

#### 2. Created 2 Integration Test Files (40 tests)

**files.test.ts** — 23 tests
- API routes: GET/POST /api/files (list, create folder)
- File operations: POST /api/files (create file), GET /api/files/content
- Update: PUT /api/files (update content)
- Delete: DELETE /api/files
- Rename: POST /api/files/rename
- Search: GET /api/files/search
- Profile: GET/POST /api/files/profile
- Recents: GET/PUT /api/files/user/recents
- Starred: GET/PUT /api/files/user/starred
- Auth: all routes require authentication

**reminders.test.ts** — 17 tests
- API routes: POST /api/reminders (create), GET /api/reminders (list)
- Grouped: GET /api/reminders/grouped (upcoming/past)
- Update: PUT /api/reminders/:id
- Thread: POST /api/reminders/:id/thread
- Delete: DELETE /api/reminders/:id
- Check: POST /api/reminders/check (fire due reminders)
- Convert: POST /api/reminders/:id/convert
- Auth: all routes require authentication
- Error handling: validation errors, not-found responses

#### 3. Test Patterns Established

- **Mock strategy**: `vi.mock()` for module-level mocks, `vi.spyOn(axios, 'get').mockResolvedValue()` for HTTP, `vi.mocked()` for typed mocked exports
- **Config mock pattern**: Mock config.js with default LLM settings before service import
- **Filesystem isolation**: `createTempWorkspace()` helper for file/tag/tool service tests
- **Location isolation**: `os.homedir()` mock pointing to temp directory
- **Integration pattern**: start test server, login for auth token, make HTTP requests with supertest
- **Small-change delegation**: Create .new copy first, test it, then `cp` to final name

### Test Results

```
 Test Files  11 passed (11)
      Tests  285 passed (285)
   Duration  900ms
```

| Test File | Tests | Status |
|-----------|-------|--------|
| authService.test.ts | 17 | ✓ |
| authMiddleware.test.ts | 8 | ✓ |
| fileService.test.ts | 63 | ✓ |
| tagService.test.ts | 32 | ✓ |
| toolService.test.ts | 31 | ✓ |
| llmService.test.ts | 21 | ✓ |
| reminderService.test.ts | 35 | ✓ |
| locationService.test.ts | 24 | ✓ |
| auth.test.ts (integration) | 14 | ✓ |
| files.test.ts (integration) | 23 | ✓ |
| reminders.test.ts (integration) | 17 | ✓ |

### Files Changed
- `server/tests/unit/services/fileService.test.ts` — Created (63 tests)
- `server/tests/unit/services/tagService.test.ts` — Created (32 tests)
- `server/tests/unit/services/toolService.test.ts` — Created (31 tests)
- `server/tests/unit/services/llmService.test.ts` — Created (21 tests)
- `server/tests/unit/services/reminderService.test.ts` — Created (35 tests)
- `server/tests/unit/services/locationService.test.ts` — Created (24 tests)
- `server/tests/integration/files.test.ts` — Created (23 tests)
- `server/tests/integration/reminders.test.ts` — Created (17 tests)
- `CHANGELOG.md` — Added v6.2.49 entry
- `update_record.md` — This file

---

## v6.2.48 — Test Suite Master Plan Decomposed into 9 Phase Docs (2026-05-05)

**Goal:** Decompose the monolithic TEST_SUITE_SETUP.md (~900 lines) into 9 focused, actionable phase documents that an AI agent can implement sequentially without losing context.

**Problem:** The original TEST_SUITE_SETUP.md was a comprehensive plan covering test infrastructure, security tests, service tests, client hooks, component tests, and CI — all in one document. At ~900 lines with 8 sections, it was too large for a single implementation session. An AI agent working through it would run out of context before completing even Phase 2. Additionally, the original doc lacked WORBI-specific details (actual hook names, route patterns, service method signatures) discovered by analyzing the current codebase.

### Changes Made

#### 1. Created 9 Phase Documents
Each phase document is self-contained with enough detail to be implemented independently:

- **PHASE_0_TEST_INFRASTRUCTURE.md** — Test framework setup (Vitest config, helpers, test setup files, npm scripts)
- **PHASE_1_SECURITY_TESTS.md** — Path traversal guards + authentication tests (CRITICAL priority)
- **PHASE_2_CORE_SERVICES.md** — File, Tag, Tool, LLM, Reminder, and Location service tests
- **PHASE_3_LIFECYCLE_CONFIG_SERVICES.md** — Lifecycle, Detector, Provider, and Template service tests
- **PHASE_4_CLIENT_HOOKS.md** — React hook tests (useAuth, useFiles, useLLM, useTags, etc.)
- **PHASE_5_FEATURE_MODULES.md** — Feature module tests (AuthProvider, useActivityRouter, useUnsavedWarning, etc.)
- **PHASE_6_COMPONENT_SMOKE_TESTS.md** — UI component smoke tests (ActivityBar, FileExplorer, TabBar, etc.)
- **PHASE_7_TIPAP_AND_UTILS.md** — TipTap extension tests and utility function tests
- **PHASE_8_COVERAGE_AND_CI.md** — Coverage ratcheting strategy and CI pipeline setup

#### 2. Updated TEST_SUITE_SETUP.md
- Added Master Phase Index table linking to all 9 phase documents with test counts
- Updated target version to v6.2.48
- Added "Key Differences from Original" section summarizing WORBI-specific additions

#### 3. Key WORBI-Specific Additions in Phase Docs
Phase documents include details discovered by analyzing the WORBI codebase:
- Actual WORBI service names (fileService, tagService, toolService, llmService, reminderService, locationService, lifecycleService, detectorService, providerCatalog, templateService)
- Actual WORBI route patterns (/api/files/**, /api/tags/**, /api/llm/**, /api/reminders/**, /api/settings/**, /api/timeline/**, /api/graph/**, /api/images/**, /api/image-generation/**)
- Actual WORBI hook names (useAuth, useFiles, useLLM, useTags, useRecents, useSearch, useReminders, useLocations, useImageGeneration, useTheme, useKeyboardShortcuts, etc.)
- Mock strategies tailored to WORBI architecture (axios mocking for LLM server, child_process.spawn mocking for lifecycle services, localStorage mocking for client hooks)
- WORBI-specific test cases (profile-aware templates, game engine tool constraints, managed vs external LLM modes, Z-Image lifecycle, cumulative graph)

#### 4. Test Count Summary
Total planned tests across all phases: ~488 tests
- Phase 0: 20-30 tests (infrastructure verification)
- Phase 1: ~85 tests (security: path traversal + auth)
- Phase 2: ~145 tests (core services)
- Phase 3: ~60 tests (lifecycle/config services)
- Phase 4: ~70 tests (client hooks)
- Phase 5: ~25 tests (feature modules)
- Phase 6: ~30 tests (component smoke tests)
- Phase 7: ~25 tests (TipTap extensions + utilities)
- Phase 8: 0 new tests (coverage + CI only)

### Files Changed
- `docs/handoff/priority-high/TEST_SUITE_SETUP.md` — Added Master Phase Index table, version update, key differences section
- `docs/handoff/priority-high/PHASE_0_TEST_INFRASTRUCTURE.md` — Created (test infrastructure setup)
- `docs/handoff/priority-high/PHASE_1_SECURITY_TESTS.md` — Created (path traversal + auth tests)
- `docs/handoff/priority-high/PHASE_2_CORE_SERVICES.md` — Created (file, tag, tool, LLM, reminder, location)
- `docs/handoff/priority-high/PHASE_3_LIFECYCLE_CONFIG_SERVICES.md` — Created (lifecycle, detector, provider, template)
- `docs/handoff/priority-high/PHASE_4_CLIENT_HOOKS.md` — Created (React hook tests)
- `docs/handoff/priority-high/PHASE_5_FEATURE_MODULES.md` — Created (feature module tests)
- `docs/handoff/priority-high/PHASE_6_COMPONENT_SMOKE_TESTS.md` — Created (UI component smoke tests)
- `docs/handoff/priority-high/PHASE_7_TIPAP_AND_UTILS.md` — Created (TipTap extensions & utilities)
- `docs/handoff/priority-high/PHASE_8_COVERAGE_AND_CI.md` — Created (coverage ratcheting & CI)
- `CHANGELOG.md` — Added v6.2.48 entry

---

## v6.2.51 — Production Deploy Fix: Profile Selector, Bin Scripts, Dist Symlink (2026-05-07)

### Problem
v6.2.50 package did not include the compiled AuthProvider fix (profile selector loop on refresh). Additionally, the production `worbi-start`/`worbi-stop` bin scripts had incorrect working directory paths, and the server reported "Cannot GET /" because it couldn't find the frontend dist/.

### Root Causes Discovered
1. **Package didn't include compiled fix** — The `worbi-6.2.50.tar.gz` archive was built before the AuthProvider fix was applied to the client dist, so installing it deployed stale code.
2. **Bin scripts ran from wrong directory** — `worbi-start` executed `node src/index.js` from `$HOME/worbi` instead of `$HOME/worbi/server`, causing the Express server to fail to find its files.
3. **Server dist path mismatch** — `server/src/index.js` resolves frontend dist at `path.resolve(__dirname, '../dist')` which is `server/dist/` relative to the server directory, but the installer placed dist at `~/worbi/dist/`. The server fell back to "API-only mode" and returned 404 for `/`.

### Fixes Applied
1. **Rebuilt dist from source** — Ran `npm run build` in Nymphs-Brain/WORBI to produce fresh dist/ with AuthProvider fix included, verified `wbu_profile` present in bundle.
2. **Fixed bin scripts** — Updated `worbi-start` to `cd "$INSTALL_DIR/server"` before running Node, fixed node_modules check path.
3. **Created dist symlink** — `ln -sf /home/nymph/worbi/dist /home/nymph/worbi/server/dist` bridges the path gap between where installer puts dist and where server expects it.
4. **Updated installer** — Modified `installer_from_package.sh` to: (a) copy `dist/` from archive, (b) create `server/dist` symlink automatically after install.

### Files Changed
- `Nymphs-Brain/WORBI/client/dist/` — Rebuilt with AuthProvider fix
- `worbi-installer/scripts/installer_from_package.sh` — Added `dist/` copy and `server/dist` symlink creation
- `worbi-installer/scripts/install_worbi.sh` — Resolved merge conflict, kept dynamic nymph.json archive path
- `worbi-installer/nymph.json` — Updated to `packages/worbi-6.2.51.tar.gz`
- `CHANGELOG.md` — Updated v6.2.51 entry with dist symlink details
- `update_record.md` — This entry

### Installer Architecture Note
The server's `index.js` uses `path.resolve(__dirname, '../dist')` to find the frontend. When installed to `~/worbi/`, this resolves to `~/worbi/server/dist/`. The installer places dist at `~/worbi/dist/`. A symlink `server/dist -> /home/nymph/worbi/dist` is the correct solution because:
- It doesn't require modifying the server source code
- It survives reinstall (installer recreates the symlink)
- It preserves the separation between server code and frontend assets

### Production Verification
- Health check: `curl http://localhost:8082/api/health` → `{"status":"ok"}`
- Frontend: `curl http://localhost:8082/` → returns React HTML with `wbu_profile` in bundle
- Server logs: `Serving frontend from: /home/nymph/worbi/server/dist` (no longer "API-only mode")
