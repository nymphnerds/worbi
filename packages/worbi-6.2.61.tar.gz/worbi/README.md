# 🌍 WORBI

<div align="center">

# WorldBuilder UI

**Write stories. Design quests. Build worlds. Powered by AI.**

A professional world-building workspace for writers, GMs, and creators —
running 100% locally on your machine. No cloud. No trackers. Your data, your rules.

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Version](https://img.shields.io/badge/Version-5.0.0-brightgreen.svg)](./CHANGELOG.md)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.4-blue.svg)](https://www.typescriptlang.org/)
[![React](https://img.shields.io/badge/React-18-green.svg)](https://react.dev/)
[![Node.js](https://img.shields.io/badge/Node.js-18+-black.svg)](https://nodejs.org/)
[![Powered by AI](https://img.shields.io/badge/Powered%20by-Local%20AI-purple)](#)

---

> **WORBI** gives you a VS Code–style editor purpose-built for crafting
> fictional universes — with a full rich-text editor, AI writing assistant,
> local image generation, and smart file organization.

---</div>

## ✨ Feature Highlights

| Domain | What you get |
|--------|--------------|
| [📝 Rich Editor](#-rich-document-editor) | WYSIWYG, two-column layout, TipTap/ProseMirror under the hood |
| [🤖 AI Assistant](#-ai-writing-assistant) | Ghost-text completions, name generator, document scaffolding |
| [🎨 Image Generation](#-ai-image-generation) | Local text-to-image & image-to-image via Z-Image-Turbo |
| [🧰 AI Tools](#-ai-tools-engine) | Web search, file CRUD, granular permission controls |
| [📁 Organization](#-file--tag-management) | Tags, relationships, hero images, timeline, story-bible export |
| [💾 Import / Export](#-export--import) | DOCX import · PDF & DOCX export |

---

## 📸 Screenshots

### Main Editor

_The two-pane workspace with the file explorer, Information Panel, and AI sidebar._

<!--
  TODO: replace with real screenshots
  ─────────────────────────────────────────────
  Place files at docs/screenshots/ and update paths below.
-->

<!-- <img src="docs/screenshots/editor-main.png" alt="WORBI Editor" width="100%" /> -->

### AI Image Generator

_Full generator panel with prompt controls, progress, and VRAM protection._

<!-- <img src="docs/screenshots/image-generator.png" alt="WORBI Image Generator" width="100%" /> -->

### Tag & Relationship Manager

_Color-coded tags, implicit/explicit relationships, timeline view._

<!-- <img src="docs/screenshots/tag-manager.png" alt="WORBI Tag Manager" width="100%" /> -->

> **No screenshots yet?** Drop them in `docs/screenshots/` and uncomment the lines above.

---

## 🚀 Quick Start

### Prerequisites

| Requirement | Details |
|-------------|---------|
| **Node.js** | `>= 18` |
| **npm** | `>= 9` |
| **GPU (optional)** | NVIDIA w/ ≥ 8 GB VRAM for local image generation |
| **Z-Image server (optional)** | [Nymphs2D2](../Z-Image/) running externally on `localhost:8090` |
| **LLM backend** | Any OpenAI-compatible server (LM Studio, Ollama, vLLM …) or cloud provider |

> **Note:** Image generation is fully optional. WORBI works without it — you'll just skip the 🎨 features.

### Install & Run

```bash
# 1. Clone
git clone git@github.com:rauty79/worbi.git
cd worbi

# 2. Install dependencies
npm install

# 3. Start dev server (server + client)
npm run dev
```

| Service | URL |
|---------|-----|
| 🖥️ API Server | `http://localhost:8082` |
| 🌐 Web Client | `http://localhost:5173` |

Open **http://localhost:5173** in your browser — you're in.

---

## 📝 Rich Document Editor

- **Two-Column Layout** — Main editor + draggable Information Panel
- **Full WYSIWYG** — Bold, italic, headings (H1–H6), lists, tables, code blocks, inline code, alignment & colors
- **Drag-to-Resize Images** — Hover for handles; persist via blob bridge
- **Spellcheck** — Real-time typo detection
- **Multi-File Tabs** — Dirty-state indicators for unsaved changes
- **Full-Text Search** — Across every document in your workspace

---

## 🤖 AI Writing Assistant

| Feature | Shortcut | Description |
|---------|----------|-------------|
| **Ghost Text** | `Ctrl+Space` | Inline AI continuation as dimmed text |
| **Accept** | `Tab` | Commit suggestion |
| **Dismiss** | `Esc` | Dismiss suggestion |
| **Auto-Complete** | ✨ toggle | Continuous suggestions after 1.5 s idle |
| **Name Generator** | — | Culture-specific names on demand |
| **Document Generator** | — | Scaffold characters, locations, quests, timelines |

### LLM Providers

WORBI supports **any OpenAI-compatible API**:

- **Local:** LM Studio · Ollama · llama.cpp · TextGen WebUI · LocalAI · Jan · vLLM
- **Cloud:** OpenAI · Groq · Together AI · OpenRouter · Mistral · Anthropic ⚠ · xAI · Google AI ⚠

> ⚠ Non-OpenAI providers (Anthropic, Google) may require a custom adapter for chat.

Configure your provider in **Settings → LLM** — no env vars needed.

---

## 🎨 AI Image Generation

Powered by [**Z-Image-Turbo**](../Z-Image/) (Nymphs2D2) running on your GPU:

- **Text-to-Image** — Prompt → image in seconds
- **Image-to-Image** — Variations from an existing image
- **Full Controls** — Steps, guidance scale, seed, negative prompt, strength
- **VRAM Protection** — Server-side GPU check prevents OOM crashes
- **Real-Time Progress** — Live progress bar
- **Auto Save** — Images land in `assets/images/`

Configure your Z-Image server URL in **Settings → Images** and hit **Test Connection**.

---

## 🧰 AI Tools Engine

The AI doesn't just write — it **takes action**:

| Tool | Description |
|------|-------------|
| 🔍 Web Search | Internet research & lore lookups |
| 📄 File Read | Read workspace files, search content |
| 📝 File Create | Create new documents from chat |
| ✏️ File Edit | Modify existing documents |
| 🗑️ Delete / Rename | Destructive ops (gated by permissions) |

- **Granular Permissions** — Settings → Tools tab
- **One-Click Toggle** — ⚡ button in chat header
- **Live Status Cards** — See what the AI is doing, in real time

---

## 📁 File & Tag Management

- **File Explorer** — Create, rename, delete, copy, move
- **Default Folders** — `MainStory` · `Quests` · `Characters` · `World`
- **Tag System** — Color-coded, attachable to any file
- **Tag Relationships** — Implicit (shared tags) + explicit connections
- **Hero Images** — Visual identity per document
- **Timeline View** — Era-based chronological event browser
- **Story Bible Export** — Compile entire workspace into a single document

---

## 💾 Export & Import

| Format | Direction | Notes |
|--------|-----------|-------|
| **DOCX** | Import | Drag a `.docx` into WORBI |
| **PDF** | Export | Print-ready world bibles |
| **DOCX** | Export | Edit offline in Word |

---

## ⌨️ Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Ctrl+S` / `Cmd+S` | Save file |
| `Ctrl+B` | Bold |
| `Ctrl+I` | Italic |
| `Ctrl+U` | Underline |
| `Ctrl+Space` | AI ghost text |
| `Tab` | Accept AI suggestion |
| `Esc` | Dismiss AI suggestion |
| `Ctrl+F` | Find |
| `Ctrl+H` | Replace |

---

## 🛠️ Tech Stack

<div align="center">

| **Frontend** | **Backend** |
|---|---|
| ⚛️ React 18 | 🟢 Node.js 18+ |
| 📘 TypeScript 5 | 🚂 Express.js |
| ✍️ TipTap / ProseMirror | 🔐 JWT Auth |
| 🎨 Tailwind CSS | 📦 Multer |
| ⚡ Vite | 🌐 HTTP (Z-Image) |

</div>

---

## 📂 Project Structure

```
WORBI/
├── server/                  # Express.js backend
│   ├── src/
│   │   ├── routes/          # API routes (auth, files, LLM, settings, tags)
│   │   ├── services/        # Business logic
│   │   ├── middleware/      # Auth middleware
│   │   └── config.js        # Server + user settings config
│   └── package.json
├── client/                  # React + Vite frontend
│   ├── src/
│   │   ├── components/      # React components
│   │   ├── hooks/           # Custom hooks (useFiles, useAuth, useLLM …)
│   │   ├── extensions/      # TipTap extensions
│   │   ├── pages/           # Page components
│   │   ├── services/        # API client layer
│   │   └── styles/          # Tailwind + global CSS
│   └── package.json
├── data/                    # User data (settings, assets, workspace)
├── docs/                    # Technical documentation
├── CHANGELOG.md
└── README.md
```

---

## 📖 Documentation

| Doc | Topic |
|-----|-------|
| [CHANGELOG.md](./CHANGELOG.md) | Version history |
| [docs/BRANDING.md](./docs/BRANDING.md) | Visual identity & design system |
| [docs/SPELLCHECK_SYSTEM.md](./docs/SPELLCHECK_SYSTEM.md) | Spellcheck internals |
| [docs/TAG_SYSTEM_ENHANCEMENT.md](./docs/TAG_SYSTEM_ENHANCEMENT.md) | Tag architecture |
| [docs/TAG_RELATIONSHIP_SYSTEM.md](./docs/TAG_RELATIONSHIP_SYSTEM.md) | Relationships |
| [docs/INFORMATION_PANEL_SYSTEM.md](./docs/INFORMATION_PANEL_SYSTEM.md) | Info panel & hero images |
| [docs/AI_TOOLS_INTEGRATION.md](./docs/AI_TOOLS_INTEGRATION.md) | Tool engine & permissions |

---

## 🤝 Contributing

Contributions are welcome! Please read the docs in `/docs` before opening a PR
to stay aligned with project conventions.

1. **Fork** the repository
2. Create a feature branch (`git checkout -b feat/amazing-thing`)
3. Commit with descriptive messages (`git commit -m 'feat: add amazing thing'`)
4. Push and open a **Pull Request**

---

## 📄 License

**MIT** — See [LICENSE](LICENSE) for details.

---

<div align="center">

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

**Built with 💜 by [Nymphs](https://github.com/rauty79)**

_Write stories. Design quests. Build worlds._

_Your world. Your rules. Your tools._

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

</div>