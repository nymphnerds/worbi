# WBUI — Game Worldbuilder UI (Handoff Document)

## Project Overview

**WBUI** (WorldBuilder UI) is a local, self-hosted web application for game developers to write and manage main story quests, side quests, character profiles, lore, and related assets. It features a modern VSCode-inspired layout with integrated AI chat powered by a user-configured local LLM server (OpenAI-compatible).

---

## Core Requirements

### Layout (3-Panel IDE Style)
```
┌──────────────────────────────────────────────────────────┐
│  Header / Toolbar (app title, settings gear, new file)  │
├─────────────┬────────────────────────┬──────────────────┤
│             │                        │                  │
│ File/Folder │   Document Editor      │   AI Chat Panel  │
│ Explorer    │   (Markdown + Preview) │                  │
│ (Left)      │   (Center)             │   (Right)        │
│             │   - Inline images      │   - Context-     │
│ - Quests/   │   - Drag-drop images   │     aware        │
│ - Characters│   - Split edit/preview │   - Chat history │
│ - Lore/     │                        │   - Per-doc      │
│ - Maps/     │                        │     sessions     │
│ - Assets/   │                        │                  │
│             │                        │                  │
├─────────────┴────────────────────────┴──────────────────┤
│  Status Bar (file info, connection status, word count)   │
└──────────────────────────────────────────────────────────┘
```

### Features
- **File/Folder Explorer**: Tree view with create, rename, delete
- **Document Editor**: Markdown-based with live preview, inline image rendering
- **Image Support**: Drag-and-drop image attachment, displayed inline in documents
- **AI Chat Panel**: Connected to user-configured local LLM, context-aware of current document
- **Settings Panel**: User-configured LLM server connection details
- **Dark Theme**: Modern IDE-style dark UI
- **Local Storage**: All game content stored locally on disk

---

## LLM Configuration Interface

Users configure their own LLM connection via a settings panel:

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| Server Type | Dropdown | LM Studio | LM Studio / Ollama / Custom |
| Base URL | Text | `http://localhost:1234/v1` | OpenAI-compatible API endpoint |
| API Key | Password | (empty) | Optional authentication key |
| Model Name | Text | (auto-detected) | Model to use for chat |
| Max Tokens | Number | 4096 | Maximum response length |
| Temperature | Number | 0.7 | Creativity (0.0–2.0) |

- **"Test Connection"** button to verify connectivity
- Settings persisted in server-side config file (`server/data/settings.json`)
- Model list auto-fetched from the configured server

---

## Tech Stack

| Layer | Technology |
|-------|------------|
| Frontend | React 18 + TypeScript + Vite |
| UI Components | Tailwind CSS + custom components |
| Icons | Lucide React |
| Markdown | react-markdown |
| Backend | Node.js + Express (ESM modules) |
| File Storage | Local filesystem (configurable root directory) |
| Image Handling | Multer upload + static file serving |
| Deployment | WSL (NymphsCore), Port 8082 |

---

## Project Structure

```
WBServer/
├── package.json                   # Root workspace
├── WBUI_HANDOFF.md                # This file
├── server/
│   ├── package.json
│   ├── src/
│   │   ├── index.js               # Express entry point (ESM)
│   │   ├── config.js              # Server configuration + settings persistence (ESM)
│   │   ├── routes/
│   │   │   ├── files.js           # File CRUD API
│   │   │   ├── llm.js             # LLM proxy API
│   │   │   └── settings.js        # Settings API
│   │   └── services/
│   │       ├── fileService.js     # File system operations
│   │       └── llmService.js      # OpenAI-compatible API client
│   └── data/                       # Game content root (files + images)
│       ├── quests/
│       │   ├── main/
│       │   └── side/
│       ├── characters/
│       ├── lore/
│       ├── maps/
│       └── assets/
│           └── images/
├── client/
│   ├── package.json
│   ├── index.html
│   ├── vite.config.ts
│   ├── tsconfig.json
│   ├── tsconfig.node.json
│   ├── tailwind.config.js
│   ├── postcss.config.js
│   └── src/
│       ├── main.tsx               # React entry point
│       ├── App.tsx                # Main 3-panel layout
│       ├── pages/
│       │   └── Settings.tsx       # LLM configuration page
│       ├── components/
│       │   ├── FileExplorer.tsx   # Left panel: file tree
│       │   ├── DocumentEditor.tsx # Center: Markdown editor + preview
│       │   ├── ChatPanel.tsx      # Right: AI chat
│       │   ├── Header.tsx         # Top toolbar
│       │   └── StatusBar.tsx      # Bottom status bar
│       ├── hooks/
│       │   ├── useFiles.ts        # File operations hook
│       │   └── useLLM.ts          # LLM chat + settings hook
│       ├── services/
│       │   └── api.ts             # API client, types
│       └── styles/
│           └── globals.css        # Tailwind + dark theme
```

---

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/files` | List files/folders (with path query) |
| POST | `/api/files` | Create file or folder |
| PUT | `/api/files/:path` | Update file content |
| DELETE | `/api/files/:path` | Delete file or folder |
| POST | `/api/files/upload` | Upload image (multipart) |
| GET | `/api/files/image/:filename` | Serve uploaded image |
| GET | `/api/llm/models` | Fetch available models from LLM server |
| POST | `/api/llm/chat` | Send chat message to LLM (with document context) |
| GET | `/api/settings` | Get saved LLM settings |
| POST | `/api/settings` | Save LLM settings |
| POST | `/api/settings/test` | Test LLM connection |
| GET | `/api/health` | Health check |

---

## AI Context System

When the user sends a message in the AI chat:
1. Current document content is attached as system/context prompt
2. Embedded image references are noted
3. Chat history for the current document session is maintained
4. The LLM responds with AI-assisted suggestions, writing help, or answers

---

## Deployment

- **Target**: WSL (NymphsCore distribution)
- **Port**: 8082
- **Access**: `http://localhost:8082` from Windows browser
- **Data Persistence**: All game content stored in `server/data/` on WSL filesystem
- **Startup**: `npm run dev` (or `npm start` for production)

---

## Design Principles

1. **Modern & Clean**: Dark theme, subtle borders, consistent spacing
2. **Intuitive**: Familiar VSCode-like layout for developers
3. **Local-First**: All data stays on the user's machine
4. **Flexible LLM**: Supports any OpenAI-compatible endpoint
5. **Image-First**: Images are first-class citizens in documents

---

## Status

- **Phase**: Implementation in progress
- **Created**: 2026-04-29
- **Last Updated**: 2026-04-29

### Completed
- ✅ Project structure and config files (Vite, TypeScript, Tailwind, PostCSS)
- ✅ Backend: Express server with ESM modules (index.js, config.js)
- ✅ Backend: File routes (CRUD + image upload/serve)
- ✅ Backend: LLM proxy routes (chat, models)
- ✅ Backend: Settings routes (get, save, test connection)
- ✅ Backend: File service and LLM service
- ✅ Frontend: All components (Header, FileExplorer, DocumentEditor, ChatPanel, StatusBar)
- ✅ Frontend: Settings page with full LLM config UI
- ✅ Frontend: Hooks (useFiles, useLLM)
- ✅ Frontend: API service with types
- ✅ Frontend: Dark theme with Tailwind CSS

### Remaining
- [ ] Fix server service files to use ESM `import` (currently CommonJS `require`)
- [ ] Create `server/data/` directory structure
- [ ] Install all npm dependencies (root, server, client)
- [ ] Test end-to-end: start server, verify API, test frontend
- [ ] Add ImagePreview.tsx component (optional enhancement)
- [ ] Add client `services/llm.ts` (optional - LLM logic is in useLLM hook)
- [ ] Add error boundaries and loading states
- [ ] Add keyboard navigation for file explorer
- [ ] Add drag-and-drop file reordering in explorer

---

## Quick Start (Once Dependencies Installed)

```bash
# Install dependencies
cd WBServer
npm install
cd server && npm install
cd ../client && npm install
cd ..

# Start development servers
# Terminal 1: Backend
cd server && npm run dev

# Terminal 2: Frontend
cd client && npm run dev

# Access at http://localhost:5173 (frontend)
# API at http://localhost:8082 (backend)
```

---

## Known Issues

1. **Module system mismatch**: `fileService.js`, `llmService.js`, and route files may still use CommonJS `require()` — need to convert to ESM `import` to match `config.js` and `index.js`
2. **No dependencies installed**: `node_modules` directories don't exist yet
3. **No data directory**: `server/data/` and subdirectories need to be created