import { renderHook, act, waitFor } from '@testing-library/react';
import { vi, describe, it, expect, beforeEach } from 'vitest';

vi.mock('../services/api', async () => ({
  getLocations: vi.fn(),
  createLocation: vi.fn(),
  updateLocation: vi.fn(),
  deleteLocation: vi.fn(),
  getFileLocations: vi.fn(),
  addLocationsToFile: vi.fn(),
  removeLocationFromFile: vi.fn(),
  setFileLocations: vi.fn(),
  getFilesByLocation: vi.fn(),
}));

import * as api from '../services/api';
const mockGetLocations = api.getLocations as ReturnType<typeof vi.fn>;
const mockCreateLocation = api.createLocation as ReturnType<typeof vi.fn>;
const mockUpdateLocation = api.updateLocation as ReturnType<typeof vi.fn>;
const mockDeleteLocation = api.deleteLocation as ReturnType<typeof vi.fn>;
const mockGetFileLocations = api.getFileLocations as ReturnType<typeof vi.fn>;
const mockAddLocationsToFile = api.addLocationsToFile as ReturnType<typeof vi.fn>;
const mockRemoveLocationFromFile = api.removeLocationFromFile as ReturnType<typeof vi.fn>;
import { useLocations, useFileLocations } from './useLocations';

beforeEach(() => {
  vi.clearAllMocks();
  mockGetLocations.mockResolvedValue([
    { id: '1', name: 'Castle', color: '#10b981' },
    { id: '2', name: 'Forest', color: '#22c55e' },
  ]);
  mockGetFileLocations.mockResolvedValue(['Castle']);
  mockAddLocationsToFile.mockResolvedValue(undefined);
  mockRemoveLocationFromFile.mockResolvedValue(undefined);
});

describe('useLocations', () => {
  it('should load locations on mount', async () => {
    const { result } = renderHook(() => useLocations());
    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(result.current.locations).toHaveLength(2);
    expect(result.current.locations[0].name).toBe('Castle');
  });

  it('should create a new location', async () => {
    const newLoc = { id: '3', name: 'Mountain', color: '#f59e0b' };
    mockCreateLocation.mockResolvedValue(newLoc);

    const { result } = renderHook(() => useLocations());
    await waitFor(() => expect(result.current.loading).toBe(false));

    await act(async () => {
      await result.current.createLocation('Mountain', '#f59e0b');
    });

    expect(result.current.locations).toHaveLength(3);
    expect(result.current.locations[2]).toEqual(newLoc);
  });

  it('should update a location', async () => {
    const updatedLoc = { id: '1', name: 'Dark Castle', color: '#6366f1' };
    mockUpdateLocation.mockResolvedValue(updatedLoc);

    const { result } = renderHook(() => useLocations());
    await waitFor(() => expect(result.current.loading).toBe(false));

    await act(async () => {
      await result.current.updateLocation('1', { name: 'Dark Castle' });
    });

    expect(result.current.locations.find(l => l.id === '1')).toEqual(updatedLoc);
  });

  it('should delete a location', async () => {
    mockDeleteLocation.mockResolvedValue(undefined);

    const { result } = renderHook(() => useLocations());
    await waitFor(() => expect(result.current.loading).toBe(false));

    await act(async () => {
      await result.current.deleteLocation('1');
    });

    expect(result.current.locations).toHaveLength(1);
    expect(result.current.locations[0].name).toBe('Forest');
  });

  it('should get color by location name', async () => {
    const { result } = renderHook(() => useLocations());
    await waitFor(() => expect(result.current.loading).toBe(false));

    expect(result.current.getByColor('Castle')).toBe('#10b981');
    expect(result.current.getByColor('Unknown')).toBe('#10b981'); // default
  });

  it('should handle fetch error', async () => {
    mockGetLocations.mockRejectedValue(new Error('Network error'));

    const { result } = renderHook(() => useLocations());
    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(result.current.error).toBe('Network error');
  });
});

describe('useFileLocations', () => {
  it('should load file locations on mount', async () => {
    mockGetFileLocations.mockResolvedValue(['Castle', 'Forest']);

    const { result } = renderHook(() => useFileLocations('/file.txt'));
    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(result.current.fileLocations).toEqual(['Castle', 'Forest']);
  });

  it('should return empty when path is null', async () => {
    const { result } = renderHook(() => useFileLocations(null));
    await waitFor(() => expect(result.current.fileLocations).toEqual([]));
  });
});