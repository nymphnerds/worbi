import { renderHook, act, waitFor } from '@testing-library/react';
import { vi, describe, it, expect, beforeEach } from 'vitest';

vi.mock('../services/api', async () => ({
  getTags: vi.fn(),
  createTag: vi.fn(),
  updateTag: vi.fn(),
  deleteTag: vi.fn(),
  getFileTags: vi.fn(),
  addTagsToFile: vi.fn(),
  removeTagFromFile: vi.fn(),
  setFileTags: vi.fn(),
  getFilesByTag: vi.fn(),
  getFileRelationships: vi.fn(),
}));

import * as api from '../services/api';
const mockGetTags = api.getTags as ReturnType<typeof vi.fn>;
const mockCreateTag = api.createTag as ReturnType<typeof vi.fn>;
const mockUpdateTag = api.updateTag as ReturnType<typeof vi.fn>;
const mockDeleteTag = api.deleteTag as ReturnType<typeof vi.fn>;
const mockGetFileTags = api.getFileTags as ReturnType<typeof vi.fn>;
const mockAddTagsToFile = api.addTagsToFile as ReturnType<typeof vi.fn>;
const mockRemoveTagFromFile = api.removeTagFromFile as ReturnType<typeof vi.fn>;
const mockSetFileTags = api.setFileTags as ReturnType<typeof vi.fn>;
const mockGetFilesByTag = api.getFilesByTag as ReturnType<typeof vi.fn>;
const mockGetFileRelationships = api.getFileRelationships as ReturnType<typeof vi.fn>;
import { useTags, useFileTags, useTagQueries } from './useTags';

beforeEach(() => {
  vi.clearAllMocks();
  mockGetTags.mockResolvedValue([
    { id: '1', name: 'red', color: '#ff0000' },
    { id: '2', name: 'blue', color: '#0000ff' },
  ]);
  mockGetFileTags.mockResolvedValue(['red']);
  mockGetFilesByTag.mockResolvedValue([]);
  mockGetFileRelationships.mockResolvedValue(null);
});

describe('useTags', () => {
  it('should load tags on mount', async () => {
    const { result } = renderHook(() => useTags());
    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(result.current.tags).toHaveLength(2);
    expect(result.current.tags[0].name).toBe('red');
  });

  it('should create a new tag', async () => {
    const newTag = { id: '3', name: 'green', color: '#00ff00' };
    mockCreateTag.mockResolvedValue(newTag);

    const { result } = renderHook(() => useTags());
    await waitFor(() => expect(result.current.loading).toBe(false));

    await act(async () => {
      await result.current.createTag('green', '#00ff00');
    });

    expect(result.current.tags).toHaveLength(3);
    expect(result.current.tags[2]).toEqual(newTag);
  });

  it('should update a tag', async () => {
    const updatedTag = { id: '1', name: 'crimson', color: '#dc143c' };
    mockUpdateTag.mockResolvedValue(updatedTag);

    const { result } = renderHook(() => useTags());
    await waitFor(() => expect(result.current.loading).toBe(false));

    await act(async () => {
      await result.current.updateTag('1', { name: 'crimson' });
    });

    expect(result.current.tags.find(t => t.id === '1')).toEqual(updatedTag);
  });

  it('should delete a tag', async () => {
    mockDeleteTag.mockResolvedValue(undefined);

    const { result } = renderHook(() => useTags());
    await waitFor(() => expect(result.current.loading).toBe(false));

    await act(async () => {
      await result.current.deleteTag('1');
    });

    expect(result.current.tags).toHaveLength(1);
    expect(result.current.tags[0].name).toBe('blue');
  });

  it('should get color by tag name', async () => {
    const { result } = renderHook(() => useTags());
    await waitFor(() => expect(result.current.loading).toBe(false));

    expect(result.current.getByColor('red')).toBe('#ff0000');
    expect(result.current.getByColor('unknown')).toBe('#a78bfa'); // default
  });

  it('should handle fetch error', async () => {
    mockGetTags.mockRejectedValue(new Error('Network error'));

    const { result } = renderHook(() => useTags());
    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(result.current.error).toBe('Network error');
  });
});

describe('useFileTags', () => {
  it('should load file tags on mount', async () => {
    mockGetFileTags.mockResolvedValue(['red', 'blue']);

    const { result } = renderHook(() => useFileTags('/file.txt'));
    await waitFor(() => expect(result.current.loading).toBe(false));
    expect(result.current.fileTags).toEqual(['red', 'blue']);
  });

  it('should return empty tags when path is null', async () => {
    const { result } = renderHook(() => useFileTags(null));
    await waitFor(() => expect(result.current.fileTags).toEqual([]));
  });

  it('should add tags to file', async () => {
    mockAddTagsToFile.mockResolvedValue(undefined);
    mockGetFileTags.mockResolvedValueOnce(['red']).mockResolvedValueOnce(['red', 'blue']);

    const { result } = renderHook(() => useFileTags('/file.txt'));
    await waitFor(() => expect(result.current.loading).toBe(false));

    await act(async () => {
      await result.current.addTags(['blue']);
    });

    expect(mockAddTagsToFile).toHaveBeenCalledWith('/file.txt', ['blue']);
    expect(result.current.fileTags).toContain('blue');
  });

  it('should remove a tag from file', async () => {
    mockRemoveTagFromFile.mockResolvedValue(undefined);
    mockGetFileTags.mockResolvedValueOnce(['red', 'blue']).mockResolvedValueOnce(['red']);

    const { result } = renderHook(() => useFileTags('/file.txt'));
    await waitFor(() => expect(result.current.loading).toBe(false));

    await act(async () => {
      await result.current.removeTag('blue');
    });

    expect(mockRemoveTagFromFile).toHaveBeenCalledWith('/file.txt', 'blue');
    expect(result.current.fileTags).toEqual(['red']);
  });
});