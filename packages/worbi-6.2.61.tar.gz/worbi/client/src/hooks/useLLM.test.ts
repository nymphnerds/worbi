import { renderHook, act, waitFor } from '@testing-library/react';
import { vi, describe, it, expect, beforeEach } from 'vitest';

vi.mock('../services/api', async () => ({
  sendChat: vi.fn(),
  fetchModels: vi.fn(),
  getSettings: vi.fn(),
  testConnection: vi.fn(),
  saveUserSettings: vi.fn(),
}));

vi.mock('../utils/tokenCounter', () => ({
  estimateTokens: vi.fn((s: string) => s?.length || 0),
  trimChatHistory: vi.fn((msgs: any[]) => msgs.slice(-4)),
  calculateHistoryBudget: vi.fn((_w: number, r: number) => 4000 - r),
}));

import * as api from '../services/api';
const mockSendChat = api.sendChat as ReturnType<typeof vi.fn>;
const mockFetchModels = api.fetchModels as ReturnType<typeof vi.fn>;
const mockGetSettings = api.getSettings as ReturnType<typeof vi.fn>;
const mockTestConnection = api.testConnection as ReturnType<typeof vi.fn>;
const mockSaveUserSettings = api.saveUserSettings as ReturnType<typeof vi.fn>;
import { useLLM } from './useLLM';

const defaultSettings = {
  baseUrl: 'http://localhost:11434',
  modelName: 'llama3',
  maxTokens: 4096,
  contextWindow: 8192,
  temperature: 0.7,
  systemPrompt: 'You are helpful.',
};

beforeEach(() => {
  vi.clearAllMocks();
  mockGetSettings.mockResolvedValue(defaultSettings);
  mockSendChat.mockResolvedValue({ role: 'assistant', content: 'Reply' });
  mockFetchModels.mockResolvedValue(['llama3', 'mistral']);
  mockTestConnection.mockResolvedValue({ success: true, message: 'OK' });
  mockSaveUserSettings.mockResolvedValue(defaultSettings);
});

describe('useLLM', () => {
  it('should load settings on mount and check health', async () => {
    vi.spyOn(global, 'fetch').mockResolvedValueOnce({
      ok: true,
      json: async () => ({ detected: [{ models: ['test-model'] }] }),
    } as Response);

    const { result } = renderHook(() => useLLM());
    await waitFor(() => expect(result.current.llmConnected).toBe(true));
    expect(mockGetSettings).toHaveBeenCalled();
  });

  it('should set llmConnected=false when health check fails', async () => {
    vi.spyOn(global, 'fetch').mockResolvedValueOnce({
      ok: true,
      json: async () => ({ detected: [], notDetected: ['ollama'] }),
    } as Response);

    const { result } = renderHook(() => useLLM());
    await waitFor(() => expect(result.current.llmConnected).toBe(false));
  });

  it('should send a message and add to chat history', async () => {
    vi.spyOn(global, 'fetch').mockResolvedValue({
      ok: true,
      json: async () => ({ detected: [{ models: ['test-model'] }] }),
    } as Response);

    const { result } = renderHook(() => useLLM());
    await waitFor(() => expect(result.current.loading).toBe(false));

    await act(async () => {
      await result.current.sendMessage('Hello', 'document content');
    });

    expect(result.current.chatHistory).toHaveLength(2);
    expect(result.current.chatHistory[0].role).toBe('user');
    expect(result.current.chatHistory[1].role).toBe('assistant');
  });

  it('should set error when sendChat fails', async () => {
    vi.spyOn(global, 'fetch').mockResolvedValue({
      ok: true,
      json: async () => ({ detected: [{ models: ['test-model'] }] }),
    } as Response);
    mockSendChat.mockRejectedValue(new Error('API down'));

    const { result } = renderHook(() => useLLM());
    await waitFor(() => expect(result.current.loading).toBe(false));

    await act(async () => {
      await result.current.sendMessage('Hello', '');
    });

    expect(result.current.error).toBe('API down');
    expect(result.current.llmConnected).toBe(false);
  });

  it('clearChat should empty history', async () => {
    vi.spyOn(global, 'fetch').mockResolvedValue({
      ok: true,
      json: async () => ({ detected: [{ models: ['test-model'] }] }),
    } as Response);

    const { result } = renderHook(() => useLLM());
    await waitFor(() => expect(result.current.loading).toBe(false));

    await act(async () => {
      await result.current.sendMessage('Hi', '');
    });
    expect(result.current.chatHistory).toHaveLength(2);

    act(() => { result.current.clearChat(); });
    expect(result.current.chatHistory).toEqual([]);
  });

  it('testConn should test connection', async () => {
    vi.spyOn(global, 'fetch').mockResolvedValue({
      ok: true,
      json: async () => ({ detected: [{ models: ['test-model'] }] }),
    } as Response);

    const { result } = renderHook(() => useLLM());
    await waitFor(() => expect(result.current.loading).toBe(false));

    await act(async () => {
      await result.current.testConn();
    });

    expect(mockTestConnection).toHaveBeenCalled();
    expect(result.current.llmConnected).toBe(true);
    expect(result.current.testing).toBe(false);
  });

  it('loadModels should fetch and set models', async () => {
    vi.spyOn(global, 'fetch').mockResolvedValue({
      ok: true,
      json: async () => ({ detected: [{ models: ['test-model'] }] }),
    } as Response);

    const { result } = renderHook(() => useLLM());
    await waitFor(() => expect(result.current.loading).toBe(false));

    await act(async () => {
      await result.current.loadModels();
    });

    expect(result.current.models).toEqual(['llama3', 'mistral']);
  });

  it('updateSettings should update partial settings', async () => {
    vi.spyOn(global, 'fetch').mockResolvedValue({
      ok: true,
      json: async () => ({ detected: [{ models: ['test-model'] }] }),
    } as Response);

    const { result } = renderHook(() => useLLM());
    await waitFor(() => expect(result.current.loading).toBe(false));

    act(() => {
      result.current.updateSettings({ temperature: 0.9 });
    });

    expect(result.current.settings.temperature).toBe(0.9);
  });

  it('should handle health check failure on mount', async () => {
    mockGetSettings.mockRejectedValue(new Error('No settings'));

    const { result } = renderHook(() => useLLM());
    await waitFor(() => expect(result.current.llmConnected).toBe(false));
  });

  it('aiOffline should be true when not connected', async () => {
    mockGetSettings.mockRejectedValue(new Error('No settings'));

    const { result } = renderHook(() => useLLM());
    await waitFor(() => expect(result.current.aiOffline).toBe(true));
  });
});