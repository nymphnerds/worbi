import React from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import TimelineView from './TimelineView';

// ---- Mock API ----
const mockTimelineData = {
  eras: [
    {
      name: 'Prologue',
      events: [
        {
          name: 'The Beginning',
          date: '1200',
          path: 'Lore/beginning.html',
          snippet: 'The world was created...',
          tags: [{ name: 'world', color: '#a78bfa' }],
          isApproximate: false,
        },
      ],
    },
    {
      name: 'Act I',
      events: [
        {
          name: 'First Quest',
          date: '1201',
          path: 'Lore/quest.html',
          snippet: 'The hero set forth...',
          tags: [{ name: 'quest', color: '#22c55e' }],
          isApproximate: true,
        },
      ],
    },
  ],
};

const mockGetTimeline = vi.fn().mockResolvedValue(mockTimelineData);

vi.mock('../services/api', () => ({
  getTimeline: () => mockGetTimeline(),
}));

vi.mock('../utils/timelineConfig', () => ({
  getEras: vi.fn().mockReturnValue(['Prologue', 'Act I', 'Act II']),
  saveEras: vi.fn(),
  DEFAULT_ERAS: ['Prologue', 'Act I'],
}));

describe('TimelineView', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockGetTimeline.mockResolvedValue(mockTimelineData);
  });

  it('renders skeleton while loading', async () => {
    mockGetTimeline.mockResolvedValue(new Promise(() => {}));
    render(<TimelineView onFileSelect={vi.fn()} />);
    // Initially renders, then loading state appears
    await waitFor(() => {
      expect(mockGetTimeline).toHaveBeenCalled();
    });
  });

  it('renders timeline eras with events after loading', async () => {
    render(<TimelineView onFileSelect={vi.fn()} />);

    await waitFor(() => {
      expect(screen.getByText('The Beginning')).toBeTruthy();
    });

    expect(screen.getByText('First Quest')).toBeTruthy();
  });

  it('renders era headers', async () => {
    render(<TimelineView onFileSelect={vi.fn()} />);

    await waitFor(() => {
      expect(screen.getByText('Prologue')).toBeTruthy();
    });

    expect(screen.getByText('Act I')).toBeTruthy();
  });

  it('collapses and expands era sections', async () => {
    render(<TimelineView onFileSelect={vi.fn()} />);

    await waitFor(() => {
      expect(screen.getByText('The Beginning')).toBeTruthy();
    });

    // Click era header to collapse
    const prologueHeader = screen.getByText('Prologue').closest('button');
    if (prologueHeader) {
      fireEvent.click(prologueHeader);

      // Event should no longer be visible
      expect(screen.queryByText('The Beginning')).toBeFalsy();
    }
  });

  it('calls onFileSelect when event is clicked', async () => {
    const onFileSelect = vi.fn();
    render(<TimelineView onFileSelect={onFileSelect} />);

    await waitFor(() => {
      expect(screen.getByText('The Beginning')).toBeTruthy();
    });

    const eventRow = screen.getByText('The Beginning').closest('.timeline-event');
    if (eventRow) {
      fireEvent.click(eventRow);
      expect(onFileSelect).toHaveBeenCalledWith('Lore/beginning.html');
    }
  });

  it('shows approximate date indicator', async () => {
    render(<TimelineView onFileSelect={vi.fn()} />);

    await waitFor(() => {
      const approxEvent = screen.getByText('First Quest');
      expect(approxEvent).toBeTruthy();
    });
  });

  it('displays total event count in header', async () => {
    render(<TimelineView onFileSelect={vi.fn()} />);

    await waitFor(() => {
      expect(screen.getByText(/2 events/)).toBeTruthy();
    });
  });

  it('opens settings modal when settings button is clicked', async () => {
    render(<TimelineView onFileSelect={vi.fn()} />);

    await waitFor(() => {
      expect(screen.getByText('Timeline')).toBeTruthy();
    });

    const settingsBtn = screen.getByTitle('Manage Eras');
    fireEvent.click(settingsBtn);

    await waitFor(() => {
      expect(screen.getByText('Timeline Settings')).toBeTruthy();
    });
  });
});