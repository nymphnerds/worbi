import { describe, it, expect, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import SearchPanel from './SearchPanel';

describe('SearchPanel', () => {
  const minimalProps = {
    width: 300,
    query: '',
    onQueryChange: vi.fn(),
    results: [],
    loading: false,
    error: null,
    onFileOpen: vi.fn(),
  };

  it('renders without crashing', () => {
    render(<SearchPanel {...minimalProps} />);
    expect(screen.getByText('SEARCH')).toBeInTheDocument();
  });

  it('renders search input', () => {
    render(<SearchPanel {...minimalProps} />);
    expect(screen.getByPlaceholderText(/Search in files/i)).toBeInTheDocument();
  });

  it('shows initial empty state', () => {
    render(<SearchPanel {...minimalProps} />);
    expect(screen.getByText(/Type to search across all files/i)).toBeInTheDocument();
  });

  it('shows no results when query has no matches', () => {
    render(<SearchPanel {...minimalProps} query="test" />);
    expect(screen.getByText(/No results found/i)).toBeInTheDocument();
  });

  it('shows loading state', () => {
    render(<SearchPanel {...minimalProps} loading={true} query="test" />);
    expect(screen.getByText(/Searching.../i)).toBeInTheDocument();
  });

  it('shows error when provided', () => {
    render(<SearchPanel {...minimalProps} error="Search failed" query="test" />);
    expect(screen.getByText('Search failed')).toBeInTheDocument();
  });
});