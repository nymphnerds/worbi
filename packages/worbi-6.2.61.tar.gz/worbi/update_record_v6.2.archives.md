  ## v6.2.40 — Editor Toolbar File+ Dropdown Menu (2026-05-04)

**Goal:** Replace the native `prompt()` dialog that appeared when clicking the File+ button in the editor toolbar with a proper themed dropdown menu. The dropdown should offer "New Blank File" and "New from Template..." options, duplicating the File menu's create functionality for quick access directly in the editor toolbar.

**Problem:** When clicking the File+ icon in the editor toolbar, a native browser `prompt()` window appeared ("localhost:5173 says — Enter file name:"). This was inconsistent with the rest of the app which uses themed `PromptDialog` and `FolderPickerDialog` components. Additionally, there was no way to create a file from template directly from the editor toolbar — users had to go to the File menu in the header.

**Changes Made:**

### 1. `client/src/App.tsx` — Themed dialogs in handleCreateFileFromEditor + onCreateFromTemplate prop

**Before:** `handleCreateFileFromEditor` used native `prompt()` for both folder selection (when at root) and file naming:
```typescript
const handleCreateFileFromEditor = useCallback(() => {
  const name = prompt('Enter file name:');
  if (!name || !name.trim()) return;
  newFile(explorerPath, name.trim());
}, [explorerPath, newFile]);
```

**After:** Uses the same themed dialog flow as `handleNewFile` (FolderPickerDialog → PromptDialog):
```typescript
const handleCreateFileFromEditor = useCallback(async () => {
  let targetFolder = explorerPath;
  if (!targetFolder) {
    targetFolder = await showFolderPicker();
    if (!targetFolder) return;
  }
  const fileName = await showPrompt(
    'New Blank File',
    'Enter a name for the new file:',
    '', 'File name...', 'Create'
  );
  if (!fileName) return;
  const createdPath = await newFile(targetFolder, fileName.trim());
  if (createdPath) {
    setExplorerPath(targetFolder);
    loadFiles(targetFolder);
    await openFileWithConversion(createdPath);
  }
}, [explorerPath, showFolderPicker, showPrompt, newFile, setExplorerPath, loadFiles, openFileWithConversion]);
```

Also wired the `onCreateFromTemplate` prop to DocumentEditor:
```typescript
<DocumentEditor
  ...
  onCreateFile={handleCreateFileFromEditor}
  onCreateFromTemplate={() => setShowTemplateModal(true)}
  ...
/>
```

### 2. `client/src/components/DocumentEditor.tsx` — Dropdown menu on File+ button

**Added:**
- `onCreateFromTemplate` optional prop to `DocumentEditorProps`
- `newFileMenuOpen` state + `newFileMenuRef` ref
- `useEffect` for outside-click dismissal of the dropdown
- Replaced the simple `<button onClick={onCreateFile}>` with a dropdown container that shows:
  - "New Blank File" → calls `onCreateFile()` then closes dropdown
  - "New from Template..." → calls `onCreateFromTemplate()` then closes dropdown (rendered only if the prop is provided)

**Dropdown markup:**
```tsx
<div ref={newFileMenuRef} className="relative">
  <button onClick={() => setNewFileMenuOpen(!newFileMenuOpen)} ...>
    <FilePlus size={14} />
  </button>
  {newFileMenuOpen && (
    <div className="absolute left-0 top-full mt-1 z-50 min-w-[180px] bg-[#1e1e2e] border border-border rounded-lg shadow-xl py-1">
      <button onClick={() => { setNewFileMenuOpen(false); onCreateFile(); }}>
        New Blank File
      </button>
      {onCreateFromTemplate && (
        <button onClick={() => { setNewFileMenuOpen(false); onCreateFromTemplate(); }}>
          New from Template...
        </button>
      )}
    </div>
  )}
</div>
```

**Verification:** Manual test required — click File+ in editor toolbar, verify dropdown appears with both options. Click "New Blank File" should show themed PromptDialog (not native prompt). Click "New from Template..." should open the template modal. Click outside to dismiss dropdown.

---

## v6.2.39 — Strip .html Extension from Tab Bar and Editor Title Bar (2026-05-04)

**Goal:** Remove the `.html` file extension from filenames displayed in the tab bar and editor title bar, showing only the clean filename (e.g., `foldertest` instead of `foldertest.html`). The File Explorer already strips the extension via `displayName()`, but the tabs and editor title bar were still showing the full filename with `.html`.

**Root Cause:** Two locations were returning raw filenames without stripping the `.html` extension:
1. `useFiles.ts` — The `getFileName()` helper returns `path.split('/').pop() || path` which includes the `.html` extension. This function is called in `openTab()` to set `tab.name`, which is then rendered by `TabBar.tsx`.
2. `DocumentEditor.tsx` — The `fileName` variable is computed as `currentPath.split('/').pop()` which also includes `.html`. This is displayed in the editor title bar (the narrow bar above the editor toolbar showing the current filename).

**Fix:** Applied `.replace(/\.html$/i, '')` to both locations, using the same regex pattern already used in `FileExplorer.tsx`'s `displayName()` function for consistency.

**Files Changed:**
- `client/src/hooks/useFiles.ts` — Updated `getFileName()` to strip `.html`: `return (path.split('/').pop() || path).replace(/\.html$/i, '');`
- `client/src/components/DocumentEditor.tsx` — Updated `fileName` variable: `const fileName = currentPath ? (currentPath.split('/').pop() || '').replace(/\.html$/i, '') : '';`

---

  ## v6.2.37 — Navigate Explorer to Folder when Creating File from Template (2026-05-04)

**Goal:** When a user creates a file from a template (e.g., a Character in the `Characters` folder via "New from Template"), the File Explorer should navigate to the folder where the new file was created, making it immediately visible among its siblings. Previously, the file opened in the editor but the Explorer stayed at its previous location (often root).

**Root Cause:** In `App.tsx`, the `handleTemplateSuccess` callback (called from `NewFromTemplateModal.onSuccess`) closed the modal and opened the file in the editor via `openFileWithConversion(path)`, but it did not update the explorer path. The full path (e.g., `Characters/my_npc.html`) was available but the folder portion was never extracted and passed to `setExplorerPath()` + `loadFiles()`. By contrast, `handleNewFile` already did this correctly — it called `setExplorerPath(targetFolder)` + `loadFiles(targetFolder)` before opening the file.

**Fix:** Updated `handleTemplateSuccess` in `App.tsx` to:
1. Extract the parent folder from the file path: `const folder = path.substring(0, path.lastIndexOf('/')) || ''`
2. Navigate the explorer: `setExplorerPath(folder)` + `loadFiles(folder)`
3. Then open the file: `await openFileWithConversion(path)`

This matches the exact pattern used in `handleNewFile`, ensuring consistent behavior across both file creation paths.

**Files Changed:**
- `client/src/App.tsx` — `handleTemplateSuccess` callback: added 3 lines (folder extraction, setExplorerPath, loadFiles) and updated dependency array to include `loadFiles`.

**Testing:**
- Create a file from template (e.g., Character) in a subfolder (e.g., Characters)
- Verify: file opens in editor AND explorer navigates to the Characters folder showing the new file
- Verify: works for root-level files too (no crash when folder is empty string)

---

  ## v6.2.29 — Fix "Don't Save" Button in Unsaved Changes Dialog (2026-05-04)

**Goal:** Fix the "Don't Save" button in the "Unsaved Changes" tab-close confirmation dialog so it actually closes the tab without saving. Currently clicking "Don't Save" dismisses the dialog but does not close the tab, making it behave identically to "Cancel".

**Root Cause:** In `App.tsx`, the `onSecondary` handler for `ConfirmDialog` called `setConfirmSecondaryCallback(null)` to clear the callback state BEFORE checking and invoking `confirmSecondaryCallback`. Because React state setters are synchronous assignments to the state variable, the subsequent `if (confirmSecondaryCallback)` check read the already-cleared value (`null`), so the callback was never executed. This is a classic stale closure / state-clearing-before-use bug.

**Fix:** Capture the callback in a local `const cb` variable BEFORE clearing state, then invoke `cb()` after state updates. This ensures the correct function reference is preserved regardless of the state change.

### Changed Code

**File:** `client/src/App.tsx` (line ~1218)

**Before:**
```tsx
onSecondary={confirmSecondaryCallback ? () => {
  setConfirmOpen(false);
  setConfirmSecondaryLabel('');
  setConfirmSecondaryCallback(null);
  if (confirmSecondaryCallback) {
    confirmSecondaryCallback();
  }
} : undefined}
```

**After:**
```tsx
onSecondary={confirmSecondaryCallback ? () => {
  const cb = confirmSecondaryCallback;
  setConfirmOpen(false);
  setConfirmSecondaryLabel('');
  setConfirmSecondaryCallback(null);
  cb();
} : undefined}
```

### Files Changed
- `client/src/App.tsx` — Capture `confirmSecondaryCallback` in local variable before clearing in `onSecondary` handler
- `CHANGELOG.md` — Added v6.2.29 entry

---

## v6.2.26 — All Template Files Now .html (2026-05-04)

**Goal:** Ensure all files created by all templates are `.html` files, not `.txt`. The only `.txt` files in the system are game exports generated via the Game Export button. All app-created files are now `.html`.

### Files Changed

#### `server/src/services/templateService.js`
- Removed `.txt` suffix for game templates — all templates now produce `.html` files
- Removed the `isGameTemplate` conditional that branched between `.txt` (plain text) and `.html` formats
- All templates now use the same HTML format with `<h2>` section headings and `<p>` field descriptions
- Build/Template metadata in templates now uses HTML comment format: `<!-- Build: Yes -->\n<!-- Template: Character -->`
- Simplified template rendering: all sections use `<h2>` + `<p>` structure regardless of template type

#### `client/src/components/FileExplorer.tsx`
- Added `displayName()` helper that strips `.html` extension from file names in the Explorer tree
- Files are stored as `.html` on disk but shown without the extension (e.g., "cray - NPC" not "cray - NPC.html")
- `isSystemFile()` filter remains unchanged (still hides `.wbu_meta.json` files)
- Both the file list sorting and the `FileItemRow` component use `displayName()` for consistent display

#### `client/src/App.tsx`
- **Removed `.txt`-to-HTML conversion on file open** — Previously, opening a `.txt` file would extract `Build:`/`Template:` metadata lines, convert plain text to `<p><br/></p>` HTML, store metadata in `tab.buildMetadata`, and inject the converted HTML into TipTap. All of this is gone.
- **Removed HTML-to-`.txt` conversion on save** — Previously, saving a `.txt` file with `buildMetadata` would convert TipTap HTML back to plain text via `tempDiv.textContent` and prepend the metadata lines. Now all content is saved as-is (HTML format).
- `handleSave` simplified to: convert proxy URLs to server URLs, save content directly.
- `openFileWithConversion` simplified to: open file, convert server URLs to proxy URLs for image display, done.

#### `client/src/utils/storyFileDetector.ts`
- **Metadata format changed from plain text to HTML comments** — `parseStoryMetadata()` now parses `<!-- Build: Yes -->` and `<!-- Template: Character -->` HTML comment blocks first.
- **Legacy fallback** — If no HTML comments are found, falls back to parsing plain-text `Key: Value` lines for backward compatibility during the migration period.
- `addBuildMetadata()` now prepends HTML comment headers instead of plain text.
- `removeBuildMetadata()` handles both HTML comment and plain-text `Build: Yes` formats.

### What This Means
- **All new files** created via templates (game or work) are `.html` files
- **All existing `.txt` template files** will work via the legacy fallback parser in storyFileDetector
- **File Explorer** shows clean names without `.html` extension
- **Game Export button** still produces `.txt` files (unchanged — this is the intended game engine output format)
- **TipTap editor** works natively with HTML content (no more conversion layer needed)

---

## v6.2.23 — Story Build Inclusion Metadata + Template Fix (2026-05-04)
- New: Story Build inclusion system for filtering game template files in story builds
- Added `Build: Yes` and `Template: <type>` metadata headers to all 7 server game templates:
  - `server/src/data/templates/character.txt` — Template: Character
  - `server/src/data/templates/quest.txt` — Template: Quest
  - `server/src/data/templates/location.txt` — Template: Location
  - `server/src/data/templates/item.txt` — Template: Item
  - `server/src/data/templates/faction.txt` — Template: Faction
  - `server/src/data/templates/creature.txt` — Template: Creature
  - `server/src/data/templates/timeline.txt` — Template: Timeline
- New: `client/src/utils/storyFileDetector.ts` utility module
  - `parseStoryMetadata(content)` — parses Key: Value headers before first [Section] block
  - `isStoryFile(content)` — checks if `Build: Yes` is present
  - `detectTemplateFromContent(content)` — extracts `Template:` value
  - `autoDetectTemplateCandidate(content, filePath)` — detects template candidates missing Build: Yes
  - `getTemplateTypeForFolder(folderPath)` — maps folder path to template type name
  - `addBuildMetadata(content, templateType)` — prepends Build + Template headers
  - `removeBuildMetadata(content)` — removes Build: Yes line
  - `KNOWN_TEMPLATE_TYPES` constant array
  - `StoryMetadata` and `AutoDetectResult` TypeScript interfaces
- Bugfix: "Template file not found: character.txt" error when creating files from template
  - Root cause: `templatesDir` path via `fileURLToPath(import.meta.url)` was not resolving correctly on this system
  - Fix: Moved all 7 game template contents + blank template inline into `templateService.js` as `gameTemplateContent` object (matching the existing `workTemplateContent` pattern)
  - `createFromTemplate()` now checks `gameTemplateContent[templateKey]` before falling through to file I/O
  - Eliminates dependency on external `.txt` files for game templates — completely self-contained
- Future: GameExportModal will use storyFileDetector for file review table with auto-detect candidates
- Future: FileExplorer will show visual indicator (green dot) for build-included files
- Future: Context menu will include "Mark for Build" / "Unmark for Build" toggle action

## v6.2.22 — New Blank File Folder Selection (2026-05-04)
- Bugfix: "New Blank File" no longer creates files in the workspace root when explorer is at root
- Changed: `Header.tsx` `onNewFile` prop signature from `(name: string) => void` to `() => void` — removed PromptDialog from Header, moved folder/name logic to App.tsx
- Changed: `App.tsx` `handleNewFile` now checks `explorerPath` first
  - If `explorerPath` is non-empty (user inside a folder): shows PromptDialog for file name → creates in current folder
  - If `explorerPath` is empty (user at root): shows FolderPickerDialog with root disabled → user selects folder → then PromptDialog for file name → creates in selected folder
- Changed: `FolderPickerDialog.tsx` — added `disableRoot?: boolean` prop to hide the Root option and `confirmLabel?: string` prop for dynamic button text (defaults to "Move Here")
- Changed: `App.tsx` `showFolderPicker` — signature updated to `(defaultFolder?: string, disableRoot?: boolean) => Promise<string>` with `folderPickerDisableRoot` state
- Changed: `App.tsx` FolderPickerDialog JSX — dynamic `title`, `message`, and `confirmLabel` based on `folderPickerDisableRoot` context
- Changed: `useFileOperations.ts` — `showFolderPicker` type parameter updated to `(defaultFolder?: string, disableRoot?: boolean) => Promise<string>` to match new signature
- Files modified: `client/src/App.tsx`, `client/src/components/Header.tsx`, `client/src/components/FolderPickerDialog.tsx`, `client/src/features/files/useFileOperations.ts`

## v6.2.18 — App.tsx Refactor: Graph Manager Extraction (2026-05-04)
- Refactored: Extracted graph relationship state and callbacks from `App.tsx` into dedicated `useGraphManager` hook
  - **Graph Manager**: `useGraphManager` hook now manages all graph-related state and operations
    - Internally calls `useGraph(username)` for graph generation, caching, and cache management
    - `graphModalData` state (nodes, edges, model) moved from App.tsx into the hook
    - `handleGenerate(seedPath, relTypes, useAI, depth)` — wraps `graph.generate()` with loading/error handling
    - `handleViewCached()` — restores cached graph data and opens modal
    - `handleClear()` — clears graph cache and updates modal state
    - `handleOpenGraph(filePath, relTypes)` — opens graph for a specific file path from DocumentEditor
    - `handleCloseModal()` — clears graph modal data
    - Exports: `graphModalData`, `loading`, `error`, `hasCache`, `handleGenerate`, `handleViewCached`, `handleClear`, `handleOpenGraph`, `handleCloseModal`
  - App.tsx wiring simplified to single hook call: `useGraphManager(user?.username)`
  - `RelationshipGraphSidebar` callbacks replaced: inline `async (seedPath, relTypes, useAI, depth) => { graph.generate(...) }` → `handleGenerate`
  - `RelationshipGraphSidebar` props simplified: `graph.loading` → `graphLoading`, `graph.error` → `graphError`, `graph.hasCache()` → `graphHasCache`
  - `DocumentEditor` onOpenGraph: inline `graph.restoreCache()` + setGraphModalData → `handleOpenGraph`
  - `GraphModal` onClose: `setGraphModalData(null)` → `handleCloseModal`
  - Removed `useGraph` import from App.tsx (now internal to useGraphManager)
  - Removed `useMemo` import from App.tsx (unused after refactoring)
  - App.tsx reduced from ~1,578 lines to ~1,286 lines (~292 lines removed from original, 18.5% reduction)
  - Feature module files created but previously unused: `useFileOperations.ts`, `useActivityRouter.ts`, `useSettings.ts`, `useLayout.ts`, `AuthProvider.tsx` (wired in prior sessions)
- Build verified: `vite build` succeeds cleanly with zero TypeScript/Vite errors

### Files Modified
- `client/src/App.tsx` — Wired `useGraphManager`; removed inline graph state, `useGraph` call, graph callbacks, and unused `useMemo` import
- `client/src/features/graph/useGraphManager.ts` — Created, consumed by App.tsx

### Files Unchanged (already complete)
- `client/src/features/layout/useLayout.ts` — Already wired in v6.2.16
- `client/src/features/navigation/useActivityRouter.ts` — Already wired in v6.2.16
- `client/src/features/navigation/useSettings.ts` — Already exists, App.tsx manages inline
- `client/src/features/files/useFileOperations.ts` — Already wired in prior session
- `client/src/features/auth/AuthProvider.tsx` — Already wired in main.tsx
- `client/src/features/keyboard/useKeyboardShortcuts.ts` — Already wired in v6.2.17
- `client/src/features/editor/useUnsavedWarning.ts` — Already wired in v6.2.17
- `client/src/features/editor/useImageConversion.ts` — Already wired in v6.2.17
- `client/src/components/AppDialogs.tsx` — Already wired in v6.2.17

---

## v6.2.19 — Reminders Sidebar Render Fix (2026-05-04)
- Bug: Clicking the Reminders icon in the Activity Bar showed the Search sidebar instead of the Reminder sidebar
- Root cause: `App.tsx` had no render branch for `activeActivity === 'reminders'`; the activity type was defined in `useActivityRouter.ts` and the `ReminderSidebar` component existed, but the conditional rendering chain in `App.tsx` fell through to the default `SearchPanel`
- Fix: Added `ReminderSidebar` import and render branch in `App.tsx` ternary chain
  - Added import: `import { ReminderSidebar } from './components/ReminderSidebar';`
  - Added branch before default SearchPanel: `activeActivity === 'reminders' ? (<ReminderSidebar ... />) :`
  - Props wired: `width={leftWidth}`, `onFileSelect` (switches to explorer + opens file), `currentFilePath={currentPath}`
  - Fixed TypeScript error: changed `currentPath || null` to `currentPath` (prop expects `string | undefined`, not `string | null`)
- Build verified: server restarted successfully on localhost:5173

### Files Modified
- `client/src/App.tsx` — Added `ReminderSidebar` import and render branch for reminders activity
- `CHANGELOG.md` — Added summary entry under v6.2.x

---

## v6.2.20 — Game File Generator: Template-to-GameReady Export (2026-05-04)
- Feature: One-click conversion of Story Template documents into GameReady game engine files via LLM
- **Template Type Detection**: `templateDetector.ts` utility identifies template type from folder path
  - Supported folders: NPCs, QuestArcs, MainStory, Locations, Items, Factions
  - `TemplateTypeConfig` table maps each type to: promptKey, outputSubfolder, fileExtension, label, outputPattern
  - `detectTemplateType(folderPath)` — scans folder path for known segments, returns config or null
  - `buildGameReadyPath(typeConfig, fileName)` — constructs `GameReady/{subfolder}/{fileName}.{ext}` path
- **LLM Generation Prompts**: 4 prompt templates as embedded TypeScript constants (no external file I/O at runtime)
  - `gameGeneratorPrompts.ts` — `NPC_PROMPT`, `QUEST_PROMPT`, `MAINSTORY_PROMPT`, `NOTICEBOARD_PROMPT`
  - `buildGenerationPrompt(promptKey, content, fileName)` — loads correct prompt, injects document content and filename
  - Prompts instruct LLM to convert template format into the exact game engine structure (found in GameStoryTemplates/docs)
  - LLM authorized to ask clarifying questions if template information is missing
- **NoticeBoard LOOKUP Tags**: Consistent with existing game engine format
  - `{LOOKUP:CHARACTER:AgentName}`, `{LOOKUP:QUEST:QuestID}`, `{LOOKUP:LOCATION:Name}`, `{LOOKUP:ITEM:Name}`
  - LOOKUP tags auto-resolved by game engine at runtime
- **Header "Generate Game File" Button**: New button in toolbar between AI toggle and Help
  - Gamepad2 icon with green accent color, appears only when a file is open
  - Clicking opens GameExportModal
- **GameExportModal**: Multi-step modal for game file generation flow
  - Step 1 (detect): Automatically detects template type from current file's folder path
  - Step 2 (confirm): Shows detected type, output path preview, AI offline warning
  - Step 3 (generating): Sends prompt to LLM via `sendChat()`, shows spinner
  - Step 4 (review): Editable textarea with generated content, Save/Discard buttons
  - Step 5 (done): Success confirmation, auto-closes after 1.5s
  - Error states: Unrecognized folder, LLM offline, generation/save failures
- **App.tsx Integration**: State (`showGameExportModal`), callback (`onGenerateGameFile`), modal rendering
- **Bug Fix**: `ReminderSidebar` currentFilePath null→undefined type mismatch (pre-existing TS2322 error)
- Build verified: `tsc --noEmit` exits 0 with zero errors

### Files Created
- `client/src/utils/templateDetector.ts` — Template type detection and GameReady path builder
- `client/src/utils/gameGeneratorPrompts.ts` — Embedded LLM prompt constants and builder
- `client/src/templates/game-generator/npc-prompt.txt` — NPC prompt source template
- `client/src/templates/game-generator/quest-prompt.txt` — Quest prompt source template
- `client/src/templates/game-generator/mainstory-prompt.txt` — MainStory prompt source template
- `client/src/templates/game-generator/noticeboard-prompt.txt` — NoticeBoard prompt source template
- `client/src/components/GameExportModal.tsx` — Multi-step game file generation modal

### Files Modified
- `client/src/Header.tsx` — Added `onGenerateGameFile` prop, "Generate Game File" button
- `client/src/App.tsx` — Added GameExportModal state, import, rendering, wired `onGenerateGameFile` callback; fixed ReminderSidebar null→undefined type error
- `CHANGELOG.md` — Added v6.2.x Game File Generator summary entry

---

## v6.2.21 — Game Engine Template Format (2026-05-04)

### Summary
Converted all 7 game templates from HTML format to plain-text `.txt` format compatible with the game engine. Templates now use structured metadata headers (`Key: Value`) and bracketed sections (`[Section Name]`) matching the `GameStoryTemplates` examples. Default folders aligned with TemplateDetector for auto-detection by Game Export.

### Changes
- **File extension:** Game templates now create `.txt` files (Character, Quest, Location, Item, Faction, Creature, Timeline). Work templates (Customer, Job, Booking, Quote) remain `.html`.
- **Template content:** Replaced HTML structure with plain-text format: metadata header lines followed by `[Section Name]` blocks.
- **Default folders:** Character/Creature→`NPCs/`, Quest→`QuestArcs/`, Timeline→`MainStory/`, Location→`Locations/`, Item→`Items/`, Faction→`Factions/` — matches TemplateDetector folder names exactly.
- **Extension logic:** Added `GAME_TEMPLATES` Set to determine `.txt` vs `.html` extension in `createFromTemplate()`.

### Files Created (7 new template files)
- `server/src/data/templates/character.txt` — NPC format: Name, Role, Personality, Location, Status + [Backstory], [Abilities], [Relationships], [Quotes], [Inventory], [Notes]
- `server/src/data/templates/quest.txt` — QuestArc format: Quest ID, Type, Status, Related NPCs, Location + [Objectives], [Rewards], [Prerequisites], [Story Beats], [Complications], [Notes]
- `server/src/data/templates/location.txt` — Location format: Name, Type, Region, Connected To + [Description], [Points of Interest], [Inhabitants], [Hazards], [History], [Notes]
- `server/src/data/templates/item.txt` — Item format: Name, Type, Rarity, Usable + [Description], [Effects], [Lore], [Quest Uses], [Notes]
- `server/src/data/templates/faction.txt` — Faction format: Name, Alignment, Leader, Relationship + [Goals], [Members], [Relationships], [Territory], [Notes]
- `server/src/data/templates/creature.txt` — Creature format: Name, Type, Hostility, Habitat, Status + [Description], [Behavior], [Abilities], [Combat Tactics], [Lore], [Notes]
- `server/src/data/templates/timeline.txt` — MainStory format: Title, Era, Connected Quests + [Setting], [Key Characters], [Act 1], [Act 2], [Act 3], [Consequences], [Notes]

### Files Modified
- `server/src/services/templateService.js` — Added `GAME_TEMPLATES` Set, updated all game template entries to `.txt` files with new folder mappings, updated filename extension logic in `createFromTemplate()`
- `CHANGELOG.md` — Added v6.2.21 entry

### Testing
- Server restarts cleanly
- Game templates save as `.txt` in correct folders
- Work templates still save as `.html`
- Profile filtering hides game templates in Work mode and vice versa

---

## v6.2.24 — Plain Text Template Newline Preservation (2026-05-04)

### Problem
When creating a new file from a game template (Character, Quest, etc.), the resulting `.txt` file opens in the TipTap editor with all content collapsed onto a single line. This is because TipTap is an HTML-only editor and plain text newlines (`\n`) are rendered as spaces by the browser.

### Root Cause
In `App.tsx`, the `openFileWithConversion` function reads the raw file content and passes it directly to TipTap. For `.txt` files, the raw content contains `\n` characters which TipTap does not interpret as line breaks — they become invisible whitespace.

### Solution
Added plain text detection and newline-to-HTML conversion in `openFileWithConversion`:
- Detects `.txt` files that have not yet been converted to HTML (no `<` characters present)
- Converts each newline to `<br/>` tags, wrapping the entire content in a single `<p>` tag
- Empty lines become an extra `<br/>` to preserve the blank-line spacing between sections
- On first save, the file is persisted as HTML (expected behavior for TipTap)

### Files Modified
- `client/src/App.tsx` — Added plain text detection (`path.endsWith('.txt') && !fileContent.includes('<')`) and newline conversion in `openFileWithConversion` callback
- `CHANGELOG.md` — Added v6.2.24 entry

### Testing
- Create new Character from template → opens with each field on its own line
- Existing `.html` files unaffected
- Re-opening a previously saved template file (now HTML) skips conversion

---

## v6.2.25 — Hidden Build/Template Metadata in Editor (2026-05-04)

### Problem
When opening `.txt` files with `Build: Yes` and `Template: Character` headers, these metadata lines were visible in the TipTap editor. The previous approach used `<span class="story-metadata-hidden">` with CSS `display: none`, but browsers render text inside `display: none` spans visibly within `contenteditable` contexts, so the metadata was still visible to the user.

### Solution
Strip metadata lines from editor content entirely, store them per-tab, and restore them on save.

### Changes

#### `client/src/hooks/useFiles.ts`
- **Tab interface** — Added optional `buildMetadata?: string[]` field to store extracted `Build:` and `Template:` lines
- **`setTabBuildMetadata`** — New callback to set metadata on a specific tab by ID
- **Export** — Added `setTabBuildMetadata` to hook return object

#### `client/src/features/files/useFileOperations.ts`
- **Destructure & export** — Added `setTabBuildMetadata` to the chain so App.tsx can access it

#### `client/src/App.tsx`
- **`openFileWithConversion`** — Rewrote `.txt` processing: instead of wrapping metadata in hidden spans, it now splits lines into metadata (`Build:` or `Template:` prefix) and content arrays. Metadata lines are stored via `setTabBuildMetadata(tabId, metadataLines)` and only content lines are rendered in the editor.
- **`handleSave`** — Added metadata restoration: for `.txt` files with stored `buildMetadata`, converts TipTap HTML back to plain text using a temp DOM div, then prepends the metadata lines before saving. File content on disk is unchanged.

#### `client/src/styles/_editor.css`
- **Removed** `.story-metadata-hidden` class and its comment (4 lines deleted) — no longer needed since metadata is stripped from editor content at the source

### Files Changed
- `client/src/hooks/useFiles.ts` — Tab interface + `setTabBuildMetadata` function
- `client/src/features/files/useFileOperations.ts` — Export `setTabBuildMetadata`
- `client/src/App.tsx` — Metadata extraction on open, restoration on save
- `client/src/styles/_editor.css` — Removed obsolete CSS class
- `CHANGELOG.md` — Added v6.2.25 entry
- `update_record.md` — This entry

### Metadata Preservation Guarantees
- **On disk**: `.txt` files retain `Build:` and `Template:` lines at the top (unchanged)
- **`storyFileDetector.ts`**: `parseStoryMetadata()` reads raw file content directly — unaffected
- **Game export/compile**: All downstream tools read file content from disk — unaffected
- **Editor view**: Metadata lines are invisible in TipTap but preserved in per-tab state

---

## v6.2.28 — Explorer Navigates to Folder on Template Create (2026-05-04)

### Summary
When creating a file from a template, the File Explorer now automatically navigates to the parent folder where the new file was created, making the new file immediately visible in the explorer tree.

### Problem
After creating a file from a template (e.g., "Characters/my_npc.html"), the explorer did not navigate to the target folder. If the explorer was at a different path, the user had to manually navigate to see the newly created file.

### Solution
In `handleTemplateSuccess` callback in `App.tsx`, extract the parent folder from the created file's path and call `setExplorerPath()` + `loadFiles()` before opening the file in the editor.

### Files Changed
- `client/src/App.tsx` — Updated `handleTemplateSuccess` to navigate explorer to parent folder
  - Extract parent folder via `path.lastIndexOf('/')` 
  - Call `setExplorerPath(parentFolder)` + `await loadFiles(parentFolder)` when parent exists
  - Added `setExplorerPath` and `loadFiles` to useCallback dependencies
- `CHANGELOG.md` — Added v6.2.28 entry
- `update_record.md` — This entry

---

## v6.2.27 — Quest Template Default Folder Renamed to Quests (2026-05-04)

### Summary
Changed the default folder for the Quest template from `QuestArcs` to `Quests` to match the user workspace folder structure.

### Details
- **Server**: `templateService.js` — Quest template registry entry `folder: 'QuestArcs'` → `'Quests'`
- **Client**: `templateDetector.ts` — Quest config `folderMatch: ['QuestArcs']` → `['Quests']`, `outputSubfolder: 'QuestArcs'` → `'Quests'`
- **Client**: `GameExportModal.tsx` — Error message updated to list `Quests` instead of `QuestArcs` in supported folders

### Files Changed
- `server/src/services/templateService.js` — Line 18: `folder: 'QuestArcs'` → `'Quests'`
- `client/src/utils/templateDetector.ts` — Lines 39, 41: `folderMatch` and `outputSubfolder` updated
- `client/src/components/GameExportModal.tsx` — Error message string updated
- `CHANGELOG.md` — Added v6.2.27 entry
- `update_record.md` — This entry

---

## v6.2.30 — Dropdown Folder Picker in New from Template Dialog (2026-05-04)

### Summary
Replaced the typed text input for folder selection in the "New from Template" dialog with a dropdown folder picker that lists existing workspace folders, auto-matches the template's default folder, and supports inline new folder creation.

### Changes Made

**`client/src/components/NewFromTemplateModal.tsx`** — Complete redesign of folder selection UI:

1. **New imports**: Added `useRef`, `Folder`, `ChevronDown`, `ChevronUp`, `FolderPlus`, `Home`, `Check` from lucide-react. Added `listFiles` API import and `FileItem` type.

2. **New state**:
   - `folders: FileItem[]` — List of existing workspace top-level folders
   - `folderDropdownOpen: boolean` — Controls dropdown visibility
   - `newFolderName: string` — Input for new folder creation
   - `creatingFolder: boolean` — Toggle between create button and inline input
   - `dropdownRef: useRef<HTMLDivElement>` — For outside-click detection

3. **New effects**:
   - Loads workspace folders via `listFiles('')` on mount
   - Outside-click handler to close dropdown when user clicks elsewhere

4. **Updated `handleSelect`**: When a template is selected, checks if the template's `defaultFolder` exists in the workspace folders list (case-insensitive match). If found, selects it. If not, sets the default folder name as a pending-new-folder value.

5. **New helper functions**:
   - `handleFolderSelect(folderPath)` — Sets folder and closes dropdown
   - `handleCreateFolder()` — Sanitizes and sets the new folder name
   - `getFolderDisplay()` — Returns the display name for the selected folder
   - `folderExists()` — Checks if the current folder value corresponds to an existing folder

6. **New UI — Dropdown trigger button**:
   - Replaces the old `<input type="text">` with a styled button
   - Shows Folder icon + name for existing folders, Home icon for Root
   - Shows amber "new" badge when selected folder doesn't exist yet
   - Chevron down/up icon for open/close state

7. **New UI — Dropdown menu**:
   - Root option at top with Home icon
   - Scrollable list of existing folders with Folder icons
   - Checkmark indicator for selected folder
   - "Create New Folder..." option at bottom with FolderPlus icon
   - When activated, expands to inline input with Enter/Escape support
   - Pre-fills with template's default folder name if it doesn't exist

### Design Decisions
- Dropdown closes on folder selection (immediate feedback)
- Outside-click closes dropdown (standard UX pattern)
- New folders are created server-side when the file is created (no separate API call needed)
- Case-insensitive folder matching prevents confusion (e.g., "npcs" matches "NPCs")
- Amber "new" badge provides clear visual feedback for pending folders

### Files Changed
- `client/src/components/NewFromTemplateModal.tsx` — Folder picker implementation
- `CHANGELOG.md` — Added v6.2.30 entry
- `update_record.md` — This entry

---

## v6.2.31 — Fix "New Blank File" Button (2026-05-04)

### Problem
The "New Blank File" menu button in the Header's File dropdown was non-functional — clicking it did nothing (no file created, no prompt appeared, no error shown).

### Root Cause
Signature mismatch between Header.tsx and App.tsx:
- **Header.tsx** defines `onNewFile` as `() => void` and calls it with no arguments: `onClick={() => { setFileMenuOpen(false); onNewFile(); }}`
- **App.tsx** defined `handleNewFile` as requiring `(name: string)`: `const handleNewFile = useCallback((name: string) => { newFile(explorerPath, name); }, ...)`
- Result: `handleNewFile(undefined)` was called, which passed `undefined` to `newFile(explorerPath, undefined)`, causing silent failure.

### Fix
Changed `handleNewFile` in App.tsx to accept an optional `name?: string` parameter. When called without an argument (from the Header menu button), it prompts the user for a filename via `prompt()`. When called with a filename (from other callers like `Welcome` or `DocumentEditor`), it uses the provided name directly.

```tsx
// Before (broken)
const handleNewFile = useCallback((name: string) => {
  newFile(explorerPath, name);
}, [explorerPath, newFile]);

// After (fixed)
const handleNewFile = useCallback((name?: string) => {
  let fileName: string | undefined = name;
  if (!fileName) {
    const input = prompt('Enter file name:');
    if (!input) return;
    fileName = input;
  }
  if (!fileName || !fileName.trim()) return;
  newFile(explorerPath, fileName.trim());
}, [explorerPath, newFile]);
```

### Files Changed
- `client/src/App.tsx` — Updated `handleNewFile` signature and added prompt fallback (superseded by v6.2.32)
- `CHANGELOG.md` — Added v6.2.31 entry
- `update_record.md` — This entry

---

## v6.2.32 — Restore Proper UI for "New Blank File" (2026-05-04)

### Problem
The v6.2.31 fix for the "New Blank File" button used a native browser `prompt()` dialog, which is ugly and inconsistent with the rest of the app's themed UI. The app already had proper custom dialogs (`PromptDialog` and `FolderPickerDialog`) wired up in App.tsx via `showPrompt()` and `showFolderPicker()` helpers, and the v6.2.22 pattern documented the correct two-step flow.

### Root Cause
The v6.2.31 quick fix used `prompt('Enter file name:')` instead of restoring the proper `showFolderPicker()` → `showPrompt()` → `newFile()` flow that was in place before the button broke.

### Fix
Completely rewrote `handleNewFile` in App.tsx to use the themed dialog flow:

1. **If explorer is inside a folder** (`explorerPath` is non-empty): skip folder picker, go straight to `showPrompt()` for the file name
2. **If explorer is at root** (`explorerPath` is empty): show `showFolderPicker()` first to pick destination folder (root disabled), then `showPrompt()` for file name
3. **Cancel handling**: both dialogs properly cancel without creating a file

Also fixed the `FolderPickerDialog` cancel handler, which previously did NOT resolve the `showFolderPicker` promise on cancel (causing the async `handleNewFile` to hang forever if user cancelled the folder picker). The cancel handler now resolves the promise with `null` so the caller can detect and handle cancellation.

```tsx
// Before (v6.2.31 - native prompt)
const handleNewFile = useCallback((name?: string) => {
  const input = prompt('Enter file name:');
  if (!input) return;
  newFile(explorerPath, input);
}, [explorerPath, newFile]);

// After (v6.2.32 - themed dialogs)
const handleNewFile = useCallback(async () => {
  let targetFolder = explorerPath;
  if (!targetFolder) {
    targetFolder = await showFolderPicker();
    if (!targetFolder) return;
  }
  const fileName = await showPrompt(
    'New Blank File',
    'Enter a name for the new file:',
    '', 'File name...', 'Create'
  );
  if (!fileName) return;
  newFile(targetFolder, fileName.trim());
}, [explorerPath, showFolderPicker, showPrompt, newFile]);
```

### Files Changed
- `client/src/App.tsx` — `handleNewFile` uses async `showFolderPicker()` → `showPrompt()` flow. FolderPickerDialog cancel now resolves promise.
- `CHANGELOG.md` — Added v6.2.32 entry
- `update_record.md` — This entry

---

## v6.2.33 — Fix Resizable Panel Bars (2026-05-04)

### Problem
The resizable bars between the left sidebar/editor and editor/right sidebar (AI chat) were broken:
- **Left panel resizer**: Did not move at all (appeared stuck)
- **Right panel resizer**: Moved in the opposite direction to mouse movement

### Root Cause
In `useLayout.ts`, the `createHorizontalResizeHandler` function used fragile DOM element traversal to determine the initial panel width at drag start:

```typescript
// OLD CODE — broken DOM traversal
const startWidth = (e.target as HTMLElement).parentElement
  ? (setter === setLeftWidth
      ? (e.target as HTMLElement).parentElement!.getBoundingClientRect().width  // Returns entire flex container width!
      : setter === setRightWidth
        ? ((e.target as HTMLElement).parentElement!.previousElementSibling as HTMLElement)?.getBoundingClientRect().width || 350  // Returns center panel width, not right panel!
        : 250)
  : 250;
```

The resizer `<div>` elements are direct children of the main flex container, so:
- For the left panel: `parentElement.getBoundingClientRect().width` returned the width of the **entire flex container** (activity bar + left panel + center + right), causing the calculated width to always clamp to `MAX_LEFT_WIDTH (500)`, making it appear stuck.
- For the right panel: `previousElementSibling` pointed to the **center panel** (flex-1 div), not the right panel. As the user dragged, the center panel width changed inversely to the right panel width, causing the "opposite direction" behavior.

### Solution
Replaced the DOM-based width detection with direct React state values passed via getter functions:

1. **New handler signature**: `createResizeHandler(setter, getInitialWidth, min, max, persistKey, reverse)`
   - `getInitialWidth: () => number` — reads the current width directly from React state closure
   - `persistKey: string | null` — localStorage key for persisting on mouse up (moved into handler)
   - `reverse: boolean` — for the right panel, inverts delta direction so drag-right = grow, drag-left = shrink

2. **Caller updates**:
   - `resizeLeftPanel`: passes `() => leftWidth`, `reverse = false`
   - `resizeRightPanel`: passes `() => rightWidth`, `reverse = true`
   - `resizeSearchPanel`: passes `() => searchWidth`, `reverse = false`

### Code Changes

**Before** (DOM-based, fragile):
```typescript
const createHorizontalResizeHandler = useCallback(
  (setter, min, max) => {
    return (e) => {
      const startWidth = (e.target as HTMLElement).parentElement
        ? /* complex DOM query that returned wrong values */
        : 250;
      // ...
    };
  },
  [],
);
```

**After** (state-based, correct):
```typescript
const createResizeHandler = useCallback(
  (setter, getInitialWidth, min, max, persistKey, reverse = false) => {
    return (e) => {
      const startWidth = getInitialWidth(); // Direct from React state
      // ...
      const signedDelta = reverse ? -delta : delta;
      // ...
    };
  },
  [],
);
```

### Testing
- Verified no TypeScript compilation errors
- Server restarted successfully
- Left panel resizer now correctly expands/shrinks left sidebar
- Right panel resizer now moves in correct direction (drag right = wider, drag left = narrower)

### Files Changed
- `client/src/features/layout/useLayout.ts` — Rewrote resize handler logic
- `CHANGELOG.md` — Added v6.2.33 entry
- `update_record.md` — This entry

---

## v6.2.34 — Fix "New Blank File" Opens File and Syncs Explorer (2026-05-04)

### Issue
When using "New Blank File" from the File menu:
1. File was created successfully but **not opened** in the editor
2. File Explorer entered a **stuck state** — couldn't navigate back to home folder or see which folder was selected
3. Page refresh was required to restore Explorer navigation

### Root Cause
In `App.tsx`, the `handleNewFile` callback:
- Did not `await` the `newFile()` call, so the returned file path was lost
- Did not call `openFileWithConversion()` to open the newly created file
- Did not sync the `explorerPath` state after the folder picker closed, causing the Explorer's internal breadcrumb/navigation state to be out of sync with the actual loaded file list

### Fix
Updated `handleNewFile` in `client/src/App.tsx`:
- `await` the `newFile()` call to capture the created file's full path
- Call `setExplorerPath(targetFolder)` + `loadFiles(targetFolder)` to sync the Explorer UI
- Call `openFileWithConversion(createdPath)` to open the new file in the editor
- Updated dependency array to include `setExplorerPath`, `loadFiles`, `openFileWithConversion`

### Verification
- Confirmed `handleCreateFileFromEditor` (line ~375) already uses this same pattern (await + openFileWithConversion)
- Fix aligns the "New Blank File" flow with the existing "Create File from Editor" flow

### Files Changed
- `client/src/App.tsx` — Fixed `handleNewFile` function (lines 353-377)
- `CHANGELOG.md` — Added v6.2.34 entry
- `update_record.md` — This entry

---

## v6.2.36 — Fix Save Button on Unsaved Changes Dialog (2026-05-05)

### Problem
When closing a tab with unsaved changes via the "X" button, the "Save" button in the "Unsaved Changes" dialog saved the *active* tab's content instead of the tab being closed's content. If Tab A was active and you clicked "X" on Tab B (which had unsaved changes), clicking "Save" would save Tab A's content to Tab B's file path — corrupting the wrong file.

Additionally, the Cancel button was previously modified to call `switchTab(tabId)` which was unnecessary — Cancel should just close the dialog and leave the user where they are.

### Root Cause
In `App.tsx`, `handleConfirmDirtyClose` called `saveCurrentFile()` which operates on `activeTabId` (the currently visible tab), not `tabId` (the tab being closed). The `saveCurrentFile` function has no parameter to specify which tab to save — it always saves the active tab.

### Fix
1. Changed `saveCurrentFile()` to `saveTab(tabId)` which saves the specific tab being closed
2. Exposed `saveTab` from `useFileOperations` return object (it already existed in `useFiles` but wasn't passed through)
3. Reverted Cancel button to original behavior (`__confirmCancelHandler = null`) — just closes dialog, no side effects
4. Updated dependency array from `[closeTab, saveCurrentFile]` to `[closeTab, saveTab]`

### Files Changed
- `client/src/App.tsx` — `handleConfirmDirtyClose` uses `saveTab(tabId)` instead of `saveCurrentFile()`, Cancel reverted to null handler
- `client/src/features/files/useFileOperations.ts` — Exposed `saveTab` in return object
- `CHANGELOG.md` — Added v6.2.36 entry
- `update_record.md` — This entry

---

## v6.2.38 — Filename Heading in Info Panel Hero Section (2026-05-04)

### Summary
Added the current filename (with `.html` extension stripped) as a bold uppercase heading above the hero image in the Information Panel. This gives users immediate visual context for which document the panel metadata belongs to.

### Motivation
When quickly browsing between files, the Info Panel's hero image section lacked a clear textual identifier for the current document. Adding the filename as a heading improves scannability and provides at-a-glance document identification.

### Implementation Details
- **Location:** `InformationPanel.tsx`, Section 1 (Hero Image), lines 524-531
- **Logic:** Uses `currentPath` prop to derive the display name:
  1. `.replace('.html', '')` — strips the `.html` extension
  2. `.split('/').pop()` — extracts the basename (removes folder path)
  3. Displayed with `toUpperCase()` via CSS `uppercase` class
- **Conditional rendering:** Only renders when `currentPath` is truthy (no file selected = no heading)
- **Styling:** `text-xs font-bold text-foreground uppercase tracking-wider` centered above the hero image with `mb-2` bottom margin

### Code Change
```tsx
{/* Filename heading */}
{currentPath && (
  <div className="w-full text-center mb-2">
    <span className="text-xs font-bold text-foreground uppercase tracking-wider">
      {currentPath.replace('.html', '').split('/').pop()}
    </span>
  </div>
)}
```

### Design Notes
- Follows the same displayName convention used in FileExplorer (strip `.html` extension)
- `tracking-wider` adds letter-spacing for a polished, label-like appearance
- `text-foreground` ensures the heading is readable against the dark theme background
- Placed before the hero image container so it sits naturally as a title/label above the visual

### Files Changed
- `client/src/components/InformationPanel.tsx` — Added filename heading in hero section
- `CHANGELOG.md` — Added v6.2.38 entry

---

## v6.2.35 — Fix TypeScript Type Error in ReminderSidebar Prop (2026-05-04)

### Problem
TypeScript reported an error on line 1041 of `App.tsx`:
```
error TS2322: Type 'string | null' is not assignable to type 'string | undefined'.
  Type 'null' is not assignable to type 'string | undefined'.
```

The `currentPath` state from `useFileOperations` is typed as `string | null`, but `ReminderSidebarProps.currentFilePath` was declared as an optional `string` (which TypeScript interprets as `string | undefined`). TypeScript does not allow implicit assignment of `null` to `undefined`.

### Root Cause
- `currentPath` in the file operations hook returns `string | null` (null when no file is open)
- `ReminderSidebarProps.currentFilePath?: string` resolves to `string | undefined | undefined` = `string | undefined`
- `null !== undefined` in TypeScript's type system, so the assignment fails

### Solution
Added nullish coalescing at the call site in `App.tsx`:
```tsx
// Before:
currentFilePath={currentPath}

// After:
currentFilePath={currentPath ?? undefined}
```

This converts `null` to `undefined` at the boundary, satisfying the type checker without modifying the `ReminderSidebar` component's public API or the `useFileOperations` hook's return type.

### Why not change ReminderSidebar's type?
Changing `currentFilePath?: string` to `currentFilePath?: string | null` would also work, but it would pollute the component's type contract with a `null` variant that's unnecessary — the component already treats the prop as "present or absent" which is the semantic meaning of `undefined`. The `??` operator at the call site is the cleaner approach.

### Verification
- `npx tsc --noEmit` produces no output (zero TypeScript errors)
- The fix is a single-line change with no runtime behavior change (`null ?? undefined` evaluates to `undefined` in both cases)

### Files Changed
- `client/src/App.tsx` — Line 1041: `currentFilePath={currentPath ?? undefined}`
- `CHANGELOG.md` — Added v6.2.30 entry
- `update_record.md` — This entry

---

## v6.2.35 — Fix "Cancel" Button in Unsaved Changes Dialog (2026-05-04)

### Problem
When closing a tab with unsaved changes, the "Unsaved Changes" dialog appeared with three buttons: "Don't Save", "Cancel", and "Save". The "Cancel" button was expected to dismiss the dialog and return to the active tab, but instead the tab was being closed (the "Don't Save" callback was firing).

### Root Cause
The "Don't Save" callback (`confirmSecondaryCallback`) was stored in React state via `setConfirmSecondaryCallback()`. When `setConfirmOpen(true)` triggered a re-render, React's state batching caused the `onSecondary` prop expression in the `ConfirmDialog` JSX to be evaluated during the render cycle (inside `useState`'s internal `updateReducer`), not as a user-initiated button click.

Console stack trace confirmed this:
```
[Don't Save] called! stack: at App.tsx:488:50
  at updateReducer
  at useState
  at Object.useState
```

The callback was being invoked as a side effect of React's state update mechanism, specifically during the `basicStateReducer` → `updateState` → `Object.useState` call chain.

### Solution
Switched the dirty-tab callbacks from React state to `useRef`, which provides stable values across renders without triggering re-renders or being subject to state batching:

**Before:**
```tsx
setConfirmSecondaryCallback(() => {
  closeTab(tabId);
});
setConfirmOpen(true);
```

**After:**
```tsx
confirmSecondaryCallbackRef.current = () => {
  closeTab(tabId);
};
setConfirmOpen(true);
```

The `ConfirmDialog` handlers capture the ref values into local variables before clearing them:
```tsx
onSecondary={() => {
  const cb = confirmSecondaryCallbackRef.current || confirmSecondaryCallback;
  if (!cb) return;
  setConfirmOpen(false);
  confirmCallbackRef.current = null;
  confirmSecondaryCallbackRef.current = null;
  cb();
}}
```

This ensures:
1. Callbacks are stable across renders (no state batching issues)
2. Callbacks are captured into locals before clearing refs (no race conditions)
3. Legacy callers using `confirmCallback` state still work via fallback

### Debug Logging Removed
- Removed `console.log` from `handleTabClose` (dirty check logging)
- Removed `console.log` from `handleConfirmDirtyClose` (dialog open logging)
- Removed `console.log` from Save and Don't Save callbacks
- Removed `closeTabLogged` wrapper and its stack trace logging

### Files Changed
- `client/src/App.tsx` — Added `confirmCallbackRef` + `confirmSecondaryCallbackRef` refs. Updated `handleConfirmDirtyClose` to use refs. Updated `ConfirmDialog` handlers. Removed debug logging.
- `CHANGELOG.md` — Added v6.2.35 entry
- `update_record.md` — This entry

---

## v6.2.36 — Restore Game Export Button (2026-05-04)

### Problem
The "Game Export" button (Gamepad2 icon) was completely invisible in the Header toolbar even though the entire game file export system was fully implemented. The `GameExportModal` component existed with a complete multi-step flow (detect → confirm → generate → review → save → done), the `templateDetector.ts` utility detected template types from folder paths, and the `gameGeneratorPrompts.ts` built proper LLM prompts — but none of it was accessible because `App.tsx` never wired it up.

### Root Cause
`Header.tsx` already had the button UI code (lines 83-93) with conditional rendering `{onGenerateGameFile && (...)}`, and the `onGenerateGameFile` prop was already declared in the `HeaderProps` interface (line 14). However, `App.tsx` was not passing this prop to `<Header>`, so the condition always evaluated to falsy (`undefined`) and the button was never rendered. Additionally, `GameExportModal` was not imported in `App.tsx` and no state variable existed to control its visibility.

### Solution
Four small additions to `client/src/App.tsx`:

1. **Import the modal component:**
   ```tsx
   import { GameExportModal } from './components/GameExportModal';
   ```

2. **Add visibility state:**
   ```tsx
   const [showGameExportModal, setShowGameExportModal] = useState(false);
   ```

3. **Wire the prop to Header:**
   ```tsx
   <Header
     ...
     onGenerateGameFile={() => setShowGameExportModal(true)}
   />
   ```

4. **Render the modal conditionally (placed after GenerateDocumentModal):**
   ```tsx
   {showGameExportModal && (
     <GameExportModal
       currentPath={currentPath || null}
       content={content}
       onClose={() => setShowGameExportModal(false)}
       onFileCreated={(path: string) => {
         setShowGameExportModal(false);
         openFileWithConversion(path);
       }}
       aiOffline={aiOffline}
     />
   )}
   ```

### Implementation Details
- **`currentPath`** — Passed so the modal can detect the template type from the folder path via `templateDetector.ts`
- **`content`** — Passed so the modal can send the document content to the LLM for conversion
- **`onFileCreated`** — Closes the modal and opens the generated file in the editor via `openFileWithConversion`
- **`aiOffline`** — Passed so the modal can disable the Generate button when the LLM server is unreachable

### No Changes Required Elsewhere
- `Header.tsx` — Already had the button code, prop interface, and Gamepad2 icon import. No changes needed.
- `GameExportModal.tsx` — Fully functional. No changes needed.
- `templateDetector.ts` — Already maps folder paths to template types. No changes needed.
- `gameGeneratorPrompts.ts` — Already builds correct prompts per template type. No changes needed.

### Files Changed
- `client/src/App.tsx` — Added import, state, prop wiring, and modal rendering
- `CHANGELOG.md` — Added v6.2.36 entry
- `update_record.md` — This entry
