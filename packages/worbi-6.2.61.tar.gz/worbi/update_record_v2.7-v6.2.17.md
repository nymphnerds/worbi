## v6.2.17 — App.tsx Refactor: Keyboard, Editor, and Dialogs Extraction (2026-05-04)
- Refactored: Extracted keyboard shortcuts, unsaved-warning, image conversion, and dialog JSX from `App.tsx` into dedicated feature hooks and components
  - **Keyboard**: `useKeyboardShortcuts` hook now handles Cmd/Ctrl+S save and Cmd/Ctrl+M compile-modal toggle (previously inline useEffect with ~35 lines)
  - **Unsaved Warning**: `useUnsavedWarning` hook now handles beforeunload and visibilitychange warnings for dirty tabs (previously inline useEffects with ~40 lines)
  - **Image Conversion**: `useImageConversion` hook now handles server-URL-to-proxy-URL round-trip conversion for images in editor content (previously inline ~105 lines)
    - `convertServerUrlsToProxyUrls` and `convertProxyUrlsToServerUrls` extracted from App.tsx
    - `openFileWithConversion` and `handleSave` now use the hook instead of inline conversion logic
  - **Dialogs**: `AppDialogs` component consolidates all modal/dialog JSX (Template, Compile, Generate, Confirm, Prompt, FolderPicker, Graph, Help) into one self-contained component (~110 lines removed from App.tsx render)
    - `AppDialogs` accepts ~35 props but encapsulates all dialog rendering and conditional logic
    - App.tsx no longer contains any `<NewFromTemplateModal>`, `<CompileStoryBibleModal>`, `<GenerateDocumentModal>`, `<ConfirmDialog>`, `<PromptDialog>`, `<FolderPickerDialog>`, `<GraphModal>`, or inline HelpPanel JSX
  - App.tsx reduced from ~1,484 lines to ~1,268 lines (~216 lines removed, ~310 total from v6.2.15)
- Build verified: `vite build` succeeds cleanly with zero errors

### Files Modified
- `client/src/App.tsx` — Wired `useKeyboardShortcuts`, `useUnsavedWarning`, `useImageConversion`, `AppDialogs`; removed inline keyboard, warning, conversion, and dialog JSX
- `client/src/features/keyboard/useKeyboardShortcuts.ts` — Created, consumed by App.tsx
- `client/src/features/editor/useUnsavedWarning.ts` — Created, consumed by App.tsx
- `client/src/features/editor/useImageConversion.ts` — Created, consumed by App.tsx
- `client/src/components/AppDialogs.tsx` — Created, consolidates all dialog/modal JSX

### Files Deleted
- `client/src/features/editor/useEditorActions.ts` — Dead file (created in previous session, never imported, removed per safety rule)

---

## v6.2.16 — App.tsx Refactor: Layout & Navigation Extraction (2026-05-04)
- Refactored: Extracted layout management and activity navigation from `App.tsx` into dedicated feature hooks
  - **Layout**: `useLayout` hook now manages panel widths, visibility, AI sidebar toggle, panel resizers, and sidebar icon visibility (hiddenIcons Set + storage-event listener)
    - Added `hiddenIcons` Set and `visibilityRefreshKey` to `useLayout` (previously inline in App.tsx)
    - Added `resizeLeftPanel` and `resizeRightPanel` callback factories (previously inline mouse-down handlers)
    - App.tsx resizer divs now use `onMouseDown={resizeLeftPanel}` / `onMouseDown={resizeRightPanel}` instead of inline handler factories
  - **Navigation**: `useActivityRouter` hook now manages active activity state, tag sidebar state, and activity switching logic
    - Extracted `activeActivity`, `tagsShowAddTag`, `handleActivitySwitch`, `handleOpenTagSidebar`
    - Activity toggle-on-same-activity behavior moved into the hook
    - Auto-reset of `tagsShowAddTag` when switching away from tags moved into the hook
  - Removed duplicate `HideableIcon` type declaration from App.tsx (now imported from `useLayout`)
  - App.tsx reduced from ~1,578 lines to ~1,484 lines (~94 lines removed)
- Build verified: `tsc --noEmit` passes cleanly with zero errors

### Files Modified
- `client/src/App.tsx` — Wired `useLayout` and `useActivityRouter`; removed inline layout/navigation logic; removed duplicate `HideableIcon` type
- `client/src/features/layout/useLayout.ts` — Added `hiddenIcons`, `visibilityRefreshKey`, `resizeLeftPanel`, `resizeRightPanel`
- `client/src/features/navigation/useActivityRouter.ts` — Already existed, now consumed by App.tsx

### Files Unchanged (already complete, not double-instantiated)
- `client/src/features/files/useFileOperations.ts` — Already contains `createFileWithContent`; wraps `useFiles` so App.tsx continues to use `useFiles` directly to avoid double-instantiation
- `client/src/features/navigation/useSettings.ts` — Already exists with `showSettings` state; App.tsx manages it inline for now

---

## v6.2.15 — Relationship Graph Filters (2026-05-04)
- Added: Collapsible filter panel in the Relationship Graph modal toolbar for decluttering large graphs
  - Filter button (funnel icon) in toolbar with purple dot indicator when filters are active
  - **Search** — text input to filter nodes by name, ID, or tags (hides non-matching nodes)
  - **Edge Type Toggles** — color-coded pills to show/hide connection types (Character, Location, Thematic, Narrative, Tag-Based, Time)
  - **Tag Toggles** — auto-detected tags from graph data as color-coded pills; click to hide nodes with that tag
  - **Minimum Strength Slider** — range 1-5 to hide weak connections below threshold
  - **Reset All** button to clear all filters at once
  - Hidden count badge shows number of hidden nodes and edge types when filters are active
  - Uses Cytoscape hide/show (no re-layout on filter toggle for performance)
  - Tags and edge types are auto-detected from the current graph data — no hardcoded lists

### Files Modified
- `client/src/components/GraphModal.tsx` — Added filter state, filter useEffect with Cytoscape hide/show, filter panel UI with search/strength/edge type/tag toggles

---

## v6.2.14 — Mini Graph Preview Username Prop Gap Fix (2026-05-04)
- Fixed: Mini Graph Preview in Information Panel still showed "No graph generated yet" even after v6.2.13 fix
  - Root cause: `App.tsx` was not passing `username` prop to `<DocumentEditor>`, so the entire chain received `undefined`:
    - `App.tsx` → `DocumentEditor` (no username) → `InformationPanel` → `MiniGraphPreview`
  - `MiniGraphPreview.getCacheKey(undefined)` returned `'wbu_graph_cache_anon'` while `useGraph(user?.username)` saved to `'wbu_cumulative_graph_rauty'`
  - Two different cache keys meant the mini preview never saw the cached graph data
  - Fix: Added `username={user?.username}` prop to `<DocumentEditor>` in App.tsx

### Files Modified
- `client/src/App.tsx` — Added `username={user?.username}` prop to `<DocumentEditor>` element

---

## v6.2.13 — Mini Graph Preview Cache Isolation Fix (2026-05-04)
- Fixed: Mini Graph Preview in Information Panel showed "No graph generated yet" even after generating a graph
  - Root cause: `useGraph()` was called without a `username` argument in App.tsx, causing it to save graph data to an anonymous `localStorage` key (`wbu_graph_cache_v8_seed_anon`) while `MiniGraphPreview` read from a username-scoped key (`wbu_cumulative_graph_${username}`)
  - The two components were reading/writing different keys, so the mini preview never saw the cached graph
  - Fix: Pass `user?.username` to `useGraph()` in App.tsx so both components use the same key
  - Added automatic migration: on first load with username, data from the anonymous key is copied to the username-scoped key so existing graphs are not lost

### Files Modified
- `client/src/App.tsx` — Changed `useGraph()` to `useGraph(user?.username)`
- `client/src/hooks/useGraph.ts` — Added migration from anonymous cache key to username-scoped key in `loadCache()`

---

## v6.2.12 — Multi-Select Relationship Types (2026-05-04)
- Changed: Relationship Types dropdown now supports multi-select instead of single-select
  - All 5 relationship types are selected by default (Character, Location, Time, Thematic, Narrative)
  - Dropdown button shows count: "N type(s) selected"
  - Selected types highlighted with purple background, border, and checkmark (✓)
  - Click any type to toggle on/off (no dropdown close on selection — pick multiple)
  - "Clear" button in header to deselect all types at once
  - LLM receives all selected types in one prompt pass, edges merged into cumulative graph
  - Backend already supports receiving an array of relTypes — no backend changes needed

### Files Modified
- `client/src/components/RelationshipGraphSidebar.tsx` — Changed `selectedRelType: string` to `selectedRelTypes: string[]`, multi-select dropdown UI with toggle behavior, Clear button, count display

---

## v6.2.11 — Implicit AI Mode (2026-05-04)
- Changed: Removed the redundant "AI Semantic Analysis" toggle from the Relationship Graph sidebar
  - AI mode is now implicit: when no instant toggles (Tag/Era/Location-Based) are active, AI mode is automatically used
  - Selecting a relationship type from the dropdown means "analyze content with AI for this type"
  - Two mutually exclusive modes: Instant (metadata-only, fast) vs AI (content-aware, deeper)
  - Generate button now shows "Generate with AI" when no instant toggles are on, "Generate (Instant)" when any are on
  - AI warning banner now shows whenever no instant toggles are active (instead of requiring the separate AI toggle)

### Files Modified
- `client/src/components/RelationshipGraphSidebar.tsx` — Removed `useAI` state, `Brain`/`Sparkles` imports, AI toggle UI; added implicit `isAIMode` derived from instant toggles

---

## v6.2.10 — Instant Relationship Toggle Switches (2026-05-04)
- Changed: Restructured the instant relationship type UI in the Relationship Graph sidebar
  - Removed "Tag Based", "Era-Based", and "Location-Based" from the Relationship Type dropdown
  - Added three toggle switches in the Analysis Mode section: Tag-Based, Era-Based, Location-Based
  - Relationship Type dropdown is now disabled (locked) when any instant toggle is ON
  - Switching on any instant toggle automatically disables AI mode
  - Switching on AI Semantic Analysis clears all instant toggles
  - Instant toggles can be combined (e.g., Tag + Era together)
  - Generate button shows "Generate (Instant)" when any instant toggle is active

### Files Modified
- `client/src/components/RelationshipGraphSidebar.tsx` — New `ToggleSwitch` component, three instant toggle states, disabled dropdown logic, combined instant mode behavior

---

## v6.2.9 — Era-Based and Location-Based Relationship Types (2026-05-04)
- Added: Two new instant metadata-based relationship types to the graph system
  - **Era-Based**: Files sharing the same timeline era are automatically connected without AI
  - **Location-Based**: Files sharing the same location metadata are automatically connected without AI
  - Both types work in AI and non-AI (instant) modes
  - Non-AI mode now adds era_based and location_based edges in addition to tag_based edges
  - AI mode adds metadata-based edges for candidates the LLM didn't mention (safety net)
  - Backend: `collectCandidateFiles()` now detects shared locations via `same_location` reason
  - Backend: Seed loads location metadata via `locationService.getFileLocations()`
  - Backend: `REL_TYPE_INSTRUCTIONS` updated with era_based and location_based definitions
  - Client: Relationship type picker now includes "Era-Based" and "Location-Based" options

### Files Modified
- `server/src/routes/graph.js` — Added `locationService` import, era/location edge logic in AI and non-AI branches, updated `REL_TYPE_INSTRUCTIONS`, `collectCandidateFiles()` now tracks shared locations
- `client/src/components/RelationshipGraphSidebar.tsx` — Added `era_based` and `location_based` to `RELATIONSHIP_TYPES` array

---

## v6.2.8 — Graph Route Mount Fix (2026-05-04)
- Fixed: "Cannot POST /api/llm/graph/from-seed" error when clicking Generate Graph
  - The graph routes were mounted at `/api/llm` instead of `/api/llm/graph` in `index.js`, causing a 404 on the `/from-seed` endpoint
  - Changed mount point to `/api/llm/graph` so the full path `/api/llm/graph/from-seed` now correctly resolves

### Files Modified
- `server/src/index.js` — Changed `app.use('/api/llm', authMiddleware, graphRoutes)` to `app.use('/api/llm/graph', authMiddleware, graphRoutes)`

---

## v6.2.7 — Cumulative/Accumulating Graph (2026-05-04)
- Added: Graph now accumulates across sessions instead of replacing on each generation
  - When generating a graph from a new seed file, new nodes and edges are merged into the existing graph instead of creating a fresh one
  - Over time, as different files are used as seeds, the graph grows into a bigger picture of workspace connections
  - Deduplication: nodes deduplicated by `filePath`, edges deduplicated by `source+target+type`
  - Graph persists across browser sessions via `localStorage` (single cumulative cache key per user: `wbu_cumulative_graph_${username}`)
  - Unbounded growth — no cap on how many nodes accumulate
  - **Clear Graph** button added to sidebar to reset the accumulated graph and start fresh
  - MiniGraphPreview now also reads from the cumulative cache so it reflects the full accumulated graph

### Files Modified
- `client/src/hooks/useGraph.ts` — Added `mergeGraph()` for dedup merge, single cumulative cache key, `genGraph()` now loads existing cache before merge
- `client/src/components/RelationshipGraphSidebar.tsx` — Added `onClear` prop and Clear Graph button, `mergeMessage` prop for feedback
- `client/src/components/MiniGraphPreview.tsx` — Updated cache key to `wbu_cumulative_graph_${username}`
- `client/src/App.tsx` — Passes `onClear` and `mergeMessage` props to sidebar

---

## v6.2.6 — Seed-Based Relationship Graph Rewrite (2026-05-04)
- Changed: Complete rewrite of the Relationship Graph system from multi-filter to single-seed model
  - **Old approach**: Selected a graph type (Tag-Based, Character, Location, Plot, Combined), applied multiple filters (tags, eras, folders, relationship types), then generated a global graph
  - **New approach**: Pick one seed document from the currently open file, choose relationship filters, and generate a graph outward from that single viewpoint
  - Graph is now generated from the perspective of a single seed document, relating only to documents that connect to it
  - No longer attempts to relate everything in the workspace to everything else
  - Much faster, more focused results that are directly relevant to the open document
  - **Sidebar UI**: Simplified RelationshipGraphSidebar with sections for Seed Document, Analysis Mode (AI toggle + depth), Relationship Type filter, and Generate button
  - **Analysis Modes**: Tag-Based (instant, shared-tag connections) and AI Semantic (LLM-powered, deeper insights)
  - **Depth Control**: 1-Hop (direct connections only) and 2-Hop (connections + their connections)
  - **Backend**: New `POST /api/llm/graph/from-seed` endpoint replaces old `/generate-graph` and `/tag-based` endpoints
  - **Relationship Types**: Character Connection, Location Connection, Time Connection, Thematic, Narrative, Tag-Based — with improved LLM prompt including per-type instructions and `time_connection` support
  - **LLM Prompt**: Enhanced system prompt with explicit relationship type definitions and human-readable focus instructions per type

### Files Modified
- `client/src/services/api.ts` — Removed `GraphType` export, new `GraphGenerationRequest` and `GraphGenerationResponse` types, new `generateGraphFromSeed()` function
- `client/src/hooks/useGraph.ts` — Rewritten for seed-based API, `generate(seedPath, relTypes, useAI, depth)`, simplified cache
- `client/src/components/RelationshipGraphSidebar.tsx` — Complete UI rewrite with seed display, AI toggle, depth selector, relationship type picker
- `client/src/App.tsx` — Updated props for new sidebar interface, passes `seedPath` from `currentPath`
- `client/src/components/MiniGraphPreview.tsx` — Removed `GraphType` reference, updated cache entry shape
- `server/src/routes/graph.js` — New `POST /api/llm/graph/from-seed` endpoint with seed-centric graph generation, `time_connection` support, `REL_TYPE_INSTRUCTIONS` for per-type LLM focus, removed old `/generate-graph` and `/tag-based` endpoints

---

## v6.2.5 — Independent Sidebar Background Colors (2026-05-04)
- Added: Independent background color settings for left and right sidebars
  - Left Sidebar (Explorer/Search/Tags/etc.) and Right Sidebar (ChatPanel/Settings) now have their own background color properties
  - Default: Each sidebar background is 12% darker than the Panel/Card color for subtle visual depth
  - New "Sidebars" section in ThemePicker Custom Colours with separate color pickers for "Left Sidebar BG" and "Right Sidebar BG"
  - User can set completely different background colors for each sidebar via the theme settings
  - Activity Bar (48px icon strip) and Tab Bar remain unchanged at the Panel/Card color as visual separators
  - All 9 theme presets updated with computed darker sidebar colors (6 dark + 3 light themes)
  - New CSS custom properties: `--left-sidebar` and `--right-sidebar` with hex variants
  - New `darkenColor()` utility function in useTheme.ts for computing darker preset defaults
  - localStorage backward compatibility: missing sidebar colors fall back to defaults on load

### Files Modified
- `client/src/hooks/useTheme.ts` — Added `leftSidebar`/`rightSidebar` to ThemeColours interface, `darkenColor()` utility, updated all 9 presets, extended CSS_VAR_MAP, loader fallbacks
- `client/src/styles/_layout.css` — `.explorer` background changed from `--card` to `--left-sidebar`
- `client/src/components/ThemePicker.tsx` — Added "Sidebars" section with Left Sidebar BG and Right Sidebar BG color pickers
- `client/src/components/ChatPanel.tsx` — Background changed from `bg-card` to inline `--right-sidebar` CSS variable

---

## v6.2.4 — Sidebar Icon Visibility Settings (2026-05-04)
- Added: Per-icon visibility toggles in Settings → Editor tab
  - Users can now hide individual Activity Bar icons (Explorer, Starred, Tags, Timeline, Locations, Graph, Images, Outline, Reminders, AI Chat) via a "Sidebar Icons" section
  - Each icon has an on/off toggle; untoggling hides it from the Activity Bar
  - **Default: All optional icons hidden** — New users see only Explorer, Search, Starred Files, and Settings. Optional icons (Tags, Locations, Timeline, Outline, Graph, Images, Reminders, AI) are hidden until the user enables them in Settings
  - Visibility state persists in `localStorage` under `wbu_sidebar_visibility` key
  - Changes take effect immediately without page reload (custom event dispatch ensures same-tab reactivity)
  - ActivityBar conditionally renders icons based on the `hiddenIcons` Set prop

### Files Modified
- `client/src/components/ActivityBar.tsx` — Accepts `hiddenIcons: Set<string>` prop, wraps each button in `{!hiddenIcons.has(key) && ...}`
- `client/src/pages/Settings.tsx` — Added "Sidebar Icons" section in Editor tab with toggle for each icon
- `client/src/App.tsx` — Added `hiddenIcons` computed state from localStorage, passes to ActivityBar

---

## v6.2.3 — Sidebar Theme Unification (2026-05-04)
- Fixed: All sidebars now use consistent theme-aware background colors
  - Replaced hardcoded hex/HSL colors (`bg-[hsl(225,15%,8%)]`, `bg-[#1e1e2e]`) with `bg-card` semantic token
  - Affected components: FileExplorer, ChatPanel, HelpPanel, InformationPanel, RelationshipGraphSidebar
  - All sidebars now automatically adapt when the user changes themes
  - FileExplorer batch action bar uses `bg-card/80` for subtle depth while remaining theme-aware

### Files Modified
- `client/src/components/FileExplorer.tsx` — Main container and batch action bar background
- `client/src/components/ChatPanel.tsx` — Main container background
- `client/src/components/HelpPanel.tsx` — Main container background
- `client/src/components/InformationPanel.tsx` — Main container background
- `client/src/components/RelationshipGraphSidebar.tsx` — Main container background

---

## v6.2.2 — Reminder File Picker Improvements (2026-05-03)
- Fixed: Reminder "Select a file" field now auto-populates with the currently active file when a document is open
- Replaced the small inline file dropdown with a full modal file browser (FilePickerModal) for better usability
- FilePickerModal provides folder navigation with breadcrumb, back button, root button, and select confirmation
- When on the welcome screen (no file open), the user is prompted to pick a file via the modal
- File picker modal opens at the folder of the current active file for quick navigation

### Files Created
- `client/src/components/FilePickerModal.tsx` — Generic file browser modal with folder navigation, breadcrumb, and file selection

### Files Modified
- `client/src/components/ReminderSidebar.tsx` — Added `currentFilePath` prop, auto-populate logic, replaced inline dropdown with FilePickerModal
- `client/src/App.tsx` — Passes `currentPath` to ReminderSidebar as `currentFilePath`

---

## v6.2.1 — Reminder Theme Fix (2026-05-03)
- Fixed: ReminderSidebar now follows theme settings
  - Replaced all hardcoded hex colors with Tailwind semantic classes
  - Uses `bg-card`, `bg-input`, `bg-secondary`, `border-border`, `text-muted-foreground`, `text-foreground`, `bg-primary`, `text-primary`, `hover:bg-accent`
  - Matches the same theme-aware pattern used by FileExplorer, InformationPanel, and all other sidebars
  - Sidebar now automatically adapts when the user changes themes

---

## v6.2.0 — Reminder System (2026-05-03)
- **Reminder System** — Added a full reminder system with a dedicated sidebar panel (Bell icon in Activity Bar). Create reminders attached to any workspace file with a title, date/time, and optional recurrence (once, daily, weekly, monthly)
- **Quick Presets** — One-click time presets: 30 min, 1 hour, 3 hours, Tomorrow 9am, End of day
- **Weekly Day Picker** — When recurrence is set to Weekly, a day-of-week selector appears (Sun–Sat)
- **Toast Notifications** — Fired reminders appear as in-app toast notifications that auto-dismiss after 15 seconds. Click the file link in a toast to navigate directly to the file
- **Reminder Threading** — Each reminder has a note thread: click the message icon to add timestamped notes (e.g., "Done", "Deferred") that persist with the reminder
- **File Grouping** — Reminders are grouped by file in expandable/collapsible sections, sorted by earliest fire date
- **Status Indicators** — Color-coded status dots: purple (pending), amber (<1hr), red (fired/overdue), green (completed), grey (converted)
- **Completed Section** — Completed and converted reminders collapse into a collapsible "Completed" section
- **Auto-Polling** — Client polls for fired reminders every 30 seconds automatically
- **Recursion & Conversion** — Recurring reminders auto-advance to their next fire date. One-time fired reminders can be "converted" into a new reminder with a different date, preserving the thread history
- **File-Based Storage** — Reminders stored per-user in `.wbu_reminders.json` in the user's workspace directory

### Files Created
- `server/src/services/reminderService.js` — File-based reminder CRUD service with per-user storage, recurrence management, conversion (fired → new), threading, and fire-time checking
- `server/src/routes/reminders.js` — Express endpoints: `GET /reminders`, `POST /reminders`, `PATCH /reminders/:id`, `PATCH /reminders/:id/thread`, `POST /reminders/:id/convert`, `DELETE /reminders/:id`, `POST /reminders/check`
- `client/src/hooks/useReminders.ts` — React hook with state management, auto-polling (30s interval), toast notifications, and all reminder CRUD operations
- `client/src/components/ReminderSidebar.tsx` — Full sidebar UI with create form (title, file picker, datetime input, quick presets, recurrence picker, weekly day picker), grouped reminder list with expandable file sections, toast notifications, thread note inputs, and completed/collapsed view

### Files Modified
- `server/src/index.js` — Registered reminders route at `/api/reminders`
- `client/src/services/api.ts` — Added `ReminderThreadNote`, `Reminder` types and `getReminders()`, `createReminderAPI()`, `updateReminderAPI()`, `addReminderThreadNote()`, `convertReminder()`, `deleteReminderAPI()`, `checkReminders()` functions
- `client/src/features/navigation/useActivityRouter.ts` — Added `'reminders'` to `ActivityType` union
- `client/src/components/ActivityBar.tsx` — Added Bell icon button for reminders; added to `ActivityType` union
- `client/src/App.tsx` — Imported `ReminderSidebar`, wired into activity router with file selection callback

---

## v6.1.9 — Inline Rename via Double-Click (2026-05-03)
- **UX Improvement** — File/folder rename in the Explorer now supports inline editing directly in the file list. Double-clicking a file or folder name replaces it with an inline input field pre-filled with the current name (with the name portion selected, excluding the file extension). Press Enter or click the ✓ checkmark to confirm, Escape or click the ✕ X to cancel, or click away (blur) to auto-confirm. This eliminates the extra modal step for the most common rename workflow

### Files Created
- `client/src/components/InlineRenameInput.tsx` — Reusable inline text input component with auto-focus, select-name-only, keyboard support (Enter/Escape), blur-to-confirm, and confirm/cancel buttons with check/X icons

### Files Modified
- `client/src/components/FileExplorer.tsx` — Replaced `PromptDialog`-based rename with inline rename state (`renamingItemPath`); added `onDoubleClick` handler on file rows that triggers inline input; `InlineRenameInput` renders in-place when `isRenaming` is true; removed `PromptDialog` for rename entirely

---

## v6.1.8 — Native Rename Dialog Replaces window.prompt() (2026-05-03)
- **UX Improvement** — File rename in the Explorer now uses WORBI's native `PromptDialog` component instead of the browser's `window.prompt()`. Clicking the rename (pencil) icon on a file or folder opens a styled modal with the current name pre-filled, keyboard support (Enter to confirm, Escape to cancel), and visual consistency with the rest of the app's dark theme

### Files Modified
- `client/src/components/FileExplorer.tsx` — Replaced `window.prompt()` in `handleRename` with state-driven `PromptDialog` rendering; added `renamingItem` state, `handleRenameConfirm`, and `handleRenameCancel` callbacks

---

## v6.1.7 — Relationship Graph Cache Isolation (2026-05-03)
- **Bug Fix** — Relationship graph data from one user was appearing when viewing another user's files. The graph cache used a shared `localStorage` key (`wbu_graph_cache_v7`) across all users, so when User A generated a graph, User B would see User A's cached graph data after logging in. The cache key is now scoped to the logged-in username (e.g., `wbu_graph_cache_v7_alice`, `wbu_graph_cache_v7_bob`) so each user's graph data is isolated
- **Logout Cleanup** — Logging out clears old shared graph cache keys (legacy `wbu_graph_cache_v6` and `wbu_graph_cache_v7`) but preserves username-scoped keys so your own graph data persists across logout/login
- **Mini Graph Preview** — The sidebar mini graph preview also scopes its cache to the username, ensuring the small relationship preview in the Information Panel shows the correct per-user data

### Files Modified
- `client/src/hooks/useGraph.ts` — Cache key now includes username: `wbu_graph_cache_v7_${username}` instead of a shared key
- `client/src/components/MiniGraphPreview.tsx` — Cache key now includes username for the mini preview
- `client/src/hooks/useAuth.ts` — Logout clears old shared graph cache keys but preserves username-scoped keys
- `client/src/App.tsx` — Thread `user?.username` through to `<DocumentEditor>` component
- `client/src/components/DocumentEditor.tsx` — Accept and pass `username` prop to `<InformationPanel>`
- `client/src/components/InformationPanel.tsx` — Pass `username` prop to `<MiniGraphPreview>`

---

## v6.1.6 — Profile Selection UX Improvements (2026-05-03)
- **Bug Fix** — New users were not being prompted to choose a workspace profile (Game vs. Work). The login flow called `initializeUserDirs()` without a profile argument, which defaulted to creating Game folders automatically. `detectProfile()` then detected those folders and returned `'game'`, so the client never showed the Profile Selector Modal
- **Fix** — Login now passes `null` to `initializeUserDirs()`, creating only the base workspace/assets directories with no profile folders. The profile folders are created only when the user selects a profile. Existing users are unaffected (their folders already exist and are detected correctly)
- **Bug Fix** — File Explorer did not refresh immediately after profile selection. Profile folders were created on the server but not visible until page reload. Added a `useEffect` that triggers `loadFiles('')` when `recentsRefreshKey` changes, so the File Explorer reloads immediately after profile folders are created

### Files Modified
- `server/src/services/authService.js` — Changed `initializeUserDirs(cleanUsername)` to `initializeUserDirs(cleanUsername, null)` so no profile folders are auto-created on login
- `server/src/services/fileService.js` — Updated `initializeUserDirs()` to treat `null` profileKey as "create no folders" (empty array) instead of falling back to the default Game folders
- `client/src/App.tsx` — Added `useEffect` to refresh File Explorer on `recentsRefreshKey` change (profile selection triggers explorer refresh)

### Files Modified
- `server/src/services/authService.js` — Changed `initializeUserDirs(cleanUsername)` to `initializeUserDirs(cleanUsername, null)` so no profile folders are auto-created on login
- `server/src/services/fileService.js` — Updated `initializeUserDirs()` to treat `null` profileKey as "create no folders" (empty array) instead of falling back to the default Game folders

---

## v6.1.4 — Workspace Profiles: Game & Work Templates (2026-05-03)
- **Workspace Profiles** — Added a profile system that lets users choose how they want to use WORBI. Two profiles are available: **Game** (story writing & world-building) and **Work** (business management)
- **Profile Selector Modal** — On first login, users are presented with a "Choose Your Workspace" modal to select their preferred profile. The selection creates the default folder structure for that profile
- **Work Profile** — New Work profile includes 4 template types: **Customer**, **Job**, **Booking**, and **Quote** with pre-populated content templates for business workflows. Default folders: Customers, Jobs, Bookings, Quotes
- **Profile Persistence** — Selected profile is stored in `localStorage` (`wbu_profile`) and the backend `.wbu_config.json`. Switching profiles merges folder structures without deleting existing content
- **Profile-Aware Templates** — The "New from Template" dialog now filters templates based on the active profile, showing only Game templates (Character, Location, Quest, etc.) for Game profile and Work templates (Customer, Job, Booking, Quote) for Work profile. Blank template is always available
- **Profile API** — New `GET /api/files/profile` and `POST /api/files/profile` endpoints for reading and switching profiles. `GET /api/files/templates?profile=game` supports profile-filtered template lists

### Files Modified
- `server/src/services/fileService.js` — Added profile config management (`getUserProfile`, `setUserProfile`, `getUserConfig`, `saveUserConfig`), `PROFILES` registry with Game and Work folder definitions
- `server/src/routes/files.js` — Added `GET /files/profile`, `POST /files/profile` endpoints; `GET /files/templates` now accepts optional `?profile=` query param
- `server/src/services/templateService.js` — Added Work templates (customer, job, booking, quote) with inline content generators; template registry includes profile filtering
- `client/src/services/api.ts` — Added `ProfileInfo`, `ProfileResponse` interfaces; `getProfile()`, `setProfile()` functions; `getTemplates()` now accepts optional profile param
- `client/src/components/ProfileSelectorModal.tsx` — New component for profile selection with Gamepad2/Briefcase icons and descriptions
- `client/src/components/NewFromTemplateModal.tsx` — Profile-aware template loading from `localStorage`; added Work template icons (Users, ClipboardList, Calendar, Receipt)
- `client/src/App.tsx` — Wired `ProfileSelectorModal` with auto-show on first auth; profile state management

---

## v6.1.3 — Custom Modal for New File Dialog (2026-05-03)
- **UI Improvement** — Replaced the native browser `prompt()` dialog with the reusable `PromptDialog` component when creating a new blank file from the File menu. The new modal matches the WORBI dark theme with proper title, message, placeholder text, and styled Create/Cancel buttons
- **Consistency** — The "New Blank File" flow now uses the same modal pattern as other dialogs (template selection, compile, generate) instead of the inconsistent browser-native prompt window

### Files Modified
- `client/src/components/Header.tsx` — Imported `PromptDialog`, added `showNewFilePrompt` state, replaced `prompt()` call with modal open/close handlers
- `client/src/components/PromptDialog.tsx` — Fixed `hsl()` to `rgb()` in all inline styles so the modal correctly matches the active theme

---

## v6.1.2 — Dotfile Hiding Bug Fix (2026-05-03)
- **Bugfix** — Dotfiles (`.wbu_recents.json`, `.wbu_starred.json`) were still visible in the File Explorer despite v6.0.40 claiming they were hidden. Root cause: `tagService.listDirectoryWithTags()` (the function actually called by `GET /api/files`) was missing the dotfile filter that existed in `fileService.listDirectory()`. Added `.filter(entry => !entry.name.startsWith('.'))` before `.map()` in `listDirectoryWithTags()`
- **Bugfix** — `wbu_timeline_metadata.json` was visible in the File Explorer since it didn't start with a dot. Renamed to `.wbu_timeline_metadata.json` in both `graph.js` and `timeline.js` so it is now hidden by the backend dotfile filter

### Files Modified
- `server/src/services/tagService.js` — Added dotfile filter to `listDirectoryWithTags()`
- `server/src/routes/graph.js` — Renamed `TIMELINE_METADATA_FILE` to `.wbu_timeline_metadata.json`
- `server/src/routes/timeline.js` — Renamed `TIMELINE_METADATA_FILE` to `.wbu_timeline_metadata.json`

---

## v6.1.1 — Location Filter in Relationship Graph Sidebar (2026-05-03)
- **Location Filter for Graph Generation** — Added a "Filter by Locations" section to the Relationship Graph sidebar, allowing users to filter graph generation by one or more defined locations. Uses the same collapsible picker pattern as Tags and Eras, with color-coded location dots and removable badges
- **Graph Payload Extended** — `GenerateGraphPayload` now includes a `locationFilters` field that is passed through to the LLM graph generation prompt
- **Graph Cache Updated** — `GraphCacheEntry` and cache save/restore now include `locationFilters`; cache version unchanged since the field is additive

### Files Modified
- `client/src/components/RelationshipGraphSidebar.tsx` — Added location filter UI (state, toggle, picker, badges)
- `client/src/hooks/useGraph.ts` — Added `locationFilters` parameter to `generate()`, `saveCache()`, and `GraphCacheEntry`
- `client/src/services/api.ts` — Added `locationFilters` to `GenerateGraphPayload` interface
- `client/src/App.tsx` — Updated graph `onGenerate` callback to pass `locationFilters` to `graph.generate()`

---

## v6.1.0 — App.tsx Decomposition into Feature Slices (2026-05-03)
- **Refactor** — Decomposed `App.tsx` from 1538 lines monolithic component into an orchestrator (~595 lines) that composes feature modules. Each concern is now a self-contained hook in `client/src/features/`
- **Layout Feature** (`features/layout/`) — `useLayout` hook manages panel widths, drag handlers with min/max constraints, AI sidebar toggle, and localStorage persistence. `LayoutContext` provides layout state to deeply nested components. `AppLayout` is a pure presentational grid component
- **Auth Feature** (`features/auth/`) — `AuthProvider` wraps the app with auth context, rendering `<Login>` when not authenticated. Auth state (`useAuthContext`) is available anywhere via context
- **Navigation Feature** (`features/navigation/`) — `useActivityRouter` manages activity switching (explorer/search/starred/tags/timeline/locations/graph/images/outline), tag sidebar state, and panel toggle. `useSettings` manages settings modal toggle
- **File Operations Feature** (`features/files/`) — `useFileOperations` wraps `useFiles` + `useFileSystemUndoRedo`, managing all file CRUD, explorer path, DOCX upload handling, undo/redo wiring, and batch operations
- **Editor logic kept in App.tsx** — Image proxy conversion, save/restore, keyboard shortcuts, DOCX import/export, PDF export, and dirty close handling remain in the orchestrator since they wire across feature boundaries
- **main.tsx updated** — Wrapped `<App>` in `<AuthProvider>` for app-level auth context

### Files Created
- `client/src/features/layout/useLayout.ts` — Panel width management, drag handlers, AI sidebar toggle
- `client/src/features/layout/LayoutContext.tsx` — React context for layout state
- `client/src/features/layout/AppLayout.tsx` — Presentational grid component
- `client/src/features/auth/AuthProvider.tsx` — Auth context provider with login gate
- `client/src/features/navigation/useActivityRouter.ts` — Activity switching and tag sidebar state
- `client/src/features/navigation/useSettings.ts` — Settings modal toggle
- `client/src/features/files/useFileOperations.ts` — File CRUD orchestration, DOCX uploads, undo/redo

### Files Modified
- `client/src/App.tsx` — Reduced from 1538 to 595 lines; imports and composes feature hooks
- `client/src/main.tsx` — Wrapped `<App>` with `<AuthProvider>`

---

## v6.0.41 — Cross-User Recents/Starred Leak Fix (2026-05-03)
- **Bugfix** — Starred and recent files from one user leaking into another user's welcome screen. Root cause was a client-side race condition: the `useDebouncedSave` timer (500ms) wasn't cancelled on logout, so a pending save could fire with the old user's data under the new user's JWT token, writing to the wrong server-side file
- **Debounce Cleanup** — `useDebouncedSave` now tracks a `mountedRef` and clears the timer on unmount via `useEffect` cleanup, ensuring a departing user's pending save never reaches the server
- **State Reset on Login** — When `refreshKey` changes (login event), `useRecents` now immediately clears stale recents/starred arrays and sets `loading = true` before fetching, preventing the debounced save effects from flushing old-user data during the auth transition

---

## v6.0.40 — Server-Side Recents/Starred + Dotfile Hiding (2026-05-03)
- **Recents/Starred Persisted Server-Side** — Moved recent files and starred files from browser localStorage to server-side hidden files (`.wbu_recents.json` and `.wbu_starred.json` in each user's workspace root). This ensures each user sees their own unique welcome screen regardless of browser, and data persists across devices
- **Dotfile Hiding** — All dotfiles (files/folders starting with `.`) are now hidden in the File Explorer, preventing users from accidentally seeing or modifying the hidden `.wbu_*.json` support files
- **New API Endpoints** — `GET/PUT /api/files/user/recents` and `GET/PUT /api/files/user/starred` for server-side persistence of welcome screen data
- **useRecents Hook Rewrite** — Completely rewritten to load from server API on mount with debounced saves (500ms) instead of localStorage. No longer requires a `username` parameter since user identity is determined server-side via JWT auth
- **Migration** — Old localStorage-based recents/starred keys (`wbu_recent_files_v2_*`, `wbu_starred_files_v2_*`) are no longer read or written; data will start fresh for all users

---

## v6.0.38 — Welcome Screen State Rehydration on Auth Load (2026-05-03)
- **Bugfix** — Welcome screen still showed another user's starred/recent files after login. The `useRecents` hook initialized state from localStorage before auth loaded (username was `undefined`), loading stale unscoped data that never updated. Added a `useEffect` to reload recents and starred files from the correct user-scoped keys when the username changes (i.e., when auth resolves)

---

## v6.0.37 — Welcome Screen Key Version Bump (2026-05-03)
- **Bugfix** — Previous v6.0.36 migration logic inadvertently copied another user's starred/recent files to new users' scoped keys. Bumped all localStorage keys to `_v2_` format (e.g., `wbu_recent_files_v2_shaz`) so every user starts with a clean, isolated welcome screen

---

## v6.0.36 — Per-User Welcome Screen (2026-05-03)
- **Welcome Screen Data Isolation** — Fixed a bug where all users shared the same recent files and starred files on the welcome screen when using the same browser. The `useRecents` hook now scopes `localStorage` keys to the authenticated user (e.g., `wbu_recent_files_{username}` and `wbu_starred_files_{username}`) so each user sees only their own favorites and recents

---

## v6.0.35 — Location Metadata System (2026-05-03)
- **Location Field for Files** — Every file now has an optional location metadata field stored in the database (SQLite/PostgreSQL) via `metadata_locations` table
- **Location Dropdown in Info Panel** — Timeline section of the Information Panel in the editor includes a searchable dropdown (react-select AsyncCreatable) to view, edit, create, and clear the file's location
- **Locations Sidebar Panel** — New activity bar icon (map pin) opens a Locations panel with full CRUD: list all locations, rename, delete, create, and browse files grouped by location
- **Location API Endpoints** — `GET/POST/PUT/DELETE /api/files/location` for managing locations; `GET /api/files/location/all`, `/files`, `/usage`; all endpoints integrated into `files.js` routes via `locationService`
- **Location Autocomplete** — Debounced async search (`/api/files/location/search?q=`) powers the dropdown with create-new-on-type support
- **Location Service Layer** — New `locationService.js` with functions for getAll, getFiles, getFile, update, create, remove, deleteLocation, getUsage, normalize, and search

---

## v6.0.34 — Collapsible Left Sidebar (2026-05-03)
- **Collapsible Left Sidebar** — Clicking the currently active sidebar icon now hides the entire left panel (ActivityBar + panel + resizer) for a distraction-free editing experience
- **Restore Panel** — A small unfold button appears at the left edge when the panel is hidden; clicking it restores the sidebar with the previously active panel
- **Persistent State** — Hidden/visible state saved to localStorage and restored across page reloads

---

## v6.0.33 — Z-Image Folder Input Hidden in External Mode (2026-05-03)
- **Z-Image Folder Conditional** — "Z-Image Installation Folder" input in Settings → Images → Portable Configuration now hides when External mode is selected (the folder path is only relevant in Managed mode where WORBI controls the server)

---

## v6.0.32 — LLM Settings Redesign (2026-05-03)
- **LLM Settings Consolidated** — Settings → LLM tab completely restructured with a single, linear flow: Provider → Connection Mode → URL → API Key → Managed/External sections → Model → Connection Status → Token params
- **Provider-Based Conditional UI** — URL field now hides for Managed local mode (not needed since WORBI controls the server), and API Key only shows when relevant (cloud providers require it, local external is optional)
- **Connection Mode Per-Provider** — Connection Mode toggle (Managed/External) only appears for local/custom providers; cloud providers skip it entirely since they're always external
- **Duplicate Panel Removal** — Removed the old separate "LLM Configuration" section that duplicated the Connection Mode and Folder Path controls; all LLM management now lives in one cohesive form
- **Visual Status Badges** — Detected servers now show green "Found" and blue "Running" badges for clearer at-a-glance status
- **Server List Removed from Status Panel** — LLM Server (Managed) panel no longer displays a list of all detected servers; it now focuses solely on the server matching the selected provider, reducing clutter and avoiding confusion. Provider-to-server-type mapping ensures correct target for Start/Stop/Status actions

---

## v6.0.31 — LLM Portable Config + Detect-Servers Route Fix (2026-05-03)
- **LLM Portable Configuration** — Settings → LLM tab now includes operation mode selector (Managed vs External) and custom installation folder path input (mirrors Z-Image Portable Config)
- **Detect-Servers Route Fix** — Added missing `GET /api/llm/detect-servers` route that was causing "Cannot GET" errors rendered in the UI
- **GPU Handoff Fix** — Fixed `startLlm()` call in gpu-handoff route to use correct two-argument signature `(serverType, options)`
- **Save Settings Button Style** — Changed from translucent purple to solid purple with scale/brightness hover effects for better visibility
- **Folder Path Wiring** — LLM start/stop/status routes now accept `serverType` and `folderPath` from request body, passed through to `llmLifecycle.js`

---

## v6.0.30 — Multi-Server Detection & Management (2026-05-03)
- **Multi-Server LLM Lifecycle** — Managed LLM server now supports multiple server types (llama.cpp, Ollama, vLLM, LM Studio, TextGen WebUI, LocalAI, Jan) with per-type start/stop/status
- **Server Auto-Detection** — New `GET /api/llm/detect-servers` endpoint scans the system for installed LLM server binaries and reports which are found/running
- **Server Type Definitions** — New `serverTypes` config in `config.js` with binary names, default ports, base URLs, search paths, and priorities for each supported server type
- **Detection UI** — Settings → LLM tab now includes a "Detect Servers" button that scans for installed servers, displays them with Found/Running badges, and allows selecting which server to manage
- **Per-Type Management** — Start/Stop/Status actions now target the selected server type instead of defaulting to llama.cpp only
- **Panel Relocation** — LLM Server Management panel moved from Settings → Images tab to Settings → LLM tab (more logical location)
- **API Client Updates** — New `detectLlmServers()` function and `DetectedLlmServer` type in `api.ts`; `getLlmServerStatus()`, `startLlm()`, `stopLlmServer()` now accept optional `serverType` parameter
- **Backend Updates** — `llmLifecycle.js` now has `detectServers()`, multi-type `start()`, `stop()`, and `getStatus()`; `llm.js` routes pass `serverType` query/body param

---

## v6.0.29 — Managed LLM Server + GPU Handoff (2026-05-03)
- **Managed LLM Server** — WORBI can now start/stop a local llama.cpp server directly from Settings → Images → "LLM Server (Managed)" panel
- **LLM Lifecycle Service** — New `llmLifecycle.js` backend service (mirrors `imageGenLifecycle.js` pattern) with process spawning, graceful shutdown, health checks, and stdout/stderr capture
- **LLM Server API Routes** — New endpoints: `GET /api/llm/server/status`, `POST /api/llm/server/start`, `POST /api/llm/server/stop`
- **GPU Handoff Endpoint** — New `POST /api/llm/gpu-handoff` orchestrates full GPU handoff cycle: LLM stop → VRAM drain → image gen start → generate → image gen stop → LLM restore → VRAM verify
- **LLM Config Settings** — New `llm` section in `config.js` with `mode` (managed/external) and `folderPath` for portable llama.cpp installations
- **Settings UI** — LLM Server Management panel in Settings → Images tab with Start/Stop/Refresh buttons, live status indicator, PID/port/model display
- **API Client** — New `getLlmServerStatus()`, `startLlmServer()`, `stopLlmServer()`, `gpuHandoff()` functions in `api.ts`

---

## v6.0.28 — Portable Z-Image Configuration (2026-05-03)
- **Portable Z-Image Configuration** — Settings → Images tab now includes operation mode selector (Managed vs External) and custom installation folder path input
- **Managed Mode** — WORBI starts/stops Z-Image automatically (Start/Stop buttons visible in Image Generator panel)
- **External Mode** — User manages Z-Image manually, WORBI connects to the configured URL (Start/Stop buttons hidden, "External" badge shown)
- **Custom Installation Folder** — Specify a custom Z-Image installation path (default: ~/Z-Image), passed as `Z_IMAGE_DIR` environment variable to startup scripts
- **Server-Side Support** — Backend `imageGenLifecycle.js` accepts `folderPath` parameter, `imageGeneration.js` respects `zImage.mode` from user settings

---

## v6.0.27 — Theme Color Consistency Fix (2026-05-03)
- **Theme Color Consistency** — Fixed `hsl()` vs `rgb()` mismatch across all CSS files — CSS custom properties store RGB values but were wrapped in `rgb()` using legacy HSL-named variables (`--background`, `--foreground`, `--secondary`, `--accent`), causing incorrect colors that displayed as bright/washed-out instead of the intended dark purple theme
- **CSS Variable Cleanup** — Replaced all legacy HSL variable references (`--background`, `--foreground`, `--secondary`, `--accent`) with correct RGB variable names (`--bg`, `--fg`, `--muted`, `--card`) across 7 CSS files: `_editor.css`, `_layout.css`, `_modals.css`, `_tags.css`, `_chat.css`, `_timeline.css`, `_components.css`
- **Dead Code Removal** — Removed 18 unused legacy CSS custom properties from `_theme.css` that were remnants of the old HSL-based theme system

---

## v6.0.26 — Auto-Adjust Max Tokens (2026-05-03)
- **Auto-Adjust Max Tokens** — Selecting a Context Window Size preset or entering a custom value now automatically adjusts Max Tokens to 50% of the context window, ensuring the AI response fits without overflow
- **Visual Feedback** — Amber notification appears when Max Tokens is auto-adjusted, showing "⚡ Max Tokens auto-adjusted to fit context window"
- **Smart Capping** — Max Tokens is never reduced below 256, and increasing the context window will not unexpectedly raise Max Tokens beyond its current value

---

## v6.0.25 — Context Window Management (2026-05-03)
- **Auto-Trim Chat History** — Chat history is automatically trimmed before each send to stay within the configured context window, preventing token overflow errors
- **Context Window Setting** — New "Context Window Size" setting in AI Settings with presets (8K, 16K, 32K, 64K, 128K) and custom input
- **Trim Notification** — Inline banner in the chat panel notifies the user when old messages were trimmed, with a dismiss button
- **Token Estimation Utility** — New `tokenCounter.ts` utility with `estimateTokens()`, `trimChatHistory()`, and `calculateHistoryBudget()` functions

---

## v6.0.24 — Batch File Operations (2026-05-02)
- **Batch Selection Mode** — Select multiple files/folders in the File Explorer for bulk copy, move, or delete operations
- **Selection Toggle** — Click the checkbox icon in the toolbar to enter selection mode, revealing checkboxes on all file/folder items
- **Batch Action Bar** — When items are selected, a floating action bar appears with Delete, Copy, and Move buttons showing the selection count
- **Select All** — Checkbox in the "Files & Folders" header selects all items in the current directory
- **Keyboard Support** — Ctrl/Cmd+Click toggles individual items without entering full selection mode
- **Batch API** — New batch endpoints (`/api/files/batch/delete`, `/api/batch-copy`, `/api/batch-move`) for efficient server-side operations
- **Reuse of Existing Dialogs** — Batch Copy and Move use the existing FolderPickerDialog for destination selection

---

## v6.0.23 — Folder Picker Dialog (2026-05-02)
- **FolderPickerDialog** — Visual folder tree picker for "Move to" operations, replacing the native `window.prompt()` text input
- **Tree Navigation** — Clickable folder list with breadcrumb navigation, root folder option, and selected path display
- **Theme-Aware Styling** — Fixed `hsl()` vs `rgb()` mismatch in shared modal CSS (`_modals.css`) and FolderPickerDialog inline styles — CSS variables store RGB values but were wrapped in `hsl()`, causing incorrect colors (tan/bright pink instead of dark purple). Converted all new RGB variables (`--card`, `--primary`, `--border`, `--input`, `--destructive`) to use `rgb()` while keeping legacy HSL variables on `hsl()`.
- **Keyboard Support** — Enter to confirm, Escape to cancel

---

## v6.0.22 — Mini Graph Preview in Relationships Panel (2026-05-02)
- **Mini Graph Preview** — Interactive mini graph visualization in the Relationships section of the Information Panel (right sidebar) showing the local context of connected entities for the current document
- **Auto-Fetch on Tag Change** — Mini graph automatically fetches cached graph data when tags in the current document change
- **Generate/View/Refresh Actions** — "Generate" button to create a new graph, "View Graph" to open the full Relationship Graph view, and "↻ Refresh" to manually re-fetch cached data
- **Local Context Visualization** — Highlights the center node (current document) in blue with a glowing ring, shows connected edges and neighbor nodes in a compact 200px canvas
- **Full Graph Shortcut** — "Open Graph" link in the DocumentEditor header now switches the left sidebar to the Relationship Graph view

---

## v6.0.21 — Graph Era Filtering (2026-05-02)
- **Filter by Era** — New "Filter by Era" section in the Relationship Graph sidebar allows selecting specific eras to include in graph generation
- **Era API Endpoint** — New `GET /api/llm/graph/eras` returns unique eras from timeline metadata for the dropdown
- **Server-Side Era Filtering** — Graph generation now filters workspace files by selected eras; files without an era are excluded when era filters are active
- **Full Pipeline** — Era filters threaded through API payload, useGraph hook, cache, and sidebar UI

---

## v6.0.20 — Graph JSON Parsing Resilience (2026-05-02)
- **Graph Strategy 6** — Added last-resort JSON parser that extracts `nodes`/`edges` arrays separately via regex with balanced bracket matching, even when the LLM returns deeply malformed JSON
- **Graph Error Diagnostics** — Failed graph generation now logs the full LLM response (first 1000 chars) with clear delimiters instead of truncating at 200 chars, making it easy to diagnose why the model refused to return valid JSON
- **Better Error Messages** — Client-side error now mentions checking server logs for the raw LLM response

---

## v6.0.19 — Graph UX Fixes (2026-05-02)
- **Bugfix** — Graph modal now stays open when clicking a node to open a document (was closing immediately, leaving no way to get the graph back)
- **Bugfix** — "View Cached Graph" button now correctly restores and displays the cached graph from localStorage instead of triggering a brand new graph generation API call

---

## v6.0.18 — Graph Label Rendering Fix (2026-05-02)
- **Bugfix** — Graph node labels now render correctly in LLM-generated graphs, displaying document names below each node. Removed broken `label` override from `node:hover` Cytoscape CSS style that was rendering the literal text `data(label)\n\ndata(tags)` instead of the actual label values
- **Client Cache Bumped to v6** — Old v5 cache entries purged automatically on next load

---

## v6.0.17 — Graph Timeline Metadata (2026-05-02)
- **Timeline Data in Graph Nodes** — Graph nodes now include timeline era and date metadata from `wbu_timeline_metadata.json`
- **Timeline Tooltip Display** — Hovering over graph nodes shows "Timeline: [Era] [Date]" line when timeline metadata is available
- **Server-Side Optimization** — Timeline metadata loaded once at top level instead of per-file to improve performance
- **Client Cache Bumped to v5** — Old v4 cache entries purged automatically on next load

---

## v6.0.16 — Graph Label Safety Net (2026-05-02)
- **Graph Label Triple-Layer Safety** — Added explicit label validation at every layer to ensure node labels are never empty/undefined:
  - **Server:** Final safety net forces empty/missing labels to `pathToName()` fallback after enrichment; debug logging for first node enrichment
  - **Client (useGraph):** Cache bumped to v4, all old versions (v1-v3) purged; cached labels validated before restore
  - **Client (GraphModal):** Final safety net ensures non-empty string before passing to Cytoscape; warnings logged for empty-label nodes

---

## v6.0.15 — Graph Label Rendering Fix (2026-05-02)
- **Graph Label Fix (3-Layer Defense)** — Node labels now render correctly even when LLM returns missing/empty labels. Server: dual-key metadata map indexes files by both full path and without `.html` extension. Client: validates labels before passing to Cytoscape, falls back to deriving from file path. Cache: bumped to v3, purges stale v1/v2 entries.
- **Robust LLM JSON Parsing** — Replaced fragile single-pass JSON extractor with 5-strategy fallback system (direct parse → code block extraction → nodes-anchored pattern → trailing comma fix → balanced brace matching)
- **Graph Debug Logging** — Server now logs raw LLM response (first 500 chars) on every graph generation for troubleshooting
- **Graph Label Fix v2** — Server now enriches LLM graph response with authoritative file metadata (label, tags, color) before returning to client; bumped client cache version to clear stale cached data

---

## v6.0.14 — Graph LLM JSON Parsing + Label Fix (2026-05-02)
- **Robust LLM JSON Parsing** — Replaced fragile single-pass JSON extractor with 5-strategy fallback system (direct parse → code block extraction → nodes-anchored pattern → trailing comma fix → balanced brace matching)
- **Graph Debug Logging** — Server now logs raw LLM response (first 500 chars) on every graph generation for troubleshooting
- **Graph Label Fix v2** — Server now enriches LLM graph response with authoritative file metadata (label, tags, color) before returning to client; bumped client cache version to clear stale cached data

---

## v6.0.11 — Interactive Relationship Graph (2026-05-02)
- **Interactive Relationship Graph** — New Activity Bar panel visualizes document connections as an interactive force-directed graph using Cytoscape.js
- **LLM-Powered Graph Generation** — AI analyzes document content to discover implicit relationships (characters, locations, themes, narrative connections)
- **5 Graph Types** — Full Graph, Character Network, Location Map, Thematic Links, and Tag-Based Only views
- **Draggable Modal** — Graph renders in a resizable, draggable modal with maximize, zoom, pan, and re-layout controls
- **5 Relationship Types** — Character Connection (amber), Location (green), Thematic (purple), Narrative (blue), Tag-Based (gray dashed)
- **Node Interaction** — Click nodes to open documents, drag to rearrange, hover for tooltips with tags and metadata
- **Filtering** — Filter by tags and relationship types in the sidebar before generating
- **Smart Caching** — Generated graphs cached to localStorage for fast reload
- **AI-Only Feature** — Graph icon greys out when LLM is offline, following existing AI feature visibility rules
- **Tag-Based Fallback** — Tag-Based Only mode works without LLM by computing implicit edges from shared tags

---

## v6.0.10 — WikiLink Emoji Prefix (2026-05-02)
- **WikiLink Emoji Prefix** — Default wiki link display text now includes a 📒 emoji (e.g., "📒 Link to: timeline") for quicker visual identification of links in editor content

---

## v6.0.9 — WikiLink Popover Auto-Close (2026-05-02)
- **WikiLink Popover Auto-Close** — Popover now closes automatically after 1500ms of inactivity instead of requiring a click-outside to dismiss
- **Smart Timer** — Timer only starts after link data has resolved (so slow API calls don't prematurely close the popover)
- **Mouse-Aware** — Moving mouse into the popover cancels the timer; moving mouse out restarts it
- **Refactored Close Logic** — Auto-close handling moved from editor extension into `WikiLinkPopover` component for cleaner separation of concerns

---

## v6.0.8 — Keyboard Shortcuts Settings (2026-05-02)
- **Keyboard Shortcuts Tab** — New "Keyboard" tab in Settings to view and customize all programmable hotkeys
- **7 Rebindable Shortcuts** — Save, New from Template, Find, Find & Replace, AI Complete, Accept AI Suggestion, Decline AI Suggestion
- **Key Capture UI** — Click any shortcut to record a new key combination with visual feedback
- **Category Filtering** — Filter shortcuts by All, App, Editor, or AI categories
- **Conflict Detection** — Visual warnings when multiple actions share the same key binding
- **Custom Badges** — "custom" badge for modified shortcuts, "conflict" badge for conflicting bindings
- **Reset Controls** — Reset individual shortcuts to default or reset all at once
- **Persistent Storage** — Custom key bindings saved to localStorage and restored on startup
- **Cross-Platform Display** — Ctrl shown as ⌘ on macOS, Win on Windows for Meta key

---

## v6.0.7 — Emoji Picker (2026-05-02)
- **Emoji Picker** — New emoji picker button (smile icon) in the editor toolbar for inserting emojis at cursor position
- **8 Categories** — Smileys, People, Animals, Food, Activities, Travel, Objects, Symbols, Flags with ~800 curated emojis
- **Search** — Filter emojis within the active category using the search input
- **Category Tabs** — Horizontal scrollable tabs with emoji icons for quick category switching
- **Dark Theme** — Solid dark background (`#1a1a1a`) with inline style override for consistent appearance across all browser/system themes

---

## v6.0.6 — Custom Dialogs (2026-05-02)
- **Custom Confirm Dialog** — Replaced native `window.confirm()` with a styled custom `ConfirmDialog` component matching the WORBI dark theme
- **Custom Prompt Dialog** — Replaced native `window.prompt()` with a styled custom `PromptDialog` component
- **3-Button Dirty Tab Close** — Closing a tab with unsaved changes now shows "Save / Don't Save / Cancel" buttons (previously was a basic 2-button confirm)
- **Consistent UX** — All confirmation prompts (delete file/folder, insert image, etc.) now use the custom dialog instead of browser-native popups
- **Keyboard Support** — Both dialogs support Enter to confirm and Escape to cancel

---

## v6.0.5 — Unsaved Changes Warning (2026-05-02)
- **Unsaved Changes Dialog** — Browser "Are you sure you want to leave?" confirmation now appears when closing the tab, navigating away, or refreshing the page with unsaved edits in any open document

---

## v6.0.4 — Theme & Colour Settings (2026-05-02)
- **Appearance Settings** — New "Appearance" tab in Settings with full theme customization
- **Theme Presets** — 6 curated presets: Purple Mist (default), Nord, Gruvbox, Dracula, Ocean, Rose
- **Light/Dark Toggle** — Smooth animated toggle between light and dark modes (3 presets include dedicated light variants: Purple Mist, Nord, Ocean)
- **Full Colour Picker** — 13 individually customizable colours: Background, Text, Panels, Panel Text, Borders, Input BG, Muted BG, Muted Text, Primary, Primary Text, Danger, Success, Warning
- **Live Preview** — Real-time preview panel showing how your colour combination looks with buttons, status dots, and input fields
- **Persistent** — Theme settings saved to localStorage and restored on app startup
- **Reset to Default** — One-click reset button to restore Purple Mist dark theme
- **CSS Custom Properties** — All theme colours applied as CSS variables (`--bg`, `--fg`, `--primary`, etc.) for consistent theming across all components
- **Bugfix** — Theme buttons now render the correct colour. Tailwind config was wrapping RGB CSS variables in `hsl()`, causing Purple Mist to show bright pink and Nord to show magenta instead of their intended colours. Fixed by switching Tailwind from `hsl()` to `rgb()` for all theme-managed colour variables
- **Bugfix** — Nord theme primary colour toned down from bright teal (`#88c0d0`) to a soft, muted steel blue-grey (`#5e8899`) for a more subtle, calm aesthetic
- **Bugfix** — Theme preset cards now use responsive grid layout (2 columns on narrow panels, 3 on wide) with centered content for a cleaner look
- **Bugfix** — WikiLink popover "Open Document" button now uses theme colours. Was using `hsl()` for CSS variables which store RGB values, causing bright pink instead of subtle purple. Popover background, border, text, and autocomplete dropdown now all adapt to the active theme

---

## v6.0.3 — Hide System Files in Explorer (2026-05-02)
- **Explorer Filter** — System-generated `*.wbu_meta.json` support files are now hidden in the File Explorer, showing only user-created files for a cleaner workspace view

---

## v6.0.2 — Information Panel Tag Color Fix (2026-05-02)
- **Bugfix** — Tags in the Information Panel TAGS section now display with text color, border color, and glow matching the tag's defined color from the sidebar (was hardcoded to yellow text with purple glow)

---

## v6.0.1 — WikiLink Bugfixes (2026-05-02)
- **Bugfix** — WikiLink input rule no longer duplicates `[[...]]` text after conversion (was using `insertContent` which re-triggered the rule; now uses `deleteRange` + `insertContent` in a single chain)
- **Bugfix** — WikiLinks now render as styled inline pills (blue for existing, amber for missing) instead of plain text with dotted underline
- **Bugfix** — Hover popover no longer disappears when moving mouse over the popover (removed `mouseout` hiding; popover only closes on click-outside)
- **Bugfix** — "Open Document" button in WikiLink popover now correctly opens the target file (was missing `onOpenFile` prop wiring from `DocumentEditor` to `App`)
- **Bugfix** — "Create Document" button for missing links now creates the file in the current explorer folder (wired `onCreateNamedFile` prop through `DocumentEditor` to `App`)
- **Bugfix** — WikiLink display text now shows "Link to: {Name}" prefix instead of just the document name. Custom pipe syntax `[[Name|Custom Text]]` still overrides it
- **Bugfix** — All WikiLink states (exists/missing/resolving) now render as blue instead of amber/purple
- **Bugfix** — WikiLinks now survive save/reopen cycle (added `getAttrs` to `parseHTML` so TipTap correctly extracts `targetName`, `displayText`, `exists`, and `filePath` from saved HTML)
- **Bugfix** — WikiLink hover popover now closes after clicking "Open Document" or "Create Document" button (was staying open)

---

## v6.0.0 — Cross-Document WikiLinks (2026-05-02)
- **WikiLinks** — Obsidian-style `[[Document Name]]` syntax creates clickable links between documents
- **Link Resolution** — `[[Name]]` is case-insensitively matched against all workspace `.html` files
- **Blue Links** — Document exists, clicking opens it in a new tab
- **Amber Links** — Document doesn't exist yet, clicking prompts creation
- **Pipe Syntax** — `[[Name|Custom Display Text]]` for custom link labels
- **Autocomplete** — Typing `[[` triggers a dropdown with matching documents and keyboard navigation (arrows + Enter)
- **Hover Popover** — Hover over a link (300ms delay) to see document name, path, content preview, and "Open" button
- **Backlinks Panel** — New section in Information Panel showing which documents link to the current one with context snippets
- **WikiLink TipTap Extension** — Custom Mark extension that parses `[[...]]` as styled inline spans with click/hover handlers
- **Backend API** — Three new endpoints: `resolve-wikilink` (name→path), `wikilink-search` (autocomplete), `backlinks` (reverse lookup)
- **Edge Cases** — Links in code blocks are not parsed; circular links handled gracefully; self-links render as non-clickable

---

## v5.9.0 — File Restore (2026-05-02)
- **File Restore** — One-click "Restore to last opened version" button (⟲ icon) in the editor toolbar to revert all changes since a file was opened
- **Persistent Snapshot** — When a file is opened, its content is snapshotted; the snapshot is preserved even after saving, so you can restore if you accidentally save wrong changes
- **Safety Confirmation** — Clicking Restore prompts a confirmation dialog to prevent accidental data loss
- **Restore Awareness** — Restore button stays enabled after saving if content differs from the original snapshot (not just when dirty)
- **Bugfix** — Restore now correctly updates both TipTap editor instances (main + margin) by bypassing the editor sync guard

---

## v5.8.0 — Outline/Bookmark Sidebar (2026-05-02)
- **Outline/Bookmark Sidebar** — New Activity Bar panel (List icon) showing all headings in the active document as quick-navigate bookmarks
- **Automatic Heading Detection** — H1, H2, and H3 headings are parsed in real-time from the editor content
- **Quick Navigation** — Click any heading to scroll to it in the editor with a smooth animation and brief purple highlight
- **Manual Bookmarks** — Ctrl+Shift+M to pin the current cursor position as a permanent bookmark with an auto-generated label
- **Per-File Persistence** — Bookmarks are stored in localStorage per file path and survive page reloads
- **Bookmark Management** — Hover to reveal remove button; delete unwanted bookmarks with one click
- **Empty State Guidance** — Helpful hints when no document is open or no headings are found

---

## v5.7.0 — Image to Text (Document Transcription) (2026-05-02)
- **Image to Text Mode** — New "Image to Text" mode in the Image Generator Panel for converting handwritten or printed documents to text
- **Document Transcription** — Upload an image or select from workspace, then transcribe using your LLM's vision capabilities
- **Transcription Controls** — Optional custom instructions, copy to clipboard, insert result into prompt area, and "Open in Editor" to create a new document with the transcribed text
- **Open in Editor** — One-click button creates a new timestamped document (e.g., `Transcribed_20260502_042700`) in the current folder and opens it in the DocumentEditor
- **Vision Model Support** — Works with any vision-capable LLM (LLaVA, GPT-4o, Claude Vision) configured in Settings
- **Backend Transcription Endpoint** — New `POST /api/llm/transcribe-image` sends the image as base64 to the LLM for transcription

---

## v5.6.0 — Z-Image Integration + VRAM Protection + AI Offline Detection (2026-05-02)
- **AI Image Generation** — Generate images directly within WORBI using Nymphs2D2 (Z-Image-Turbo) local backend
- **Image Generator Panel** — Full-featured sidebar with text-to-image and image-to-image modes, prompt, negative prompt, size selector, steps, seed randomization, and img2img strength
- **Generate Image Modal** — Simplified progress view showing real-time progress bar and generated image result
- **Sparkles Generate Button** — Quick-access ✨ icon in ImageExplorer header opens the Image Generator Panel
- **Images Settings Tab** — Settings → Images panel with Z-Image server status, start/stop controls, model info, and refresh
- **Server Lifecycle Management** — Start/stop Nymphs2D2 backend from Settings or automatically on first generation request
- **VRAM Protection** — Server-side VRAM check before starting Z-Image server; configurable minimum free VRAM threshold (default 8 GB) prevents crashes from GPU OOM when LLM is also running
- **VRAM Warning Dialog** — If free VRAM is below threshold, a yellow confirmation dialog warns the user with "Cancel" or "Generate Anyway" options
- **GPU Memory Check Settings** — Settings → Images → Minimum Free VRAM input field (1024–32768 MB, saved to localStorage)
- **Progress Polling** — Real-time progress bar during image generation (polls every 2s)
- **Graceful Degradation** — Image features hidden when Z-Image server is unavailable or not configured
- **Server-side Image Proxy** — Generated images copied from Nymphs2D2 outputs to assets/images/ for persistent access
- **AI Offline Detection** — Proactive health check on app mount detects whether the LLM server is reachable
- **Greyed-out AI Features** — When AI server is offline, AI-related UI elements are greyed out with 30% opacity and disabled:
  - ActivityBar: AI toggle (Sparkles) and Image Generator icons are disabled with "AI server is offline" tooltip
  - Header: AI sidebar toggle button is disabled with offline tooltip
  - Welcome: "Generate with AI" button is visually dimmed and disabled
  - ChatPanel: Red offline banner, disabled input with "AI server offline..." placeholder, disabled send button
- **Automatic Status Recovery** — UI automatically re-enables AI features when a successful LLM response is received
- **Bugfix** — LLM health check now correctly reads `detected` field from detect endpoint (was checking `providers`), and requires detected providers to have loaded models before reporting "connected"
- **Bugfix** — StatusBar shows "LLM Offline" (red dot) when AI server is unreachable instead of incorrectly showing "LLM Connected"
- **Bugfix** — LLM health check now automatically re-runs after login so AI features activate immediately without requiring a page refresh

---

## v5.5.0 — Timeline View + AI Writing Assistant (2026-05-02)
- **Timeline View** — New Activity Bar panel (Clock icon) showing all timeline entries grouped by era, sorted chronologically
- **Timeline entry detection** — Documents with Date/Period + Era fields are automatically detected (anywhere in workspace)
- **Tag-based categories** — Replaced hardcoded category system with user tags; timeline event dots use tag colors
- **Timeline Settings Modal** — Manage Era Order and Date Format via gear icon in Timeline header
- **Timeline filters** — Era and Tag filter dropdowns with multi-select checkboxes
- **Collapsible eras** — Click era headers to expand/collapse groups of events
- **Timeline metadata in Information Panel** — Set Date/Period and Era fields per document
- **Auto-suggest date** — Selecting an era auto-fills the date field with the next sequential number (1, 2, 3...) based on how many entries already exist in that era. User can freely edit.
- **Server-side file scanning** — Timeline endpoint scans entire workspace for extensionless HTML files (not just .html)
- **NoTag label** — Timeline entries without tags display "NoTag" instead of blank; untagged events always appear even when tag filters are active
- **Bug fix** — Resizable sidebar bar now works for Timeline, Starred Files, and Tags panels (was only working for Explorer and Search)
- **AI Ghost Text** — Inline AI completion suggestions rendered as dimmed text at cursor position; triggered via `Ctrl+Space` or ✨ Sparkles button in the toolbar
- **Tab to Accept / Escape to Dismiss** — Accept ghost text suggestions with `Tab`, dismiss with `Escape`
- **Auto-Complete Mode** — Toggle the "AI" button in the toolbar for continuous automatic suggestions while typing (1.5s idle debounce)
- **AI Name Generator** — Generate culture-specific names (Elvish, Dwarvish, Nordic, etc.) for characters, places, items, and factions; insert directly at cursor
- **AI Document Generation** — Generate structured documents from a prompt via "Generate with AI" modal; supports character sheets, location descriptions, quest outlines, timeline entries, and freeform

---

## v5.4.0 — Document Templates + Story Bible Compiler (2026-05-01)

- **Document Templates** — 7 pre-built structured HTML templates for world-building content: Character Sheet, Location Description, Quest Outline, Timeline Entry, Item/Artifact, Faction/Organization, and Creature/Monster. Templates include relevant headings, prompts, and the `<!-- MARGIN_SPLIT -->` delimiter for the two-column editor. A Blank Document template is also available.
- **New from Template modal** — Grid-based template picker with icon cards, folder selector, and preview. Accessible from four entry points: Header "File" menu → "New from Template...", Welcome screen button, File Explorer context menu, and `Ctrl+Shift+N` keyboard shortcut.
- **Story Bible Compiler** — Compile selected files, entire folders, or the whole workspace into a single organized HTML reference document. Supports Table of Contents with clickable anchor links, section dividers between folders, file path subtitles, optional margin note exclusion, and ordering by folder structure, alphabetical, or last modified. Wiki links `[[...]]` are flattened to plain text in compiled output.
- **File menu redesign** — Replaced the single "New File" button in the Header with a dropdown menu containing "New Blank File", "New from Template...", and "Import DOCX" options, improving discoverability and reducing toolbar clutter.
- **Server-side template service** — Templates stored as `.html` files on disk in `server/src/data/templates/`, loaded and served via `templateService.js`. The `POST /api/files/template` endpoint creates new files from templates with proper naming and folder placement. The `POST /api/files/compile` endpoint handles document concatenation with ToC generation, margin note stripping, and wiki link flattening.

### Files Changed

**New files:**
- `server/src/data/templates/character.html` — Character sheet template with Physical Description, Personality, Background, Abilities, Motivations, Relationships sections
- `server/src/data/templates/location.html` — Location description template with Geography, Population, Points of Interest, History, Adventure Hooks sections
- `server/src/data/templates/quest.html` — Quest outline template with Hook, Objectives, Key NPCs, Encounters, Rewards, Complications sections
- `server/src/data/templates/timeline.html` — Timeline entry template with Date/Period, Description, Key Figures, Causes, Consequences, Related Events sections
- `server/src/data/templates/item.html` — Item/artifact template with Type, Rarity, Attunement, Description, Properties, History, Plot Significance sections
- `server/src/data/templates/faction.html` — Faction/organization template with Type, Alignment, Size, Goals, Leadership, Structure, Resources, Allies/Enemies sections
- `server/src/data/templates/creature.html` — Creature/monster template with Type, CR, Size, Alignment, Behavior, Habitat, Abilities, Combat, Lore sections
- `server/src/services/templateService.js` — Template loading, placeholder replacement, file creation, and story bible compilation logic
- `client/src/components/NewFromTemplateModal.tsx` — Template selection modal with grid layout, icon cards, folder selector, and keyboard shortcut support
- `client/src/components/CompileStoryBibleModal.tsx` — Compilation options modal with source selection, ordering, ToC, section dividers, and margin note exclusion controls

**Modified files:**
- `server/src/routes/files.js` — Added `POST /api/files/template` and `POST /api/files/compile` route handlers
- `client/src/services/api.ts` — Added `createFromFileTemplate()` and `compileStoryBible()` API functions with request/response types
- `client/src/components/Header.tsx` — Replaced single "New File" button with dropdown File menu, added `onCreateFromTemplate` prop
- `client/src/components/FileExplorer.tsx` — Added `onCompile` prop and BookOpen toolbar button for story bible compilation
- `client/src/components/Welcome.tsx` — Added "New from Template" button with purple styling
- `client/src/App.tsx` — Wired template/compile modals, `Ctrl+Shift+N` shortcut, modal success handlers, Welcome `onCreateFromTemplate` prop
- `client/src/styles/globals.css` — Added `.story-bible-document`, `.story-bible-path`, `.story-bible-section`, `.template-grid`, `.template-card` CSS classes

---

## v5.2.0 — Session Persistence + LLM Provider Config Redesign (2026-05-01)

- **Session persistence** — WORBI now restores your workspace on page reload: open tabs (and the active tab), File Explorer folder path, and active Activity Bar panel are saved to `localStorage` and restored on startup. Missing files are silently skipped. The `wbu-session` key is cleared on logout so fresh logins start with a clean slate.
- **LLM Provider Config Redesign** — Replaced the hardcoded local-server-only config with a full provider selection system. The Settings → LLM tab now features a provider dropdown with curated local and cloud providers (16 presets including LM Studio, Ollama, llama.cpp, OpenAI, Groq, Together AI, OpenRouter, Mistral, Anthropic, xAI, Google AI Studio, and Custom), model browser with dropdown, API key field with show/hide toggle, connection status indicator, and "Test Connection" button. Selecting a provider auto-fills its default API URL. Non-OpenAI-compatible providers (Anthropic, Google AI Studio) show warning banners.
- **Per-User LLM Settings** — `baseUrl`, `apiKey`, `providerId`, and `serverType` are now stored per-user (no more hardcoded `.env` config for the LLM URL). The LLM service functions accept explicit settings instead of reading from a global config.
- **Settings Persistence** — LLM settings (provider, URL, API key, model, inference params) are saved per-user to `data/user-settings/{username}-settings.json` and persist across sessions. Settings are loaded from the server on app mount via `GET /api/settings`, and saved via `POST /api/settings/user`.
- **Bug Fix: Settings not persisting** — The `data/user-settings/` directory was not created on server startup, causing `saveUserSettings()` to fail silently and `loadUserSettings()` to always return empty defaults. Fixed by calling `ensureSettingsDir()` at module initialization in `config.js`. Also fixed `toolPermissions` not being destructured/saved in the `POST /user` route.
- **Bug Fix: Model name resetting to placeholder** — When the model list fetch returned an empty `models` array, the saved model name had no matching `<option>` in the `<select>` element, causing HTML to reset it to the first option ("-- Select a model --"). Fixed by always rendering the saved model name as a pinned option (prefixed with "✓") when it is not in the fetched model list.
- **Bug Fix: Yellow warning shown on page load** — The "Could not load models" warning under the Model dropdown was shown whenever `models.length === 0`, regardless of whether the connection was actually tested. Fixed the condition from `connectionStatus !== 'connected'` to `connectionStatus === 'failed'` so the warning only appears after an explicit failed connection test, not on initial page load.
- **Removed** — `lmsStartScript` config reference (was non-functional on non-dev machines), 10-second `fetchSystemInfo` polling, read-only model name field, auto-detection system (port probing, Re-scan button, detection states). `GET /api/llm/system-info` deprecated (returns a deprecation notice).

## v5.1.10 — AI Sidebar Visibility Fix (2026-05-01)

- **Bug Fix:** AI sidebar now correctly hides on fresh login. Previously, if the user toggled the AI sidebar on in a prior session, it would remain visible after logout + re-login. The fix clears the `wbu-ai-sidebar` localStorage key during logout and resets sidebar state when authentication transitions from unauthenticated → authenticated.

### Files Changed

- `client/src/hooks/useAuth.ts` — Added `localStorage.removeItem('wbu-ai-sidebar')` in `logout()`
- `client/src/App.tsx` — Added `prevAuthRef` + `useEffect` to detect fresh login and reset `showAISidebar` to `false`

---

## v5.1.9 — AI Tools Engine (MCP-Style Function Calling) (2026-04-30)

- **AI Tools Engine** — The LLM chat can now execute actions beyond text generation. When tools are enabled (⚡ toggle in chat header), the AI can call tools in a loop up to 10 iterations per message, with results fed back as context.
- **8 Built-in Tools:**
  - `web_search` — DuckDuckGo web search for research and facts
  - `read_file` — Read a workspace file by path
  - `list_files` — List files in a workspace directory
  - `create_file` — Create a new file with content
  - `edit_file` — Apply search/replace edits to an existing file
  - `delete_file` — Delete a workspace file
  - `rename_file` — Rename a file or folder
  - `search_files` — Regex search across workspace files
- **Granular Permission System** — Configure exactly what the AI can do via Settings → Tools tab:
  - Web search on/off toggle
  - File access level: none → read → readwrite → full
  - Individual toggles for create, edit, delete, rename
  - Max search results slider (1–20)
- **Tool Status Messages** — Real-time styled cards in the chat showing what the AI is doing ([🔍 Web Search] ✅ Done, [📄 Read File] ❌ Error, etc.)
- **Tool Toggle** — One-click enable/disable all tools via the ⚡ zap icon in the chat panel header. When disabled, the AI operates in standard chat-only mode.
- **Settings → Tools Tab** — Full permission management UI with info banner, toggles, access level selector, granular permissions, and save button.

### Files Changed

- `server/src/services/toolService.js` — **NEW** — Tool execution engine with `executeTool()` dispatcher, permission validation, and 8 built-in tools
- `server/src/services/llmService.js` — Added tool-calling loop with `tool_call`/`tool_result` message pairs, up to 10 iterations, tool activity tracking
- `server/src/routes/llm.js` — Accept optional `permissions` object from client, pass to `chatWithLLM()`
- `server/src/config.js` — Default tool permission settings (`toolPermissions` object)
- `client/src/services/api.ts` — New types: `ToolPermissions`, `ToolActivity`, `ChatMessageWithTools`; `sendChat()` now accepts optional permissions
- `client/src/hooks/useLLM.ts` — Tool permissions state, `toolsEnabled` toggle, `updateToolPermissions()`, `saveToolPermissions()`, tool activity rendering in chat history
- `client/src/components/ChatPanel.tsx` — ⚡ toggle button, tool status message detection and rendering, "⚡ Thinking & acting..." loading state, tools-active placeholder message
- `client/src/pages/Settings.tsx` — New "Tools" tab with permission controls
- `client/src/App.tsx` — Wired `toolsEnabled`/`setToolsEnabled` from `useLLM` to `ChatPanel`
- `README.md` — Updated features section with AI Tools Engine details
- `docs/AI_TOOLS_INTEGRATION.md` — **NEW** — Technical documentation for the AI tools system

---

## v5.1.8 — Redesign Tag Dropdown in Editor Toolbar (2026-04-30)

- **Tag dropdown now applies tags directly** — Selecting a tag from the dropdown in the editor toolbar immediately applies that tag to the current document, eliminating the previous two-step select-then-click flow. The preview banner and intermediate state have been removed.
- **+ button opens Tags sidebar for new tag creation** — Clicking the + button next to the tag dropdown now switches the left sidebar to the Tags view and automatically opens the "Create New Tag" form, ready for the user to type a tag name. This provides a direct path from the editor toolbar to creating new tags.
- **State synchronization** — The Tags sidebar (`TagManager`) now accepts a `defaultShowAddTag` prop that controls whether the "Create New Tag" form is shown. When the + button is clicked from the editor, the sidebar switches to Tags and the form is displayed. The form state resets when switching away from the Tags activity.

### Files Changed

- `client/src/components/TagInsertControl.tsx` — Simplified component: dropdown `onChange` now directly calls `addTags()` and fires `wbu-tags-changed` event. Added `onOpenTagSidebar` prop for the + button. Removed `selectedTag` state, preview banner, and disabled-state logic.
- `client/src/components/TagManager.tsx` — Added `defaultShowAddTag` prop and `useEffect` to sync `showAddTag` state when the prop changes (e.g., from toolbar + button).
- `client/src/components/DocumentEditor.tsx` — Added `onOpenTagSidebar` prop and passed it through to `TagInsertControl`.
- `client/src/App.tsx` — Added `tagsShowAddTag` state, `useEffect` to reset it when switching away from tags activity, and `handleOpenTagSidebar` callback that switches to Tags view and enables the add form.

---

## v5.1.7 — Hero Image Removal Confirmation (2026-04-30)

- **Confirmation dialog when removing hero image** — Clicking the X button to remove a document's hero image now shows a confirmation prompt: "Remove this image as the hero image for this document? The image file will not be deleted." This prevents accidental removal and clarifies that only the hero image association is removed, not the image file itself from the workspace.

### Files Changed

- `client/src/components/InformationPanel.tsx` — Added `window.confirm()` in `handleRemoveHero()` before calling `removeHeroImage()`

---

## v5.1.6 — Fix Tag File Filter for Non-HTML Files (2026-04-30)

- **Fixed "All Tags" file search returning no results** — The tag filter in the Tags sidebar now correctly finds files with any extension, not just `.html` files. Previously, `getFilesByTag()`, `getFileRelationships()`, and `listDirectoryWithTags()` only scanned `.html` files, so files without that extension were invisible to tag-based queries even when they had tags attached.
- **Extension-agnostic metadata** — `getMetaPath()` no longer assumes a `.html` extension when building metadata filenames, ensuring metadata files are correctly paired with their source files regardless of extension.
- **Binary file exclusion** — Added `isScannableFile()` helper that skips hidden/meta files (starting with `.`) and binary file types (images, PDFs, archives, media, etc.), matching the same pattern used by the workspace search.

### Files Changed

- `server/src/services/tagService.js` — Added `BINARY_EXTENSIONS` set and `isScannableFile()` helper. Replaced `.html` filter with `isScannableFile()` in `getFilesByTag()`, `getFileRelationships()`, and `listDirectoryWithTags()`. Fixed `getMetaPath()` to use `path.basename()` without stripping `.html`.

---

## v5.1.5 — Find & Replace in Editor Toolbar (2026-04-30)

- **Find & Replace panel in document editor** — Added a collapsible Find & Replace toolbar that appears above the main editor content. Toggle with the Search icon button in the toolbar or via keyboard shortcuts `Ctrl+F` (Find) and `Ctrl+H` (Find & Replace). Press `Escape` to close.
- **Search with highlights** — All matches are highlighted in yellow (`search-highlight` class). The currently active match is highlighted in orange (`search-highlight-active` class) and scrolled into view. Match counter shows "X of Y" format.
- **Navigate matches** — Previous/Next buttons (ChevronLeft/ChevronRight icons) cycle through matches with smooth scrolling.
- **Replace and Replace All** — Replace the currently active match or all matches at once. Enter key in the Replace field triggers a single replace.
- **Case sensitivity toggle** — "Aa" checkbox for case-sensitive search.
- **DOM-based search** — Uses a TreeWalker to traverse text nodes in the TipTap editor DOM, wrapping matches in `<span class="search-highlight">` elements. Highlights are cleared when the panel is closed.

### Files Changed

- `client/src/components/DocumentEditor.tsx` — Added Find & Replace state (`showFindReplace`, `findText`, `replaceText`, `caseSensitive`, `matchCount`, `currentMatch`), search logic (`performSearch`, `navigateMatch`, `handleReplace`, `handleReplaceAll`, `clearSearchHighlights`), keyboard shortcuts (Ctrl+F, Ctrl+H, Escape), Search icon toggle button in toolbar, collapsible Find & Replace panel UI with Find input, Replace input, navigation buttons, case sensitivity toggle, and Replace/Replace All buttons. Imported `Search`, `Replace`, `X`, `ChevronLeft`, `ChevronRight` from lucide-react.
- `client/src/styles/globals.css` — Added `.search-highlight` and `.search-highlight.search-highlight-active` CSS classes for match highlighting.

---

## v5.1.4 — Larger Editor Tabs (2026-04-30)

- **Bigger editor tabs** — Increased tab padding from `px-3 py-1.5` to `px-4 py-2.5`, text size from `text-xs` to `text-sm`, and close button size from `p-0.5` with a 12px icon to `p-1` with a 14px icon. Tabs are now more comfortable to use with better spacing between the file name and close button, reducing accidental close clicks.

### Files Changed

- `client/src/components/TabBar.tsx` — Increased padding, text size, and close button size

---

## v5.1.3 — ActivityBar AI Icon Consistency (2026-04-30)

- **Unified AI icon across UI** — Replaced the star-shaped SVG icon in the Activity Bar with the same Sparkles icon from lucide-react that is used in the Header toolbar button. This ensures visual consistency for the AI sidebar toggle between both the header and the activity bar.

### Files Changed

- `client/src/components/ActivityBar.tsx` — Imported `Sparkles` from `lucide-react`, replaced star SVG with `<Sparkles size={20} />`

---

## v5.1.2 — AI Sidebar Show/Hide Toggle (2026-04-30)

- **AI Sidebar toggle in Header and Activity Bar** — Added a toggle button in the header (sparkles icon + "AI" label) and an AI star icon in the Activity Bar, both of which show/hide the right-side AI Chat panel. When visible, the header button highlights with a purple background; the Activity Bar icon shows an active state.
- **Persistent state** — The show/hide preference is saved to `localStorage` under the key `wbu-ai-sidebar` and restored on page reload, so the user's layout choice persists across sessions.

### Files Changed

- `client/src/App.tsx` — Added `showAISidebar` state (initialized from localStorage), `toggleAISidebar` handler, passed props to Header and ActivityBar, wrapped ChatPanel + resizer in conditional render
- `client/src/components/Header.tsx` — Added `showAISidebar` and `onToggleAISidebar` props, new AI toggle button with Sparkles icon and purple active-state styling
- `client/src/components/ActivityBar.tsx` — Added `onToggleAI` and `showAISidebar` props, new AI toggle icon button (star shape) above Settings

---

## v5.1.1 — Tag Insert to Info Panel + Dirty Save Glow (2026-04-30)

- **Tag + button now adds tags to Information Panel** — Clicking the + (plus) button in the tag toolbar dropdown now adds the selected tag to the file's tag associations (persisted server-side) in addition to inserting a tag banner into the margin editor. The Information Panel automatically refreshes its Tags section via a `wbu-tags-changed` custom event dispatched after the tag is added.
- **Save button glow for unsaved changes** — The Save button in the editor toolbar now displays a pulsing purple glow (matching the tag banner glow style) whenever the active tab has unsaved (dirty) changes. The glow is a CSS animation (`save-btn-pulse`) that alternates between two box-shadow intensities, providing clear visual feedback that the file needs saving. The glow disappears automatically after a successful save.

### Files Changed

- `client/src/components/TagInsertControl.tsx` — Added `currentPath` prop, imported `useFileTags` hook, changed `handleInsert` to call `addTags()` for server-side persistence, dispatch `wbu-tags-changed` event after adding tag
- `client/src/components/DocumentEditor.tsx` — Added `dirty` prop to interface, pass `currentPath` to `<TagInsertControl>`, apply `save-btn-dirty` CSS class on Save button when `dirty` is true
- `client/src/components/InformationPanel.tsx` — Already listens for `wbu-tags-changed` event and refreshes tag display via `refetch()`
- `client/src/App.tsx` — Compute `dirty` from active tab's `dirty` flag, pass it to `<DocumentEditor>`
- `client/src/styles/globals.css` — Added `.save-btn-dirty` class with purple glow and `@keyframes save-btn-pulse` animation

---

#
- **StarredFiles component** — Lists all starred/favorited files with document icons, file names, and hover-to-reveal remove buttons. Clicking a file opens it in the editor and switches the Activity Bar back to Explorer.
- **Empty state** — Friendly empty state with icon and hint text when no files are starred.
- **Activity Bar integration** — New `starred` activity type added to ActivityBar and App.tsx routing.

### Files Changed

- `client/src/components/StarredFiles.tsx` — **NEW** — Starred files list panel with empty state, file rows, and remove buttons
- `client/src/components/ActivityBar.tsx` — Added `starred` activity type with star icon
- `client/src/App.tsx` — Imported StarredFiles, added `starred` to ActivityType, wired StarredFiles component into left panel
- `client/src/styles/globals.css` — Added CSS for `.starred-files-panel`, `.starred-file-row`, `.starred-remove-btn`, empty state styles


## v5.1.0 — Visual Brand Identity (2026-04-30)

- **Orbitron font for WORBI logo** — The "WORBI" brand name now renders in Orbitron (Google Font), a futuristic, geometric typeface that gives the UI a sci-fi/world-building aesthetic
- **Trademark-style logo treatment** — "by Nymphs" sits on the same baseline as WORBI in small, dim text (10px), like a ® trademark mark
- **Header refinements** — Taller header (h-12), wider padding (px-5), reduced WORBI boldness (font-semibold instead of font-black), more spacing between elements
- **Welcome screen branding** — WORBI heading on the welcome screen now also uses Orbitron font for consistency
- **Branding documentation** — New `docs/BRANDING.md` documenting the visual identity system (typography, spacing, design principles)

### Files Changed

- `client/index.html` — Added Google Fonts Orbitron (weights 500, 600, 700)
- `client/src/components/Header.tsx` — Orbitron font on WORBI, `font-semibold`, `items-baseline` alignment, `ml-0.5` tight spacing for "by Nymphs", taller header with more padding
- `client/src/components/Welcome.tsx` — Orbitron font on WORBI heading
- `docs/BRANDING.md` — **NEW** — Brand identity documentation (typography, implementation, design principles)

---

## v5.0.0 — Rebrand to WORBI by Nymphs (2026-04-30)

- **Major rebrand from WBUI to "WORBI by Nymphs"** — The application has been rebranded to WORBI by Nymphs
- **Visual identity update** — Header and Welcome screen now display "WORBI" as the primary brand name with "by Nymphs" as a secondary byline
- **WorldBuilder UI retained as descriptor** — "WorldBuilder UI" remains as a subtitle/tagline to maintain continuity
- **Project moved to dedicated workspace** — Source copied from WBServer to Nymphs-Brain/WORBI for the new development cycle
- **GitHub-ready documentation** — README.md and CHANGELOG.md updated for public repository presentation

---

## v4.34 — Hero Image Picker Thumbnails (2026-04-30)

- **Fixed HeroImagePicker thumbnails not showing** — Image thumbnails in the Hero Image Picker modal appeared as generic file icons because `<img>` tags cannot send custom HTTP headers (required for JWT auth on `/api/files/workspace/*` routes). Fixed by fetching images with auth headers, converting to blob URLs via `URL.createObjectURL()`, and displaying those blob URLs in the thumbnail grid. Blob URLs are properly cleaned up on component unmount and folder navigation changes.

### Files Changed

- `client/src/components/HeroImagePicker.tsx` — Added `fetchImageBlobUrl()` helper, `blobUrls` state + `blobUrlsRef` for tracking, cleanup effect on unmount, and effect that fetches blob URLs for all image files when folder changes

---

## v4.33 — Margin Panel with Hero Image (2026-04-30)

- **Margin Panel** — New 3-section details panel above the margin editor: Hero Image, File Tags, and Relationships
- **Hero Image** — Clickable placeholder area to set a per-file hero image via URL prompt. Images persist in `localStorage` (key: `wbu_hero_images`), auto-load on file switch, and support hover-to-remove with overlay
- **Tag Banners in Margin Panel** — Active file tags displayed as interactive, color-coded banners with ✕ remove buttons, styled with black bg, bold yellow text, and glowy purple border
- **Tag Insert Toolbar Preview** — When selecting a tag in the TagInsertControl dropdown, a compact tag banner preview appears in the toolbar before insertion
- **Tag Insert into Margin Editor** — Tags are now inserted as styled `.tag-banner` elements into the margin (right) editor instead of the main editor

### Files Changed

- `client/src/components/MarginPanel.tsx` — **NEW** — 3-section panel (hero image, file tags, relationships placeholder) with localStorage persistence
- `client/src/components/DocumentEditor.tsx` — Integrated `MarginPanel` above margin editor
- `client/src/components/TagInsertControl.tsx` — Added toolbar tag banner preview, insert tags into margin editor, fixed tag dropdown visibility
- `client/src/styles/globals.css` — Added `.toolbar-tag-banner` styles, updated tag banner CSS
- `docs/MARGIN_PANEL_SYSTEM.md` — **NEW** — Documentation for the Margin Panel system

---

## v4.32 — Tag Insert in Editor (2026-04-30)

- **Tag Insert Control** — New inline control in the Main editor toolbar allowing quick insertion of tags as styled, color-coded badges directly into document content
- **TagInsertControl Component** — Dropdown select + insert button that renders a `<span class="tag-badge-inline">` at the cursor position using the tag's name and color
- **Inline Tag Badge Styling** — CSS for `.tag-badge-inline` with subtle background, border, and font-weight using `color-mix()` for automatic color adaptation

### Files Changed

- `client/src/components/TagInsertControl.tsx` — New component with tag dropdown and insert button
- `client/src/components/DocumentEditor.tsx` — Imported and wired TagInsertControl into Main toolbar
- `client/src/styles/globals.css` — Added `.tiptap .tag-badge-inline` styles

## v4.31 — Tag Management System (2026-04-30)

- **Tag Management System** — Full file tagging system for organizing and filtering workspace documents
- **Tag Registry** — Server-side tag service (`tagService.js`) with persistent JSON-based tag registry supporting create, update, delete, and query operations
- **Default Tags** — 8 built-in tags: `plot`, `character`, `worldbuilding`, `setting`, `theme`, `lore`, `important`, `draft`, `research`, `timeline`
- **Tag CRUD API** — Full REST endpoints: `GET/POST /api/tags`, `GET/PUT/DELETE /api/tags/:id`, `GET /api/tags/:id/files`
- **Tag-File Association** — Tags stored in `WBU_DATA/.wbi-meta.json` with auto-initialization on first access
- **TagManager UI** — Dedicated Tags panel accessible via Activity Bar with tag creation, editing, filtering, and file browsing
- **Activity Bar Integration** — New Tags icon (tag symbol) in Activity Bar alongside Explorer and Search
- **Tag Badges** — Color-coded tag badges in file explorer showing tags on each file row
- **Tag-based File Filtering** — Click any tag to filter and browse all files with that tag
- **File Tag Management** — Add/remove tags from active document directly in TagManager panel

### Files Changed

- `server/src/services/tagService.js` — New tag service with TagRegistry (CRUD, file associations, persistence)
- `server/src/routes/files.js` — Added 7 tag API route handlers
- `client/src/services/api.ts` — Extended with Tag types, `fetchTags`, `createTag`, `updateTag`, `deleteTag`, `fetchFilesByTag`, `addTagsToFile`, `removeTagFromFile`
- `client/src/hooks/useTags.ts` — New hook: `useTags()`, `useFileTags()`, `useTagQueries()`
- `client/src/components/TagManager.tsx` — New TagManager UI component
- `client/src/components/ActivityBar.tsx` — Added Tags activity type and icon
- `client/src/App.tsx` — Wired TagManager into layout with `tags` activity type
- `client/src/styles/globals.css` — Tag Manager CSS: badges, forms, lists, filters, explorer tag dots
- `docs/TAG_RELATIONSHIP_SYSTEM.md` — Design document with relationship taxonomy and implementation phases
- `docs/TAG_SYSTEM_ENHANCEMENT.md` — Implementation tracking document

---

## v4.30 — Heading Underlines (2026-04-30)

- **Subtle blue underlines on headings** — Headings (H1–H6) in the editor now display a blue underline that scales in thickness with the heading level. H1 gets the thickest line (3px) and H6 gets the thinnest (0.75px), using a subtle blue color (`rgba(96, 165, 250, 0.35)`). Purely CSS-based via `border-bottom` on heading elements.

### Files Changed

- `client/src/styles/globals.css` — Replaced generic heading color rule with individual H1–H6 rules that include scaling `border-bottom-width` for visual hierarchy.

---

## v4.29 — Batch Apply Spellcheck Marks (Visual Underlines Restored) (2026-04-30)

**Problem:** v4.28 fixed the lockup by removing DOM mark dispatching entirely, but this also removed the visual red underlines. Users only saw a count ("41 errors") with no indication of which words were wrong.

**Fix:** Apply all marks in a **single batch transaction** at the end:
1. Dictionary checks run on unique words only (with UI yields every 200 words) — main thread stays responsive
2. After identifying misspelled words, walk the document via `descendants()` to collect all `(from, to, word)` positions
3. Clear existing marks and add all new marks in one `dispatch()` call
4. Suggestions cached by word to avoid redundant dictionary calls

**Why This Doesn't Freeze:** The expensive work (dictionary checks) has UI yields and unique-word deduplication. The DOM update happens once at the end in a single transaction, which is instant.

**Changes:**
- `client/src/extensions/spellcheck.ts` — `runSpellcheck()` now applies marks in a single batch transaction.

## v4.28 — Spellcheck no longer freezes UI (2026-04-30)
- **Fixed spellcheck button lockup** — `runSpellcheck()` now checks only unique words instead of every token, avoiding redundant dictionary lookups. Added `await` yields every 200 unique words so the browser can render the "spellchecking" state before the work begins. Count is still accurate (unique check × frequency).

## v4.27 — User-initiated spellcheck (2026-04-30)
- **"Check Spelling" button** in the main toolbar (📝 icon) with status indicator
- **No keyboard shortcut** (avoids conflicts with browser shortcuts like Ctrl+Shift+N)
- **Error count display**: Shows number of misspelled words (amber) or "Clean" (green) after check
- Browser's native spellcheck (`spellcheck="true"`) still provides real-time red squiggles as a free bonus

All notable changes to WBUI (World Builder UI) are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

---

## [v4.25] - 2026-04-30

### Fixed

- **Spellcheck not detecting misspelled words** — The `typo-js` API was used incorrectly: `checkWord()` doesn't exist (typo-js uses `check(word)` returning `boolean`), and `suggest(word)` doesn't accept a limit parameter. Fixed `isMisspelled()` to use `!typoInstance.check(word)` and `getSuggestions()` to use `typoInstance.suggest(word, 5)`. Added `loaded` property guard to prevent calls before dictionary finishes loading. Updated TypeScript declarations with correct API signatures.

---

## [v4.24] - 2026-04-30

### Fixed

- **White screen on refresh** — The `spellchecker` npm package (GNU Aspell bindings via `node-ffi`) crashed in the browser because `node-ffi` is a Node.js-only library with native C bindings that cannot run in a browser environment. This caused a module resolution failure on every page load, resulting in a blank white screen. Replaced with `typo-js`, a pure JavaScript spellchecker using Hunspell-style dictionaries (.aff/.dic) that runs entirely in the browser with no native dependencies.

### Technical Details

- Dictionary files (`en_US.aff`, `en_US.dic`) copied to `client/public/dictionaries/en_US/` and served statically by Vite.
- `typo-js` instance is lazily loaded on first spellcheck operation via async `fetch()` of the dictionary files, so the initial page load is fast and spellcheck activates once the dictionary is ready.
- Synchronous word checking (`isMisspelled`, `getSuggestions`) returns early (false/empty) until the dictionary finishes loading, preventing race conditions.
- Removed `spellchecker` package from dependencies, replaced with `typo-js`.
- New `typo-js.d.ts` declaration with overloaded constructor signatures for TypeScript support.
- Removed old `spellchecker.d.ts` declaration (no longer needed).

### Files Changed

- `client/src/extensions/spellcheck.ts` — Rewritten: lazy-async dictionary loading, synchronous spell checking after init.
- `client/src/types/typo-js.d.ts` — **NEW** — TypeScript declarations for `typo-js` with constructor overloads.
- `client/src/types/spellchecker.d.ts` — **DELETED** — No longer needed after removing `spellchecker` package.
- `client/public/dictionaries/en_US/en_US.aff` — **NEW** — Hunspell affinity file (copied from `typo-js` package).
- `client/public/dictionaries/en_US/en_US.dic` — **NEW** — Hunspell dictionary file (~50K words).
- `client/package.json` — Replaced `spellchecker` with `typo-js` dependency.

---

## [v4.23] - 2026-04-30

### Added

- **JavaScript spellchecker library** — Browser-native `spellcheck="true"` failed in Chrome even with `lang="en"`, so replaced it with a custom ProseMirror-based spellchecker using the `spellchecker` npm package (GNU Aspell dictionary). Misspelled words are underlined with a red wavy underline in real-time as you type (debounced 400ms). Hovering a misspelled word shows a tooltip with up to 5 replacement suggestions — click a suggestion to replace the word. Works in both main and margin editors independently.

### Technical Details

- Custom TipTap `MisspelledMark` — a Mark type that wraps misspelled words with a `span.spellcheck-misspelled` element styled with red wavy underline.
- Custom TipTap `Spellcheck` extension — uses a ProseMirror `PluginView` with debounced `update` callback. On each document change, it walks all text nodes word-by-word, checks each word against the Aspell English dictionary, and applies/removes `misspelled` marks accordingly.
- Performance: skips documents over 50K characters, debounces at 400ms, only runs when editor has focus.

### Files Changed

- `client/src/extensions/spellcheck.ts` — New file: `MisspelledMark` (Mark) + `Spellcheck` (Extension with ProseMirror plugin).
- `client/src/components/DocumentEditor.tsx` — Added `MisspelledMark` and `Spellcheck` to both main and margin editor extension arrays.
- `client/src/styles/globals.css` — Added `.spellcheck-tooltip` and `.spellcheck-suggestion` CSS for the hover suggestion popup.
- `client/src/types/spellchecker.d.ts` — TypeScript declaration for the `spellchecker` npm package (untyped).
- `client/package.json` — Added `spellchecker` dependency.

---

## [v4.22] - 2026-04-30

### Fixed

- **Spellchecker not working in Chrome** — Chrome requires both `spellcheck="true"` AND a `lang` attribute on `contenteditable` elements to activate spellcheck. The `lang` attribute was missing, so Chrome silently disabled spellcheck. Added `lang: 'en'` to both main and margin editors. Also removed deprecated `-webkit-user-modify` and Firefox-only `::-moz-spelling-error-primary` CSS rules that do nothing in Chrome.

### Files Changed

- `client/src/components/DocumentEditor.tsx` — Added `lang: 'en'` to `editorProps.attributes` on both main and margin editors.
- `client/src/styles/globals.css` — Removed deprecated `-webkit-user-modify` and `::-moz-spelling-error-primary` CSS rules.

---

## [v4.21] - 2026-04-30

### Fixed

- **Cursor jumping to end of document** — Typing in the editor no longer jumps the cursor to the end. The content sync mechanism now distinguishes between user-initiated changes (typing) and external changes (file loads, blob URL conversion). User typing keeps the cursor position intact, while external content updates (like opening a new file or blob URL conversion for image auth) correctly sync to the editor.
- **Images not displaying after cursor fix** — Previous cursor fix broke image display by preventing blob URL content from reaching the editor. The new `isUserChangeRef` approach only skips sync when the user is actively typing, allowing blob URL conversions to propagate correctly.
- **Spellcheck underlines not visible** — Added `-webkit-user-modify: read-write` and `::-moz-spelling-error-primary` CSS to ensure browser-native spellcheck underlines render visibly on the dark theme.

### Files Changed

- `client/src/components/DocumentEditor.tsx` — Rewrote content sync `useEffect` with `isUserChangeRef` flag: user typing sets the flag in `onUpdate`, so the sync effect skips those changes; external changes (blob URL conversion) don't set the flag, so they sync normally.
- `client/src/styles/globals.css` — Added spellcheck visibility CSS rules.

---

## [v4.20] - 2026-04-30

### Added

- **Spell checker** — Browser-native spell checking is now enabled on both the main and margin TipTap editors. Misspelled words show a red squiggly underline, and right-clicking provides spelling suggestions from the browser's built-in dictionary. No additional dependencies required.

### Files Changed

- `client/src/components/DocumentEditor.tsx` — Added `spellcheck: 'true'` attribute to both `mainEditor` and `marginEditor` via `editorProps.attributes`

---

## [v4.19] - 2026-04-30

### Added

- **Welcome screen** — When no file tab is open, a new landing page displays with a "New File" button, recent files list (up to 10 with relative timestamps), and starred/favorites quick access. Clicking a recent or starred file opens it directly.
- **Starred files (Favorites)** — Files in the explorer now show a star icon on hover. Click it to add/remove from favorites. Starred files appear in a collapsible "Favorites" section at the top of the File Explorer for instant access from any folder.
- **Recent files tracking** — Every opened file is automatically tracked with a timestamp. Recents persist across sessions via `localStorage` and display relative time ("2 hours ago", "3 days ago", etc.).

### Files Changed

- `client/src/hooks/useRecents.ts` — NEW — Hook for recent files and starred files management with localStorage persistence
- `client/src/components/Welcome.tsx` — NEW — Welcome/landing screen with recent files, starred files, and "New File" action
- `client/src/components/FileExplorer.tsx` — Added collapsible Favorites section, star toggle button on file rows, `StarredFileRow` component
- `client/src/App.tsx` — Wired `useRecents` hook, shows `Welcome` when no tab is open, tracks recents on file open, passes star props to `FileExplorer`

---

## [v4.18] - 2026-04-30

### Fixed

- **Full-screen editor layout** — Editor was not filling the viewport. Added `height: 100vh` on both `body` and `#root` elements to force the app to occupy the full browser window.
- **File explorer text contrast** — Folder and file names were nearly invisible (dark text on dark background). Added explicit `text-gray-200` on file rows, `text-gray-400` on icons and empty/loading states, `text-gray-300` on the Explorer header, and `hover:text-white` for better hover feedback.
- **Breadcrumb current folder prominence** — The current folder name in the breadcrumb bar was too subtle. Made it `text-white font-semibold text-sm` (larger, bold, white) while keeping parent path segments as clickable `text-gray-300` links.
- **AI Chat panel header contrast** — "AI CHAT" label and Bot icon were hard to read. Changed from `text-muted-foreground` to `text-gray-300`.
- **Header toolbar button contrast** — File, Import, Undo, and Redo buttons were too dark. Changed from default text color to `text-gray-300` with `hover:text-white`.
- **Global muted text brightness** — Increased `--muted-foreground` CSS variable from `60%` to `72%` lightness, improving readability across all muted text (toolbar buttons, status bar, ActivityBar icons, search results).
- **Editor text color** — Ensured TipTap editor content remains white with explicit `color: #f5f5f5` on `.tiptap` and `color: inherit` on all child elements.
- **Draggable split divider** — Restored the movable divider between main and margin editor columns with proper `.editor-split-divider` CSS class.

### Files Changed

- `client/src/styles/globals.css` — Full-screen layout (`height: 100vh` on `body`/`#root`), brightened `--muted-foreground` from 60% to 72%, white text on `.tiptap`, `.editor-split-divider` styles
- `client/src/components/FileExplorer.tsx` — Explicit `text-gray-200` on container and file rows, `text-gray-300` on breadcrumb current folder, `text-gray-400` on icons/loading/empty states, `hover:text-white` on file rows
- `client/src/components/ChatPanel.tsx` — Brightened header to `text-gray-300` on label and Bot icon
- `client/src/components/Header.tsx` — Brightened File, Import, Undo, Redo buttons to `text-gray-300` with `hover:text-white`

---

## [v4.17] - 2026-04-30

### Added

- **VS Code-style Activity Bar** — Thin vertical icon bar on the far left (48px wide) with activity switching between Explorer and Search views, featuring active indicator bar on the left side of the selected icon.
- **Full-text workspace search** — Search across all text files in the workspace with debounced input (300ms). Results show file path + matching line, and double-clicking a result opens the file in the editor.
  - **Backend**: `searchWorkspace()` in `fileService.js` recursively scans the workspace directory, reads each text file line-by-line, and returns matches with file path and line content
  - **Backend**: New `GET /api/files/search?q=...` endpoint in `files.js`
  - **Frontend**: `searchFiles()` API method in `api.ts`
  - **Frontend**: `useSearch` hook with debounced auto-search on query change
  - **Frontend**: `ActivityBar` component with Explorer and Search icons
  - **Frontend**: `SearchPanel` component with search input, results list, loading/error/empty states
  - Switching to a search result automatically activates the Explorer activity so the file opens correctly

### Files Changed

- `server/src/services/fileService.js` — Added `searchWorkspace(query)` function that recursively walks the workspace, filters to text files (`.txt`, `.md`, `.html`, `.css`, `.js`, `.ts`, `.tsx`, `.json`, `.xml`, `.yaml`, `.yml`, `.toml`, `.log`, `.env`, `.sh`, `.py`, `.rb`, `.java`, `.c`, `.cpp`, `.h`, `.rs`, `.go`, `.php`, `.sql`, `.svg`), and returns matching lines
- `server/src/routes/files.js` — Added `GET /api/files/search` route with query parameter support
- `client/src/services/api.ts` — Added `searchFiles(query)` and `SearchResult` type
- `client/src/hooks/useSearch.ts` — **NEW** — Hook with debounced search (300ms), auto-search on query change, loading/error states
- `client/src/components/ActivityBar.tsx` — **NEW** — Thin left sidebar with Explorer/Search activity icons, active state indicator
- `client/src/components/SearchPanel.tsx` — **NEW** — Search input with debounce indicator, results list with file path + line preview, click-to-open
- `client/src/App.tsx` — Added ActivityBar before FileExplorer, conditional Explorer vs Search panel rendering, `activeActivity` state
- `client/src/styles/globals.css` — Added ActivityBar and SearchPanel CSS styles

---

## [v4.16] - 2026-04-30

### Added

- **File system undo/redo** — Destructive file operations (create file, create folder, delete, rename, copy, move) can now be undone and redone. Each operation captures the necessary state to reverse or re-apply the change, then refreshes the file explorer.
  - **Undo/Redo buttons** in the Header toolbar (Undo2/Redo2 icons from lucide-react), auto-disable when the respective stack is empty
  - **`useFileSystemUndoRedo` hook** with separate undo/redo stacks and a `refreshRef` pattern to avoid circular dependency with `useFiles`
  - **Wrapped operations in `useFiles`**: `newFile`, `newFolder`, `deleteSelected`, `renameSelected`, `copySelected`, `moveSelected`

### Files Changed

- `client/src/hooks/useFileSystemUndoRedo.ts` — **NEW** — Undo/redo hook with `push()`, `undo()`, `redo()`, `clear()`, and `refreshRef` for post-operation file list refresh
- `client/src/hooks/useFiles.ts` — Accept `pushUndo` callback; wrap each destructive operation with a `FsOperation` containing `undo()` and `redo()` functions
- `client/src/components/Header.tsx` — Added `onUndo`/`onRedo`/`canUndo`/`canRedo` props; render undo/redo buttons with disabled state styling
- `client/src/App.tsx` — Initialize `useFileSystemUndoRedo()` before `useFiles`; wire `refreshRef.current = () => loadFiles(explorerPath)` via `useEffect`; pass undo props to `Header`

---

## [v4.15] - 2026-04-30

### Fixed

- **External image URLs now display in the editor** — Previously, external image URLs (e.g., `https://i.imgur.com/abc123.jpg`) were skipped during the blob URL conversion process, so they appeared as broken images. Fixed by removing the external URL skip check in `convertServerUrlsToBlobUrls()`. External URLs are now fetched and converted to blob URLs for display, tracked in the blob URL map for save/reload cycles, and cleaned up on tab close. If an external URL cannot be fetched (e.g., CORS policy), it is left as-is in the HTML gracefully.

### Files Changed

- `client/src/App.tsx` — Removed external URL skip in `convertServerUrlsToBlobUrls()`

---

## [v4.14] - 2026-04-30

### Investigated

- **Blob URL map rebuild on reload** — Investigated rebuilding `blobUrlMapRef` automatically after page reload. Found that tabs are not persisted (stored in React state only, not localStorage), so the map has no tab data to scan on mount. Confirmed that the existing `openFileWithConversion()` flow already handles blob URL rebuild correctly when the user reopens files after a refresh. Added a documentation comment in `App.tsx` explaining this decision. Full blob URL rebuild on reload requires first implementing tab persistence.

---

## [v4.13] - 2026-04-30

### Fixed

- **Explorer now displays folders on initial page load** — The `loadFiles()` function was never called when the app mounted, so the `files` state remained at its initial empty array `[]`, causing the explorer to always show "Empty folder". Fixed by adding a `useEffect(() => { loadFiles('') }, [])` in `App.tsx` to load the root workspace directory on component mount.

### Files Changed

- `client/src/App.tsx` — Added mount-time `useEffect` to call `loadFiles('')`

---

## [v4.12] - 2026-04-30

### Added

- **DOCX Export** — New toolbar button in DocumentEditor exports current document as `.docx` with 2-column layout preserved as a table (70% main, 30% margin). Uses `docx` library with dynamic import. HTML headings, bold, italic, and paragraphs are converted to proper DOCX elements.
- **DOCX Import via Header** — New "Import" button in Header opens a file picker for `.docx` files. Converts DOCX → HTML via `mammoth.js` and opens the result in the editor.
- **DOCX upload detection** — Dragging/dropping `.docx` files into the FileExplorer now auto-imports them as HTML instead of uploading as binary.

### Files Changed

- `client/src/App.tsx` — Added `isDocxFile()`, `handleExportDOCX()`, `handleImportDOCX()`, `handleDocxFileSelected()`, DOCX detection in upload flow
- `client/src/components/DocumentEditor.tsx` — Added `onExportDOCX` prop, new DOCX export button with `FileSpreadsheet` icon
- `client/src/components/Header.tsx` — Added `onImportDOCX` prop, new "Import" button with `FileInput` icon

---

## [v4.11] - 2026-04-30

### Fixed

- **Runtime crash when opening files with images** — `renderHTML()` in the custom image extension crashed with `Cannot read properties of undefined (reading 'width')` because `attributes` could be `undefined` during content load. Fixed with null-safe access: `attributes?.width || HTMLAttributes?.['data-width'] || HTMLAttributes?.width`.

---

## [v4.10] - 2026-04-30

### Fixed

- **Image resize dimensions now persist correctly across tab switches and reloads** — The v4.9 `posAtDOM`-based approach failed for two reasons: (1) `$from.node(1)` returned the paragraph node (depth 1) instead of the inline image (depth 2), so the `type.name === 'image'` check always failed; (2) `$from.before(1)` targeted the wrong position for `setNodeAttribute`. Replaced the fragile DOM-to-state mapping with a robust tree walk: `view.state.doc.descendants()` finds the image node by matching `src` attribute, then `setNodeMarkup()` updates the width attribute reliably regardless of nesting depth.

---

## [v4.9] - 2026-04-30

### Fixed

- **Image resize dimensions now truly persist across tab switches and reloads** — The previous v4.8 approach only modified the DOM (`setAttribute('data-width', ...)`) without updating TipTap's internal ProseMirror state, so the width was lost whenever TipTap re-rendered from state (tab switch, content update, reload). Fully rewritten to properly integrate width into TipTap's state model:
  - Added `width` as a stored attribute via `addAttributes()`, with `parseHTML` reading from `data-width` in saved HTML
  - Custom `setImage` command in `addCommands()` that accepts a `width` option
  - Resize handler now finds the image node's position in the ProseMirror document and updates its `width` attribute via `setNodeAttribute()` transaction
  - `renderHTML()` outputs `data-width` on the `<img>` element and applies inline `style: width:Wpx` for immediate rendering

---

## [v4.8] - 2026-04-30

### Added

- **Persist resize dimensions across reloads** — Image resize changes now persist as `data-width` attribute on `<img>` elements. When resizing is complete, the final width (rounded to nearest pixel) is saved via `setAttribute('data-width', ...)`, and a transaction is dispatched so TipTap captures the change in its internal state. On render, `data-width` is read from `HTMLAttributes` and applied as the initial inline `style.width`, so images load at their correct resized dimensions even after page reloads or file save/load cycles.

---

## [v4.7] - 2026-04-30

### Added

- **Download as HTML button** — Fetches the current file from the server and triggers a browser download with the proper `.html` filename. Added as a download icon button in the Main toolbar next to Save.
- **Export as PDF button using html2pdf.js** — Renders the current editor content to a PDF file using `html2pdf.js` (which combines `html2canvas` + `jsPDF`). The two-column split delimiter (`<!-- MARGIN_SPLIT -->`) is replaced with a horizontal rule in the PDF output. PDF is exported in A4 portrait format. Added as a file-text icon button in the Main toolbar.

---

## [v4.6] - 2026-04-30

### Added

- **Auto-append `.html` extension on file create** — When creating a new file via the "New File" prompt, if the entered name has no file extension, `.html` is automatically appended. This targets the primary user base (story writers) who expect HTML documents by default. Files with an explicit extension (e.g., `notes.txt`) are preserved as-is.

---

## [v4.5] - 2026-04-30

### Added

- **Copy & Move file operations** — Full file copy and move support across the workspace:
  - Server-side: `copyFile()` and `moveFile()` in `fileService.js` using Node.js `fs.copyFile` and `fs.rename`
  - Server routes: `POST /copy-file` and `POST /move-file` in `files.js`
  - Client API: `copyFile()` and `moveFile()` in `api.ts`
  - Client hooks: `copySelected()` and `moveSelected()` in `useFiles` hook
  - UI: Copy and Move buttons in the FileExplorer context menu

---

## [v4.4] - 2026-04-29

### Fixed

- **Blob URLs now cleaned up when tabs are closed** — Blob URLs created for images (both from file loading and from image insertion) stayed in browser memory forever, only being cleaned up on full app unmount. Fixed by tracking which blob URLs belong to which tab via `tabBlobUrlsRef`, and revoking them when the tab is closed, closed via "Close Others", or "Close All". This prevents memory leaks when opening and closing many image-heavy files.

---

## [v4.3] - 2026-04-29

### Fixed

- **File uploads now respect the selected folder** — Files uploaded via the explorer upload button were always landing in the workspace root. The root cause was `req.body.folder` being read before multer parsed the FormData in the `/upload-file` route, so it was always `undefined`. Moved the `folder` read inside the multer callback where `req.body` is properly populated.

---

## [v4.2] - 2026-04-29

### Fixed

- **Images no longer turn into broken placeholders on save** — A React stale closure in `handleSave` caused `saveCurrentFile()` to read old tab content still containing blob URLs. Fixed by passing converted content directly to `saveCurrentFile()`, bypassing the stale closure.
- **Images now render immediately when opening any file** — `openFileWithConversion` used `activeTabId` from a `useCallback` closure, which was always the previous tab's ID. Fixed by having `openTab` return the tab ID along with content, so the correct tab is always updated.
- **Sequential URL conversion to prevent race conditions** — `convertServerUrlsToBlobUrls` processed images in parallel with `Promise.all()`, but all callbacks mutated the same result string. Changed to sequential `for...of` processing so each replacement operates on the updated string.
- **Eliminated fragile setTimeout-based content reading** — `openFileWithConversion` previously used `await setTimeout(50)` to wait for tab state to update. `openTab` now returns file content directly, removing reliance on React state flush timing.

---

## [v4.1] - 2026-04-29

### Changed

- **Images insert into margin editor** — Images clicked from the file explorer now insert into the margin (right) editor instead of the main (left) editor, making the margin column the designated area for images and references.

---

## [v4.0] - 2026-04-29

### Added

- **Two-column editor layout with draggable split divider** — The editor is now split into a main column (~66%) and a margin column (~34%), with a draggable divider allowing adjustment from 30/70 to 80/20.
- **Independent TipTap instances per column** — Each column has its own editor instance with independent toolbars and formatting controls.
- **Content parse/combine with delimiter** — Files are saved with a `<!-- MARGIN_SPLIT -->` delimiter separating main and margin content. Legacy files without the delimiter load entirely into the main column.

---

## [v3.1] - 2026-04-29

### Fixed

- **Blob URL persistence** — Blob URLs (`blob:http://...`) are ephemeral and only exist for the lifetime of the browser tab. On save, blob URLs in HTML content are now replaced with persistent server URLs. On file load, server URLs are fetched with auth headers and converted back to blob URLs for rendering. Images now survive page reloads and file save/load cycles.
- **Image sizing** — High-resolution images were rendering at full native dimensions, filling the viewport. Added `max-width: 600px` constraint so images render at a reasonable size.

---

## [v3.0] - 2026-04-29

### Added

- **Custom image resize extension** — Since `@tiptap/extension-resize-image` does not exist as an npm package, a custom `ImageResize` extension was created that extends the built-in `Image` extension with:
  - Custom `renderHTML()` wrapping each image in `<span class="image-wrapper">` with a resize drag handle
  - ProseMirror `mousedown` handler on the drag handle for mouse-driven resizing
  - Images can be resized by hovering to reveal the handle, then dragging left/right

---

## [v2.9] - 2026-04-29

### Fixed

- **Image auth on requests** — Images appeared as broken icons because HTML `<img>` tags cannot send custom HTTP headers (required for `Authorization: Bearer <token>` on all `/api/files/*` routes). Fixed by fetching images with auth headers first, converting to a Blob, creating a `blob:` URL, and inserting that into TipTap. Blob URLs are served by the browser itself, requiring no auth.

---

## [v2.8] - 2026-04-29

### Fixed

- **Images insert as rendered images, not Markdown text** — Previously, clicking an image in the explorer appended raw Markdown text `![name](path)` to the content string, which appeared literally since TipTap has no Markdown parser. Fixed by using TipTap's native `setImage()` command via a prop-based trigger system (`imageToInsert` + `onImageInserted`).

---

## [v2.7] - 2026-04-29

### Fixed

- **Initial image insertion** — Identified the original bug where clicking an image file in the explorer appended raw Markdown text instead of rendering an image in the editor.

---

## [UI Improvements] - 2026-04-29

### Added

- **Heading buttons** on Main and Margin toolbars
- **Save/Create File buttons** moved to Main toolbar for easier access

### Changed

- **Toolbar consolidation** — Removed upper toolbar; all formatting controls consolidated into bottom row per-column toolbars
- **AI status message** — Changed "LLM Disconnected" to "Ask a question to wake up AI" for clearer user guidance

### Fixed

- **Table button** — Fixed to use the correct editor instance for table insertion
- **Stale `isMain` reference** — Replaced with `showHeadings` to correctly reference the current toolbar state
- **Unused callbacks removed** — Cleaned up `insertTable`/`insertTableMargin` callback dead code

---

## Unreleased / Future Enhancements

- Proper file type system (text/html, markdown, etc.)
- Multi-handle resize support (corners + edges)
- Blob URL map rebuild on page reload
- DOCX export with better styling (fonts, margins, page breaks)
- DOCX import with image extraction (currently mammoth embeds images as base64)
