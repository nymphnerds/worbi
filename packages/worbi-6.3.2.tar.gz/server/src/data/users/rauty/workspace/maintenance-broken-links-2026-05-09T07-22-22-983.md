# Broken Image Links Report

Generated: 2026-05-09T07:22:22.993Z
Mode: Report only (not auto-fixed)

## Characters/Jim.html
- Broken image reference: /api/files/images/Screenshot%202026-02-04%20214934-1777457870613-416720368.png
- External URL cannot be verified: http://localhost:5173/api/files/workspace/Screenshot%20(6).png

